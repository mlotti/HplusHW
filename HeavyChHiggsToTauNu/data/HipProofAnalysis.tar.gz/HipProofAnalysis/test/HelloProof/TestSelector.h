//////////////////////////////////////////////////////////
// This class has been automatically generated on
// Sat Jan 12 14:06:42 2008 by ROOT version 5.17/09
// from TTree rootTree/events
// found on file: test_data/test.root
//////////////////////////////////////////////////////////

#ifndef TestSelector_h
#define TestSelector_h

#include <TROOT.h>
#include <TChain.h>
#include <TFile.h>
#include <TSelector.h>

#include <vector>
#include "MyGlobalPoint.h"
#include "MyJet.h"
#include "MyMET.h"
#include "MyMCParticle.h"
#include "MyAnalysis.h"

using namespace std;

class TestSelector : public TSelector {
public :
   TTree          *fChain;   //!pointer to the analyzed TTree or TChain

   // Histograms
   TH1F *myPionPt; // Pion Pt:

   // Declaration of leave types
   //   MyEvent         *myEvent;
   Int_t           eventNumber;
   MyGlobalPoint   primaryVertex;
   vector<MyJet>   L1objects;
   vector<MyJet>   HLTobjects;
   vector<MyJet>   electrons;
   vector<MyJet>   photons;
   vector<MyJet>   muons;
   vector<MyJet>   taujets;
   vector<MyJet>   pftaus;
   vector<MyJet>   jets;
   MyMET           MET;
   MyMET           mcMET;
   MyGlobalPoint   mcPrimaryVertex;
   vector<MyMCParticle> mcParticles;

   MyAnalysis *analysis;

   // List of branches
   //   TBranch        *b_MyEvent;
   TBranch        *b_MyEvent_eventNumber;   //!
   TBranch        *b_MyEvent_primaryVertex;   //!
   TBranch        *b_MyEvent_L1objects;   //!
   TBranch        *b_MyEvent_HLTobjects;   //!
   TBranch        *b_MyEvent_electrons;   //!
   TBranch        *b_MyEvent_photons;   //!
   TBranch        *b_MyEvent_muons;   //!
   TBranch        *b_MyEvent_taujets;   //!
   TBranch        *b_MyEvent_pftaus;   //!
   TBranch        *b_MyEvent_jets;   //!
   TBranch        *b_MyEvent_MET;   //!
   TBranch        *b_MyEvent_mcMET;   //!
   TBranch        *b_MyEvent_mcPrimaryVertex;   //!
   TBranch        *b_MyEvent_mcParticles;   //!

   TestSelector(TTree * /*tree*/ =0) { }
   virtual ~TestSelector() { }
   virtual Int_t   Version() const { return 2; }
   virtual void    Begin(TTree *tree);
   virtual void    SlaveBegin(TTree *tree);
   virtual void    Init(TTree *tree);
   virtual Bool_t  Notify();
   virtual Bool_t  Process(Long64_t entry);
   virtual Int_t   GetEntry(Long64_t entry, Int_t getall = 0) { return fChain ? fChain->GetTree()->GetEntry(entry, getall) : 0; }
   virtual void    SetOption(const char *option) { fOption = option; }
   virtual void    SetObject(TObject *obj) { fObject = obj; }
   virtual void    SetInputList(TList *input) { fInput = input; }
   virtual TList  *GetOutputList() const { return fOutput; }
   virtual void    SlaveTerminate();
   virtual void    Terminate();

   ClassDef(TestSelector,0);
};

#endif

#ifdef TestSelector_cxx
void TestSelector::Init(TTree *tree)
{
   // The Init() function is called when the selector needs to initialize
   // a new tree or chain. Typically here the branch addresses and branch
   // pointers of the tree will be set.
   // It is normaly not necessary to make changes to the generated
   // code, but the routine can be extended by the user if needed.
   // Init() will be called many times when running on PROOF
   // (once per file to be processed).

   // Set branch addresses and branch pointers
  cout <<"DEBUG::: " << __FILE__ << ":" << __LINE__ << " Starting TestSelector::Init" << endl;
   if (!tree) return;
   fChain = tree;
   fChain->SetMakeClass(1);

   //myEvent = new MyEvent();
   //   b_MyEvent = fChain->GetBranch("MyEvent");
   //   b_MyEvent->SetAddress(&myEvent);
   //   fChain->SetBranchAddress("MyEvent", &myEvent, &b_MyEvent);
   fChain->SetBranchAddress("eventNumber", &eventNumber, &b_MyEvent_eventNumber);
   fChain->SetBranchAddress("primaryVertex", &primaryVertex, &b_MyEvent_primaryVertex);
   fChain->SetBranchAddress("L1objects", &L1objects, &b_MyEvent_L1objects);
   fChain->SetBranchAddress("HLTobjects", &HLTobjects, &b_MyEvent_HLTobjects);
   fChain->SetBranchAddress("electrons", &electrons, &b_MyEvent_electrons);
   fChain->SetBranchAddress("photons", &photons, &b_MyEvent_photons);
   fChain->SetBranchAddress("muons", &muons, &b_MyEvent_muons);
   fChain->SetBranchAddress("taujets", &taujets, &b_MyEvent_taujets);
   fChain->SetBranchAddress("pftaus", &pftaus, &b_MyEvent_pftaus);
   fChain->SetBranchAddress("jets", &jets, &b_MyEvent_jets);
   fChain->SetBranchAddress("MET", &MET, &b_MyEvent_MET);
   fChain->SetBranchAddress("mcMET", &mcMET, &b_MyEvent_mcMET);
   fChain->SetBranchAddress("mcPrimaryVertex", &mcPrimaryVertex, &b_MyEvent_mcPrimaryVertex);
   fChain->SetBranchAddress("mcParticles", &mcParticles, &b_MyEvent_mcParticles);
   cout <<"DEBUG::: " << __FILE__ << ":" << __LINE__ << " Branch address set." << endl;
}

Bool_t TestSelector::Notify()
{
   // The Notify() function is called when a new file is opened. This
   // can be either for a new TTree in a TChain or when when a new TTree
   // is started when using PROOF. It is normaly not necessary to make changes
   // to the generated code, but the routine can be extended by the
   // user if needed. The return value is currently not used.

   return kTRUE;
}

#endif // #ifdef TestSelector_cxx
