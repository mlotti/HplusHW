void runInProof()
{
  TString dir(getenv("PWD"));
  cout <<"Running in directory " << dir << endl;

  cout <<"Opening PROOF session." << endl;
  TProof *proof = TProof::Open("");

  cout <<"Loading libraries." << endl;
  TString loadMyEventCommand("gSystem->Load(\"" + dir + "/libMyEvent.so\");");
  TString loadFrameworkCommand("gSystem->Load(\"" + dir + "/libFramework.so\");");
  TString loadSelectorCommand("gSystem->Load(\"" + dir + "/libTestSelector.so\");");
  proof->Exec("gSystem->Load(\"libNetx.so\");");
  proof->Exec("gSystem->Load(\"libMatrix.so\");");
  proof->Exec("gSystem->Load(\"libPhysics.so\");");
  proof->Exec("gSystem->Load(\"libProof.so\");");
  proof->Exec(loadMyEventCommand);
  proof->Exec(loadFrameworkCommand);
  proof->Exec(loadSelectorCommand);

  cout <<"Starting analysis." << endl;
  dataChain->SetProof(1);
  dataChain->Process("TestSelector");
  
  cout <<"PROOF analysis complete." << endl;

  TString proofOutputFile("proofOutput.root");
  cout <<"Writing PROOF output to file " << proofOutputFile << endl;
  TList *output = proof->GetOutputList();
  TListIter *iter = new TListIter(output);
  TFile *file = new TFile("proofOutput.root", "RECREATE");
  TObject *obj;
  do {
    obj = 0;
    obj = iter();
    if(obj != 0) {
      obj->Write();
    }
  } while(obj != 0);
  file->Close();
  cout <<"Done." << endl;
}

