#include "MyAnalysis.h"

MyAnalysis::MyAnalysis() {

}

MyAnalysis::MyAnalysis(MyInput input){
	init(input);
}
MyAnalysis::~MyAnalysis(){
	print();
	plotHistograms();
}

/////////////////////////////////////////////////////////////////////////////

void MyAnalysis::setDefaultCuts(){

    ////////////////////////////////////////////////////////////////////////
    // Defining default cuts
    ////////////////////////////////////////////////////////////////////////

}

/////////////////////////////////////////////////////////////////////////////

void MyAnalysis::bookHistograms(){

	histograms = new MyHistogram("histograms.root");
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////


void MyAnalysis::analyse(MyEvent* event){

  cout << "begin analysis .,. " << event->eventNumber << endl;
  eventCounter->addCount("all events");
  
  if(!histograms->booked("h_pionPt")) histograms->book("h_pionPt",100,0,20);
  
  vector<MyMCParticle> mcParticles = event->getMCParticles();
  for(vector<MyMCParticle>::const_iterator iMC = mcParticles.begin();
      iMC!= mcParticles.end(); iMC++){
    double pid = fabs(iMC->pid);
    if(pid != 211) continue; // selecting charged pions only
    
    double pt = iMC->Pt();
    histograms->fill("h_pionPt",pt);
  }
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void MyAnalysis::print(){

	eventCounter->print();

}

/////////////////////////////////////////////////////////////////////////////

void MyAnalysis::plotHistograms(){

        histograms->normalize(eventCounter);
        delete histograms; // saving
}
