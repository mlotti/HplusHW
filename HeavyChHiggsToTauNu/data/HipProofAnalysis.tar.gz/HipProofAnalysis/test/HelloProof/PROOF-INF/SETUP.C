{
	cout <<"PROOF analysis." << endl;
	gSystem->Load("libMatrix.so");
	gSystem->Load("libPhysics.so");
	gSystem->Load("libProof.so");
	gSystem->Load("libMyEvent.so");
	gSystem->Load("libFramework.so");
	gSystem->Load("libTestSelector.so");
	//	TFile *f = new TFile("test_data/test.root");
	//	TTree *rootTree = (TTree*) f->Get("rootTree");
	TChain *dataChain = new TChain("rootTree");
	//	dataChain->AddFile("http://www.cs.helsinki.fi/u/kaitanie/data/hipproof.root");
	dataChain->AddFile("http://localhost/data/test.root");
}
