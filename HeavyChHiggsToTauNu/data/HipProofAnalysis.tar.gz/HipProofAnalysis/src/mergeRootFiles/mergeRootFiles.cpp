// 17.10.2007/S.Lehti

#include <stdio.h>
#include <stdlib.h>
#include <iostream>   //IO library
#include <fstream>
#include <string>
#include <map>

#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TH1F.h"

#include "TFileMerger.h"

using namespace std;

void print_usage(char*);
char* newName(string,int);

int main(int argc, char *const *argv){

  char* rootInputFile[argc-1];
  char* outputFile = "merged.root";

  int iarg  = 1,
      iRoot = 0,
      maxNumberOfFiles = 10000000;
  while(iarg < argc){ 
    if(string(argv[iarg-1]) == "-o") {
      outputFile = argv[iarg];
    }else{
      if(string(argv[iarg-1]) == "-split") {
        maxNumberOfFiles = atoi(argv[iarg]);
      }else{
        string rootTest = string(argv[iarg]);
        if(rootTest.length() > 5 && rootTest != string(outputFile) &&
           rootTest.substr(rootTest.length()-4,4)=="root") 
           rootInputFile[iRoot++] = argv[iarg];
      }
    }
    iarg++;
  }

  // no root files given, print usage and stop
  if(iRoot == 0) print_usage(argv[0]);

  TFileMerger* fileMerger = NULL;

  cout << " merging files " << endl;
  int nFiles = 0;
  int nMerged = 0;
  for(int i = 0; i < iRoot; i++){
	cout << "file " << rootInputFile[i] << endl;
	if(fileMerger == NULL) fileMerger = new TFileMerger;
	fileMerger->AddFile(rootInputFile[i]);
	nFiles++;
	if(nFiles >= maxNumberOfFiles){
		nFiles = 0;
		char* newFileName = newName(string(outputFile),++nMerged);
		fileMerger->OutputFile(newFileName);
		fileMerger->Merge();
		delete fileMerger;
		fileMerger = NULL;
	}
  }
  if(nMerged > 0 && nFiles > 0){
	outputFile = newName(string(outputFile),++nMerged);
  }

  if(nFiles > 0){
  	fileMerger->OutputFile(outputFile);
  	fileMerger->Merge();
  }
}

char* newName(string name,int i){
	string outFileBody = name.substr(0,name.length() - 5);
	outFileBody += "_";

	return Form("%s%i%s",outFileBody.c_str(),i,".root");
}

void print_usage(char* executable){
	cout << "Usage: " << executable 
       	     << " file1 file2.. [-o outputfile][-split #files]" << endl;
	exit(0);
}


