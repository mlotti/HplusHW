#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::pftauElectronVeto(vector<const MyJet*> taus){
        vector<const MyJet*> selectedTaus;
    
        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){

		MyTrack leadingTrack = (*i)->leadingTrack();
		bool electronFound = false;
		vector<MyTrack>::const_iterator iTrackEnd = (*i)->tracks_end();
		for(vector<MyTrack>::const_iterator iTrack = (*i)->tracks_begin();
                                                    iTrack!= iTrackEnd; ++iTrack){
		        if(iTrack->Pt() < cuts->getCutValue("leadingTrackPtCut")) continue;
	                double DR = deltaR(leadingTrack.eta(),iTrack->eta(),  
                                           leadingTrack.phi(),iTrack->phi());
			//			cout << " pf track pt " << iTrack->Pt() << "id " <<  iTrack->pfType() << " DR " << DR << endl;

		        if(fabs(iTrack->pfType()) != 2) continue;

			if(DR > cuts->getCutValue("isolationCone")) continue;

			electronFound = true;
		}

                if( electronFound ) continue;
                eventCounter->addSubCount("tau pf electron rejection");
		selectedTaus.push_back(*i);
        }

	return selectedTaus;
}

