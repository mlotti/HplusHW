#include "MyAnalysis/interface/MyAnalysis.h"

double phifun(double,double);

bool MyAnalysis::metIsolation(MyEvent *event, MyJet& theTau, MyMET& met, double& dphiTauMet) {
        histograms->book("h_deltaphiMetJet",90,0,180);
        histograms->book("h_deltaphiMetTau",90,0,180);

        bool isolatedMet = true;  
        //double Met   = met.value();
	double metX   = met.getX();
	double metY   = met.getY();
	double phiMET = phifun(metX,metY);
	dphiTauMet = 180/3.14159*deltaPhi(theTau.phi(),phiMET);
        histograms->fill("h_deltaphiMetTau",dphiTauMet);

	string jetCalibration = "MCJetCorrectorMcone5";
	vector<MyJet> calibatedJets = event->getJets(jetCalibration);
        int nCalibratedJets= 0;   
        
        histograms->book("h_calibratedJetsEt",100,0,250);
        histograms->book("h_calibratedJetsEta",100,-5,5);
  
        for(vector<MyJet>::iterator iJet = calibatedJets.begin();
                                    iJet != calibatedJets.end(); iJet++){         
	        histograms->fill("h_calibratedJetsEt",iJet->Et());              
	        histograms->fill("h_calibratedJetsEta",iJet->Eta());
                double DR = deltaR(theTau.eta(),iJet->Eta(),
                                            theTau.phi(),iJet->Phi());
                if ( DR > 0.4  && iJet->Et() > 20 ) nCalibratedJets++;
                if ( DR < 0.4  ) continue;
                if ( iJet->Eta() < -theTau.eta() || iJet->Eta() > theTau.eta()) continue;
	        double dphiJetMet = 180/3.14159*deltaPhi(iJet->Phi(),phiMET);
                histograms->fill("h_deltaphiMetJet",dphiJetMet);
                if ( dphiJetMet < 20 ) isolatedMet = false;
		//                cout << " phi " <<  dphiJetMet << " frag " << isolatedMet << endl;
        }

	//         cout << " Tau phi " <<  dphiTauMet << " frag " << isolatedMet << endl;
        return isolatedMet;
}
