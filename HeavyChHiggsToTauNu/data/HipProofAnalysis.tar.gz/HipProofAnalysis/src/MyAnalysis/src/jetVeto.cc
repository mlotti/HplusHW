#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::jetVeto(MyEvent* event,vector<TauPair> taus){

	int nJets = 0;

	vector<MyJet> jets = event->getJets();

	vector<MyJet>::const_iterator iJet;
        for(iJet = jets.begin(); iJet != jets.end(); iJet++){
                if(!cuts->applyCut("jetEtaCut", fabs(iJet->eta()))) continue;
                if(!cuts->applyCut("jetEtCut", iJet->Et())) continue;
                if(iJet->getTracks().size() == 0) continue;

		bool tauJet = false;
		vector<TauPair>::const_iterator iTau;
		for(iTau = taus.begin(); iTau != taus.end(); iTau++){
			double eta = iTau->p4().Eta();
			double phi = iTau->p4().Phi();
			double DR = deltaR(eta,iJet->eta(),
                                           phi,iJet->phi());
			if(DR < 0.4) tauJet = true;
		}

		if(tauJet) continue;
		nJets++;

	}

        if(!histograms->booked("h_vetojets")) histograms->book("h_vetojets",10,0,10);
        histograms->fill("h_vetojets",nJets);


	if(nJets > 0) return false;
	return true;
}


