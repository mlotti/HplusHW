#include "MyAnalysis/interface/MyAnalysis.h"

vector<MyJet> MyAnalysis::recalculateTauEnergyUsingHardTauAlgorithm(MyEvent* event,string correction){
        if(hardTauAlreadyCorrected)
                return event->getTaujets();

	vector<MyJet> hardTaus;

	vector<MyJet> taus = event->getTaujets(correction);
	vector<MyJet>::const_iterator i;
	for(i = taus.begin(); i!= taus.end(); i++){
		TLorentzVector p4 = hardTauAlgorithm->recalculateEnergy(*i);

		if(p4.Et() == 0) continue;

		MyJet newTau = *i;
		newTau.setP4(p4);
		hardTaus.push_back(newTau);
	}
        hardTauAlreadyCorrected = true;
	return hardTaus;
}

