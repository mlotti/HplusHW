#include "MyAnalysis/interface/MyAnalysis.h"

void MyAnalysis::metResolutionAnalysis(MyMET met,MyMET mcMet){

	histograms->book("h_MET",100,0,500);
        histograms->fill("h_MET",met.value());

	histograms->book("h_mcMET",100,0,500);
        histograms->fill("h_mcMET",mcMet.value());

	double metResolution   = met.value() - mcMet.value();
	double metResolution_x = met.getX()  - mcMet.getX();
        double metResolution_y = met.getY()  - mcMet.getY();

	double metResolutionNor   = 999;
	if ( mcMet.value()> 0 ) metResolutionNor = (met.value() - mcMet.value())/mcMet.value();

        if ( mcMet.getX()> 0 ) {
		double metResolutionNor_x = (met.getX() - mcMet.getX())/mcMet.getX();
		histograms->book("h_METResolutionNor_x",100,-250,250);
	        histograms->fill("h_METResolutionNor_x",metResolutionNor_x);
	}
        if ( mcMet.getY()> 0 ) {
		double metResolutionNor_y = (met.getY() - mcMet.getY())/mcMet.getY();
                histograms->book("h_METResolutionNor_y",100,-250,250);
                histograms->fill("h_METResolutionNor_y",metResolutionNor_y);
	}

	histograms->book("h_METResolution",100,-100,250);
	histograms->fill("h_METResolution",metResolution);

        histograms->book("h_METResolution_x",100,-250,250);
        histograms->fill("h_METResolution_x",metResolution_x);

        histograms->clone("h_METResolution_y","h_METResolution_x");
        histograms->fill("h_METResolution_y",metResolution_y);


        if ( mcMet.value()==0 ) {
	    histograms->book("h_METResolution0",100,-100,250);
	    histograms->fill("h_METResolution0",metResolution);
        }

        if ( mcMet.value()> 0 && mcMet.value() < 50 ) {
	    histograms->book("h_METResolution050",100,-1,5);
	    histograms->fill("h_METResolution050",metResolutionNor);
        }
        if ( mcMet.value()> 50 && mcMet.value() < 100 ) {
	    histograms->book("h_METResolution50100",100,-1,5);
	    histograms->fill("h_METResolution50100",metResolutionNor);
        }
        if ( mcMet.value()> 100 ) {
	    histograms->book("h_METResolution100",100,-1,5);
	    histograms->fill("h_METResolution100",metResolutionNor);
        }
	histograms->book("h_METResoVsMCMET",100,0,250,100,-100,250);
	histograms->fill("h_METResoVsMCMET",mcMet.value(),metResolution);


}
