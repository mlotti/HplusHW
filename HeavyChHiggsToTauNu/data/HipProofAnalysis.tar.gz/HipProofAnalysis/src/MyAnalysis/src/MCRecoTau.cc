#include "MyAnalysis/interface/MCRecoTau.h"

#include <TMath.h>
#include <iostream>

double deltaR(double, double, double, double);

MCRecoTau::MCRecoTau(MyEvent* event, const MyJet* jet) {
  using namespace TMath;

  vector<const MyMCParticle*> myTaus;
  MyTrack myLdgTrack = jet->leadingTrack();
  
  vector<MyMCParticle>::const_iterator iMCEnd = event->mcParticles_end();
  for (vector<MyMCParticle>::const_iterator iMC = event->mcParticles_begin(); iMC != iMCEnd; ++iMC) {
    if (Abs(iMC->pid) == 15) myTaus.push_back(&(*iMC));
  }
  // Find best matching MC tau to the jet in terms of deltaR
  double myMatchValue = 9999;
  const MyMCParticle* myMatchedTau = 0;
  for (vector<const MyMCParticle*>::const_iterator iMC = myTaus.begin(); iMC != myTaus.end(); ++iMC) {
    double myDeltaR = deltaR((*iMC)->eta(), jet->eta(), (*iMC)->phi(), jet->phi());
    if (myDeltaR < myMatchValue) {
      myMatchValue = myDeltaR;
      myMatchedTau = *iMC;
    }
  }
  if (myMatchValue > 0.10) {
    fTauStatus = false;
    return;
  }
  fTauStatus = true;
  fTau = *myMatchedTau;
  
  fVisibleEnergy.SetXYZM(0,0,0,0);
  fInvisibleEnergy.SetXYZM(0,0,0,0);
  fChargedEnergy.SetXYZM(0,0,0,0);
  fEMEnergy.SetXYZM(0,0,0,0);
  fProngCount = 0;
  fPi0Count = 0;
  fGammaCount = 0;
  fContainsElectron = false;
  fContainsMuon = false;
  fContainsPi0 = false;
  fContainsGamma = false;
  fContainsPion = false;
  fContainsKaon = false;
  fContainsProton = false;
  fOriginZ = false;
  fOriginW = false;
  fOriginHplus = false;
  
  // tau has been matched to jet, now look at its ancestors and offspring
  double myMinMatch = 9999;
  int myMatchPid = 0;
  for (vector<MyMCParticle>::const_iterator iMC = event->mcParticles_begin(); iMC != iMCEnd; ++iMC) {
    // Find the offspring of the tau
    vector<int>::const_iterator iBarEnd = iMC->motherBarcodes_end();
    for (vector<int>::const_iterator iBar = iMC->motherBarcodes_begin(); iBar != iBarEnd; ++iBar) {
      if (*iBar == myMatchedTau->barcode) {
        int myAbsPid = Abs(iMC->pid);
        // Sum energy of stable offspring
        if (iMC->status == 1 && Abs(iMC->eta()) < 3.0) {
          switch (myAbsPid) {
          case 12: case 14: case 16: fInvisibleEnergy += *iMC; break; // neutrinos
          case 11: case 22: fEMEnergy += *iMC; break; // EM energy
          case 211: case 321: case 2212: fChargedEnergy += *iMC; break; // charged hadronic energy
          default: if (myAbsPid != 13) fVisibleEnergy += *iMC; break; // neutral hadronic energy
          }
          // Count prongs
          if (myAbsPid == 11 || myAbsPid == 211 || myAbsPid == 321) ++fProngCount;
          // Match leading track to a MC particle
          if (myAbsPid == 211 || myAbsPid == 321 || myAbsPid == 2212) {
            double dEta = iMC->Eta() - myLdgTrack.eta();
            double dPt = iMC->Perp() - myLdgTrack.pt();
            double myValue = dEta*dEta + dPt*dPt;
            if (myValue < myMinMatch) { 
              myMinMatch = myValue;
              myMatchPid = iMC->pid;
            }
          }
        }
        // Detect type of offspring
        switch (myAbsPid) {
        case 11: fContainsElectron = true; break;
        case 13: fContainsMuon = true; break;
        case 111: fContainsPi0 = true; ++fPi0Count; break;
        case 22: fContainsGamma = true; ++fGammaCount; break;
        case 211: fContainsPion = true; break;
        case 321: fContainsKaon = true; break;
        case 2212: fContainsProton = true; break;
        }
      }
    }
    // Find the ancestor of the tau
    iBarEnd = myMatchedTau->motherBarcodes_end();
    for (vector<int>::const_iterator iBar = myMatchedTau->motherBarcodes_begin(); iBar != iBarEnd; ++iBar) {
      if (iMC->barcode == *iBar) {
        int myAbsPid = Abs(iMC->pid);
        switch (myAbsPid) {
        case 23: fOriginZ = true; break;
        case 24: fOriginW = true; break;
        case 37: fOriginHplus = true; break;
        }
      }
    }
  }
  fLdgPid = myMatchPid;
  // Add the charged and neutral energy as the visible energy
  fVisibleEnergy += fChargedEnergy;
  
  // leading track MC matching ???
  
}


MCRecoTau::~MCRecoTau() {

}

void MCRecoTau::print() {
  using namespace std;
  
  if (isTau()) {
    cout << "Object is MC tau, eta=" << fTau.Eta() << ", phi=" << fTau.Phi() << " pt=" << fTau.Perp() << endl;
    if (originatesFromZ()) cout << "  originates from a Z decay" << endl;
    if (originatesFromW()) cout << "  originates from a W decay" << endl;
    if (originatesFromHplus()) cout << "  originates from a Hplus decay" << endl;
    if (decaysToHadrons()) cout << "  decays to hadron(s)" << endl;
    if (decaysToElectrons()) cout << "  decays to electron(s)" << endl;
    if (decaysToMuons()) cout << "  decays to muon(s)" << endl;
    if (decaysSemiLeptonically()) {
      cout << "  decays to";
      if (fContainsElectron) cout << " electron(s)";
      if (fContainsMuon) cout << " muon(s)";
      if (fContainsPion || fContainsKaon)  cout << " hadron(s)";
      cout << endl;
    }
    cout << "  pi0 count=" << fPi0Count << ", gamma count=" << fGammaCount << endl;
    cout << "  prong count=" << fProngCount << endl;
  } else {
    cout << "Object is not a MC tau" << endl;
  }
}

/*
void MCRecoTau::FindElectrons() {
  // Check this code

  vector<MyMCParticle>::const_iterator mcParticlesBegin = event->mcParticles_begin();
  vector<MyMCParticle>::const_iterator mcParticlesEnd   = event->mcParticles_end();
  vector<MyMCParticle> mcElectrons;
  mcElectrons.clear();
  MyMCParticle ElectronFromW(0,0,0,0);
  MyMCParticle ElectronFromTau(0,0,0,0);
  MyMCParticle ElectronFromWTau(0,0,0,0);
  int motherId = 24;
  for(vector<MyMCParticle>::const_iterator i = mcParticlesBegin; i!= mcParticlesEnd; i++){
    int id = i->pid;
    if(abs(id) != 11) continue;
    bool motherSelectionTau = false;
    bool motherSelectionW = false;
    bool motherSelectionHplus = false;
    vector<int>::const_iterator motherListBegin = i->mother_begin();
    vector<int>::const_iterator motherListEnd = i->mother_end();
    for(vector<int>::const_iterator iMother = motherListBegin;
                                    iMother != motherListEnd; ++iMother){
      if(abs(*iMother) == 24 ) motherSelectionW = true;
      if(abs(*iMother) == 15  ) motherSelectionTau = true;
      if(abs(*iMother) == 37  ) motherSelectionHplus = true;
    }
    if( motherSelectionW  && !motherSelectionTau )  ElectronFromW = *i;
    if( motherSelectionTau && motherSelectionHplus)  ElectronFromTau = *i;
    if( motherSelectionTau && motherSelectionW)  ElectronFromWTau = *i;
    mcElectrons.push_back(*i);
}

void MCRecoTau::Find
*/
