#include "MyAnalysis/interface/TauResolutionAnalysis.h"

#include "TLorentzVector.h"

#include <iostream>
using namespace std;

double deltaR(double,double,double,double);
double phiDis(double,double);
MyTrack leadingTrack(MyJet);

TauResolutionAnalysis::TauResolutionAnalysis(){
	histograms = new MyHistogram("resolution.root");
	init();
}

TauResolutionAnalysis::TauResolutionAnalysis(MyHistogram* histo){
	histograms = histo;
	init();
}

TauResolutionAnalysis::~TauResolutionAnalysis(){
	if(eventCounter > 0) print();
}

void TauResolutionAnalysis::init(){

        eventCounter                    = 0;
        mcHadronicTauCounter            = 0;
        mcVisibleTauCounter             = 0;
        mcTauPtCutCounter               = 0;
        caloTauCounter                  = 0;
        pfTauCounter                    = 0;
        caloTauWithLeadingTrackCounter  = 0;
        isolatedCaloTauCounter          = 0;
        pfTauWithLeadingTrackCounter    = 0;
        isolatedPfTauCounter            = 0;

	nAllTaus			= 0;
	nFakeTaus			= 0;
}

void TauResolutionAnalysis::print(){

        if(eventCounter > 0){
          cout << endl;
          cout << "TauResolutionAnalysis: "
               << eventCounter << " events analysed " << endl;
          cout << " mc visible taus       " << mcVisibleTauCounter << endl;
          cout << " mc hadronic taus      " << mcHadronicTauCounter << endl;
          cout << " mc tau pt cut         " << mcTauPtCutCounter << endl;
          cout << endl;
          cout << " calotaus in cone      " << caloTauCounter << endl;
          cout << " calotaus with ltrack  " << caloTauWithLeadingTrackCounter << endl;
          cout << " isolated calotaus     " << isolatedCaloTauCounter << endl;
          cout << endl;
          cout << " pftaus in cone        " << pfTauCounter << endl;
          cout << " pftaus with ltrack    " << pfTauWithLeadingTrackCounter << endl;
          cout << " isolated pftaus       " << isolatedPfTauCounter << endl;
          cout << endl;
        }

}

bool TauResolutionAnalysis::analyse(MyEvent* event,double ptcut, int motherId){

	bool select = false;

        eventCounter++;

	vector<MyMCParticle> visible_taus = ::visibleTaus(event,motherId);

	vector<MyMCParticle> tmpVisibleTaus;
	vector<MyMCParticle>::const_iterator i;
	for(i = visible_taus.begin(); i!= visible_taus.end(); i++){
		mcVisibleTauCounter++;

		int id = i->pid;
		if(abs(id) > 1510) continue; // drop leptonic taus
		mcHadronicTauCounter++;

		if(i->Pt() < ptcut) continue;
		mcTauPtCutCounter++;

		tmpVisibleTaus.push_back(*i);
	}
	visible_taus = tmpVisibleTaus;
        tmpVisibleTaus.clear();

	if(visible_taus.size() == 0) return false;
	select = true;



////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        double ptLeadingTrackMin   	= 20;

	vector<MyJet> caloTaus = event->getTaujets();
        vector<MyJet> pfTaus = event->getPFTaus();

	for(vector<MyMCParticle>::const_iterator i = visible_taus.begin();
                                                 i!= visible_taus.end(); i++){
		MyMCParticle visibleTau = *i;

		vector<MyJet>::const_iterator iTau;
		for(iTau = caloTaus.begin(); iTau != caloTaus.end(); iTau++){
			double DR = deltaR(iTau->eta(),visibleTau.Eta(),
                                           iTau->phi(),visibleTau.Phi());

                        if(DR > 0.4) continue;
                        caloTauCounter++;

                        MyTrack lTrack = leadingTrack(*iTau);
			if(lTrack.Pt() == 0) continue;
			caloTauWithLeadingTrackCounter++;			

			double d_trackIsolation = iTau->tag("d_trackIsolation");
			if(d_trackIsolation == 0) continue;
			if(lTrack.Pt() < ptLeadingTrackMin) continue; // in discriminator leading track ptcut 6 GeV used
			isolatedCaloTauCounter++;

			analyse(*iTau,visibleTau,"caloTau");
		}

                for(iTau = pfTaus.begin(); iTau != pfTaus.end(); iTau++){
			MyJet theTau = *iTau;
                        double DR = deltaR(theTau.eta(),visibleTau.Eta(),
                                           theTau.phi(),visibleTau.Phi());
                        if(DR > 0.4) continue;
                        pfTauCounter++;

                        MyTrack lTrack = leadingTrack(*iTau);
                        if(lTrack.Pt() == 0) continue;
                        pfTauWithLeadingTrackCounter++;

                        double d_trackIsolation = theTau.tag("d_trackIsolation");
                        if(d_trackIsolation == 0) continue;
                        if(lTrack.Pt() < ptLeadingTrackMin) continue;
                        isolatedPfTauCounter++;

                        analyse(theTau,visibleTau,"pfTau");


                        // pfjet energy from candidates in 0.4 around the jet axis
                        TLorentzVector newPFTau(0,0,0,0);

			vector<MyTrack> signalPFCands = iTau->getTracks();
			vector<MyTrack>::const_iterator iTrack;
			for(iTrack = signalPFCands.begin(); iTrack != signalPFCands.end(); iTrack++){
				double DR_trackTau = deltaR(iTau->eta(),iTrack->eta(),
                                                            iTau->phi(),iTrack->phi());
				if(DR_trackTau > 0.4) continue;
				newPFTau += iTrack->p4();
			}
			theTau.setP4(newPFTau);
			analyse(theTau,visibleTau,"pfcandTau");
                }
        }

	return select;
}

void TauResolutionAnalysis::analyse(const MyJet theTau,const MyMCParticle visibleTau,string label){

	nAllTaus++;
	if(visibleTau.Et() == 0){
		nFakeTaus++;
		return;
	}

	histograms->book("h_mcJetEt",100,0,500);
	histograms->fill("h_mcJetEt",visibleTau.Et());
	
	histograms->book("h_mcJetEta",100,-5,5);
	histograms->fill("h_mcJetEta",visibleTau.Eta());


        double dEt = (theTau.Et() - visibleTau.Et())/visibleTau.Et();
        string histoName = "h_" + label;

	histograms->book(histoName+"EnergyResolution",100,-1.2,1.2);
        histograms->fill(histoName+"EnergyResolution",dEt);

	double DR = deltaR(theTau.eta(),visibleTau.Eta(),
                           theTau.phi(),visibleTau.Phi());
	histograms->book(histoName+"DR",100,0,0.5);
        histograms->fill(histoName+"DR",DR);    

	histograms->book(histoName+"Deta",100,-1.,1.);  
	histograms->fill(histoName+"Deta",theTau.Eta()-visibleTau.Eta());

	histograms->book(histoName+"Dphi",100,-3,3);
        histograms->fill(histoName+"Dphi",phiDis(theTau.Phi(),visibleTau.Phi()));

	//  calo deposit
	TLorentzVector HcalCluster = theTau.hcalClusterMomentum(0.4); 
/*
	MyTrack leadingTrack = theTau.leadingTrack();
	MyGlobalPoint trackEcalHitPoint = leadingTrack.ecalHitPoint();
	TVector3 HcalCluster(0,0,0);
	vector<MyCaloTower> towers = theTau.getCaloInfo();
	for(vector<MyCaloTower>::const_iterator i = towers.begin();
                                                i!= towers.end(); i++){
		vector<TVector3> cells = i->HCALCells;
		for(vector<TVector3>::const_iterator j = cells.begin();
                                                     j!= cells.end(); j++){
			double DR = deltaR(leadingTrack.eta(),j->Eta(),
                                           trackEcalHitPoint.Phi(),j->Phi());
			if(DR <  0.4 ){
                              HcalCluster += *j;
			}
		}
	}
*/
	TLorentzVector tracksMomentum = theTau.combinedTracksMomentum(0.1);
	double etHcalOverTracks = (HcalCluster.Pt()-tracksMomentum.Pt())/tracksMomentum.Pt();
	histograms->book(histoName+"EtHcalOverTracks",100,-5,5);
	histograms->fill(histoName+"EtHcalOverTracks",etHcalOverTracks);
}

void TauResolutionAnalysis::chargedTrackCounter(MyEvent* event){

        int nPfTrack        = 0;
        int nPfTrackCaloTau = 0;
        int nCaloTauTrack   = 0;

        vector<MyMCParticle> visible_taus = ::visibleTaus(event,0);
        vector<MyMCParticle>::const_iterator i;
        for(i = visible_taus.begin(); i!= visible_taus.end(); i++){

                vector<MyJet>::const_iterator caloTauEnd = event->taujets_end();
                vector<MyJet>::const_iterator pfTauEnd   = event->pftaus_end();

                for(vector<MyJet>::const_iterator iPfTau = event->pftaus_begin();
                                                  iPfTau != pfTauEnd; ++iPfTau){
                    double DR_mcTau = deltaR(i->Eta(),iPfTau->Eta(),
                                             i->Phi(),iPfTau->Phi());
                    if(DR_mcTau > 0.4) continue;

                    for(vector<MyJet>::const_iterator iCaloTau = event->taujets_begin();
                                                  iCaloTau!= caloTauEnd; ++iCaloTau){
                        double DR = deltaR(iPfTau->Eta(),iCaloTau->Eta(),
                                           iPfTau->Phi(),iCaloTau->Phi());
                        if(DR < 0.4){
                                vector<MyTrack>::const_iterator pfTracksEnd = iPfTau->tracks_end();
                                for(vector<MyTrack>::const_iterator iTrack = iPfTau->tracks_begin();
                                                                    iTrack!= pfTracksEnd; ++iTrack){
                                        if(iTrack->pfType() != 1) continue;
                                        double DRPfTrackPfTau = deltaR(iTrack->Eta(),iPfTau->Eta(),
                                                                       iTrack->Phi(),iPfTau->Phi());
                                        if(DRPfTrackPfTau < 0.45) nPfTrack++;
                                        double DRPfTrackCaloTau = deltaR(iTrack->Eta(),iCaloTau->Eta(),
                                                                         iTrack->Phi(),iCaloTau->Phi());
                                        if(DRPfTrackCaloTau < 0.45) nPfTrackCaloTau++;
                                }
                                vector<MyTrack>::const_iterator caloTracksEnd = iCaloTau->tracks_end();
                                for(vector<MyTrack>::const_iterator iTrack = iCaloTau->tracks_begin();
                                                                    iTrack!= caloTracksEnd; ++iTrack){
                                        double DRCaloTrackCaloTau = deltaR(iTrack->Eta(),iCaloTau->Eta(),
                                                                           iTrack->Phi(),iCaloTau->Phi());
                                        if(DRCaloTrackCaloTau < 0.45) nCaloTauTrack++;
                                }
                        }
                    }
                }
        }

        if(nPfTrack == 0 && nCaloTauTrack == 0) return;

        histograms->book("h_ntracksPfTau",20,-0.5,19.5);
        histograms->clone("h_ntracksCaloTau","h_ntracksPfTau");
        histograms->clone("h_ntracksPfInCaloTauCone","h_ntracksPfTau");
        histograms->book("h_ntracksPfTauMinusCaloTau",21,-10.5,10.5);

        histograms->fill("h_ntracksPfTau",nPfTrack);
        histograms->fill("h_ntracksCaloTau",nCaloTauTrack);
        histograms->fill("h_ntracksPfInCaloTauCone",nPfTrackCaloTau);
        histograms->fill("h_ntracksPfTauMinusCaloTau",nPfTrack-nCaloTauTrack);

}

