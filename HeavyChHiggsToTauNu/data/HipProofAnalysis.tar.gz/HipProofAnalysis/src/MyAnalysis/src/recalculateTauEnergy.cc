#include "MyAnalysis/interface/MyAnalysis.h"

vector<MyJet> MyAnalysis::recalculateTauEnergy(vector<const MyJet*> taus){
        vector<MyJet> selectedTaus;

	vector<const MyJet*>::const_iterator i;
	for(i = taus.begin(); i!= taus.end(); ++i){
                MyJet newTau = **i;
	        TLorentzVector p4 = hardTauAlgorithm->recalculateEnergy(newTau);

	        if(p4.Et() == 0) continue;

		newTau.setP4(p4);
 
		selectedTaus.push_back(newTau);
	}
	return selectedTaus;
}
