#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::tauVeto(MyEvent* event,string tauType , MyJet theTau){
        vector<MyJet> taus;
	vector<MyJet>::const_iterator iTauBegin;
	vector<MyJet>::const_iterator iTauEnd;
	iTauBegin = event->taujets_begin();
	iTauEnd = event->taujets_end();
	if(tauType == "PFTau") {
	  iTauBegin = event->pftaus_begin();
	  iTauEnd = event->pftaus_end();
	}
	else if(tauType == "HardTau") {
	  taus = recalculateTauEnergyUsingHardTauAlgorithm(event);
	  iTauBegin = taus.begin();
	  iTauEnd = taus.end();
	}
        else if(tauType == "CaloTauCorrected") {
          //taus = caloTaus(event,"TauJet");
         
          // Yes, this is a bit ugly, but it was the easiest way to
          // get vector of non-pointers. This is essentially the same as caloTaus() does
          taus = event->getTaujets("TauJet");
	  iTauBegin = taus.begin();
	  iTauEnd = taus.end();
        }


	vector<MyMCParticle> visible_taus = ::visibleTaus(event,24);


        histograms->book("h_tauEt_veto",100,0,500);
        histograms->book("h_leadingTrackPt_veto",100,0,200);
        histograms->book("h_leadingTrackChi2_veto",100,0,20);
        histograms->book("h_leadingTrackHits_veto",20,0,20);
        histograms->book("h_leadingTrackIpz_veto",100,0,0.1);
        histograms->book("h_leadingTrackDipz_veto",100,0,20);
        histograms->book("h_leadingTrackIp2D_veto",100,0,0.1);
	histograms->book("h_etHcalOverTracks_veto",100,-1.5,2);
	histograms->book("h_etHcalOverTrack_veto",100,-1.5,2);
        histograms->book("h_etHcalOverTracks_vetoWenu",100,-1.5,2);
	histograms->book("h_etHcalOverTracks_vetoWtau",100,-1.5,2);
        histograms->book("h_etHcalOverTrack_vetoWtau",100,-1.5,2);
        histograms->book("h_etHcalOverTrack_vetoWenu",100,-1.5,2);
        histograms->book("h_etMcTauVeto",50,0,200);
        histograms->book("h_etaMcTauVeto",50,-2.5,2.5);
        histograms->book("h_etMcTauCandidateVeto",50,0,200);
        histograms->book("h_etMcTauTrackVeto",50,0,200);
        histograms->book("h_etMcTauIsolationVeto",50,0,200);
        histograms->book("h_etMcTauSelectedVeto",50,0,200);
        histograms->book("h_etaMcTauSelectedVeto",50,-2.5,2.5);
        histograms->book("h_EtSelectedVetoTau",50,0,200);
        histograms->book("h_EtMatchingVetoTau",50,0,200);
        histograms->book("h_etMcTauAfterVeto",50,0,200);
        histograms->book("h_etaMcTauAfterVeto",100,-2.5,2.5);
        histograms->book("h_etMcTauNeutrinoAfterVeto",100,0,200);
        histograms->book("h_etAfterVeto",100,0,200);
        histograms->book("h_leadingTrackPtAfterveto",100,0,200);

        histograms->book("h_ptMcTauFromW", 100, 0, 200);
        histograms->book("h_etaMcTauFromW", 100, -5, 5);
        histograms->book("h_ptMcTauFromWSelected", 100, 0, 200);
        histograms->book("h_etaMcTauFromWSelected", 100, -5, 5);

        histograms->book("h_ptVisibleTauFromW", 100, 0, 200);
        histograms->book("h_etaVisibleTauFromW", 100, -5, 5);
        histograms->book("h_ptVisibleTauFromWSelected", 100, 0, 200);
        histograms->book("h_etaVisibleTauFromWSelected", 100, -5, 5);


        TLorentzVector mcMuonFromW(0,0,0,0);
        TLorentzVector mcElectronFromW(0,0,0,0);
        vector<const MyMCParticle *> mcTausFromW;

        vector<MyMCParticle> mcParticles = event->mcParticles;
        for(vector<MyMCParticle>::iterator imc = mcParticles.begin();
	                               imc!= mcParticles.end(); imc++){
            int mother1 = 0;
            vector<int> motherList = imc->mother; 
            if(motherList.size() > 0) mother1 = (*motherList.begin());

            if(abs(mother1) == 24) {
	      //	   	      	      cout << " part form W " << imc->pid << endl;
	         if(abs(imc->pid) == 13 ) mcMuonFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());
	         if(abs(imc->pid) == 11 ) mcElectronFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P()); 
                 if(abs(imc->pid) == 15) {
                         histograms->fill("h_ptMcTauFromW", imc->Pt());
                         histograms->fill("h_etaMcTauFromW", imc->Eta());
                         mcTausFromW.push_back(&(*imc));
                 }
	    }
        }

        for(vector<MyMCParticle>::iterator imc = visible_taus.begin();
            imc != visible_taus.end(); ++imc) {
                histograms->fill("h_ptVisibleTauFromW", imc->Pt());
                histograms->fill("h_etaVisibleTauFromW", imc->Eta());
        }


	double PVz = event->getPrimaryVertex().getZ();

	vector<const MyJet*> selectedTaus;
        for(vector<MyJet>::const_iterator iJet = iTauBegin;
	    iJet != iTauEnd; ++iJet) {

                MyMCParticle visibleTau(0,0,0,0);
	        for(vector<MyMCParticle>::const_iterator i = visible_taus.begin();
                                                 i!= visible_taus.end(); i++){
		    double DR = deltaR(iJet->eta(),i->Eta(),
                                       iJet->phi(),i->Phi());
                        if(DR > 0.4) continue;
                        visibleTau = *i;
                }

		eventCounter->addSubCount("tauveto all tau cands");
                double DR = deltaR(iJet->eta(),theTau.eta(),
                                   iJet->phi(),theTau.phi());
                if(DR < 0.5) continue;

                eventCounter->addSubCount("tauveto hard tau removed");

		histograms->fill("h_tauEt_veto",iJet->Pt());
                //if(iJet->Pt() < cut["tauEtCutVeto"] ) continue;
                if(!cuts->applyCut("tauEtCutVeto", iJet->Pt())) continue;
		eventCounter->addSubCount("tauveto tau Et cut");

                if(!cuts->applyCut("tauEtaCutVeto", fabs(iJet->Eta()))) continue;
                eventCounter->addSubCount("tauveto tau Eta cut");

		MyTrack leadingTrack = iJet->leadingTrack(cuts->getCutValue("matchingConeVeto"));

                histograms->fill("h_leadingTrackPt_veto",leadingTrack.Pt());

                if(!cuts->applyCut("leadingTrackPtVeto", leadingTrack.Pt())) continue;
                eventCounter->addSubCount("tauveto leading track ");

		histograms->fill("h_leadingTrackChi2_veto",leadingTrack.normalizedChi2());
		histograms->fill("h_leadingTrackHits_veto",leadingTrack.numberOfValidHits());
		histograms->fill("h_leadingTrackIpz_veto",leadingTrack.impactParameter().impactParameterZ().value());
		histograms->fill("h_leadingTrackIp2D_veto",leadingTrack.impactParameter().impactParameter2D().value());
		double dipZ = fabs(leadingTrack.impactParameter().impactParameterZ().value() - PVz);
		histograms->fill("h_leadingTrackDipz_veto",dipZ);


		//bool isolated = isolation(&(*iJet),cuts->getCutValue("isolationConeVeto"),cuts->getCutValue("signalConeVeto"),cuts->getCutValue("isolationTrackPtVeto") );
		//bool isolated = vetoIsolationSum(&(*iJet),cuts->getCutValue("isolationConeVeto"),cuts->getCutValue("signalConeVeto"), 1);
                bool isolated = vetoIsolationTrackSum(&(*iJet), cuts->getCutValue("isolationConeVeto"), cuts->getCutValue("signalConeVeto"));
		if(!isolated) continue;
		eventCounter->addSubCount("tauveto isolation");

                isolated = vetoIsolationGammaSum(&(*iJet), cuts->getCutValue("isolationConeVeto"), cuts->getCutValue("signalConeVeto"));
		if(!isolated) continue;
		eventCounter->addSubCount("tauveto ecal isolation");

		//int nprongs = tauProngCounter(*iJet,cuts->getCutValue("signalConeVeto"),cuts->getCutValue("matchingConeVeto"));
                int nprongs = iJet->getTracksAroundLeadingTrack(cuts->getCutValue("signalCone"), cuts->getCutValue("matchingCone")).size();
		if(nprongs != 1 && nprongs != 3) continue;
		eventCounter->addSubCount("tauveto 1/3 prong");

                double chargeSum = 0;
                vector<MyTrack> tauTracks = iJet->tracks; 
	        for(vector<MyTrack>::iterator iTrack = tauTracks.begin();
                                              iTrack != tauTracks.end(); iTrack++){
                        if(iTrack->charge() == 0) continue;
                        double DR = deltaR(iJet->eta(),iTrack->eta(),iJet->phi(),iTrack->phi());
                        if( DR < cuts->getCutValue("signalConeVeto") )
                                chargeSum += iTrack->charge();
                }

                if( nprongs == 3 && fabs(chargeSum) != 1 ) continue;
		eventCounter->addSubCount("tauveto charge +-, 3p");

                if(tauType == "PFTau") {
                        histograms->book("h_neutralPFSumVeto",100,0,20);
                        histograms->book("h_neutralPFSumVetoTau",100,0,20);
		        bool neutralsFound = false;
                        double isolationNeutralSum = 0;
		        vector<MyTrack>::const_iterator iTrackEnd = iJet->tracks_end();
	         	for(vector<MyTrack>::const_iterator iTrack = iJet->tracks_begin();
                                                            iTrack!= iTrackEnd; ++iTrack){
                                //			      if(iTrack->Pt() < 2) continue;
                                if(fabs(iTrack->pfType()) != 5) continue;
                                double DR = deltaR(leadingTrack.eta(),iTrack->eta(),  
                                                   leadingTrack.phi(),iTrack->phi());
                                if(DR > cuts->getCutValue("isolationConeVeto")) continue;
                                neutralsFound = true;
                                isolationNeutralSum += iTrack->Pt();
                        }

			//	 	        if(neutralsFound) continue;
			//		        eventCounter->addCount("    PF neutral rej, veto");
                        histograms->fill("h_neutralPFSumVeto",isolationNeutralSum);
                        if (visibleTau.Pt() > 0 )
                                histograms->fill("h_neutralPFSumVetoTau",isolationNeutralSum);
                        //		        if(neutralsFound) continue;
                        if(isolationNeutralSum > 2 ) continue;
                        eventCounter->addSubCount("tauveto neutral hadron rej veto");
                        if (visibleTau.Pt() > 0 ){
                                eventCounter->addSubCount("tauveto purity:pfhadron rej ");
                        	histograms->fill("h_etMcTauSelectedVeto",visibleTau.Pt());
                        	histograms->fill("h_etaMcTauSelectedVeto",visibleTau.Eta());
			}
                }
                else {
		       TLorentzVector combinedTracks = iJet->combinedTracksMomentum(cuts->getCutValue("signalConeVeto"),cuts->getCutValue("matchingConeVeto"));
		       TLorentzVector hcalCluster_tracks = iJet->hcalClusterMomentum(cuts->getCutValue("isolationConeVeto"),cuts->getCutValue("matchingConeVeto"));
		       TLorentzVector hcalCluster_track = iJet->hcalClusterMomentum(0.15,cuts->getCutValue("matchingConeVeto"));
		       double etHcalOverTracks = (hcalCluster_tracks.Pt() - combinedTracks.Pt())/combinedTracks.Pt();
	 	       double etHcalOverTrack = (hcalCluster_track.Pt() - leadingTrack.Pt())/leadingTrack.Pt();
		       histograms->fill("h_etHcalOverTracks_veto",etHcalOverTracks);
		       histograms->fill("h_etHcalOverTrack_veto",etHcalOverTrack);
                       if(visibleTau.Pt() > 0 ) {
		            histograms->fill("h_etHcalOverTrack_vetoWtau",etHcalOverTrack);
		            histograms->fill("h_etHcalOverTracks_vetoWtau",etHcalOverTracks);
                       }
	               double DRtauWenu = 999;
                       if( mcElectronFromW.Et() > 0 ) {
                            DRtauWenu = deltaR(  mcElectronFromW.Eta(),iJet->Eta(),  mcElectronFromW.Phi(),iJet->Phi()); 
                            if( DRtauWenu < 0.2 )  {
                                histograms->fill("h_etHcalOverTracks_vetoWenu",etHcalOverTracks);
                            }		 
                       }
                        
                        if( etHcalOverTracks > cuts->getCutValue("etHcalOverTracksVeto") ) continue;
                        eventCounter->addSubCount("tauveto et hcal/tracks veto");

                }

                /*
		TLorentzVector combinedTracks = iJet->combinedTracksMomentum(cuts->getCutValue("signalConeVeto"),cuts->getCutValue("matchingConeVeto"));
		TLorentzVector hcalCluster_tracks = iJet->hcalClusterMomentum(cuts->getCutValue("isolationConeVeto"),cuts->getCutValue("matchingConeVeto"));
		TLorentzVector hcalCluster_track = iJet->hcalClusterMomentum(0.15,cuts->getCutValue("matchingConeVeto"));
		double etHcalOverTracks = (hcalCluster_tracks.Pt() - combinedTracks.Pt())/combinedTracks.Pt();
		double etHcalOverTrack = (hcalCluster_track.Pt() - leadingTrack.Pt())/leadingTrack.Pt();
		histograms->fill("h_etHcalOverTracks_veto",etHcalOverTracks);
		histograms->fill("h_etHcalOverTrack_veto",etHcalOverTrack);
                if(visibleTau.Pt() > 0 ) {
		     histograms->fill("h_etHcalOverTrack_vetoWtau",etHcalOverTrack);
		     histograms->fill("h_etHcalOverTracks_vetoWtau",etHcalOverTracks);
                }
	        double DRtauWenu = 999;
                if( mcElectronFromW.Et() > 0 ) {
                      DRtauWenu = deltaR(  mcElectronFromW.Eta(),iJet->Eta(),  mcElectronFromW.Phi(),iJet->Phi()); 
                      if( DRtauWenu < 0.2 )  {
                          histograms->fill("h_etHcalOverTracks_vetoWenu",etHcalOverTracks);
                      }		 
                }
                if(!cuts->applyCut("etHcalOverTracksVeto", etHcalOverTracks)) continue;
		eventCounter->addSubCount("tauveto et hcal/tracks veto");
                */

                if(visibleTau.Pt() > 0 ) eventCounter->addSubCount("tauveto real tau jet");
		selectedTaus.push_back(&(*iJet));
        }


        for(vector<const MyJet *>::const_iterator iTau = selectedTaus.begin(); iTau != selectedTaus.end(); ++iTau) {
                const MyJet *recoTau = *iTau;

                for(vector<const MyMCParticle *>::const_iterator imc = mcTausFromW.begin(); imc != mcTausFromW.end(); ++imc) {
                        const MyMCParticle *mcTau = *imc;

                        double DR = deltaR(recoTau->eta(), mcTau->Eta(),
                                           recoTau->phi(), mcTau->Phi());

                        if(DR < 0.4) {
                                histograms->fill("h_ptMcTauFromWSelected", mcTau->Pt());
                                histograms->fill("h_etaMcTauFromWSelected", mcTau->Eta());
                        }
                }

                for(vector<MyMCParticle>::const_iterator imc = visible_taus.begin(); imc != visible_taus.end(); ++imc) {
                        double DR = deltaR(recoTau->eta(), imc->Eta(),
                                           recoTau->phi(), imc->Phi());

                        if(DR < 0.4) {
                                histograms->fill("h_ptVisibleTauFromWSelected", imc->Pt());
                                histograms->fill("h_etaVisibleTauFromWSelected", imc->Eta());
                        }
                }
        }

	return selectedTaus;
}
