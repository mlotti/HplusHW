#include "TLorentzVector.h"

double mass3jets(TLorentzVector j1,TLorentzVector j2,TLorentzVector j3){
    double j3mass = -100;
    double j3mass2 = (j1.E()+j2.E()+j3.E())*(j1.E()+j2.E()+j3.E())
                   - (j1.Px()+j2.Px()+j3.Px())*(j1.Px()+j2.Px()+j3.Px())
                   - (j1.Py()+j2.Py()+j3.Py())*(j1.Py()+j2.Py()+j3.Py())
                   - (j1.Pz()+j2.Pz()+j3.Pz())*(j1.Pz()+j2.Pz()+j3.Pz());
  if(j3mass2 >= 0) j3mass = sqrt(j3mass2);
  return j3mass;
}
