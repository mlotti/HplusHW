#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::tauEnergyCorrectionSelection(MyEvent* event,string tauType){

        vector<const MyJet*> selectedTaus;
        if(tauType == "CaloTau") selectedTaus = caloTaus(event);
        else if(tauType == "CaloTauCorrected") selectedTaus = caloTaus(event,"TauJet");
        else if(tauType == "PFTau")   selectedTaus = pfTaus(event);
        else if(tauType == "HardTau") selectedTaus = hardTaus(event);
        else if(tauType == "HardTauCorrected") selectedTaus = hardTaus(event,"TauJet");
	return selectedTaus;
}

vector<const MyJet*> MyAnalysis::caloTaus(MyEvent* event, string correction){

        vector<const MyJet*> selectedTaus;

        if(correction != ""){
                vector<MyJet> taus = event->getTaujets(correction);
                event->taujets = taus;
        }

        vector<MyJet>::const_iterator iTauBegin = event->taujets_begin();
        vector<MyJet>::const_iterator iTauEnd = event->taujets_end();

        for(vector<MyJet>::const_iterator iJet = iTauBegin;
            iJet != iTauEnd; ++iJet){
                selectedTaus.push_back(&(*iJet));
        }
        return selectedTaus;
}


vector<const MyJet*> MyAnalysis::pfTaus(MyEvent* event){

        vector<const MyJet*> selectedTaus;

        vector<MyJet>::const_iterator iTauBegin = event->pftaus_begin();
        vector<MyJet>::const_iterator iTauEnd = event->pftaus_end();

        for(vector<MyJet>::const_iterator iJet = iTauBegin;
            iJet != iTauEnd; ++iJet){
                selectedTaus.push_back(&(*iJet));
        }
        return selectedTaus;
}

vector<const MyJet*> MyAnalysis::hardTaus(MyEvent* event, string correction){

        vector<const MyJet*> selectedTaus;

        vector<MyJet> taus = recalculateTauEnergyUsingHardTauAlgorithm(event,correction);
        event->taujets = taus;

        vector<MyJet>::const_iterator iTauBegin = event->taujets_begin();
        vector<MyJet>::const_iterator iTauEnd = event->taujets_end();

        for(vector<MyJet>::const_iterator iJet = iTauBegin;
            iJet != iTauEnd; ++iJet){
                selectedTaus.push_back(&(*iJet));
        }
        return selectedTaus;
}

vector<const MyJet*> MyAnalysis::hardTaus(MyEvent* event, vector<const MyJet*> inputtaus){

        vector<const MyJet*> selectedTaus;

        vector<MyJet> taus = recalculateTauEnergy(inputtaus);
        event->taujets = taus;

        vector<MyJet>::const_iterator iTauBegin = event->taujets_begin();
        vector<MyJet>::const_iterator iTauEnd = event->taujets_end();

        for(vector<MyJet>::const_iterator iJet = iTauBegin;
            iJet != iTauEnd; ++iJet){
                selectedTaus.push_back(&(*iJet));
        }
        return selectedTaus;
}

