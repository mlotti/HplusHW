#include "MyAnalysis/interface/MyAnalysis.h"
#include "MyAnalysis/interface/RecoTauJetCandidate.h"

vector<const MyJet*> MyAnalysis::tauSelection(MyEvent* event,string tauType){

	vector<const MyJet*> selectedTaus = tauEnergyCorrectionSelection(event,tauType);

	//double PVz = event->getPrimaryVertex().getZ();
	//selectedTaus = tauTest(selectedTaus,PVz,tauType);
        if (selectedTaus.size()) eventCounter->addCount("Passed E correction");

	/////////////////////////////////////////////////////////////////////////////////
        vector<MyMCParticle> visible_taus = ::visibleTaus(event,tauOriginFromLabel(eventCounter));

        // tau candidate resolution
        histograms->book("h_tauJetResolution",100,-0.8,0.8);
	histograms->book("h_etTaucsss",100,0,500);
	histograms->book("h_etaTaucsss",100,-5,5);
	histograms->book("h_etMcTau",100,0,400);
	histograms->book("h_etaMcTau",50,-2,2);
	vector<const MyJet*>::const_iterator i;
        for(i = selectedTaus.begin(); i!= selectedTaus.end(); ++i){
                MyMCParticle visibleTau(0,0,0,0);
                for(vector<MyMCParticle>::const_iterator itau = visible_taus.begin();
                                                 itau!= visible_taus.end(); itau++){
                    double DR = deltaR((*i)->eta(),itau->Eta(),
                                        (*i)->phi(),itau->Phi());
                        if(DR > 0.3) continue;
                        visibleTau = *itau;
                }

                //           int ntracks = (*i)->getTracksAroundLeadingTrack(cut["signalCone"],cut["matchingCone"$
                //             if( ntracks != 0 ) continue;
                //              cout << " tau id " << visibleTau.pid << endl;
                //             if( visibleTau.pid != 1501 && visibleTau.pid != 1502 ) continue;

             double dEt_flow = (*i)->Et() - visibleTau.Et();
             if(visibleTau.Et() > 0) {
                       histograms->fill("h_etTaucsss",(*i)->Et());
                       histograms->fill("h_etaTaucsss",(*i)->Eta());
                       histograms->fill("h_etMcTau",visibleTau.Et() );
                       histograms->fill("h_etaMcTau",visibleTau.Eta() );
                       histograms->fill("h_tauJetResolution",dEt_flow/visibleTau.Et() );
             }
        }
	/////////////////////////////////////////////////////////////////////////////////

        // tau identification
        vector<const MyJet*> selectionPassedTaus;
        int mySelectionPassCount = 0;
        int myPassedJetCount = 0;
        
        bool isPFTau = (tauType == "PFTau");
        
        vector<RecoTauJetCandidate*> myTauJetCandidates;
	vector<const MyJet*>::const_iterator iEnd = selectedTaus.end();
        vector<RecoTauJetCandidate*> myRecoCandidates;
        RecoTauJetCandidate* myBestCandidate = 0;
	for (vector<const MyJet*>::const_iterator iJet = selectedTaus.begin(); iJet != iEnd; ++iJet) {
          RecoTauJetCandidate* myTauCand = new RecoTauJetCandidate("TAUID", event, *iJet);
          myRecoCandidates.push_back(myTauCand);
          // do tau identification with default set of cuts
          bool jetPassed = myTauCand->doSelection(cuts, eventCounter, isPFTau);
          int passcount = myTauCand->getPassedSelectionCount();
          // if needed, add histogram plotting here (get value from myTauCand)
          
          if (tauIdAnalysis) tauIdAnalysis->analyze(myTauCand, cuts, jetPassed, event->event());
          if (jetPassed) {
            selectionPassedTaus.push_back(*iJet);  
            ++myPassedJetCount;
          }
          if (passcount > mySelectionPassCount) {
            mySelectionPassCount = passcount;
            myBestCandidate = myTauCand;
          }
        }
        if (myBestCandidate) myBestCandidate->updateCounters(eventCounter, myPassedJetCount); // update event counters
        if (tauIdAnalysis && myBestCandidate) tauIdAnalysis->updateCounter(myBestCandidate->getPassTable());
        
        // Delete RecoTauJetCandidate objects
        for (vector<RecoTauJetCandidate*>::const_iterator i = myRecoCandidates.begin(); i != myRecoCandidates.end(); ++i)
          delete (*i);
        myRecoCandidates.clear();
                
        return selectionPassedTaus;
        
        // pieces of old code, which is already contained in RecoTauJetCandidate
        /*
	selectedTaus = tauEtEtaCuts(selectedTaus);

        if(tauType == "PFTau") selectedTaus = pfChargedIsolation(selectedTaus,event->getPrimaryVertex().getZ());
        else                   selectedTaus = tauTrackerIsolation(selectedTaus,event->getPrimaryVertex().getZ());

	//if(tauType != "PFTau") selectedTaus = ecalFiducialCuts(selectedTaus);
        selectedTaus = tauEcalIsolation(selectedTaus,tauType);

	if(tauType == "PFTau") selectedTaus = pftauNeutralHadronVeto(selectedTaus);
        else                   selectedTaus = tauHcalJetRejection(selectedTaus);

        if(tauType == "PFTau") selectedTaus = pftauElectronVeto(selectedTaus);
        else                   selectedTaus = tauHcalElectronRejection(selectedTaus);

	selectedTaus = tauOneOrThreeProngSelection(selectedTaus,int(cuts->getCutValue("tauProngs")));
        */
        
}
