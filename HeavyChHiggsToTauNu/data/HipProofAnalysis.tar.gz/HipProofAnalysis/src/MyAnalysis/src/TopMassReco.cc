#include "MyAnalysis/interface/TopMassReco.h"
#include "MyAnalysis/interface/TopMassRecoPartons.h"

#include "TVectorT.h"
#include "TMatrixT.h"

typedef TMatrixT<double> TMatrixD;

//TopMassReco::TopMassReco(MyHistogram* histo,Counter* counter):
//        histograms(histo), eventCounter(counter), bTagDiscriminator(100), fitChi2Cut(1e9) {}
        //reader(0) {}

TopMassReco::TopMassReco(MyHistogram *histo, Counter *counter, Cuts *c):
        histograms(histo), eventCounter(counter), cuts(c) {}
        //reader(0) {}

TopMassReco::~TopMassReco(){}

void TopMassReco::analyse(const MyJet *tau, MyEvent *event, const char *algo_, HeavyChHiggsMCAnalysis *mcAnalysis){
        string algo(algo_);
        int algoNum = 0;
        if(algo == "simple")
                algoNum = kSimple;
        else if(algo == "an2006" || algo == "kinfit")
                algoNum = kKinfit;
        else {
                cout << "Top mass algorithm " << algo << " not recognised, valid algorithms are 1 ('simple'), 2 ('an2006' or 'kinfit')" << std::endl;
                exit(0);
        }
        analyse(tau, event, algoNum, mcAnalysis);
}

void TopMassReco::analyse(const MyJet *tau, MyEvent *event, int algo, HeavyChHiggsMCAnalysis *mcAnalysis){

        // MC analysis configuration
        const bool preSelectJets = true;
        const bool useBestBquark = true;
        const bool requireCompletePartonMatch = false;
        const bool bQuarkFromMC = false;
        const bool lightQuarksFromMC = false;
        const bool verifyJetsFromMC = false;

        const bool training = false;

        const int partonsToMatch = 3;

        // disable all MC info usage
        mcAnalysis=0;


        // clear containers etc.
        this->topmass = -9999;
        this->wmass = -9999;
        this->top_pt = -9999;
        this->theta_q_qbar = -9999;
        this->theta_w_b = -9999;
        this->fit_chi2 = 9999;
	jetcontainer.clear();
        forwardjetcontainer.clear();

	string jetCalibration = "MCJetCorrectorMcone5";
	vector<MyJet> jetCandidates = event->getJets(jetCalibration);

        // Jet-parton matching
        int matchedPartons = 0;
        if(mcAnalysis != 0) {
                matchedPartons = mcAnalysis->topJetPartonMatch(jetCandidates);
                if(requireCompletePartonMatch) {
                        if(matchedPartons != partonsToMatch) return;
                        eventCounter->addSubCount("topreco_events jet-parton matching");
                }
        }

        // Jet pre-selection, fills jetcontainer and forwardjetcontainer
        jetPreSelection(jetCandidates, jetCalibration, tau, !preSelectJets);

        // MVA training data acquisition, must be done BEFORE any
        // B-jet selections
        /*
        if(algo == "trainMVAcomb") {
                topMassCombTrainMVA(tau, true); // signal training
                //topMassCombTrainMVA(tau, false); // background training
                return false;
        }
        */

        // B-jet
        bestBjet = jetcontainer.end();
        secondbestBjet = jetcontainer.end();
        if(!findBestBjet(useBestBquark? kBestDiscriminator : kSecondBestDiscriminator, bQuarkFromMC))
                return;
        eventCounter->addSubCount("topreco_events best b jet found");

        // Book and fill b jet histograms
        histograms->book("h_bestBjetEt", 100, 0, 500);
        histograms->book("h_bestBjetEta", 100, -5, 5);
        histograms->book("h_bestDiscriminator", 100, 0, 20);
        histograms->book("h_secondbestBjetEt", 100, 0, 500);
        histograms->book("h_secondbestBjetEta", 100, -5, 5);
        histograms->book("h_secondbestDiscriminator", 100, 0, 20);

        histograms->fill("h_bestDiscriminator", bestBjet->tag("discriminator"));
        histograms->fill("h_bestBjetEt", bestBjet->Et());
        histograms->fill("h_bestBjetEta", bestBjet->Eta());
        if(secondbestBjet != jetcontainer.end()) {
                histograms->fill("h_secondbestBjetEt", secondbestBjet->Et());
                histograms->fill("h_secondbestBjetEta", secondbestBjet->Eta());
                histograms->fill("h_secondbestDiscriminator", secondbestBjet->tag("discriminator"));
        }

        // Other jets, excludes bjet
        vector<MyJet> otherJets;
        bestQ1jet = otherJets.end();
        bestQ2jet = otherJets.end();
        if(lightQuarksFromMC) {
                for(vector<MyJet>::const_iterator iJet = jetcontainer.begin();
                    iJet != jetcontainer.end(); ++iJet) {
                        if(iJet == bestBjet)
                                continue;
                        else if(iJet->type == TopMassRecoPartons::lightQuark ||
                                iJet->type == TopMassRecoPartons::lightQuarkBar)
                                otherJets.push_back(*iJet);
                }
        }
        else {
                
                for(vector<MyJet>::const_iterator iJet = jetcontainer.begin();
                    iJet!= jetcontainer.end(); ++iJet) {
                        if(iJet == bestBjet) continue;
                        otherJets.push_back(*iJet);
                }
        }

        bool topFound = false;
        switch(algo) {
        case kSimple:
                topFound = topMassRecoAlgo(*bestBjet, otherJets);
                break;
        case kKinfit:
                topFound = topMassRecoAlgo2(*bestBjet, otherJets);
                break;
        default:
                cout << "Top mass algorithm " << algo << " not recognised, valid algorithms are 1 ('simple'), 2 ('an2006' or 'kinfit')" << std::endl;
                exit(0);
        }
        if(!topFound) return;
        eventCounter->addSubCount("topreco_events top jets identified");
        
        if(verifyJetsFromMC && mcAnalysis != 0) {
                MCverify(mcAnalysis, topmass, matchedPartons);
        }

        computeVariables(0, *bestQ1jet, *bestQ2jet, *bestBjet);
        
        if(training) {
                histograms->setTreeVariable("mass_w", wmass);
                histograms->setTreeVariable("mass_top", topmass);
                histograms->setTreeVariable("fit_chi2", fit_chi2);
                histograms->setTreeVariable("theta_q_qbar", theta_q_qbar);
                histograms->setTreeVariable("theta_w_b", theta_w_b);
                histograms->setTreeVariable("bjet_pt", bestBjet->Pt());
                histograms->setTreeVariable("bjet_eta", bestBjet->Eta());
                histograms->setTreeVariable("bjet_discriminator", bestBjet->tag("discriminator"));
                histograms->setTreeVariable("top_pt", top_pt);
                histograms->setTreeVariable("top_eta", top_eta);
                histograms->fillTree();
        }

        // Book histograms
        histograms->book("h_topFitChi2", 100, 0, 20);
        histograms->book("h_topFitChi2norm", 100, 0, 10);
        histograms->book("h_topFitChi2Prob", 100, 0, 1);
        histograms->book("h_Wmass",100, 0, 200);
        histograms->book("h_topmass",100, 0, 500);
        histograms->book("h_topPt", 100, 0, 500);
        histograms->book("h_topThetaQQbar", 100, 0, 10);
        histograms->book("h_topThetaWb", 100, 0, 10);


        // Fill histograms
        histograms->fill("h_topFitChi2", fit_chi2); 
        histograms->fill("h_topFitChi2norm", fit_chi2/2);
        histograms->fill("h_topFitChi2Prob", TMath::Prob(fit_chi2, 2)); // ndof = 2
        histograms->fill("h_topPt", top_pt);
        histograms->fill("h_topThetaQQbar", theta_q_qbar);
        histograms->fill("h_topThetaWb", theta_w_b);
        histograms->fill("h_Wmass", wmass);
        histograms->fill("h_topmass", topmass);

        // Apply cuts and fill histograms
        //if(!cuts->applyCut("topFitChi2", fit_chi2)) return false;
        //eventCounter->addCount("topreco: kinematic fit chi2");

        //if(!cuts->applyCut("topPtCut", top_pt)) return false;
        //eventCounter->addCount("topreco: top pt cut");        

        //if(!cuts->applyCut("topThetaQQbar", theta_q_qbar)) return false;
        //eventCounter->addCount("topreco: theta(q, qbar) cut");

        //if(!cuts->applyCut("topThetaWb", theta_w_b)) return false;
        //eventCounter->addCount("topreco: theta(W, b) cut");
}

void TopMassReco::jetPreSelection(const vector<MyJet>& jets, string jetCalibration, const MyJet *tau, bool mcJetsOnly) {
        if(mcJetsOnly) {
                for(vector<MyJet>::const_iterator iJet = jets.begin();
                                                  iJet != jets.end(); ++iJet) {
                        if(iJet->type > 0)
                                jetcontainer.push_back(*iJet);
                }
        }
        else {
                histograms->book("h_rawJetsEt",100,0,500);
                histograms->book("h_calibratedJetsEta",100,-2.5,2.5);
                histograms->clone("h_calibratedJetsEt","h_rawJetsEt");

                for(vector<MyJet>::const_iterator iJet = jets.begin();
                                                  iJet!= jets.end(); ++iJet){
                
			eventCounter->addSubCount("topreco_jets all jets ");

                        if(tau != 0) {
                                double DR = deltaR(iJet->eta(),tau->eta(),
                                                   iJet->phi(),tau->phi());
                                if(DR < 0.4) continue;
                		eventCounter->addSubCount("topreco_jets taujet removed");
                        }

                        //if(iJet->Et()/iJet->getCorrectionFactor("MCJetCorrectorMcone5") < 10) continue;
                        //eventCounter->addSubCount("topreco_jets jet raw Et > 10");

                        histograms->fill("h_calibratedJetsEt",iJet->Et());
                        histograms->fill("h_calibratedJetsEta",iJet->Eta());
                        histograms->fill("h_rawJetsEt",iJet->Et()/iJet->getCorrectionFactor(jetCalibration));

                        if(!cuts->applyCut("jetEtCut", iJet->Et())) continue;
			eventCounter->addSubCount("topreco_jets jet Et cut ");

                        if(!cuts->applyCut("jetEtaCut", fabs(iJet->Eta()))) {
                                forwardjetcontainer.push_back(*iJet);
                                continue;
                        }
                	eventCounter->addSubCount("topreco_jets jet eta cut ");

                        jetcontainer.push_back(*iJet);
                }
        }
}

bool TopMassReco::findBestBjet(BjetAlgorithm algo, bool useMCinfo) {
        bestBjet = jetcontainer.end();
        secondbestBjet = jetcontainer.end();
        if(useMCinfo) {
                for(vector<MyJet>::const_iterator iJet = jetcontainer.begin();
                                                  iJet != jetcontainer.end(); ++iJet) {
                        switch(iJet->type) {
                        case TopMassRecoPartons::bQuark:
                                bestBjet = iJet;
                                break;
                        case TopMassRecoPartons::bQuarkNotFromTop:
                                secondbestBjet = iJet;
                                break;
                        }
                }

                if(algo == kSecondBestDiscriminator)
                        std::swap(bestBjet, secondbestBjet);

                if(bestBjet == jetcontainer.end())
                        return false;
        }
        else {
                // btagging
                histograms->book("h_jetDiscriminator",100,-10,20);
                double bestDiscriminator = -99999;
                for(vector<MyJet>::const_iterator iJet = jetcontainer.begin();
                                                  iJet!= jetcontainer.end(); ++iJet){
                        double discriminator = iJet->tag("discriminator");
                        histograms->fill("h_jetDiscriminator",discriminator);
                        if( discriminator > bestDiscriminator ) {
                                bestDiscriminator = discriminator;
                                bestBjet = iJet;
                        }
                }
                double secondbestDiscriminator = -99999;
                for(vector<MyJet>::const_iterator iJet = jetcontainer.begin();
                                                  iJet!= jetcontainer.end(); ++iJet){
                        double discriminator = iJet->tag("discriminator");
                        if( discriminator > secondbestDiscriminator && iJet != bestBjet ) {
                                secondbestDiscriminator = discriminator;
                                secondbestBjet = iJet;
                        }
                }
                if(algo == kSecondBestDiscriminator)
                        std::swap(bestBjet, secondbestBjet);

                if(bestBjet == jetcontainer.end()) {
                        return false;
                }
        }

        return true;
}

/**
 * @param mcAnalysis       Pointer to MC analysis object
 * @param topmass          Top mass from kinematic fit (if < 0, assumes that kinematic fit didn't find top)
 * @param matchedPartons   Number of matched partons
 */
void TopMassReco::MCverify(HeavyChHiggsMCAnalysis *mcAnalysis, double topmass, int matchedPartons) {
        /**
         * Bins:
         *      MC Info:
         *  1     Total number of events
         *  2     Total number of (true) t->Wb->qqb events
         *  3     Total number of other events
         *     Algorithm:
         *  4     Accepted events
         *  5     Accepted true events
         *  6     Accepted false events
         *  7       Recognised B-jet is from top
         *  8       Recognised B-jet is B-jet, but not from top
         *  9       Recognised B-jet is not B-jet at all
         * 10       Found 0 correct light quarks
         * 11       Found 1 correct light quark
         * 12       Found 2 correct light quarks
         * 13       Recognised B-jet is from top, and found both light quarks
         * 14     Rejected events
         * 15     Rejected true events
         * 16     Rejected false events
         *
         */
        histograms->book("h_topFitMC",16,1,17);
        histograms->fill("h_topFitMC", 1);

        bool trueEvent = (matchedPartons == 3);
        if(trueEvent) histograms->fill("h_topFitMC", 2);
        else          histograms->fill("h_topFitMC", 3);
                

        if(topmass > 0) {
                histograms->fill("h_topFitMC", 4);
                if(trueEvent) histograms->fill("h_topFitMC", 5);
                else          histograms->fill("h_topFitMC", 6);

                bool bCorrect = bestBjet->type == TopMassRecoPartons::bQuark;
                if(bCorrect)
                        histograms->fill("h_topFitMC", 7);
                else if(bestBjet->type == TopMassRecoPartons::bQuarkNotFromTop)
                        histograms->fill("h_topFitMC", 8);
                else
                        histograms->fill("h_topFitMC", 9);

                int quarks = 0;
                // NOTE: These two iterators are valid only
                // until the end of analyse() method
                if(bestQ1jet->type == TopMassRecoPartons::lightQuark ||
                   bestQ1jet->type == TopMassRecoPartons::lightQuarkBar)
                        ++quarks;
                if(bestQ2jet->type == TopMassRecoPartons::lightQuark ||
                   bestQ2jet->type == TopMassRecoPartons::lightQuarkBar)
                        ++quarks;
                histograms->fill("h_topFitMC", quarks+10);
                
                if(bCorrect && quarks == 2)
                        histograms->fill("h_topFitMC", 13);
        }
        else {
                histograms->fill("h_topFitMC", 14);
                if(trueEvent) histograms->fill("h_topFitMC", 15);
                else          histograms->fill("h_topFitMC", 16);
        }
        
        histograms->book("h_topFitMC_bpartons",10,0,10);
        histograms->book("h_topFitMC_matched",10,0,10);

        histograms->fill("h_topFitMC_bpartons", mcAnalysis->bquarks().size());
        histograms->fill("h_topFitMC_matched", matchedPartons);
}

/**
 * @return  Number of jets 
 */
int TopMassReco::njets(){
	histograms->book("h_njets",10,0,10);
	histograms->fill("h_njets",jetcontainer.size());

	return jetcontainer.size();
}

int TopMassReco::nforwardJets(){
        histograms->book("h_nforwardjets",10,0,10);
        histograms->fill("h_nforwardjets",forwardjetcontainer.size());

        return forwardjetcontainer.size();
}

/**
 * @return  Jet used as B-jet in top reconstruction
 */
MyJet TopMassReco::bestBJet(){
	return *bestBjet;
}
/**
 * @return  Second best jet for B-jet in top reconstructions
 */
MyJet TopMassReco::secondbestBJet(){
	return *secondbestBjet;
}

vector<MyJet> TopMassReco::jets(){
	return jetcontainer;
}

double TopMassReco::topMass(){
	return topmass;
}

double TopMassReco::topPt() {
        return top_pt;
}

double TopMassReco::WMass(){
        return wmass;
}

double TopMassReco::thetaQQbar() {
        return theta_q_qbar;
}

double TopMassReco::thetaWb() {
        return theta_w_b;
}

double TopMassReco::fitChi2() {
        return fit_chi2;
}

bool TopMassReco::twoBtagging(double discriminatorCut){
        if(bJetCounter(discriminatorCut) >= 2) return true;
        return false;
}

bool TopMassReco::bJetVeto(double discriminatorCut){
        if(bJetCounter(discriminatorCut) == 0) return true;
        return false;
}

int TopMassReco::bJetCounter(double discriminatorCut){
        int bjetCounter = 0;
        for(vector<MyJet>::const_iterator iJet = jetcontainer.begin();
                                          iJet!= jetcontainer.end(); ++iJet){
                double discriminator = iJet->tag("discriminator");
                if( discriminator > discriminatorCut) ++bjetCounter;
        }
        return bjetCounter;
}

/**
 * Simple mass fit. Selects the combination of jets with least Chi^2
 * as top.
 *
 * @param    bjet  Identified B-jet
 * @param    jets  Collection of jets to be used as light quarks
 *
 * @return   top mass (if < 0, no top found)
 */
bool TopMassReco::topMassRecoAlgo(const MyJet& bjet, const vector<MyJet>& jets){
        // Chi2 algorithm

        double chiMin         = 100000;

        double massW          = -100;
        double massTop        = -100;

        double nominalWmass   = 81;
        double sigmaWmass     = 20;
        double nominalTopmass = 175;
        double sigmaTopmass   = 30;
        //        double wmassWindow    = 20;
        bool minimumFound = false;

	for(vector<MyJet>::const_iterator iJet1 = jets.begin();
                                          iJet1!= jets.end(); ++iJet1){
		for(vector<MyJet>::const_iterator iJet2 = iJet1;
                                                          iJet2 != jets.end(); ++iJet2){
			if(iJet2 == iJet1) continue;

			double jjMass = mass2jets(iJet1->p4(),iJet2->p4());
			//if( fabs(jjMass-nominalWmass) > wmassWindow ) continue;

			double jjjMass = mass3jets(iJet1->p4(),iJet2->p4(),bjet.p4());
			double chi2 = ((jjMass-nominalWmass)/sigmaWmass)*
                                      ((jjMass-nominalWmass)/sigmaWmass)+
                                      ((jjjMass-nominalTopmass)/sigmaTopmass)*
                                      ((jjjMass-nominalTopmass)/sigmaTopmass);

                        if(chi2 < chiMin){
                                chiMin  = chi2;
                                massTop = jjjMass;
                                massW   = jjMass;
                                bestQ1jet = iJet1;
                                bestQ2jet = iJet2;
                                minimumFound = true;
                        }
		}
	}

        if(!minimumFound) return false;

        fit_chi2 = chiMin;
	wmass = massW;
        topmass = massTop;

	return true;
}


/**
 * Algorithm from CMS AN 2006/29
 */
TMatrixD computeF(TLorentzVector jet1, TLorentzVector jet2, TLorentzVector jet3,
                  double Wmass, double Topmass, TMatrixD *c) {

  TMatrixD vec(2,1);

  TLorentzVector psum = jet1+jet2;
  double jjMass2;
  if(c == 0) {
    jjMass2 = psum.M2(); // M2() == invariant mass^2
  }
  else {
    TMatrixD& cc(*c);
    double jet1E = jet1.E()+ cc(0,0);
    double jet2E = jet2.E()+ cc(1,0);
    jjMass2 = psum.M2() - psum.E()*psum.E() + (jet1E+jet2E)*(jet1E+jet2E);
    Wmass += cc(3,0);
  }
  vec(0,0) = 0.5*(Wmass*Wmass - jjMass2);

  psum += jet3;
  double jjjMass2;
  if(c == 0) {
    jjjMass2 = psum.M2(); // M2() == invariant mass^2
  }
  else {
    TMatrixD& cc(*c);
    double jet1E = jet1.E()+ cc(0,0);
    double jet2E = jet2.E()+ cc(1,0);
    double jet3E = jet3.E()+ cc(2,0);
    jjjMass2 = psum.M2() - psum.E()*psum.E() + (jet1E+jet2E+jet3E)*(jet1E+jet2E+jet3E);
    Topmass += cc(4,0);
  }
  vec(1,0) = 0.5*(Topmass*Topmass - jjjMass2);

  return vec;
}

TMatrixD computeD(double jet1E, double jet2E, double jet3E, double Wmass, double Tmass) {
  TMatrixD ret(2, 5);

  double sum2 = -(jet1E+jet2E);
  double sum3 = -(jet1E+jet2E+jet3E);
  ret(0,0) = sum2; ret(0,1) = sum2; ret(0,2) = 0;    ret(0,3) = Wmass; ret(0,4) = 0;  
  ret(1,0) = sum3; ret(1,1) = sum3; ret(1,2) = sum3; ret(1,3) = 0;     ret(1,4) = Tmass;

  return ret;
}

/**
 * This computes the variance of the jet energy (i.e. the resolution
 * of energy measurement). The "algorithm" is from CMS NOTE 2005/036
 * with the assumption that E^{rec} = E^{MC}.
 */
double sigma2Jet(double jetE) {
  double x1 = 5.6;
  double x2 = 1.25*sqrt(jetE);
  double x3 = 0.033*jetE;
  return x1*x1 + x2*x2 + x3*x3;
}

double kinematicFit(TLorentzVector jet1, TLorentzVector jet2, TLorentzVector bjet,
                    double& Wmass, double& Tmass,
                    double& WmassFit, double& TmassFit) {
  double nominalWmass   = 81;
  double sigmaWmass     = 20;
  double nominalTopmass = 175;
  double sigmaTopmass   = 30;

  // These are from the paper
  double cutC = 0.01;
  double cutF = 0.1; // GeV
  int nItr = 10;
  int nStep = 25;

  // Compute measured masses
  Wmass = (jet1+jet2).M();
  Tmass = (jet1+jet2+bjet).M();

  // Iteration
  TMatrixD invG(5,5); // G^-1
  invG(0,0) = sigma2Jet(jet1.E());
  invG(1,1) = sigma2Jet(jet1.E());
  invG(2,2) = sigma2Jet(jet1.E());
  invG(3,3) = sigmaWmass*sigmaWmass;
  invG(4,4) = sigmaTopmass*sigmaWmass;


  // n=0
  TMatrixD D_curr(computeD(jet1.E(), jet2.E(), bjet.E(), nominalWmass, nominalTopmass)); // D
  TMatrixD F_curr(computeF(jet1, jet2, bjet, nominalWmass, nominalTopmass, 0)); // F
  TMatrixD R_curr(F_curr);                                                      // R
  TMatrixD GDt_curr(invG, TMatrixD::kMultTranspose, D_curr);                    // G^-1 D^T
  TMatrixD A_curr(D_curr, TMatrixD::kMult, GDt_curr);                           // A^-1=D G^-1 D^T
  A_curr.Invert();
  TMatrixD lambda_next(A_curr*R_curr);                                          // lambda=AR
  TMatrixD c_curr(GDt_curr, TMatrixD::kMult, lambda_next);                      // C=-(G^-1 D^T)lambda
  c_curr *= -1;

  TMatrixD chi2m(R_curr, TMatrixD::kTransposeMult, TMatrixD(A_curr, TMatrixD::kMult, R_curr));
  if(chi2m.GetNrows() != 1 || chi2m.GetNcols() != 1) {
    std::cout << "chi2m dim is " << chi2m.GetNrows() << "x" << chi2m.GetNcols() << "!" << std::endl;
  }

  double chi2 = chi2m(0,0);
  
  double F_prev = F_curr.Norm1();
  TMatrixD c_prev(c_curr); c_prev*=0;
  bool foundMinimum = false;
  for(int n=1; n <= nItr; ++n) {
    //std::cout << "Iteration " << n-1 << " chi2 " << chi2 << " F_curr " << F_prev << std::endl;
    D_curr = computeD(jet1.E()+c_curr(0,0), jet2.E()+c_curr(1,0), bjet.E()+c_curr(2,0),
                      nominalWmass+c_curr(3,0), nominalTopmass+c_curr(4,0));

    //F_curr = computeF(jet1, jet2, bjet, nominalWmass, nominalTopmass, &c_curr);
    F_curr = computeF(jet1, jet2, bjet, nominalWmass+c_curr(3,0), nominalTopmass+c_curr(4,0), &c_curr);
    if(F_curr.Norm1() >= cutF) {
      TMatrixD diff(c_curr, TMatrixD::kMinus, c_prev);
      while(F_curr.Norm1() > F_prev && nStep > 0) {
        --nStep;
        diff*=0.5;
        c_curr = c_prev+diff;
        //F_curr = computeF(jet1, jet2, bjet, nominalWmass, nominalTopmass, &c_curr);
        F_curr = computeF(jet1, jet2, bjet, nominalWmass+c_curr(3,0), nominalTopmass+c_curr(4,0), &c_curr);
      }
    }
    F_prev = F_curr.Norm1();

    R_curr = F_curr - D_curr*c_curr;
    GDt_curr = TMatrixD(invG, TMatrixD::kMultTranspose, D_curr);
    A_curr = D_curr*GDt_curr;
    A_curr.Invert();
    lambda_next = A_curr*R_curr;

    c_prev = c_curr;
    c_curr = GDt_curr*lambda_next; // c(n+1)
    c_curr*=-1;

    double chi2_prev = chi2;
    chi2m = TMatrixD(R_curr, TMatrixD::kTransposeMult, TMatrixD(A_curr, TMatrixD::kMult, R_curr));
    chi2 = chi2m(0,0);

    if(fabs(chi2-chi2_prev) < cutC &&
       F_curr.Norm1() < cutF) {
      foundMinimum = true;
      break;
    }


  }

  // Compute fit masses
  WmassFit = nominalWmass+c_curr(3,0);
  TmassFit = nominalTopmass+c_curr(4,0);

  return chi2;
}

bool TopMassReco::topMassRecoAlgo2(const MyJet& bjet, const vector<MyJet>& jets) {
  double chiMin         = 1e20;

  double massW = -100;
  double massWFit = -100;
  double massTop = -100;
  double massTopFit = -100;
  bool minimumFound = false;

  for(vector<MyJet>::const_iterator iJet1 = jets.begin();
      iJet1!= jets.end(); ++iJet1){
    for(vector<MyJet>::const_iterator iJet2 = iJet1+1;
        iJet2 != jets.end(); ++iJet2){

      double jjMass, jjMassFit;
      double jjjMass, jjjMassFit;
      double chi2 = kinematicFit(iJet1->p4(), iJet2->p4(), bjet.p4(), jjMass, jjjMass, jjMassFit, jjjMassFit);

      if(chi2 < chiMin) {
        chiMin  = chi2;
        massW   = jjMass;
        massWFit = jjMassFit;
        massTop = jjjMass;
        massTopFit = jjjMassFit;

        bestQ1jet = iJet1;
        bestQ2jet = iJet2;
        minimumFound = true;
      }
    }
  }

  if(!minimumFound) return false;
  
  fit_chi2 = chiMin;
  wmass = massWFit;
  topmass = massTopFit;

  /*
  histograms->book("h_Wmass",100,0,200);
  histograms->book("h_topmass",100,0,500);
  histograms->fill("h_Wmass",massW);
  histograms->fill("h_topmass",massTop);
  */

  return true;
}

void TopMassReco::computeVariables(const MyJet  *tauJet, const MyJet& jet1, const MyJet& jet2, const MyJet& bjet) {
        theta_q_qbar = deltaR(bestQ1jet->Eta(), bestQ2jet->Eta(),
                              bestQ1jet->Phi(), bestQ2jet->Phi());

        TLorentzVector w = bestQ1jet->p4() + bestQ2jet->p4();
        theta_w_b = deltaR(w.Eta(), bjet.Eta(),
                           w.Phi(), bjet.Phi());

        TLorentzVector top = w + bjet.p4();
        top_pt = top.Pt();
        top_eta = top.Eta();
       
}

void TopMassReco::computeMVAvariables(const MyJet  *tauJet, const MyJet& jet1, const MyJet& jet2, const MyJet& bjet) {
        double wMass, wMassFit, topMass, topMassFit;
        double chi2 = kinematicFit(jet1.p4(), jet2.p4(), bjet.p4(), wMass, topMass, wMassFit, topMassFit);

        mvaVariables["mass_w"] = wMassFit;
        mvaVariables["mass_top"] = topMassFit;
        mvaVariables["fit_chi2"] = chi2;
        mvaVariables["theta_q_qbar"] = deltaR(jet1.Eta(), jet2.Eta(),
                                              jet1.Phi(), jet2.Phi());

        TLorentzVector w = jet1.p4() + jet2.p4();
        mvaVariables["theta_w_b"] = deltaR(w.Eta(), bjet.Eta(),
                                           w.Phi(), bjet.Phi());
        mvaVariables["bjet_pt"] = bjet.pt();
        mvaVariables["bjet_eta"] = bjet.Eta();
        mvaVariables["bjet_discriminator"] = bjet.tag("discriminator");

        TLorentzVector top = w + bjet.p4();
        if(tauJet != 0) 
          mvaVariables["theta_tau_top"] = deltaR(tauJet->Eta(), top.Eta(),
                                                 tauJet->Phi(), top.Phi());
        mvaVariables["top_pt"] = top.Pt();
        mvaVariables["top_eta"] = top.Eta();
}

void TopMassReco::topMassCombTrainMVA(const MyJet *tauJet, bool signal) {
        histograms->book("h_mva_njets", 50, 0, 50);
        histograms->fill("h_mva_njets", jetcontainer.size());

        for(vector<MyJet>::const_iterator iJetB = jetcontainer.begin(); iJetB != jetcontainer.end(); ++iJetB) {
                if(signal && iJetB->type != TopMassRecoPartons::bQuark)
                        continue;
                
                for(vector<MyJet>::const_iterator iJet1 = jetcontainer.begin(); iJet1 != jetcontainer.end(); ++iJet1) {
                        if(iJet1 == iJetB)
                                continue;
                        if(signal && !(iJet1->type == TopMassRecoPartons::lightQuark ||
                                       iJet1->type == TopMassRecoPartons::lightQuarkBar))
                                continue;

                        for(vector<MyJet>::const_iterator iJet2 = iJet1+1; iJet2 != jetcontainer.end(); ++iJet2) {
                                if(iJet2 == iJetB)
                                        continue;
                                if(signal && !(iJet2->type == TopMassRecoPartons::lightQuark ||
                                               iJet2->type == TopMassRecoPartons::lightQuarkBar))
                                        continue;
                                if(!signal && iJetB->type == TopMassRecoPartons::bQuark &&
                                   (iJet1->type == TopMassRecoPartons::lightQuark ||
                                    iJet1->type == TopMassRecoPartons::lightQuarkBar) &&
                                   (iJet2->type == TopMassRecoPartons::lightQuark ||
                                    iJet2->type == TopMassRecoPartons::lightQuarkBar))
                                        continue;

                                computeMVAvariables(tauJet, *iJet1, *iJet2, *iJetB);
                                histograms->setTreeVariable("mass_w", mvaVariables["mass_w"]);
                                histograms->setTreeVariable("mass_top", mvaVariables["mass_top"]);
                                histograms->setTreeVariable("fit_chi2", mvaVariables["fit_chi2"]);
                                histograms->setTreeVariable("theta_q_qbar", mvaVariables["theta_q_qbar"]);
                                histograms->setTreeVariable("theta_w_b", mvaVariables["theta_w_b"]);
                                histograms->setTreeVariable("bjet_pt", mvaVariables["bjet_pt"]);
                                histograms->setTreeVariable("bjet_eta", mvaVariables["bjet_eta"]);
                                histograms->setTreeVariable("bjet_discriminator", mvaVariables["bjet_discriminator"]);
                                histograms->setTreeVariable("theta_tau_top", mvaVariables["theta_tau_top"]);
                                histograms->setTreeVariable("top_pt", mvaVariables["top_pt"]);
                                histograms->fillTree();
                         }
                }
        }
}
