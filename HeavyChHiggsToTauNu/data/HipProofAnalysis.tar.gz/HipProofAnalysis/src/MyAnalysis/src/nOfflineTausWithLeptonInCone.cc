#include "MyAnalysis/interface/MyAnalysis.h"

vector<TauPair> MyAnalysis::nOfflineTausWithLeptonInCone(MyEvent* event){

	double leptonSearchCone = cuts->getCutValue("leptonSearchCone");

	vector<TauPair> tauPairs;

	vector<vector<MyJet>::const_iterator> usedLeptons;

	if(!histograms->booked("h_ntauplusmu")) histograms->book("h_ntauplusmu",5,0,5);
	if(!histograms->booked("h_DRtaumu_allMuons")) histograms->book("h_DRtaumu_allMuons",50,0,5);
        if(!histograms->booked("h_DRtaumu")) histograms->book("h_DRtaumu",100,0,0.5);
        if(!histograms->booked("h_tau_pt")) histograms->book("h_tau_pt",50,0,200);
        if(!histograms->booked("h_mu_pt")) histograms->clone("h_mu_pt","h_tau_pt");

	vector<MyJet> taus = event->getTaujets();
	vector<MyJet> muons = event->getMuons();

	for(vector<MyJet>::const_iterator iTau = taus.begin(); 
                                          iTau!= taus.end(); iTau++){
	  eventCounter->addCount("  all tau cands");
//cout << "tau et,eta,phi " << iTau->Et() << " " << iTau->Eta() << " " << iTau->Phi() << endl; 
          if(!cuts->applyCut("tauEtCut", iTau->Et())) continue;
          eventCounter->addCount("  tau Et < cut");


	  if(iTau->getTracks().size() == 0) continue;
	  eventCounter->addCount("  tau cands with tracks");


	  MyJet theLepton;
	  theLepton.SetXYZT(0,0,0,0);
	  int nLeptonsInJetCone = 0;
	  for(vector<MyJet>::const_iterator iMuon = muons.begin();
                                            iMuon!= muons.end(); iMuon++){
                if(iMuon->Et() < cuts->getCutValue("muEtCut")) continue;

		double DR = deltaR(iTau->eta(),iMuon->eta(),
                                   iTau->phi(),iMuon->phi());
          	histograms->fill("h_DRtaumu_allMuons",DR);

		if(DR < leptonSearchCone) {
			bool unusedLepton = true;
			for(vector<vector<MyJet>::const_iterator>::const_iterator iLepton = usedLeptons.begin();
				iLepton!= usedLeptons.end(); iLepton++){
				if(iMuon == *iLepton) unusedLepton = false;
			}
			if(unusedLepton){
				theLepton = *iMuon;
				usedLeptons.push_back(iMuon);
				nLeptonsInJetCone++;
			}
		}
	  }

//cout << "nLeptonsInJetCone " << nLeptonsInJetCone << endl;

	  if(nLeptonsInJetCone != 1) continue;

	  eventCounter->addCount("  1 lepton in tau cone");

	  double DR_taumu = deltaR(iTau->eta(),theLepton.eta(),
                                   iTau->phi(),theLepton.phi());
	  histograms->fill("h_DRtaumu",DR_taumu);
//cout << "muon in jetcone " << theLepton.Et() << " " << theLepton.eta() << " " << theLepton.phi() << " " << DR_taumu << endl;

	  // find lepton track from tau tracks;
	  vector<MyTrack> tracks = iTau->getTracks();
	  double DR_min = 999;

	  vector<MyTrack>::const_iterator leptonTrack;
	  for(vector<MyTrack>::const_iterator iTrack = tracks.begin();
					      iTrack!= tracks.end(); iTrack++){
		double DR = deltaR(theLepton.eta(),iTrack->eta(),
                                   theLepton.phi(),iTrack->phi());
		if(DR < DR_min){
                	DR_min = DR;
                        leptonTrack = iTrack;
                }
	  }

	  double muonIp  = leptonTrack->impactParameter().impactParameter2D().value();
          double muonSip = leptonTrack->impactParameter().impactParameter2D().significance();

//cout << "muon Ip " << muonIp << " " << muonSip << endl;
	  if(!histograms->booked("h_muonIp")) histograms->book("h_muonIp",100,-0.03,0.03);
	  histograms->fill("h_muonIp",muonIp);

          if(!histograms->booked("h_muonSip")) histograms->book("h_muonSip",100,-10,10);
          histograms->fill("h_muonSip",muonSip);


////	  if(muonIp < 0) continue;
////	  eventCounter->addCount("  muon ip > 0");

	  // find leading track in cone 0.1
	  double ptmax = 0;
	  vector<MyTrack>::const_iterator leadingTrack = tracks.end();
          for(vector<MyTrack>::const_iterator iTrack = tracks.begin();
                                              iTrack!= tracks.end(); iTrack++){
		if(iTrack == leptonTrack) continue;

                double DR = deltaR(iTau->eta(),iTrack->eta(),
                                   iTau->phi(),iTrack->phi());
		if(DR > 0.1) continue;

		if(iTrack->pt() > ptmax){
                	ptmax = iTrack->pt();
                        leadingTrack = iTrack;
                }
	  }

	  if(ptmax == 0) continue;
	  eventCounter->addCount("  leading track");
//cout << "leading track pt,eta,phi " << leadingTrack->Et() << " " 
//<< leadingTrack->eta() << " " << leadingTrack->phi() << endl;

	  // isolated tau around the leading track, 1/3 prong
	  int signalTracks    = 0,
              isolationTracks = 0;
	  double charge = leptonTrack->charge();
	  for(vector<MyTrack>::const_iterator iTrack = tracks.begin(); 
                                              iTrack!= tracks.end(); iTrack++){
                if(iTrack == leptonTrack) continue;

                double DR = deltaR(iTrack->eta(),leadingTrack->eta(),
                                   iTrack->phi(),leadingTrack->phi());
                if(DR > 0.4) continue;
//cout << "    tau track " << iTrack->pt() << " " << iTrack->eta() << " " << iTrack->phi() << endl;
                if(DR < 0.065) {
			signalTracks++;
			charge += iTrack->charge();
                }else{
			isolationTracks++;
		}
          }
	  if(signalTracks != 1 && signalTracks != 3) continue;
	  eventCounter->addCount("  1/3 prong");

	  if(isolationTracks > 0) continue;
	  eventCounter->addCount("  isolation");

	  // charge
	  if(charge != 0) continue;
	  eventCounter->addCount("  charge");

	  // tau harder than muon
//	  if(iTau->Pt() < theLepton.Pt()) continue;
//	  eventCounter->addCount("  tau pt > muon pt");

	  TauPair tauPair;
	  tauPair.addTau(iTau->p4());
	  tauPair.addTau(theLepton.p4());
	  tauPairs.push_back(tauPair);

	  histograms->fill("h_tau_pt",iTau->Pt());
          histograms->fill("h_mu_pt",theLepton.Pt());

//cout << "tau    " << iTau->Px() << " " << iTau->Py() << " " << iTau->Pz() << endl;
//cout << "lepton " << theLepton.Px() << " " << theLepton.Py() << " " << theLepton.Pz() << endl;
//cout << "taupair p4 " << tauPair.p4().Px() << " " << tauPair.p4().Py() << " " << tauPair.p4().Pz() << endl;
//cout << "check tauPairs.push_back " << iTau->Et() << " " << theLepton.Et() << endl;
	}
	histograms->fill("h_ntauplusmu",tauPairs.size());

	return tauPairs;
}
