#include "MyAnalysis/interface/MyAnalysis.h"

double deltaR(double,double,double,double);

void MyAnalysis::removeTausFromHadronicJets(MyEvent* event){

	// use only for taus, not tau candidates

	vector<MyJet> selectedJets;
	vector<MyJet> hadronicJets = event->getJets("MCJetCorrectorMcone5");
        vector<MyJet> taus = event->getTaujets();

	for(vector<MyJet>::const_iterator iJet = hadronicJets.begin();
					  iJet!= hadronicJets.end(); iJet++){
		bool remove = false;
		for(vector<MyJet>::const_iterator iTau = taus.begin();
                                                  iTau!= taus.end(); iTau++){
			double DR = deltaR(iTau->Eta(),iJet->Eta(),
					   iTau->Phi(),iJet->Phi());
			if(DR < 0.4) remove = true;
		}
		if(!remove) selectedJets.push_back(*iJet);
        }
	event->jets = selectedJets;
}
