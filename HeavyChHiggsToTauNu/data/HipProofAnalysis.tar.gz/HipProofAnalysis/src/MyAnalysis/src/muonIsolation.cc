#include "MyAnalysis/interface/MyAnalysis.h"

double deltaR(double,double,double,double);

vector<const MyJet*> MyAnalysis::muonIsolation(MyEvent *event){

	vector<const MyJet*> selectedMuons;
	vector<MyJet>::const_iterator iMuonEnd = event->muons_end();
	
        for(vector<MyJet>::const_iterator iMuon = event->muons_begin();
	    iMuon != iMuonEnd; ++iMuon) {
                double eta = iMuon->eta();
		double phi = iMuon->phi();

		int nTracks = 0;
                vector<MyTrack> tracks = iMuon->tracks;
                for(vector<MyTrack>::iterator iTrack = tracks.begin();
                                              iTrack!= tracks.end(); iTrack++){
                        if(iTrack->Pt() > cuts->getCutValue("leptonIsolPt")){
                                double trackEta = iTrack->eta();
                                double trackPhi = iTrack->phi();
                                double DR = deltaR(eta,trackEta,
                                                   phi,trackPhi);

                                double z = fabs(iTrack->impactParameter().impactParameterZ().value());
                                if(DR < cuts->getCutValue("leptonIsolCone") && z < cuts->getCutValue("track_Zip")) nTracks++;
                        }
                }
                if(nTracks == 1) {
			selectedMuons.push_back(&(*iMuon));
//                     	h_ptIsolatedMuon->Fill(iMuon->Pt());
//                     	h_etaIsolatedMuon->Fill(iMuon->eta());
                }
	}
	return selectedMuons;
}
