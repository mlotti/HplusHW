#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::tauHcalJetRejection(vector<const MyJet*> taus){

        vector<const MyJet*> selectedTaus;

        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){
                //if(!ltrackPtOverHcalClusterEt(*i,0.15)) continue;
                double discr = ltrackPtOverHcalClusterEtDiscriminator(*i,0.45);
                if(discr > 0.1) continue;

		eventCounter->addSubCount("tau hcal jet rejection");

		selectedTaus.push_back(*i);
	}
	return selectedTaus;
}
vector<const MyJet*> MyAnalysis::tauHcalElectronRejection(vector<const MyJet*> taus){

        vector<const MyJet*> selectedTaus;

        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){
                //if(!ltrackPtOverHcalClusterEt(*i,0.04)) continue;
                double discr = ltrackPtOverHcalClusterEtDiscriminator(*i, 0.45);
                if(discr < -0.98) continue;
                eventCounter->addSubCount("tau hcal electron rejection");

                selectedTaus.push_back(*i);
        }
        return selectedTaus;
}

bool MyAnalysis::ltrackPtOverHcalClusterEt(const MyJet* jet, double cone){

        double discriminator = ltrackPtOverHcalClusterEtDiscriminator(jet, cone);

	if(discriminator > -0.9 && discriminator < 0.2) return true;
	return false;
}

double MyAnalysis::ltrackPtOverHcalClusterEtDiscriminator(const MyJet* jet, double cone){

	double matchingCone = 0.1;

	double leadingTrackPt = jet->leadingTrack(matchingCone).Pt();
	double hcalClusterEt  = jet->hcalClusterMomentum(cone,matchingCone).Pt();

	double discriminator = -9999;
	if( leadingTrackPt != 0) discriminator = hcalClusterEt/leadingTrackPt -1;

        return discriminator;
}
