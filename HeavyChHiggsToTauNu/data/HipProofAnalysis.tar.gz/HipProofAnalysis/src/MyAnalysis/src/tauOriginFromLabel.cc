#include "MyAnalysis/interface/MyAnalysis.h"

int MyAnalysis::tauOriginFromLabel(Counter* eventCounter){

        int label = eventCounter->getLabel();
        int tauOrigin = 37;
        if( label < 100 ) tauOrigin = 24;
        //cout << " origin " << tauOrigin << " label " << label << endl;

	return tauOrigin;
}
