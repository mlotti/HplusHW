#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::bjetSelection(MyEvent* event, vector<MyJet>::const_iterator iTauBegin, vector<MyJet>::const_iterator iTauEnd){

	vector<const MyJet*> bjets;

	histograms->book("h_bjetPt",100,0,250);
	histograms->book("h_bjetEta",100,-5,5);

	string jetCalibration = "MCJetCorrectorMcone5";
	vector<MyJet> bCandidates = event->getJets(jetCalibration);
	vector<MyJet>::const_iterator iJet;
	vector<MyJet>::const_iterator iJetEnd = bCandidates.end();
	for(iJet = bCandidates.begin(); iJet != iJetEnd; ++iJet){
                eventCounter->addCount("    bjets: all cands ");

		bool removeThisJet = false;
		vector<MyJet>::const_iterator iTau;
		for(iTau = iTauBegin; iTau != iTauEnd; ++iTau){
                	double DR = deltaR(iJet->eta(),iTau->eta(),
                                           iJet->phi(),iTau->phi());
			if(DR < 0.4) removeThisJet = true;
		}
                if(removeThisJet) continue;
                eventCounter->addCount("    bjets: taujets removed");

                histograms->fill("h_bjetPt",iJet->Et());
                histograms->fill("h_bjetEta",iJet->Eta());

                if(!cuts->applyCut("jetEtCut", iJet->Et())) continue;
                eventCounter->addCount("    bjets: Et cut ");

                if(!cuts->applyCut("jetEtaCut", fabs(iJet->Eta()))) continue;
                eventCounter->addCount("    bjets: eta cut");

		double discriminator = iJet->tag("discriminator");
                if(!cuts->applyCut("bTagDiscriminator", discriminator)) continue;
                eventCounter->addCount("    bjets: discr");

                bjets.push_back(&(*iJet));
	}
	return bjets;
}
