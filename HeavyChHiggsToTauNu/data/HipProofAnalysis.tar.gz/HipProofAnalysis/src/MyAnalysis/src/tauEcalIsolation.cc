#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::tauEcalIsolation(vector<const MyJet*> taus,string tauType){

	double caloEtMin     = 1.5;
	double isolationCone = 0.45;
	double signalCone    = 0.1;

        vector<const MyJet*> selectedTaus;

        vector<const MyJet*>::const_iterator i;

	if(tauType == "PFTau"){
        	for(i = taus.begin(); i!= taus.end(); ++i){

		   // option 1
			MyTrack leadingTrack = (*i)->leadingTrack();

			int pfPhotons = 0;
			double isolationGammaSum = 0;
			vector<MyTrack>::const_iterator iTrackEnd = (*i)->tracks_end();
			for(vector<MyTrack>::const_iterator iTrack = (*i)->tracks_begin();
			                                    iTrack!= iTrackEnd; ++iTrack){
				if(fabs(iTrack->pfType()) == 5) continue;
                                if(fabs(iTrack->charge()) != 0) continue;
				double DR = deltaR(leadingTrack.eta(),iTrack->eta(),
                                                   leadingTrack.phi(),iTrack->phi());
	                        if(DR > isolationCone) continue;
				if(DR < signalCone) continue;

                                if(iTrack->Pt() > 1) pfPhotons++;
				isolationGammaSum += iTrack->Pt();
			}
			//if(isolationGammaSum > caloEtMin ) continue;
			//eventCounter->addSubCount("tau ecal isolation");

                        if(pfPhotons > 0) continue;
                        eventCounter->addSubCount("tau pf photon isolation");

		  // option 2
			/*
			if((*i)->tag("d_ecalIsolation") == 0) continue;
			eventCounter->addSubCount("tau ecal isolation(d)");
			*/

                	selectedTaus.push_back(*i);
        	}
	}else{
                for(i = taus.begin(); i!= taus.end(); ++i){

			if(!ECALIsolation(**i,isolationCone,signalCone,caloEtMin)) continue;
			eventCounter->addSubCount("tau ecal isolation");

                        selectedTaus.push_back(*i);
                }
	}

	return selectedTaus;
}
