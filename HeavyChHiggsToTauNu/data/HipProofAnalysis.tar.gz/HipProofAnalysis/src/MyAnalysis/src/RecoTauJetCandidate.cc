#include "MyAnalysis/interface/RecoTauJetCandidate.h"

#define RUN_WITH_HITS 1

RecoTauJetCandidate::RecoTauJetCandidate(string counterPrefix, MyEvent* event, const MyJet* jet) : fJet(jet), fEvent(event) {
  using namespace TMath;
  
  fCounterPrefix = counterPrefix;
  
  fIsolationCalculated = false;
  fCalculateAll = false;
  fCalculateInvariantMass = false;
  fEnergyIsSummed = false;
  fQCDAnalyzed = false;
  // Initialize pass table
  for (int i = 0; i < TAUID_COUNTERS; ++i) fPassTable[i] = false;
  fPassTable[TAUID_PASSED_NOTHING] = true;
  fPassedStatus = true;
  fPassCount = 0;
  
  // Calculate tau candidate properties
  MyTrack myLdgTrack = jet->leadingTrack();
  fJetEt = jet->Et();
  fJeteta = jet->eta();
  fJetphi = jet->phi();
  
  // Copy tracks and find index of leading trck
  int myTrackIndex = 0;
  int myLeadingTrackIndex = -1;
  vector<MyTrack>::const_iterator myLeadingTrack;
  double myHighestPt = -1;
  vector<MyTrack>::const_iterator iTrackEnd = jet->tracks_end();
  for (vector<MyTrack>::const_iterator iTrack = jet->tracks_begin(); iTrack != iTrackEnd; ++iTrack) {
    double myPt = iTrack->Perp();
    if (myPt > 0) fTracks.push_back(&(*iTrack));
    if (myPt > myHighestPt &&
	(int)(iTrack->pfType()) <=1 ) {
      myLeadingTrackIndex = myTrackIndex;
      myLeadingTrack = iTrack;
      myHighestPt = myPt;
    }
    ++myTrackIndex;
  }

  fLdgPt = myLdgTrack.Perp();
  if (fLdgPt > 0) {
    fLdgphi = myLdgTrack.Phi();
    fLdgeta = myLdgTrack.Eta();
  } else {
    fLdgphi = 0;
    fLdgeta = 0;
  }
  fLdgHits = (int)myLdgTrack.numberOfValidHits();
  fLdgChi2 = myLdgTrack.normalizedChi2();
  
  // Analyse secondary vertex data
  fVertex = false;
  vector<MyVertex>::const_iterator iVertexEnd = jet->secVertices_end();
  const MyVertex* myBestVertex = 0;
  double myBestSignificance = -1;
  for (vector<MyVertex>::const_iterator iVertex = jet->secVertices_begin(); iVertex != iVertexEnd; ++iVertex) {
    if (iVertex->significance() > myBestSignificance) {
      myBestSignificance = iVertex->significance();
      myBestVertex = &(*iVertex);
    }
  }
  if (myBestSignificance >= 0) {
    fVertex = true;
    // Calculate sign of tau flightpath (dot product of jet and vertex vectors)
    TVector3 myJet(jet->Vect());
    TVector3 myVertex(myBestVertex->getX(), myBestVertex->getY(), myBestVertex->getZ());
    double myDot = myJet.Dot(myVertex);
    fFlightpathSig = myBestVertex->significance();
    fFlightpath = myBestVertex->value();
    fFlightpathT = myVertex.Perp();
    if (myDot < 0) {
      fFlightpathSig *= -1.0;
      fFlightpath *= -1.0;
      fFlightpathT *= -1.0;
    }
  } else {
    fFlightpathSig = -1;
    fFlightpath = -1;
    fFlightpathT = -1;
  }
  
  // Analyse hit data of leading track
  double myMaxHitChi2 = 0;
#ifdef RUN_WITH_HITS
  vector<MyHit> myHitContainer = jet->hits;
  vector<MyHit>::const_iterator iHitMax;
  if (myLeadingTrackIndex >= 0) {
    vector<MyHit>::const_iterator iHitEnd = myHitContainer.end();
    for (vector<MyHit>::const_iterator iHit = myHitContainer.begin();
	 iHit != iHitEnd; ++iHit) {
      if (iHit->trackAssociationLabel == myLeadingTrackIndex) {
	if (iHit->theEstimate > myMaxHitChi2) {
	  myMaxHitChi2 = iHit->theEstimate;
	  iHitMax = iHit;
	}
      }
    }
  }
#endif
  if (myMaxHitChi2 > 0) {
#ifdef RUN_WITH_HITS
    fLdgMaxHitChi2 = myMaxHitChi2 / ((double)fLdgHits*2.0 - 5.0); // normalize chi2
    TVector3 myRadius(iHitMax->getX(), iHitMax->getY(), iHitMax->getZ());
    if (myRadius.x() == 0 && myRadius.y() == 0) 
      fLdgMaxHitChi2Radius = 0;
    else 
      fLdgMaxHitChi2Radius = myRadius.Perp();
#endif
  } else {
    fLdgMaxHitChi2Radius = -1;
  }

  // Analyse impact parameter
  MyMeasurement1D myIPt = myLdgTrack.impactParameter().impactParameter2D();
  fLdgIpt = myIPt.value();
  MyMeasurement1D myIP = myLdgTrack.impactParameter().impactParameter3D();
  fLdgIp3D = myIP.value();
  fLdgIp3Dsig = myIP.significance();
  MyMeasurement1D myIPz = myLdgTrack.impactParameter().impactParameterZ();
  fLdgIpz = myIP.value();

  // Analyse isolation data
  fSignalTrackNumber = -1;
  fSignalConeExcessPt = -1;
  fIsolationTrackNumber = -1;
  fIsolationPt = -1;
  fIsolationMinHits = -1;
  fIsolationMaxHits = -1;
  fIsolationMinPt = -1;
  fIsolationMaxPt = -1;  
  
  // Analyse calorimetry energy
  fRtauT = myLdgTrack.Perp() / jet->Et();
  fRtau = myLdgTrack.E() / jet->E();  
}

void RecoTauJetCandidate::updateCounters(Counter* eventCounter, int passedJetCount) {
  
  // Add counters
  eventCounter->addSubCount(fCounterPrefix + "::initial events");
  if (fPassTable[TAUID_PASSED_ET]) eventCounter->addSubCount(fCounterPrefix + "::passed ET cut");
  if (fPassTable[TAUID_PASSED_ETA]) eventCounter->addSubCount(fCounterPrefix + "::passed eta cut");
  if (fPassTable[TAUID_PASSED_RTAU]) eventCounter->addSubCount(fCounterPrefix + "::passed rtau cut");
  if (fPassTable[TAUID_PASSED_MRTAUCUT]) eventCounter->addSubCount(fCounterPrefix + "::passed multi-rtau cut");
  if (fPassTable[TAUID_PASSED_TRISO]) eventCounter->addSubCount(fCounterPrefix + "::passed tracker isolation cut");
  if (fPassTable[TAUID_PASSED_EMISO]) eventCounter->addSubCount(fCounterPrefix + "::passed em. isolation cut");
  if (fPassTable[TAUID_PASSED_TRNO]) eventCounter->addSubCount(fCounterPrefix + "::passed track number cut");
  if (fPassTable[TAUID_PASSED_CHARGESUMCUT]) eventCounter->addSubCount(fCounterPrefix + "::passed charge sum cut");
  if (fPassTable[TAUID_PASSED_LDGPT]) eventCounter->addSubCount(fCounterPrefix + "::passed ldg track pt cut");
  if (fPassTable[TAUID_PASSED_PTSUM]) eventCounter->addSubCount(fCounterPrefix + "::passed track Pt sum cut");
  if (fPassTable[TAUID_PASSED_LDGIP]) eventCounter->addSubCount(fCounterPrefix + "::passed ldg track IPt cut");
  if (fPassTable[TAUID_PASSED_MIPTCUT]) eventCounter->addSubCount(fCounterPrefix + "::passed multitrack IPt cut");
  if (fPassTable[TAUID_PASSED_MIP3DSIGCUT]) eventCounter->addSubCount(fCounterPrefix + "::passed multitrack IP3DSig cut");
  if (fPassTable[TAUID_PASSED_MIP3DCUT]) eventCounter->addSubCount(fCounterPrefix + "::passed multitrack IP3D cut");
  if (fPassTable[TAUID_PASSED_LDGHITS]) eventCounter->addSubCount(fCounterPrefix + "::passed ldg track hit cut");
  if (fPassTable[TAUID_PASSED_LDGCHI2]) eventCounter->addSubCount(fCounterPrefix + "::passed ldg track chi2 cut");
  if (fPassTable[TAUID_PASSED_MCHI2CUT]) eventCounter->addSubCount(fCounterPrefix + "::passed multitrack chi2 cut");
  if (fPassTable[TAUID_PASSED_LDGHITCHI2]) eventCounter->addSubCount(fCounterPrefix + "::passed ldg track hit chi2 cut");
  if (fPassTable[TAUID_PASSED_MHITCHI2CUT]) eventCounter->addSubCount(fCounterPrefix + "::passed multitrack hit chi2 cut");
  if (fPassTable[TAUID_PASSED_TRKQUAL]) eventCounter->addSubCount(fCounterPrefix + "::passed track quality cuts");
  if (fPassTable[TAUID_PASSED_NEUTRHADR]) eventCounter->addSubCount(fCounterPrefix + "::passed neutral hadron cut");
  if (fPassTable[TAUID_PASSED_ELECTRONCUT]) eventCounter->addSubCount(fCounterPrefix + "::passed electron cut");
  if (fPassTable[TAUID_PASSED_VERTEX]) eventCounter->addSubCount(fCounterPrefix + "::passed vertex cut");
  if (fPassTable[TAUID_PASSED_INVMASS]) eventCounter->addSubCount(fCounterPrefix + "::passed inv.mass cut");
  if (fPassTable[TAUID_PASSED_ALL]) {
    eventCounter->addCount("Passed " + fCounterPrefix);
    eventCounter->addSubCount(fCounterPrefix + "::passed tau identification");
    if (passedJetCount == 1)
      eventCounter->addSubCount(fCounterPrefix + "::passed tauID on 1 jet in event");
    else if (passedJetCount == 2)
      eventCounter->addSubCount(fCounterPrefix + "::passed tauID on 2 jets in event");
    else
      eventCounter->addSubCount(fCounterPrefix + "::passed tauID on 3+ jets in event");
  }
}

RecoTauJetCandidate::~RecoTauJetCandidate() {
  if (fQCDAnalyzed) {
    delete fMCTau;
    delete fMCQCD;
  }
}

// cut routines --------------------------------------------------------------------------

bool RecoTauJetCandidate::EtCut(double min) {
  if (fPassedStatus) {
    fPassedStatus = (fJetEt >= min);
    fPassTable[TAUID_PASSED_ET] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::etaCut(double max) {
  if (fPassedStatus) {
    fPassedStatus = (TMath::Abs(fJeteta) <= max);
    fPassTable[TAUID_PASSED_ETA] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ldgPtCut(double min) {
  if (fPassedStatus) {
    fPassedStatus = (fLdgPt > min);
    fPassTable[TAUID_PASSED_LDGPT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ldgHitCut(int n) {
  if (fPassedStatus) {
    fPassedStatus = (fLdgHits >= n);
    fPassTable[TAUID_PASSED_LDGHITS] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ldgChi2Cut(double value) { 
  if (fPassedStatus) {
    fPassedStatus = (fLdgChi2 <= value);
    fPassTable[TAUID_PASSED_LDGCHI2] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
  
}

bool RecoTauJetCandidate::ldgHitChi2Cut(double value) { 
  if (fPassedStatus) {
    fPassedStatus = (fLdgMaxHitChi2 <= value);
    fPassTable[TAUID_PASSED_LDGHITCHI2] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ldgIptCut(double min, double max) { 
  if (fPassedStatus) {
    fPassedStatus = (TMath::Abs(fLdgIpt) >= min && TMath::Abs(fLdgIpt) <= max); 
    fPassTable[TAUID_PASSED_LDGIPT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ldgIp3DCut(double min, double max) { 
  if (fPassedStatus) {
    fPassedStatus = (fLdgIp3D >= min && fLdgIp3D <= max);
    fPassTable[TAUID_PASSED_LDGIP] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ldgIpSigCut(double min, double max) { 
  if (fPassedStatus) {
    fPassedStatus = (fLdgIp3Dsig >= min && fLdgIp3Dsig <= max);
    fPassTable[TAUID_PASSED_LDGIP] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::signalTrackNumberCut(int n) {
  if (fPassedStatus && !fIsolationCalculated) {
    cout << "Isolation parameters not calculated!" << endl
         << "Call trackerIsolationCut before signalTrackNumberCut!" << endl;
    fPassedStatus = false;
  } else if (fPassedStatus) { // don't do if selection has already failed
    fPassedStatus = (fSignalTrackNumber == n);
    fPassTable[TAUID_PASSED_TRNO] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::trackerIsolationCut(double annulusMin, double annulusMax, double minPt, double maxDz) {
  if (fPassedStatus || fCalculateAll) {
    if (!fIsolationCalculated) calculateIsolation(annulusMin, annulusMax, minPt, maxDz);

    if (fPassedStatus) { // don't do if selection has already failed
      fPassedStatus = (fIsolationTrackNumber == 0);
      fPassTable[TAUID_PASSED_TRISO] = fPassedStatus;
      if (fPassedStatus) ++fPassCount;
    }
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ECALIsolation(double annulusMin, double annulusMax, double maxEt) {
  if (fPassedStatus || fCalculateAll) {
    fEcalIsolEt = energyInAnnulus(annulusMin, annulusMax, fJet, fJeteta, fJetphi, true, false);
    if (fPassedStatus) { // don't do if selection has already failed
      fPassedStatus = (fEcalIsolEt < maxEt);
      fPassTable[TAUID_PASSED_EMISO] = fPassedStatus;
      if (fPassedStatus) ++fPassCount;
    }
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::pfTauECALIsolation(double annulusMin, double annulusMax, double maxPt) {
  if (fPassedStatus || fCalculateAll) {
    TLorentzVector myTrackSum(0,0,0,0);
    vector<const MyTrack*>::const_iterator iTrackEnd = fTracks.end();
    for (vector<const MyTrack*>::const_iterator iTrack = fTracks.begin(); iTrack != iTrackEnd; ++iTrack) {
      if ((int)((*iTrack)->pfType()) != 5 &&
          (int)((*iTrack)->charge()) == 0) {
        double myDeltaR =
          deltaR(fLdgeta, (*iTrack)->Eta(), fLdgphi, (*iTrack)->Phi());
        if (myDeltaR >= annulusMin && myDeltaR <= annulusMax) myTrackSum += **iTrack;
      }
    }
    fEcalIsolEt = myTrackSum.Perp();
    
    if (fPassedStatus) { // don't do if selection has already failed
      fPassedStatus = (myTrackSum.Perp() < maxPt);
      fPassTable[TAUID_PASSED_EMISO] = fPassedStatus;
      if (fPassedStatus) ++fPassCount;
    }
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::neutralHadronCut(double annulusMin, double annulusMax, double max) {
  if (fPassedStatus || fCalculateAll) {
    if (!fEnergyIsSummed) energySumming(annulusMin, annulusMax);
    if (fPassedStatus) { // don't do if selection has already failed
      fPassedStatus = (fHcalRatio < max);
      fPassTable[TAUID_PASSED_NEUTRHADR] = fPassedStatus;
      if (fPassedStatus) ++fPassCount;
    }
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::pfTauNeutralHadronCut(double annulusMin, double annulusMax, double maxPt) {
  if (fPassedStatus || fCalculateAll) {
    TLorentzVector myTrackSum(0,0,0,0);
    vector<const MyTrack*>::const_iterator iTrackEnd = fTracks.end();
    for (vector<const MyTrack*>::const_iterator iTrack = fTracks.begin(); iTrack != iTrackEnd; ++iTrack) {
      if ((int)((*iTrack)->pfType()) == 5) {
        double myDeltaR =
          deltaR(fLdgeta, (*iTrack)->Eta(), fLdgphi, (*iTrack)->Phi());
        if (myDeltaR >= annulusMin && myDeltaR <= annulusMax) myTrackSum += **iTrack;
      }
    }
    fHcalRatio = myTrackSum.Perp();
    if (fPassedStatus) { // don't do if selection has already failed
      fPassedStatus = (myTrackSum.Perp() < maxPt);
      fPassTable[TAUID_PASSED_NEUTRHADR] = fPassedStatus;
      if (fPassedStatus) ++fPassCount;
    }
  }
  return fPassedStatus;
}


bool RecoTauJetCandidate::electronCut(double annulusMin, double annulusMax, double min) {
  if (fPassedStatus || fCalculateAll) {
    if (!fEnergyIsSummed) energySumming(annulusMin, annulusMax);
    if (fPassedStatus) { // don't do if selection has already failed
      fPassedStatus = (fHcalRatio > min);
      fPassTable[TAUID_PASSED_ELECTRONCUT] = fPassedStatus;
      if (fPassedStatus) ++fPassCount;
    }
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::rtauCut(double min) {
  if (fPassedStatus) {
    fPassedStatus = (fRtau >= min);
    fPassTable[TAUID_PASSED_RTAU] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::rtauTCut(double min) {
  if (fPassedStatus) {
    fPassedStatus = (fRtauT >= min);
    fPassTable[TAUID_PASSED_RTAUT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ptSumCut(double min) {
  if (fPassedStatus) {
    fPassedStatus = (fPtSum >= min);
    fPassTable[TAUID_PASSED_PTSUM] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::chi2Cut(double max) {
  if (fPassedStatus) {
    fPassedStatus = (fMaxChi2 <= max);
    fPassTable[TAUID_PASSED_MCHI2CUT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::hitChi2Cut(double max) {
  if (fPassedStatus) {
    fPassedStatus = (fMaxHitChi2 <= max);
    fPassTable[TAUID_PASSED_MHITCHI2CUT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::iptCut(double min, double max) {
  if (fPassedStatus) {
    fPassedStatus = ((fMaxIpt >= min && fMinIpt <= max) || fMaxIpt < 0);
    fPassTable[TAUID_PASSED_MIPTCUT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ip3DCut(double min, double max) {
  if (fPassedStatus) {
    fPassedStatus = ((fMaxIp3D >= min && fMinIp3D <= max) || fMaxIp3D < 0);
    fPassTable[TAUID_PASSED_MIP3DCUT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::ipSigCut(double min, double max) {
  if (fPassedStatus) {
    fPassedStatus = ((fMaxIp3Dsig >= min && fMinIp3Dsig <= max) || fMaxIp3Dsig < 0);
    fPassTable[TAUID_PASSED_MIP3DSIGCUT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::chargeSumCut(int value) {
  if (fPassedStatus) {
    fPassedStatus = (TMath::Abs(fChargeSum) == value);
    fPassTable[TAUID_PASSED_CHARGESUMCUT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}

bool RecoTauJetCandidate::multipleTrackRtau(double min, double max) { 
  if (fPassedStatus) {
    fPassedStatus = (fMultipleTrackRtau >= min && fMultipleTrackRtau <= max);
    fPassTable[TAUID_PASSED_MRTAUCUT] = fPassedStatus;
    if (fPassedStatus) ++fPassCount;
  }
  return fPassedStatus;
}


bool RecoTauJetCandidate::tauComesFromWorZ() {
  MCRecoTau* myMC = getMCTau();
  return (myMC->originatesFromW() || myMC->originatesFromZ());
}

// internal calculation routines ------------------------------------------------------------

void RecoTauJetCandidate::calculateIsolation(double annulusMin, double annulusMax, double minPt, double maxDz) {
  using namespace TMath;
  fIsolationCalculated = true;  

  vector<int> mySignalTrackIDs;
  vector<const MyTrack*> myIsolationTracks;
    
  int myTrackIndex = 0;
  vector<const MyTrack*>::const_iterator iTrackEnd = fTracks.end();
  for (vector<const MyTrack*>::const_iterator iTrack = fTracks.begin(); iTrack != iTrackEnd; ++iTrack) {
    if (TMath::Abs((*iTrack)->charge()) > 0) {
      if (TMath::Abs((*iTrack)->impactParameter().impactParameterZ().value()) < maxDz) {
        double myPt = (*iTrack)->Perp();
        if (myPt > minPt) {
          double myDeltaR = deltaR(fLdgeta, (*iTrack)->Eta(), fLdgphi, (*iTrack)->Phi());
          if (myDeltaR <= annulusMax) {
            if (myDeltaR <= annulusMin) {
              // signal tracks
              fSignalTracks.push_back(*iTrack);
              mySignalTrackIDs.push_back(myTrackIndex);
            } else {
              // isolation tracks
              myIsolationTracks.push_back(*iTrack);
            }
          }
        }
      }
    }
    ++myTrackIndex;
  }
  // Analyze signal tracks           
  fSignalTrackNumber = fSignalTracks.size();
  TLorentzVector myLdgTrack(0,0,0,0);
  TLorentzVector myTrackSum(0,0,0,0);
  TLorentzVector myPosTracks(0,0,0,0);
  TLorentzVector myNegTracks(0,0,0,0);
  fDeltaE = 0;
  fChargeSum = 0;
  fMinPt = 9999;
  fMaxIpt = -1;
  fMinIpt = 9999;
  fMaxIp3D = -1;
  fMinIp3D = 9999;
  fMaxIp3Dsig = -1;
  fMinIp3Dsig = 9999;
  fMaxIpz = -1;
  fMinIpz = 9999;
  fMaxChi2 = -1;
  fMaxHitChi2 = -1;
  fMaxHitChi2Radius = -1;
  int myHits = 0;
  vector<MyHit> myHitContainer = fJet->hits;
  vector<MyHit>::const_iterator iHitMax;
  vector<int>::const_iterator i = mySignalTrackIDs.begin();
  iTrackEnd = fSignalTracks.end();
  for (vector<const MyTrack*>::const_iterator iTrack = fSignalTracks.begin(); iTrack != iTrackEnd; ++iTrack) {
    TLorentzVector trk;
    trk.SetXYZM((*iTrack)->X(), (*iTrack)->Y(), (*iTrack)->Z(), 0.139);
    fDeltaE += trk.E();
    int myCharge = (int)((*iTrack)->charge());
    fChargeSum += myCharge;
    if (myCharge > 0) myPosTracks += **iTrack;
    if (myCharge < 0) myNegTracks += **iTrack;
    double myPt = (*iTrack)->Perp();
    if (myPt > myLdgTrack.Perp()) myLdgTrack = **iTrack;
    if (myPt < fMinPt) fMinPt = myPt;
    MyMeasurement1D myIP = (*iTrack)->impactParameter().impactParameter2D();
    if (Abs(myIP.value()) > fMaxIpt) fMaxIpt = Abs(myIP.value());
    if (Abs(myIP.value()) < fMinIpt) fMinIpt = Abs(myIP.value());
    myIP = (*iTrack)->impactParameter().impactParameter3D();
    if (Abs(myIP.value()) > fMaxIp3D) fMaxIp3D = Abs(myIP.value());
    if (Abs(myIP.value()) < fMinIp3D) fMinIp3D = Abs(myIP.value());
    if (Abs(myIP.significance()) > fMaxIp3Dsig) fMaxIp3Dsig = Abs(myIP.significance());
    if (Abs(myIP.significance()) < fMinIp3Dsig) fMinIp3Dsig = Abs(myIP.significance());
    myIP = (*iTrack)->impactParameter().impactParameterZ();
    if (Abs(myIP.value()) > fMaxIpz) fMaxIpz = Abs(myIP.value());
    if (Abs(myIP.value()) < fMinIpz) fMinIpz = Abs(myIP.value());
    if ((*iTrack)->normalizedChi2() > fMaxChi2) fMaxChi2 = (*iTrack)->normalizedChi2();
    myTrackSum += **iTrack;
    // loop over hits
#ifdef RUN_WITH_HITS
    vector<MyHit>::const_iterator iHitEnd = myHitContainer.end();
    for (vector<MyHit>::const_iterator iHit = myHitContainer.begin(); iHit != iHitEnd; ++iHit) {
      if (iHit->trackAssociationLabel == *i) {
	if (iHit->theEstimate > fMaxHitChi2) {
	  fMaxHitChi2 = iHit->theEstimate;
	  iHitMax = iHit;
          myHits = (int)((*iTrack)->numberOfValidHits());
	}
      }
    }
#endif
    ++i;
  }
  fDeltaE -= fJet->E();
  fPtSum = myTrackSum.Perp();
  fctau = fFlightpathT * 1.778 / fPtSum * 1.0e6;
  myTrackSum -= myLdgTrack;
  fSignalConeExcessPt = myTrackSum.Perp();
  if (fChargeSum > 0) {
    fMultipleTrackRtau = myPosTracks.E() / fJet->E();
  } else {
    fMultipleTrackRtau = myNegTracks.E() / fJet->E();
  }
  if (!fSignalTrackNumber) {
    fMinPt = -1;
    fMinIpt = -1;
    fMinIp3D = -1;
    fMinIp3Dsig = -1;
    fMinIpt = -1;
  }
#ifdef RUN_WITH_HITS
  if (fMaxHitChi2 > 0) {
    fMaxHitChi2 /= ((double)myHits*2.0 - 5.0); // normalize chi2
    TVector3 myRadius(iHitMax->getX(), iHitMax->getY(), iHitMax->getZ());
    fMaxHitChi2Radius = myRadius.Perp();
  }
#endif
  double myP2 = fPtSum*fPtSum;
  fInvMass = Sqrt((fJetEt)*(fJetEt) - myP2) / fLdgSinTheta;

  // temporary code  
  fInvMass004 = calculateInvariantMass(0.04, 0.40);
  fInvMass006 = calculateInvariantMass(0.06, 0.40);
  fInvMass008 = calculateInvariantMass(0.08, 0.40);
  fInvMass010 = calculateInvariantMass(0.10, 0.40);
  
  // Analyze isolation tracks
  TLorentzVector myIsolatedTracks(0,0,0,0);
  fIsolationTrackNumber = 0;
  fIsolationMinHits = 9999;
  fIsolationMaxHits = -1;
  fIsolationMinPt = 9999;
  fIsolationMaxPt = -1;
  fIsolationMinDr = 9999;
  fIsolationMaxDr = -1;
 
  fIsolationTrackNumber = myIsolationTracks.size();
  iTrackEnd = myIsolationTracks.end();
  for (vector<const MyTrack*>::const_iterator iTrack = myIsolationTracks.begin(); iTrack != iTrackEnd; ++iTrack) {
    double myPt = (*iTrack)->Perp();
    if (myPt < fIsolationMinPt) fIsolationMinPt = myPt;
    if (myPt > fIsolationMaxPt) fIsolationMaxPt = myPt;
    myHits = (int)((*iTrack)->numberOfValidHits());
    if (myHits < fIsolationMinHits) fIsolationMinHits = myHits;
    if (myHits > fIsolationMaxHits) fIsolationMaxHits = myHits;
    double myDeltaR = deltaR(fLdgeta, (*iTrack)->Eta(), fLdgphi, (*iTrack)->Phi());
    if (myDeltaR < fIsolationMinDr) fIsolationMinDr = myDeltaR;
    if (myDeltaR > fIsolationMaxDr) fIsolationMaxDr = myDeltaR;
    myIsolatedTracks += **iTrack;
  }
  fIsolationPt = myIsolatedTracks.Perp();
  if (!fIsolationTrackNumber) {
    fIsolationMinHits = -1;
    fIsolationMinPt = -1;
    fIsolationMinDr = -1;
  }
}

void RecoTauJetCandidate::energySumming(double annulusMin, double annulusMax) {
  fHcalEt = energyInAnnulus(annulusMin, annulusMax, fJet, fJeteta, fJetphi, false, true);
  fEcalEt = energyInAnnulus(annulusMin, annulusMax, fJet, fJeteta, fJetphi, true, false);
  fTotalEt = energyInAnnulus(annulusMin, annulusMax, fJet, fJeteta, fJetphi, true, true);
  if (fLdgPt > 0) {
    fHcalRatio = (fHcalEt - fLdgPt) / fLdgPt;
    fTotalRatio = (fTotalEt - fLdgPt) / fLdgPt;
  } else {
    fHcalRatio = -2;
    fTotalRatio = -2;
  }
  fEnergyIsSummed = true;
}

void RecoTauJetCandidate::analyzeQCD() {
  if (!fQCDAnalyzed) {
    // Construct MC properties
    fMCTau = new MCRecoTau(fEvent, fJet);
    fMCQCD = new MCRecoQCDJet(fEvent, fJet);
    fQCDAnalyzed = true;
  }
}

double RecoTauJetCandidate::calculateInvariantMass(double annulusMin, double annulusMax) {
  fCalculateInvariantMass = true;
  if (fSignalTracks.size() == 0) return -1;
  TVector3 myP3(0,0,0);
  double myEnergy = 0;
  vector<MyCaloTower>::const_iterator iTowerEnd = fJet->caloInfo_end();
  // loop over calo cells and calculate energy clipping away double counted clusters
  for (vector<MyCaloTower>::const_iterator iTower = fJet->caloInfo_begin(); iTower != iTowerEnd; ++iTower) {
    vector<TVector3>::const_iterator iCellEnd = iTower->ECALCells_end();
    for (vector<TVector3>::const_iterator iCell = iTower->ECALCells_begin(); iCell != iCellEnd; ++iCell) {
      if (TMath::Abs(iCell->x()) > 0 && TMath::Abs(iCell->y()) > 0) {
        double myCellEta = iCell->Eta();
        double myCellPhi = iCell->Phi();
        vector<const MyTrack*>::const_iterator iTrackEnd = fSignalTracks.end();
        for (vector<const MyTrack*>::const_iterator iTrack = fSignalTracks.begin(); iTrack != iTrackEnd; ++iTrack) {
          double mydR = deltaR((*iTrack)->ecalHitPoint().Eta(), myCellEta, (*iTrack)->ecalHitPoint().Phi(), myCellPhi);
          if (mydR >= annulusMin) {
            if (mydR <= annulusMax) {
              myP3 += *iCell;
              myEnergy += (*iCell).Mag();
            }
          }
        }
      }
    }
    iCellEnd = iTower->HCALCells_end();
    for (vector<TVector3>::const_iterator iCell = iTower->HCALCells_begin(); iCell != iCellEnd; ++iCell) {
      if (TMath::Abs(iCell->x()) > 0 && TMath::Abs(iCell->y()) > 0) {
        double myCellEta = iCell->Eta();
        double myCellPhi = iCell->Phi();
        vector<const MyTrack*>::const_iterator iTrackEnd = fSignalTracks.end();
        for (vector<const MyTrack*>::const_iterator iTrack = fSignalTracks.begin(); iTrack != iTrackEnd; ++iTrack) {
          double mydR = deltaR((*iTrack)->ecalHitPoint().Eta(), myCellEta, (*iTrack)->ecalHitPoint().Phi(), myCellPhi);
          if (mydR >= annulusMin) {
            if (mydR <= annulusMax) {
              myP3 += *iCell;
              myEnergy += (*iCell).Mag();
            }
          }
        }
      }
    }
  }
  
  TLorentzVector myTracks(0,0,0,0);
  vector<const MyTrack*>::const_iterator iTrackEnd = fSignalTracks.end();
  for (vector<const MyTrack*>::const_iterator iTrack = fSignalTracks.begin(); iTrack != iTrackEnd; ++iTrack) {
    TLorentzVector tk;
    tk.SetXYZM((*iTrack)->X(), (*iTrack)->Y(), (*iTrack)->Z(), 0.139); // assume pion
    myTracks += tk;
  }
  TLorentzVector myP4;
  myP4.SetPxPyPzE(myP3.X(), myP3.Y(), myP3.Z(), myP3.Mag());
  //myP4.SetPxPyPzE(myP3.X(), myP3.Y(), myP3.Z(), myEnergy);
  myP4 += myTracks;
  
  return myP4.M();
}


double RecoTauJetCandidate::energyInAnnulus(double rMin, double rMax, const MyJet *jet, double eta, double phi, bool ecal, bool hcal) {
  TVector3 myEnergy(0,0,0);
  // Loop over calo cells
  vector<MyCaloTower>::const_iterator iTowerEnd = jet->caloInfo_end();
  for (vector<MyCaloTower>::const_iterator iTower = jet->caloInfo_begin(); iTower != iTowerEnd; ++iTower) {
    if (ecal) {
      vector<TVector3>::const_iterator iCellEnd = iTower->ECALCells_end();
      for (vector<TVector3>::const_iterator iCell = iTower->ECALCells_begin(); iCell != iCellEnd; ++iCell) {
        if (TMath::Abs(iCell->x()) > 0 && TMath::Abs(iCell->y()) > 0) {
          double dR = deltaR(eta, iCell->Eta(), phi, iCell->Phi());
          if (dR <= rMax) {
            if (dR >= rMin) {
          /*double dPhi = deltaPhi(phi, iCell->Phi());  
          double dEta = TMath::Abs(eta - iCell->Eta());
          double myValue = dPhi*dPhi + dEta*dEta; 
          if (myValue <= myMaxBoundary) {
            if (myValue >= myMinBoundary) {*/
              myEnergy += *iCell;
            }
          }
        }
      }
    }
    
    if (hcal) {
      vector<TVector3>::const_iterator iCellEnd = iTower->HCALCells_end();
      for (vector<TVector3>::const_iterator iCell = iTower->HCALCells_begin(); iCell != iCellEnd; ++iCell) {
        if (TMath::Abs(iCell->x()) > 0 && TMath::Abs(iCell->y()) > 0) {
          double dR = deltaR(eta, iCell->Eta(), phi, iCell->Phi());
          if (dR <= rMax) {
            if (dR >= rMin) {
          /*double dPhi = deltaPhi(phi, iCell->Phi());
          double dEta = TMath::Abs(eta - iCell->Eta());
          double myValue = dPhi*dPhi + dEta*dEta;
          if (myValue <= myMaxBoundary) {
            if (myValue >= myMinBoundary) {*/
              myEnergy += *iCell;
            }
          }
        }
      }
    }
  }
  
  if (myEnergy.x() == 0 && myEnergy.y() == 0) return 0;
  return myEnergy.Perp();
}

bool RecoTauJetCandidate::doSelection(Cuts* cuts, Counter* eventCounter, bool isPFtau) {
  // Calculate everything, if histogramming is turned on
  int myTauIdAnalysis = (int)(cuts->getCutValue("TauIDAnalysis"));
  if (myTauIdAnalysis) fCalculateAll = true;
  
  int myProngNumber = (int)(cuts->getCutValue("tauProngs"));
  if (myProngNumber == 1) {
    EtCut((double)(cuts->getCutValue("tauIDEtCut")));
    etaCut((double)(cuts->getCutValue("tauIDetaCut")));
    rtauCut((double)(cuts->getCutValue("tauIDRtauCut")));
    trackerIsolationCut((double)(cuts->getCutValue("tauIDSignalCone")),
                        (double)(cuts->getCutValue("tauIDIsolationCone")),
                        (double)(cuts->getCutValue("tauIDIsolationPtMin")),
                        (double)(cuts->getCutValue("tauIDIsolationIPzMax")));
    double ecalIsoConeMin = 0;
    double ecalIsoConeMax = 0;
    cuts->getCutValues("tauIDECALIsolationCone", &ecalIsoConeMin, &ecalIsoConeMax);
    if (isPFtau) {
      pfTauECALIsolation(ecalIsoConeMin, ecalIsoConeMax,
                         (double)(cuts->getCutValue("tauIDPFECALIsolation")));
    } else {
      ECALIsolation(ecalIsoConeMin, ecalIsoConeMax,
                         (double)(cuts->getCutValue("tauIDECALIsolation")));
    }
    signalTrackNumberCut((int)(cuts->getCutValue("tauIDProngs")));
    if (!isPFtau) {
      double iptMin = 0;
      double iptMax = 0;
      cuts->getCutValues("tauIDLdgIPtCut", &iptMin, &iptMax);
      ldgIptCut(iptMin, iptMax);
      ldgHitCut((int)(cuts->getCutValue("tauIDLdgHitsCut")));
      ldgChi2Cut((double)(cuts->getCutValue("tauIDLdgChi2Cut")));
      ldgHitChi2Cut((double)(cuts->getCutValue("tauIDLdgHitsChi2Cut")));
    }
    double hadronMin = 0;
    double hadronMax = 0;
    cuts->getCutValues("tauIDNeutralHadronCone", &hadronMin, &hadronMax);
    if (isPFtau) {
      pfTauNeutralHadronCut(hadronMin, hadronMax,
                            (double)(cuts->getCutValue("tauIDPFNeutralHadronCut")));
    } else {
      neutralHadronCut(hadronMin, hadronMax,
                       (double)(cuts->getCutValue("tauIDNeutralHadronCut")));
    }
    if (!isPFtau) {
      electronCut(hadronMin, hadronMax,
                  (double)(cuts->getCutValue("tauIDElectronCut")));
    }
    if (fPassedStatus) fPassTable[TAUID_PASSED_ALL] = true;
    
  } else if (myProngNumber == 3) {
    // Check these cuts! - EXPERIMENTAL CODE for 3 prongs
    EtCut(100.0);
    etaCut(2.0);
    rtauCut(0.8);
    trackerIsolationCut(0.04, 0.45, 0.5, 0.1);
    if (isPFtau) {
      pfTauECALIsolation(0.10, 0.45, 1.5);
    } else {
      ECALIsolation(0.10, 0.45, 1.5);
    }
    signalTrackNumberCut(3);

    if (fPassedStatus) fPassTable[TAUID_PASSED_ALL] = true;
  }
  
  if (fPassTable[TAUID_PASSED_ALL]) {
    if (isMCtau()) {
      MCRecoTau* myMC = getMCTau();
      if (myMC->originatesFromHplus()) {
        eventCounter->addSubCount(fCounterPrefix + "::passed jet origin H+");
      } else if (myMC->originatesFromW() || myMC->originatesFromZ()) {
        eventCounter->addSubCount(fCounterPrefix + "::passed jet origin W or Z");
      }
    } else {
      eventCounter->addSubCount(fCounterPrefix + "::passed jet origin qcd");
    }
  }
  return (fPassTable[TAUID_PASSED_ALL]);
}
