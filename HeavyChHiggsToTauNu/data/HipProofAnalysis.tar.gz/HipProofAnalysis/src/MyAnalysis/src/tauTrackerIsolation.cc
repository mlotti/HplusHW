#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::tauTrackerIsolation(vector<const MyJet*> taus,double PVz){

        vector<const MyJet*> selectedTaus;

        if(!histograms->booked("h_leadingTrackPt") ) histograms->book("h_leadingTrackPt",100,0,500);
        if(!histograms->booked("h_leadingTrackChi2") ) histograms->book("h_leadingTrackChi2",100,0,20);
        if(!histograms->booked("h_leadingTrackHits") ) histograms->book("h_leadingTrackHits",20,0,20);
        if(!histograms->booked("h_leadingTrackIpz") ) histograms->book("h_leadingTrackIpz",100,0,0.1);
        if(!histograms->booked("h_leadingTrackDipz") ) histograms->book("h_leadingTrackDipz",100,0,20);
        if(!histograms->booked("h_leadingTrackIp2D") ) histograms->book("h_leadingTrackIp2D",100,0,0.1);

        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){

             // option 1
		MyTrack leadingTrack = (*i)->leadingTrack(cuts->getCutValue("matchingCone"));

		histograms->fill("h_leadingTrackPt",leadingTrack.Pt());

                if(leadingTrack.charge() == 0) continue;

		if(!cuts->applyCut("leadingTrackPtCut", leadingTrack.Pt())) continue;
                eventCounter->addSubCount("tkIsol tau leading track");

                histograms->fill("h_leadingTrackChi2",leadingTrack.normalizedChi2());
                histograms->fill("h_leadingTrackHits",leadingTrack.numberOfValidHits());
                histograms->fill("h_leadingTrackIpz",leadingTrack.impactParameter().impactParameterZ().value());
                histograms->fill("h_leadingTrackIp2D",leadingTrack.impactParameter().impactParameter2D().value());
                double dipZ = fabs(leadingTrack.impactParameter().impactParameterZ().value() - PVz);
                histograms->fill("h_leadingTrackDipz",dipZ);

                if(leadingTrack.numberOfValidHits() < 8) continue;
                eventCounter->addSubCount("tkIsol leading track hits>7");

                bool isolated = isolation(&(**i),cuts->getCutValue("isolationCone"),cuts->getCutValue("signalCone"), cuts->getCutValue("isolationTrackPt"));
                if(!isolated) continue;
                eventCounter->addSubCount("tkIsol tau isolation");

	     // option 2
		/*
		bool isolated = (*i)->tag("d_trackIsolation"); // for pftaus also "d_pftrackIsolation"

                if(!isolated) continue;
                eventCounter->addSubCount("tkIsol tau isolation(d)");
		*/

                selectedTaus.push_back(*i);
        }
	return selectedTaus;
}
