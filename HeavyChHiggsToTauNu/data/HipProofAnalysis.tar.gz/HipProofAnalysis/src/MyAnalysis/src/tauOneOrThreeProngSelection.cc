#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::tauOneOrThreeProngSelection(vector<const MyJet*> taus,int nprongs){

        vector<const MyJet*> selectedTaus;

        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){

		bool select = false;
		int ntracks = (*i)->getTracksAroundLeadingTrack(cuts->getCutValue("signalCone"),cuts->getCutValue("matchingCone")).size();

		if(nprongs == 1 && ntracks == 1) select = true;
		if(nprongs == 3 && ntracks == 3) select = true;
		if(nprongs != 1 && nprongs != 3 && (ntracks == 1 || ntracks == 3)) select = true;

		if(!select) continue;
                eventCounter->addSubCount("tau prongs");

                selectedTaus.push_back(*i);
        }
	return selectedTaus;
}
