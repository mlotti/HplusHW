#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::hadronicJetCounter(MyEvent* event, int nJets, double etcut){

        bool decision = false;
        int jetCount = 0;

        string jetCalibration = "MCJetCorrectorMcone5";
        vector<MyJet> bCandidates = event->getJets(jetCalibration);
        for(vector<MyJet>::iterator iJet = bCandidates.begin();
                                    iJet != bCandidates.end(); iJet++){

		if(iJet->Et() < etcut || fabs(iJet->eta()) > 2.5) continue;
		jetCount++;
	}

        if(jetCount == nJets) decision = true;
	return decision;
}
