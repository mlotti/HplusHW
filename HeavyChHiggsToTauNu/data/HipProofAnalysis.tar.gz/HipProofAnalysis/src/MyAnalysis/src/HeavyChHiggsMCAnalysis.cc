#include "MyAnalysis/interface/HeavyChHiggsMCAnalysis.h"

HeavyChHiggsMCAnalysis::HeavyChHiggsMCAnalysis(MyHistogram* histo){
	histograms = histo;
}
HeavyChHiggsMCAnalysis::~HeavyChHiggsMCAnalysis(){}

vector<MyMCParticle> HeavyChHiggsMCAnalysis::visibleTaus(){
	return visible_taus;
}

MyMCParticle HeavyChHiggsMCAnalysis::visibleTau(MyJet direction){
	MyMCParticle visible_tau(0,0,0,0);
	double DRmin = 9999;
	vector<MyMCParticle>::const_iterator i;
	for(i = visible_taus.begin(); i!= visible_taus.end(); i++){
		double DR = deltaR(direction.Eta(),i->Eta(),
				   direction.Phi(),i->Phi());
		if(DR < 0.4 && DR < DRmin){
			DRmin = DR;
			visible_tau = *i;
		}
	}
        return visible_tau;
}

vector<MyMCParticle> HeavyChHiggsMCAnalysis::bquarks(){
	return bQuarks;
}

vector<MyMCParticle> HeavyChHiggsMCAnalysis::neutrinos(){
        return mcNeutrinos;
}

vector<MyMCParticle> HeavyChHiggsMCAnalysis::muons(){
        return mcMuons;
}

vector<MyMCParticle> HeavyChHiggsMCAnalysis::taus(){
        return mcTaus;
}

MyMCParticle HeavyChHiggsMCAnalysis::leadingMuon(){
	MyMCParticle theMuon(0,0,0,0);

        double ptmax = 0;

	histograms->book("h_ptMCmuons",100,0,250);
	histograms->book("h_etaMCmuons",100,-5,5);

	vector<MyMCParticle>::const_iterator i;
        for(i = mcMuons.begin(); i!= mcMuons.end(); i++){

		histograms->fill("h_ptMCmuons",i->Et());
		histograms->fill("h_etaMCmuons",i->Eta());

		if(i->pt() > ptmax){
			ptmax = i->pt();
			theMuon = *i;
		}		
        }
	return theMuon;
}

MyMCParticle HeavyChHiggsMCAnalysis::leadingBQuark(){
        MyMCParticle theB(0,0,0,0);

        double ptmax = 0;

	histograms->book("h_ptBquarks",100,0,250);
	histograms->book("h_etaBquarks",100,-5,5);

        vector<MyMCParticle>::const_iterator i;
        for(i = bQuarks.begin(); i!= bQuarks.end(); i++){

		histograms->fill("h_ptBquarks",i->Et());
		histograms->fill("h_etaBquarks",i->Eta());

                if(i->pt() > ptmax){
                        ptmax = i->pt();
                        theB = *i;
                }
        }
        return theB;
}

MyMCParticle HeavyChHiggsMCAnalysis::neutrinoSum(){
	MyMCParticle theSum(0,0,0,0);

	vector<MyMCParticle>::const_iterator i;
        for(i = mcNeutrinos.begin(); i!= mcNeutrinos.end(); i++){
		theSum += *i;
	}
	histograms->book("h_EtneutrinoSum",100,0,500);
	histograms->fill("h_EtneutrinoSum",theSum.Et());

	return theSum;
}

void HeavyChHiggsMCAnalysis::analyse(MyEvent* event){
        // Clear vectors
        visible_taus.clear();
        bQuarks.clear();
        bQuarksFromTop.clear();
        bQuarksNotFromTop.clear();
        mcNeutrinos.clear();
        mcMuons.clear();
        mcTaus.clear();
        topPartons.clear();

        map<TopMassRecoPartons::Partons, MyMCParticle> topPartonsMap;

	theEventPointer = event;

	visible_taus = ::visibleTaus(event,35);

        vector<MyMCParticle>::const_iterator mcParticlesBegin = event->mcParticles_begin();
        vector<MyMCParticle>::const_iterator mcParticlesEnd   = event->mcParticles_end();

        for(vector<MyMCParticle>::const_iterator imc = mcParticlesBegin;
                                                 imc!= mcParticlesEnd; ++imc){

		if(abs(imc->pid) == 5) {
//		if(abs(imc->pid) == 5 ||( abs(imc->pid) > 500 && abs(imc->pid) < 600) ||
//                   (abs(imc->pid) > 5000 && abs(imc->pid) < 6000) ) {
			bQuarks.push_back(*imc);
			int mother = *((imc->mother).begin());
			if(abs(mother) == 6) {
				bQuarksFromTop.push_back(*imc);
                                topPartons[TopMassRecoPartons::bQuark] = *imc;
			}else{
				bQuarksNotFromTop.push_back(*imc);
                                //topPartons[TopMassRecoPartons::bQuarkNotFromTop] = *imc;
			}
		}
                else if(abs(imc->pid) >= 1 && abs(imc->pid) <= 4) { // Light quarks (u,d,s,c)
                        vector<int>::const_iterator m_iter = imc->mother.begin();
                        int mother = *m_iter;
                        ++m_iter;
                        if(m_iter == imc->mother.end()) // Light quark doesn't have grandmother
                                continue;
                        int grandmother = *m_iter;
                        if(abs(mother) == 24 && abs(grandmother) == 6) {
                                if(imc->pid > 0)
                                        topPartons[TopMassRecoPartons::lightQuark] = *imc;
                                else
                                        topPartons[TopMassRecoPartons::lightQuarkBar] = *imc;
                        }
                }
            	else if(abs(imc->pid) == 13  ) {
                	mcMuons.push_back(*imc);
		}
                else if(abs(imc->pid) == 15) {
                        mcTaus.push_back(*imc);
                }
		else if(abs(imc->pid) == 12 || abs(imc->pid) == 14 || abs(imc->pid) == 16 ) {
                	mcNeutrinos.push_back(*imc);
            	}
	}
}

MyMCParticle HeavyChHiggsMCAnalysis::mcJet(MyJet direction){
	MyMCParticle mcjet(0,0,0,0);

        vector<MyMCParticle>::const_iterator mcParticlesBegin = theEventPointer->mcParticles_begin();
        vector<MyMCParticle>::const_iterator mcParticlesEnd   = theEventPointer->mcParticles_end();

	vector<MyMCParticle>::const_iterator i;
	for(i = mcParticlesBegin; i!= mcParticlesEnd; ++i){
		if(i->Et() == 0) continue;

		double DR =deltaR(direction.Eta(),i->eta(),
                                  direction.Phi(),i->phi());
		if( DR < 0.5 ) {
			if(i->status == 1) mcjet += *i;
		}
	}
	return mcjet;
}

MyJet HeavyChHiggsMCAnalysis::mcParton(MyMCParticle direction){
        MyJet mcjet(0,0,0,0);

        vector<MyJet> jets = theEventPointer->getJets();

        vector<MyJet>::const_iterator mcJetsBegin = jets.begin();
        vector<MyJet>::const_iterator mcJetsEnd   = jets.end();

	vector<MyJet>::const_iterator i;
	for(i = mcJetsBegin; i!= mcJetsEnd; ++i){
		if(i->Et() == 0) continue;

		double DR =deltaR(direction.Eta(),i->eta(),
                                  direction.Phi(),i->phi());
		if( DR < 0.5 ) {
			mcjet += *i;
		}
	}
        return mcjet;
}


int matchingPtOrderedPartons(std::map<TopMassRecoPartons::Partons, MyMCParticle> partons, 
                              std::vector<MyJet>& jets, double maxDist=0.5) {
        // Order partons by their pT in descending order
        std::vector<std::pair<double, TopMassRecoPartons::Partons> > ptOrderedPartons;
        for(std::map<TopMassRecoPartons::Partons, MyMCParticle>::const_iterator ip = partons.begin();
            ip != partons.end(); ++ip) {
                ptOrderedPartons.push_back(std::make_pair(ip->second.pt(), ip->first));
        }
        std::sort(ptOrderedPartons.begin(), ptOrderedPartons.end());
        std::reverse(ptOrderedPartons.begin(), ptOrderedPartons.end());
        std::vector<unsigned int> jetIndices;

        for(unsigned int ij=0; ij<jets.size(); ++ij) {
                jetIndices.push_back(ij);
        }

        std::map<unsigned int, unsigned int> matching; // mapping parton -> jet
        for(unsigned int ip=0; ip<ptOrderedPartons.size(); ++ip) {
                double minDist = 999;
                int ijMin = -1;

                for(unsigned int ij=0; ij<jetIndices.size(); ++ij) {
                        MyMCParticle& parton = partons[ptOrderedPartons[ip].second];
                        MyJet& jet = jets[jetIndices[ij]];
                        double dist = deltaR(parton.Eta(), jet.Eta(),
                                             parton.Phi(), jet.Phi());

                        if(dist < minDist) {
                                minDist = dist;
                                ijMin = ij;
                        }
                }
               
                if(ijMin >= 0 && minDist <= maxDist) {
                        matching[ptOrderedPartons[ip].second] =  jetIndices[ijMin];
                        jetIndices.erase(jetIndices.begin()+ijMin, jetIndices.begin()+ijMin+1);
                }
        }
        for(std::vector<MyJet>::iterator ijet = jets.begin(); ijet != jets.end(); ++ijet) {
                ijet->type = 0;
        }

        for(std::map<unsigned int, unsigned int>::const_iterator iter = matching.begin();
            iter != matching.end(); ++iter) {
                jets[iter->second].type = iter->first;
        }
        return matching.size();
}

/**
 * Returns the number successfully matched jet-parton pairs
 */
int HeavyChHiggsMCAnalysis::topJetPartonMatch(std::vector<MyJet> &jets) {
        return matchingPtOrderedPartons(topPartons, jets, 0.5);
}
