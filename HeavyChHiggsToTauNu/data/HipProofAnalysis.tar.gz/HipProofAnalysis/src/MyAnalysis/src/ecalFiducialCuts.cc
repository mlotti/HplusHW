#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::ecalFiducialCuts(vector<const MyJet*> taus){
        vector<const MyJet*> selectedTaus;

        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){
		
		double ecalHitPointEta = fabs((*i)->leadingTrack().ecalHitPoint().tvector3().Eta());
		if(ecalHitPointEta < 0.018 ) continue;
		if(ecalHitPointEta > 0.423 && ecalHitPointEta < 0.461 ) continue;
                if(ecalHitPointEta > 0.770 && ecalHitPointEta < 0.806 ) continue;
                if(ecalHitPointEta > 1.127 && ecalHitPointEta < 1.163 ) continue;
                if(ecalHitPointEta > 1.460 && ecalHitPointEta < 1.558 ) continue;

		eventCounter->addSubCount("tau ecal fiducial cut");
                selectedTaus.push_back(*i);
        }

	return selectedTaus;
}

