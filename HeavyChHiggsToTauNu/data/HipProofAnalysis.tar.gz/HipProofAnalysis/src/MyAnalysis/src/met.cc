#include "MyAnalysis/interface/MyAnalysis.h"

//double phidis(double,double);

bool MyAnalysis::met(MyEvent* event, vector<const MyJet*> taus){

	// uncorrected met (only calomet + muons)
	MyMET met = event->getMET(); 
        double value = met.value();
        if(!histograms->booked("h_met")) histograms->book("h_met",100,0,500);
        histograms->fill("h_met",value);


	// type1 met 
	double jetEtCut = 20;
	string corr = "MCJetCorrectorMcone5";
	MyMET type1met = type1METtau(event,taus,jetEtCut,corr);

	double type1value = type1met.value();
	if(!histograms->booked("h_type1met")) histograms->clone("h_type1met","h_met");
	histograms->fill("h_type1met",type1value);


	//
	MyMET mcMET = event->getMCMET(); 
	double mcValue = mcMET.value();
        if(!histograms->booked("h_mcmet")) histograms->clone("h_mcmet","h_met");
        histograms->fill("h_mcmet",mcValue);

	double metReso = value - mcValue;
        if(!histograms->booked("h_metEnergyResolution")) histograms->book("h_metEnergyResolution",100,-50,50);
        histograms->fill("h_metEnergyResolution",metReso);

        double type1metReso = type1value - mcValue;
        if(!histograms->booked("h_type1metEnergyResolution")) histograms->clone("h_type1metEnergyResolution","h_metEnergyResolution");
	histograms->fill("h_type1metEnergyResolution",type1metReso);

	//
        if(mcValue != 0) {
		if(!histograms->booked("h_metEnergyResolutionDiv")) histograms->book("h_metEnergyResolutionDiv",100,-10,40);
		histograms->fill("h_metEnergyResolutionDiv",metReso/mcValue);

		if(!histograms->booked("h_type1metEnergyResolutionDiv")) histograms->clone("h_type1metEnergyResolutionDiv","h_metEnergyResolutionDiv");
                histograms->fill("h_type1metEnergyResolutionDiv",type1metReso/mcValue);
	}

        double dPhiMET = deltaPhi(met.getPhi(),mcMET.getPhi());
        if(!histograms->booked("h_metPhiResolution")) histograms->book("h_metPhiResolution",180,0,180);
        histograms->fill("h_metPhiResolution",180/3.14259*dPhiMET);

        double dPhiType1MET = deltaPhi(type1met.getPhi(),mcMET.getPhi());
        if(!histograms->booked("h_type1metPhiResolution")) histograms->clone("h_type1metPhiResolution","h_metPhiResolution");
        histograms->fill("h_type1metPhiResolution",180/3.14259*dPhiType1MET);


	if(mcMET.getPhi() != 0) {
		if(!histograms->booked("h_metPhiResolutionDiv")) histograms->book("h_metPhiResolutionDiv",100,-0.1,3);
		histograms->fill("h_metPhiResolutionDiv",dPhiMET/mcMET.getPhi());

                if(!histograms->booked("h_type1metPhiResolutionDiv")) histograms->clone("h_type1metPhiResolutionDiv","h_metPhiResolutionDiv");
                histograms->fill("h_type1metPhiResolutionDiv",dPhiType1MET/mcMET.getPhi());
	}	



	theMET = type1met;

        return cuts->applyCut("MET", theMET.value());
}

