#include "MyAnalysis/interface/MyAnalysis.h"
/*
void MyAnalysis::mcAnalysis(MyEvent* event){

	//cout << "event number " << event->eventNumber << endl;
//if(event->eventNumber != 75) return;
	eventCounter->addCount("   MC: all events ");
        if(!histograms->booked("h_mcDRa0a0")) histograms->book("h_mcDRa0a0",50,0,5);
        if(!histograms->booked("h_mcDRtautau")) histograms->book("h_mcDRtautau",50,0,5);
	if(!histograms->booked("h_mcDRtaumu")) histograms->book("h_mcDRtaumu",50,0,5);


        vector<MyMCParticle> mcParticles = event->getMCParticles();

        vector<MyMCParticle>::const_iterator a0_1 = mcParticles.end();
        vector<MyMCParticle>::const_iterator a0_2 = mcParticles.end();

	vector<MyMCParticle>::const_iterator tau1 = mcParticles.end();
        vector<MyMCParticle>::const_iterator tau2 = mcParticles.end();
        vector<MyMCParticle>::const_iterator tau3 = mcParticles.end();
        vector<MyMCParticle>::const_iterator tau4 = mcParticles.end();

        vector<MyMCParticle>::const_iterator nu1 = mcParticles.end();
        vector<MyMCParticle>::const_iterator nu2 = mcParticles.end();
        vector<MyMCParticle>::const_iterator nu3 = mcParticles.end();
        vector<MyMCParticle>::const_iterator nu4 = mcParticles.end();

        TLorentzVector visibletau1(0,0,0,0);
        TLorentzVector visibletau2(0,0,0,0);
        TLorentzVector visibletau3(0,0,0,0);
        TLorentzVector visibletau4(0,0,0,0);

        vector<MyMCParticle>::const_iterator muon1 = mcParticles.end();
        vector<MyMCParticle>::const_iterator muon2 = mcParticles.end();

	int nMuonsFromTaus = 0;

	for(vector<MyMCParticle>::const_iterator iMC = mcParticles.begin();
                                                 iMC!= mcParticles.end(); iMC++){

		vector<int> mothers = iMC->mother;
		vector<int>::const_iterator mothers_begin = iMC->mother_begin();
                vector<int>::const_iterator mothers_end   = iMC->mother_end();

		
                //cout << iMC->pid << " " << iMC->status << " " << iMC->Pt() << endl;
                //for(vector<int>::const_iterator i = iMC->mother_begin();
                //                                i!= iMC->mother_end(); i++){
                //	cout << "    mother " << *i << endl;
                //}
		

		if(iMC->pid == 25) {
			a0_1 = iMC;
			if(a0_2 == mcParticles.end()){
				a0_2 = a0_1;
				a0_1 = mcParticles.end();
			}
		}

		if(abs(iMC->pid) == 15){
			if( *mothers_begin == 25){
				double DR_a0_1 = deltaR(a0_1->eta(),iMC->eta(),
                                                        a0_1->phi(),iMC->phi());
                                double DR_a0_2 = deltaR(a0_2->eta(),iMC->eta(),
                                                        a0_2->phi(),iMC->phi());
				if(DR_a0_1 < DR_a0_2){
				  if(iMC->pid > 0){
					tau1 = iMC;
				  }else{
					tau2 = iMC;
				  }
				}else{
                                  if(iMC->pid > 0){
                                        tau3 = iMC;
                                  }else{
                                        tau4 = iMC;
                                  }

				}
			}
		}

		if(abs(iMC->pid) == 13){
			if(abs(*mothers_begin) == 15){
			  bool a0found = false;
			  for(vector<int>::const_iterator i = mothers_begin;
							  i!= mothers_end; ++i){
				if(*i == 25) a0found = true;
			  }
			  if(a0found){
				nMuonsFromTaus++;
				double DR_a0_1 = deltaR(a0_1->eta(),iMC->eta(),
                                                        a0_1->phi(),iMC->phi());
                                double DR_a0_2 = deltaR(a0_2->eta(),iMC->eta(),
                                                        a0_2->phi(),iMC->phi());
                                if(DR_a0_1 < DR_a0_2){
				  muon1 = iMC;
				}else{
				  muon2 = iMC;
				}
			  }
			}
		}

                if(abs(iMC->pid) == 16){
			bool a0found = false;
			for(vector<int>::const_iterator i = mothers_begin;
                                                          i!= mothers_end; i++){
                                if(*i == 25) a0found = true;
                        }
			if(a0found){
                                  if(iMC->pid > 0){
                                        nu1 = iMC;
					if(nu3 == mcParticles.end()){
                                		nu3 = nu1;
                		                nu1 = mcParticles.end();
		                        }
                                  }else{
                                        nu2 = iMC;
		                        if(nu4 == mcParticles.end()){
                		                nu4 = nu2;
                                		nu2 = mcParticles.end();
                        		}
                                  }
			}
                }


	}

	visibletau1 = tau1->p4() - nu1->p4();
        visibletau2 = tau2->p4() - nu2->p4();
        visibletau3 = tau3->p4() - nu3->p4();
        visibletau4 = tau4->p4() - nu4->p4();


	if(tau1 == mcParticles.end()) return;
	eventCounter->addCount("   MC: 4 taus ");

	if(nMuonsFromTaus != 2 || 
           muon1 == mcParticles.end() || 
           muon2 == mcParticles.end()) return;
        eventCounter->addCount("   MC: 2 muons from taus ");

	TLorentzVector theTau1(0,0,0,0);
        TLorentzVector theTau2(0,0,0,0);

	if(muon1->pid > 0) {
		theTau1 = visibletau2;
	}else{
		theTau1 = visibletau1;
	}

        if(muon2->pid > 0) {
                theTau2 = visibletau4;
        }else{
                theTau2 = visibletau3;
        }

        double DR_a0a0 = deltaR(a0_1->eta(),a0_2->eta(),
                                a0_1->phi(),a0_2->phi());
        histograms->fill("h_mcDRa0a0",DR_a0a0);


	double DR_tautau1 = deltaR(tau1->eta(),tau2->eta(),
                                   tau1->phi(),tau2->phi());
        double DR_tautau2 = deltaR(tau3->eta(),tau4->eta(),
                                   tau3->phi(),tau4->phi());
	histograms->fill("h_mcDRtautau",DR_tautau1);
        histograms->fill("h_mcDRtautau",DR_tautau2);

	double DR_taumu1 = deltaR(theTau1.Eta(),muon1->eta(),
                                  theTau1.Phi(),muon1->phi());
        double DR_taumu2 = deltaR(theTau2.Eta(),muon2->eta(),
                                  theTau2.Phi(),muon2->phi());
        histograms->fill("h_mcDRtaumu",DR_taumu1);
        histograms->fill("h_mcDRtaumu",DR_taumu2);

}
*/
