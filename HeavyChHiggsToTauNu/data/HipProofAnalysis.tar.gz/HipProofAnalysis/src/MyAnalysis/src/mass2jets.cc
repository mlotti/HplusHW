#include "TLorentzVector.h"


double mass2jets(TLorentzVector j1,TLorentzVector j2){
  double j2mass = -100;
  double j2mass2 = (j1.E()+j2.E())*(j1.E()+j2.E())
                 - (j1.Px()+j2.Px())*(j1.Px()+j2.Px())
                 - (j1.Py()+j2.Py())*(j1.Py()+j2.Py())
                 - (j1.Pz()+j2.Pz())*(j1.Pz()+j2.Pz());
  if(j2mass2 >= 0) j2mass = sqrt(j2mass2);
  return j2mass;
}
