#include "MyAnalysis/interface/MyAnalysis.h"

void MyAnalysis::jetResolutionAnalysis(vector<MyJet> jets,MyEvent* event){

	histograms->book("h_reso_jetEnergyResolution",100,-3,3);
	histograms->book("h_reso_jetEt",100,0,250);
        histograms->book("h_reso_jetEta",100,-5,5);
        histograms->book("h_reso_jetPhi",90,0,90);
        histograms->clone("h_reso_mcjetEt","h_reso_jetEt");

	vector<MyJet>::const_iterator iJet;
	for(iJet = jets.begin(); iJet != jets.end(); iJet++){
		MyMCParticle mcJet = mcAnalysis->mcJet(*iJet);

		histograms->fill("h_reso_jetEt",iJet->Et());
		histograms->fill("h_reso_jetEta",iJet->Eta());
		histograms->fill("h_reso_jetPhi",180/3.14159*iJet->Phi());

                histograms->fill("h_reso_mcjetEt",mcJet.Et());

		double energyReso = (iJet->Et() - mcJet.Et())/mcJet.Et();
		histograms->fill("h_reso_jetEnergyResolution",energyReso);

	}
}
