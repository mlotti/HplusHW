#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::triggerTausFound(MyEvent* event){
	bool decision = false;
	vector<const MyJet*> taus = triggerTaus(event);
	if(taus.size() > 0) decision = true;
	return decision;
}

vector<const MyJet*> MyAnalysis::triggerTaus(MyEvent* event){

	double taujetEtcut 	= 96;
	double leadingTrackPt 	= 20;
	double matchingCone 	= 0.1;
	double isolationCone	= 0.45;
	double signalCone	= 0.07;
	double otherTrackPt 	= 1;
	double chi2		= 100;
	double hits		= 5;
	double d_ipz		= 0.2;
	double maxTransverseIp	= 100;

	vector<const MyJet*> HLTlikeTaus;

	if(!histograms->booked("h_triggerTau_pt")) histograms->book("h_triggerTau_pt",100,0,200);


        vector<MyJet>::const_iterator iTauEnd = event->taujets_end();

	double PVz = event->getPrimaryVertex().getZ();

        vector<MyJet>::const_iterator iJet;
	for(iJet = event->taujets_begin(); iJet != iTauEnd; ++iJet){

		histograms->fill("h_triggerTau_pt",iJet->Et());

		if(iJet->Et() < taujetEtcut) continue;

		//vector<MyTrack> tracks = iJet->getTracks();

		// leading track
                vector<MyTrack>::const_iterator iTrackBegin = iJet->tracks_begin();
                vector<MyTrack>::const_iterator iTrackEnd = iJet->tracks_end();
                vector<MyTrack>::const_iterator leadingTrack = iTrackEnd;
		vector<MyTrack>::const_iterator iTrack;
		double ptmax = 0;
		for(iTrack = iTrackBegin; iTrack != iTrackEnd; ++iTrack){
			if(iTrack->pt() < leadingTrackPt) continue;

			double DR = deltaR(iJet->eta(),iTrack->eta(),
                                           iJet->phi(),iTrack->phi());
			if(DR > matchingCone) continue;
			if(iTrack->pt() > ptmax){
				ptmax = iTrack->pt();
				leadingTrack = iTrack;
			}
		}

		if(leadingTrack == iTrackEnd) continue;

		//isolation tracks
		int nIsolationTracks = 0;
		for(iTrack = iTrackBegin; iTrack != iTrackEnd; ++iTrack){
			if(iTrack->pt() < otherTrackPt) continue;

			if(iTrack->normalizedChi2() > chi2) continue;

			if(iTrack->numberOfValidHits() < hits) continue;

			double ipZ = iTrack->impactParameter().impactParameterZ().value();
			if(fabs(ipZ - PVz) > d_ipz ) continue;

			double ipT = iTrack->impactParameter().impactParameter2D().value();
			if(ipT > maxTransverseIp) continue;

			double DR = deltaR(leadingTrack->eta(),iTrack->eta(),
                                           leadingTrack->phi(),iTrack->phi());
			if(DR > isolationCone || DR < signalCone) nIsolationTracks++;
		}

		if(nIsolationTracks > 0) continue;

		HLTlikeTaus.push_back(&(*iJet));

	}

	return HLTlikeTaus;
}

