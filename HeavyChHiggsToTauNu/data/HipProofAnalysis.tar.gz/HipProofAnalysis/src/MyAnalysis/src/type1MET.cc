#include "MyAnalysis/interface/MyAnalysis.h"

MyMET MyAnalysis::type1MET(MyEvent* event,double jetEtCut,string correction){

	MyGlobalPoint type1METCorr;
	type1METCorr.name = "type1METCorrection";
	type1METCorr.x    = 0;
	type1METCorr.y    = 0;
	vector<MyJet> jets = event->getJets(correction);
	for(vector<MyJet>::const_iterator ijet = jets.begin();
                                          ijet!= jets.end(); ijet++){
		double corr = ijet->getCorrectionFactor(correction);
		if(ijet->Et()/corr > jetEtCut){
			type1METCorr.x += -ijet->Ex()/corr*(corr - 1);
			type1METCorr.y += -ijet->Ey()/corr*(corr - 1);
		}
	}

	MyMET etmTest   = event->getMET();
	etmTest.useCorrection("muonCorrection");

	etmTest.corrections.push_back(type1METCorr);
	etmTest.useCorrection("type1METCorrection");

	return etmTest;
}

MyMET MyAnalysis::type1METtau(MyEvent* event,vector<const MyJet*> taus,double jetEtCut,string correction){

        MyGlobalPoint type1METCorr;
        type1METCorr.name = "type1METCorrection";
        type1METCorr.x    = 0;
        type1METCorr.y    = 0;
        vector<MyJet> jets = event->getJets(correction);
        for(vector<MyJet>::const_iterator ijet = jets.begin();
                                          ijet!= jets.end(); ijet++){
                bool isTau = false;
		MyJet theTau;
                for(vector<const MyJet*>::const_iterator iTau = taus.begin();
                                                         iTau!= taus.end(); iTau++){
                        double DR = deltaR(ijet->Eta(),(*iTau)->Eta(),
                                           ijet->Phi(),(*iTau)->Phi());
                        if(DR < 0.4) {
				isTau = true;
				theTau = **iTau;
			}
                }

		double corr = 1;
		if(isTau){
                        corr = theTau.Et()/ijet->Et();
                }else{
                	corr = ijet->getCorrectionFactor(correction);
		}
               	if(ijet->Et()/corr > jetEtCut){

                       	type1METCorr.x += -ijet->Ex()/corr*(corr - 1);
                       	type1METCorr.y += -ijet->Ey()/corr*(corr - 1);
               	}
        }

        MyMET etmTest   = event->getMET();
        etmTest.useCorrection("muonCorrection");

        etmTest.corrections.push_back(type1METCorr);
        etmTest.useCorrection("type1METCorrection");

        return etmTest;
}
