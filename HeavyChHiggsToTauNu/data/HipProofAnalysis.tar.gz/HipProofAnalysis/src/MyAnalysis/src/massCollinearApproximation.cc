#include "MyAnalysis/interface/MyAnalysis.h"

double MyAnalysis::massCollinearApproximation(MyMET met,TLorentzVector tau1,TLorentzVector tau2){
        double  theMet[2];
                theMet[0] = met.getX();
                theMet[1] = met.getY();
        double theTau1[4];
                theTau1[0] = tau1.P();
                theTau1[1] = tau1.Px();
                theTau1[2] = tau1.Py();
                theTau1[3] = tau1.Pz();
        double theTau2[4];
                theTau2[0] = tau2.P();
                theTau2[1] = tau2.Px();
                theTau2[2] = tau2.Py();
                theTau2[3] = tau2.Pz();
	return massCollinearApproximation(theMet,theTau1,theTau2);
}

double MyAnalysis::massCollinearApproximation(double met[2],double tau1[4],double tau2[4]){

    const double pi = 3.1415926;
    double Exmiss = met[0];
    double Eymiss = met[1];
    double Etmiss = sqrt(Exmiss*Exmiss + Eymiss*Eymiss);

	//cout << "check met " << Exmiss << " " << Eymiss << " " << Etmiss << endl;
	//cout << "check tau1 " << tau1[0] << " " << tau1[1] << " " << tau1[2] << " " << tau1[3] << endl;
	//cout << "check tau2 " << tau2[0] << " " << tau2[1] << " " << tau2[2] << " " << tau2[3] << endl;

    // cos(tau1,tau2)
    double pT1 = sqrt(tau1[1]*tau1[1]+tau1[2]*tau1[2]);
    double pT2 = sqrt(tau2[1]*tau2[1]+tau2[2]*tau2[2]);
    double cosPhi = (tau1[1]*tau2[1] + tau1[2]*tau2[2])/(pT1*pT2);

    double phi = 999;
    if(fabs(cosPhi) < 1) phi = acos(cosPhi)*180/pi;

    double efm = -999;

    // set deltaPhi cut in analysis, not in mass reco
    if(phi < 180) {
      double Emiss_tau1,
             Emiss_tau2;
      if(Etmiss == 0){
        Emiss_tau1 = 0;
        Emiss_tau2 = 0;
      }else{
        // ET/sin_E1(-E2) = E1/sin_E2ET = E2/sin_E1ET
        double sin_E1E2 = (tau1[1]*tau2[2] - tau1[2]*tau2[1])/(pT1*pT2);
        double sin_E1ET = (tau1[1]*Eymiss  - tau1[2]*Exmiss)/(pT1*Etmiss);
        double sin_E2ET = (Exmiss*tau2[2]  - Eymiss*tau2[1])/(pT2*Etmiss);

        Emiss_tau1 = Etmiss*sin_E2ET/sin_E1E2;
        Emiss_tau2 = Etmiss*sin_E1ET/sin_E1E2;
      }

      Emiss_tau1 = fabs(Emiss_tau1);
      Emiss_tau2 = fabs(Emiss_tau2);


      double E_nu1 = 0;
      double E_nu2 = 0;
      double p_nu1[4],
             p_nu2[4];
      for(int i = 1; i < 4; i++){
        p_nu1[i] = tau1[i]/pT1*Emiss_tau1;
        p_nu2[i] = tau2[i]/pT2*Emiss_tau2;
        E_nu1   += p_nu1[i]*p_nu1[i];
        E_nu2   += p_nu2[i]*p_nu2[i];
      }
      p_nu1[0] = sqrt(E_nu1);
      p_nu2[0] = sqrt(E_nu2);

      double sum4vec[4];
      for(int i = 0; i < 4; i++){
        sum4vec[i] = p_nu1[i] + p_nu2[i] + tau1[i] + tau2[i];
      }
      efm = sum4vec[0]*sum4vec[0]
           -sum4vec[1]*sum4vec[1]
           -sum4vec[2]*sum4vec[2]
           -sum4vec[3]*sum4vec[3];
      if(efm > 0) efm = sqrt(efm);

    }
    return efm;
}

