#include "MyAnalysis/interface/MyAnalysis.h"

double deltaR(double,double,double,double);

bool MyAnalysis::electronVeto(MyEvent* event, double ptcut){

	bool decision = true;

        if(!histograms->booked("h_ptElectron") ) histograms->book("h_ptElectron",100,0,250);
        if(!histograms->booked("h_ptMcElectronFromW") ) histograms->book("h_ptMcElectronFromW",100,0,250);
        if(!histograms->booked("h_ptMcElectronFromW_selected") ) histograms->book("h_ptMcElectronFromW_selected",100,0,250);
        if(!histograms->booked("h_etaElectron") ) histograms->book("h_etaElectron",100,-5,5);
        if(!histograms->booked("h_ptIsolatedElectron") ) histograms->clone("h_ptIsolatedElectron","h_ptElectron");

        histograms->book("h_ptMcElectronFromW", 100, 0, 250);
        histograms->book("h_etaMcElectronFromW", 100, -5, 5);
        histograms->book("h_ptMcElectronFromWSelected", 100, 0, 250);
        histograms->book("h_etaMcElectronFromWSelected", 100, -5, 5);


	// leptons from W
        TLorentzVector mcElectronFromW(0,0,0,0);

	vector<MyMCParticle>::const_iterator mcBegin = event->mcParticles_begin();
        vector<MyMCParticle>::const_iterator mcEnd = event->mcParticles_end();

        for(vector<MyMCParticle>::const_iterator imc = mcBegin;
	                                         imc!= mcEnd; imc++){
            int mother1 = 0;
            if(imc->mother.size() > 0) mother1 = *(imc->mother_begin());
            if(abs(mother1) == 24) {
	         if(abs(imc->pid) == 11 ) { 
                         mcElectronFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P()); 
                         histograms->fill("h_ptMcElectronFromW", imc->Pt());
                         histograms->fill("h_etaMcElectronFromW", imc->Eta());
                 }
	    }
        }

        if( mcElectronFromW.Et() > 0 ) histograms->fill("h_ptMcElectronFromW",mcElectronFromW.Pt());

        for(vector<MyJet>::const_iterator iElectron = event->electrons_begin();
                                          iElectron != event->electrons_end(); iElectron++){
		eventCounter->addSubCount("electron cands, all");
                histograms->fill("h_ptElectron",iElectron->Pt());
                histograms->fill("h_etaElectron",iElectron->Eta());

	        double DRtauWenu = 999;
                if( mcElectronFromW.Et() > 0 ) DRtauWenu = deltaR(mcElectronFromW.Eta(),iElectron->Eta(),  mcElectronFromW.Phi(),iElectron->Phi()); 

                //if(!isolation(&(*iElectron), 0.3, 0, 2) ) continue;
                //eventCounter->addSubCount("electron cands, isol");
                if(!isolationSum(&(*iElectron), 0.3, 0, 0.8) ) continue;
                eventCounter->addSubCount("electron cands, sum isol");
                
                histograms->fill("h_ptIsolatedElectron",iElectron->Pt());

		if( iElectron->Pt() < ptcut ) continue;
		eventCounter->addSubCount("electron cands, ptcut");

//		if(!electronTag(*iElectron) ) continue;
//		eventCounter->addSubCount("electron cands, tagged");

		decision = false;

                if( DRtauWenu < 0.4 ) histograms->fill("h_ptMcElectronFromW_selected",mcElectronFromW.Pt());

		//vector<MyMCParticle> mcParticles = event->mcParticles;
		for(vector<MyMCParticle>::const_iterator imc = mcBegin;
		                                         imc!= mcEnd; imc++){
			if(abs(imc->pid) != 11) continue;
			double drElectrons = deltaR(iElectron->Eta(),imc->Eta(),
                                                    iElectron->Phi(),imc->Phi());
			if(drElectrons > 0.4) continue;
			eventCounter->addSubCount("electron cands, mc match");

			int mother1 = 0;
                        if(imc->mother.size() > 0) mother1 = *(imc->mother_begin());
			if(abs(mother1) != 24) continue;
			eventCounter->addSubCount("electron cands, mc e from W");

                        histograms->fill("h_ptMcElectronFromWSelected", imc->Pt());
                        histograms->fill("h_etaMcElectronFromWSelected", imc->Eta());
		}
        }
	return decision;
}



bool MyAnalysis::muonVeto(MyEvent* event, double ptcut){

        bool decision = true;

	if(!histograms->booked("h_ptMuon") ) histograms->book("h_ptMuon",100,0,250);
        if(!histograms->booked("h_etaMuon") ) histograms->book("h_etaMuon",100,-5,5);
	if(!histograms->booked("h_ptIsolatedMuon") ) histograms->clone("h_ptIsolatedMuon","h_ptMuon");
        if(!histograms->booked("h_ptMcMuonFromW") ) histograms->book("h_ptMcMuonFromW",100,0,250);
        if(!histograms->booked("h_ptMcMuonFromW_selected") ) histograms->book("h_ptMcMuonFromW_selected",100,0,250);
	// leptons from W
        TLorentzVector mcMuonFromW(0,0,0,0);
        //vector<MyMCParticle> mcParticles = event->mcParticles;
        vector<MyMCParticle>::const_iterator mcBegin = event->mcParticles_begin();
        vector<MyMCParticle>::const_iterator mcEnd = event->mcParticles_end();

        for(vector<MyMCParticle>::const_iterator imc = mcBegin;
	                                         imc!= mcEnd; imc++){
            int mother1 = 0;
            if(imc->mother.size() > 0) mother1 = *(imc->mother_begin());
            if(abs(mother1) == 24) {
	         if(abs(imc->pid) == 13 ) mcMuonFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());
	    }
        }

        if( mcMuonFromW.Et() > 0 ) histograms->fill("h_ptMcMuonFromW",mcMuonFromW.Pt());




        for(vector<MyJet>::const_iterator iMuon = event->muons_begin();
                                          iMuon != event->muons_end(); iMuon++){
                eventCounter->addSubCount("muon cands, all");
                histograms->fill("h_ptMuon",iMuon->Pt());
		histograms->fill("h_etaMuon",iMuon->Eta());

	        double DRmuonWmunu = 999;
                if( mcMuonFromW.Et() > 0 ) DRmuonWmunu = deltaR(mcMuonFromW.Eta(),iMuon->Eta(),mcMuonFromW.Phi(),iMuon->Phi()); 

                //if(!isolation(&(*iMuon)) ) continue;
                //eventCounter->addSubCount("muon cands, isolation");
		//histograms->fill("h_ptIsolatedMuon",iMuon->Pt());

                if( iMuon->Pt() < ptcut ) continue;
                eventCounter->addSubCount("muon cands, ptcut");

//              if(!muonTag(*iMuon) ) continue;
//                eventCounter->addSubCount("muon cands, tagged");

                decision = false;

                if( DRmuonWmunu < 0.4 ) histograms->fill("h_ptMcMuonFromW_selected",mcMuonFromW.Pt());

                //vector<MyMCParticle> mcParticles = event->mcParticles;
                for(vector<MyMCParticle>::const_iterator imc = mcBegin;
                                                         imc!= mcEnd; imc++){
                        if(abs(imc->pid) != 13) continue;
                        double drmuons = deltaR(iMuon->Eta(),imc->Eta(),
                                                    iMuon->Phi(),imc->Phi());
                        if(drmuons > 0.4) continue;
                        eventCounter->addSubCount("muon cands, mc match");

                        int mother1 = 0;
                        if(imc->mother.size() > 0) mother1 = *(imc->mother_begin());
                        if(abs(mother1) != 24) continue;
                        eventCounter->addSubCount("muon cands, mc mu from W");
                }
        }
        return decision;
}
