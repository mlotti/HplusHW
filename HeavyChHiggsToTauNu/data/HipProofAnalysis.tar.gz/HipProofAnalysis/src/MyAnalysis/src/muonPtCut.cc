#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::muonPtCut(MyEvent* event,double ptcut){

	vector<const MyJet*> selectedMuons;

	vector<MyJet>::const_iterator iMuonEnd = event->muons_end();
	
        for(vector<MyJet>::const_iterator iMuon = event->muons_begin();
	    iMuon != iMuonEnd; ++iMuon) {
                double eta = iMuon->eta();
		double pt  = iMuon->Pt();

		if(pt < ptcut || fabs(eta) > 2.5) continue;
		selectedMuons.push_back(&(*iMuon));
	}
	return selectedMuons;
}
