#include "MyAnalysis/interface/TauIdAnalysis.h"

#include <TMath.h>

#include <iostream>
using namespace std;

double deltaR(double, double, double, double);
double deltaPhi(double, double);

TauIdAnalysis::TauIdAnalysis() {
  // Open root file
  theRootFile = new TFile("TauIDAnalysis.root","RECREATE");
  theRootFile->SetCompressionLevel(1);
  theRootTree = new TTree("TauID","jets");
  theRootTree->SetAutoSave(1000000000);
  //theRootTree->Branch("jets","jets", &data, bufsize, split);
  // Make branches
  theRootTree->Branch("jetEt", &data.jetEt, "jetEt/F");
  theRootTree->Branch("jeteta", &data.jeteta, "jeteta/F");
  theRootTree->Branch("jetphi", &data.jetphi, "jetphi/F");
  theRootTree->Branch("jetTrackCount", &data.jetTrackCount, "jetTrackCount/I");
  theRootTree->Branch("jetTrackPtMin", &data.jetTrackPtMin, "jetTrackPtMin/F");
  
  theRootTree->Branch("matchingCone", &data.matchingCone, "matchingCone/F");
  theRootTree->Branch("signalCone", &data.signalCone, "signalCone/F");
  theRootTree->Branch("signalTracks", &data.signalTracks, "signalTracks/I");
  theRootTree->Branch("signalExcessPt", &data.signalExcessPt, "signalExcessPt/F");
  theRootTree->Branch("isolPt", &data.isolPt, "isolPt/F");
  theRootTree->Branch("isolTracks", &data.isolTracks, "isolTracks/I");
  theRootTree->Branch("isolMinHits", &data.isolMinHits, "isolMinHits/I");
  theRootTree->Branch("isolMaxHits", &data.isolMaxHits, "isolMaxHits/I");
  theRootTree->Branch("isolMinPt", &data.isolMinPt, "isolMinPt/F");
  theRootTree->Branch("isolMaxPt", &data.isolMaxPt, "isolMaxPt/F");
  theRootTree->Branch("isolMinDr", &data.isolMinDr, "isolMinDr/F");
  theRootTree->Branch("isolMaxDr", &data.isolMaxDr, "isolMaxDr/F");
  
  theRootTree->Branch("ldgPt", &data.ldgPt, "ldgPt/F");
  theRootTree->Branch("ldgeta", &data.ldgeta, "ldgeta/F");
  theRootTree->Branch("ldgphi", &data.ldgphi, "ldgphi/F");
  theRootTree->Branch("ldgHits", &data.ldgHits, "ldgHits/I");
  theRootTree->Branch("ldgChi2", &data.ldgChi2, "ldgChi2/F");
  theRootTree->Branch("ldgHitChi2", &data.ldgHitChi2, "ldgHitChi2/F");
  theRootTree->Branch("ldgHitChi2Radius", &data.ldgHitChi2Radius, "ldgHitChi2Radius/F");
  theRootTree->Branch("ldgIpz", &data.ldgIpz, "ldgIpz/F");
  theRootTree->Branch("ldgIpt", &data.ldgIpt, "ldgIpt/F");
  theRootTree->Branch("ldgIp3D", &data.ldgIp3D, "ldgIp3D/F");
  theRootTree->Branch("ldgIp3DSig", &data.ldgIp3DSig, "ldgIp3DSig/F");
  
  theRootTree->Branch("ecalIsolEt", &data.ecalIsolEt, "ecalIsolEt/F");
  theRootTree->Branch("hcalEt", &data.hcalEt, "hcalEt/F");
  theRootTree->Branch("ecalEt", &data.ecalEt, "ecalEt/F");
  theRootTree->Branch("totalEt", &data.totalEt, "totalEt/F");
  theRootTree->Branch("hcalRatio", &data.hcalRatio, "hcalRatio/F");
  theRootTree->Branch("energyRatio", &data.energyRatio, "energyRatio/F");
  theRootTree->Branch("rtau", &data.rtau, "rtau/F");
  theRootTree->Branch("rtauT", &data.rtauT, "rtauT/F");
  
  theRootTree->Branch("ldgPid", &data.ldgPid, "ldgPid/I");
  theRootTree->Branch("istau", &data.istau, "istau/I");
  theRootTree->Branch("tauprongs", &data.tauprongs, "tauprongs/I");
  theRootTree->Branch("taugammas", &data.taugammas, "taugammas/I");
  theRootTree->Branch("tauDecayType", &data.tauDecayType, "tauDecayType/I");
  theRootTree->Branch("tautype", &data.tautype, "tautype/I");
  theRootTree->Branch("qtype", &data.qtype, "qtype/I");
  theRootTree->Branch("passedtau", &data.passedtau, "passedtau/I");

  theRootTree->Branch("ldge4", &data.ldge4, "ldge4/F");
  theRootTree->Branch("ldge6", &data.ldge6, "ldge6/F");
  theRootTree->Branch("ldge8", &data.ldge8, "ldge8/F");
  theRootTree->Branch("ldge10", &data.ldge10, "ldge10/F");
  theRootTree->Branch("mass4", &data.mass4, "mass4/F");
  theRootTree->Branch("mass6", &data.mass6, "mass6/F");
  theRootTree->Branch("mass8", &data.mass8, "mass8/F");
  theRootTree->Branch("mass10", &data.mass10, "mass10/F");
  theRootTree->Branch("mass", &data.mass, "mass/F");
  
  theRootTree->Branch("chargeSum", &data.chargeSum, "chargeSum/I");
  theRootTree->Branch("ptSum", &data.ptSum, "ptSum/F");
  theRootTree->Branch("deltaE", &data.deltaE, "deltaE/F");
  theRootTree->Branch("ctau", &data.ctau, "ctau/F");
  theRootTree->Branch("minPt", &data.minPt, "minPt/F");
  theRootTree->Branch("minIpt", &data.minIpt, "minIpt/F");
  theRootTree->Branch("maxIpt", &data.maxIpt, "maxIpt/F");
  theRootTree->Branch("minIp3D", &data.minIp3D, "minIp3D/F");
  theRootTree->Branch("minIp3Dsig", &data.minIp3Dsig, "minIp3Dsig/F");
  theRootTree->Branch("maxIpz", &data.maxIpz, "maxIpz/F");
  theRootTree->Branch("maxChi2", &data.maxChi2, "maxChi2/F");
  theRootTree->Branch("maxHitChi2", &data.maxHitChi2, "maxHitChi2/F");
  theRootTree->Branch("maxHitChi2Radius", &data.maxHitChi2Radius, "maxHitChi2Radius/F");
  theRootTree->Branch("multipleTrackRtau", &data.multipleTrackRtau, "multipleTrackRtau/F");
  theRootTree->Branch("flightpathSig", &data.flightpathSig, "flightpathSig/F");
  theRootTree->Branch("flightpath", &data.flightpath, "flightpath/F");
  theRootTree->Branch("flightpathT", &data.flightpathT, "flightpathT/F");
  
  theRootTree->Branch("evt", &data.evt, "evt/I");

  
  cout << "Opened file TauIDAnalysis.root for writing" << endl;
  
  for (int i = 0; i < TAUID_COUNTERS; ++i) fPassTable[i] = 0;
}

TauIdAnalysis::~TauIdAnalysis() {
  // Close root file
  cout << "Root tree contains " << theRootTree->GetEntries() 
       << " entries" << endl;
  theRootFile->cd();
  theRootTree->Write();
  //theRootTree->Print();
  theRootFile->ls();
  theRootFile->Close();
  delete theRootFile;
  cout << "Closed file TauIDAnalysis.root" << endl;
  
  // Save pass numbers to a file
  ofstream myOutput("TauIDAnalysis.txt");
  for (int i = 0; i < TAUID_COUNTERS; ++i) {
    myOutput << fPassTable[i] << endl;
  }
  myOutput.close(); 
}

void TauIdAnalysis::clear() {  
  // These should be set to some value in analysis, but let's clear them just to make sure ...
  data.jetEt = 0.0;        // jet parameters
  data.jeteta = 0.0;
  data.jetphi = 0.0;
  data.jetTrackCount = 0;
  data.jetTrackPtMin = 0.0;
  data.matchingCone = 0.0; // tracker isolation parameters
  data.signalCone = 0.0;
  data.isolPt = 0.0;       // combined pt of isolated tracks
  data.signalTracks = 0;
  data.signalExcessPt = 0;
  data.isolTracks = 0;
  data.isolMinHits = 0;
  data.isolMaxHits = 0;
  data.isolMinPt = 0.0;
  data.isolMaxPt = 0.0;
  data.isolMinDr = 0.0;
  data.isolMaxDr = 0.0;
  data.ldgPt = 0.0;        // leading track parameters
  data.ldgeta = 0.0;
  data.ldgphi = 0.0;
  data.ldgHits = 0;
  data.ldgChi2 = 0.0;
  data.ldgHitChi2 = 0.0;
  data.ldgHitChi2Radius = 0;
  data.ldgIpz = 0.0;
  data.ldgIpt = 0.0;
  data.ldgIp3D = 0.0;
  data.ldgIp3DSig = 0.0;
  data.ecalIsolEt = 0.0;        // ECAL isolation parameters
  data.hcalEt = 0.0;
  data.ecalEt = 0.0;
  data.hcalRatio = 0.0;
  data.energyRatio = 0.0;
  data.rtau = 0.0;  
  data.rtauT = 0.0;
  
  data.chargeSum = 0;
  data.ptSum = 0.0;
  data.deltaE = 0.0;
  data.ctau = 0.0;
  data.minPt = 0.0;
  data.minIpt = 0.0;
  data.maxIpt = 0.0;
  data.minIp3D = 0.0;
  data.maxIp3D = 0.0;
  data.minIp3Dsig = 0.0;
  data.maxIp3Dsig = 0.0;
  data.minIpz = 0.0;
  data.maxIpz = 0.0;
  data.maxChi2 = 0.0;
  data.maxHitChi2 = 0.0;
  data.maxHitChi2Radius = 0.0;
  data.multipleTrackRtau = 0.0;
  data.flightpathSig = 0.0;
  data.flightpath = 0.0;
  data.flightpathT = 0.0;
  
  data.ldgPid = 0;
  data.istau = 0;
  data.tauprongs = 0;
  data.taugammas = 0;
  data.tauDecayType = 0;
  data.tautype = 0;
  data.qtype = 0;
  data.passedtau = 0;

  data.ldge4 = 0;
  data.ldge6 = 0;
  data.ldge8 = 0;
  data.ldge10 = 0;
  data.mass = 0;
  data.mass4 = 0;
  data.mass6 = 0;
  data.mass8 = 0;
  data.mass10 = 0;
  
  data.evt = 0;
}

void TauIdAnalysis::analyze(RecoTauJetCandidate* tau, Cuts* cuts, bool passed, int evt) {
  clear();

  data.evt = evt;
  data.passedtau = passed;
    
  // jet
  data.jetEt = tau->fJetEt;
  data.jeteta = tau->fJeteta;
  data.jetphi = tau->fJetphi;
  data.jetTrackCount = tau->fSignalTrackNumber + tau->fIsolationTrackNumber;
  data.jetTrackPtMin = -1;
  // isolation
  data.matchingCone = -1;
  data.signalCone = -1;
  data.signalTracks = tau->fSignalTrackNumber;
  data.signalExcessPt = tau->fSignalConeExcessPt;
  data.isolTracks = tau->fIsolationTrackNumber;
  data.isolMinHits = tau->fIsolationMinHits;
  data.isolMaxHits = tau->fIsolationMaxHits;
  data.isolMinPt = tau->fIsolationMinPt;
  data.isolMaxPt = tau->fIsolationMaxPt;
  data.isolMinDr = tau->fIsolationMinDr;
  data.isolMaxDr = tau->fIsolationMaxDr;
  data.isolPt = tau->fIsolationPt;
  // Leading track
  data.ldgPt = tau->fLdgPt;
  data.ldgphi = tau->fLdgphi;
  data.ldgeta = tau->fLdgeta;
  data.ldgHits = tau->fLdgHits;
  data.ldgChi2 = tau->fLdgChi2;
  data.ldgHitChi2 = tau->fLdgMaxHitChi2;
  data.ldgHitChi2Radius = tau->fLdgMaxHitChi2Radius;
  data.ldgIpz = tau->fLdgIpz;
  data.ldgIpt = tau->fLdgIpt;
  data.ldgIp3D = tau->fLdgIp3D;
  data.ldgIp3DSig = tau->fLdgIp3Dsig;
  // calorimetry
  data.ecalIsolEt = tau->fEcalIsolEt;
  data.hcalEt = tau->fHcalEt;
  data.ecalEt = tau->fEcalEt;
  data.totalEt = tau->fTotalEt;
  data.hcalRatio = tau->fHcalRatio;
  data.energyRatio = tau->fTotalRatio;
  data.rtau = tau->fRtau;
  data.rtauT = tau->fRtauT;
  // multiple tracks
  data.chargeSum = tau->fChargeSum;
  data.ptSum = tau->fPtSum;
  data.deltaE = tau->fDeltaE;
  data.ctau = tau->fctau;
  data.minPt = tau->fMinPt;
  data.minIpt = tau->fMinIpt;
  data.maxIpt = tau->fMaxIpt;
  data.minIp3D = tau->fMinIp3D;
  data.maxIp3D = tau->fMaxIp3D;
  data.minIp3Dsig = tau->fMinIp3Dsig;
  data.maxIp3Dsig = tau->fMaxIp3Dsig;
  data.minIpz = tau->fMinIpz;
  data.maxIpz = tau->fMaxIpz;
  data.maxChi2 = tau->fMaxChi2;
  data.maxHitChi2 = tau->fMaxHitChi2;
  data.maxHitChi2Radius = tau->fMaxHitChi2Radius;
  data.multipleTrackRtau = tau->fMultipleTrackRtau;
  data.flightpathSig = tau->fFlightpathSig;
  data.flightpath = tau->fFlightpath;
  data.flightpathT = tau->fFlightpathT;
  
  // MC info
  data.tauDecayType = 0;
  data.tautype = 0;
  if (tau->isMCtau()) {
    data.istau = 1;
    if (tau->getMCTau()->decaysToElectrons()) data.tautype += 1;
    if (tau->getMCTau()->decaysToMuons()) data.tautype += 2;
    if (tau->getMCTau()->decaysSemiLeptonically()) data.tautype += 4;
    if (tau->getMCTau()->decaysToHadrons()) data.tautype += 8;
    if (tau->getMCTau()->gammaCount() >= 2) data.tautype += 16;
    if (tau->getMCTau()->originatesFromZ()) { data.tauDecayType += 1; }
    if (tau->getMCTau()->originatesFromW()) { data.tauDecayType += 2; }
    if (tau->getMCTau()->originatesFromHplus()) { data.tauDecayType += 4; }
    data.tauprongs = tau->getMCTau()->prongs();
    data.taugammas = tau->getMCTau()->gammaCount();
    data.ldgPid = tau->getMCTau()->ldgPid();
  } else {
    data.istau = 0;
    data.tautype = 0;
    data.tauprongs = 0;
    data.taugammas = 0;
    data.ldgPid = 0;
  }
  data.qtype = 0;
  if (tau->isMCQCD()) {
    if (tau->getMCQCDJet()->isudsJet()) { data.qtype = 1; }
    if (tau->getMCQCDJet()->iscJet()) { data.qtype = 2; }
    if (tau->getMCQCDJet()->isbJet()) { data.qtype = 3; }
    if (tau->getMCQCDJet()->isgJet()) { data.qtype = 5; }
  }
  
  data.ldge4 = tau->fLdgEnergy004;
  data.ldge6 = tau->fLdgEnergy006;
  data.ldge8 = tau->fLdgEnergy008;
  data.ldge10 = tau->fLdgEnergy010;
  data.mass4 = tau->fInvMass004;
  data.mass6 = tau->fInvMass006;
  data.mass8 = tau->fInvMass008;
  data.mass10 = tau->fInvMass010;
  data.mass = tau->fInvMass;

  // fill data to root file
  fillTree();
}


void TauIdAnalysis::fillTree() {
  theRootFile->cd();
  theRootTree->Fill();
}

void TauIdAnalysis::updateCounter(bool* pass) {
  // Update pass table
  for (int i = 0; i < TAUID_COUNTERS; ++i) {
    if (pass[i]) ++fPassTable[i];
  }
}
