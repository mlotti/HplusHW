#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::triggerLeptons(MyEvent* event){

	bool decision = false;

	if(!histograms->booked("h_triggerLepton_pt")) histograms->book("h_triggerLepton_pt",100,0,100);

	int triggerMuons     = 0;
        int triggerElectrons = 0;

	vector<MyJet>::const_iterator iMuonEnd = event->muons_end();
	for(vector<MyJet>::const_iterator iMuon = event->muons_begin();
	    iMuon != iMuonEnd; ++iMuon) {
//cout << "muons " << i->Et() << " " << i->eta() << " " << i->phi() << endl;
		eventCounter->addCount("    trigger muon all");

		if(iMuon->Et() < 19) continue;
                eventCounter->addCount("    trigger muon pt");

		if(!isolation(&(*iMuon))) continue;
                eventCounter->addCount("    trigger muon isol");

                triggerMuons++;
                histograms->fill("h_triggerLepton_pt",iMuon->Et());
	}

	vector<MyJet>::const_iterator iElectronEnd = event->muons_end();
	for(vector<MyJet>::const_iterator iElectron = event->muons_begin();
	    iElectron != iElectronEnd; ++iElectron) {
//cout << "electrons " << i->Et() << " " << i->eta() << " " << i->phi() << endl;
                eventCounter->addCount("    trigger electron all");

                if(iElectron->Et() < 26) continue;
                eventCounter->addCount("    trigger electron pt");

                if(!isolation(&(*iElectron))) continue;
                eventCounter->addCount("    trigger electron isol");

                triggerElectrons++;
                histograms->fill("h_triggerLepton_pt",iElectron->Et());
        }
//cout << "MyAnalysis::triggerLeptons leptons size " << muons.size() + electrons.size() << endl;
	if(triggerMuons == 1) eventCounter->addCount("    trigger muon pass");
        if(triggerElectrons == 1) eventCounter->addCount("    trigger electron pass");

        if(triggerMuons > 0 || triggerElectrons > 0) eventCounter->addCount("    trigger passed");

	if(triggerMuons == 1 || triggerElectrons == 1) decision = true;
////    if(triggerMuons == 0 || triggerElectrons == 1) decision = true;
	return decision;
}

