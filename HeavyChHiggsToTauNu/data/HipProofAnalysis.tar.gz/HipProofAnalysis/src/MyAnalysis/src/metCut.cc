#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::metCut(MyMET theMET) {

	double met   = theMET.value();

	if(!histograms->booked("h_met") ) histograms->book("h_met",100,0,500);
        histograms->fill("h_met",met);

        cuts->bookGreaterThanCut("MET", 100);
        return cuts->applyCut("MET", met);
}
