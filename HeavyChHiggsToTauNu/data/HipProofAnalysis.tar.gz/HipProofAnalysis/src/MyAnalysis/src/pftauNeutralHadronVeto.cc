#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::pftauNeutralHadronVeto(vector<const MyJet*> taus){
        vector<const MyJet*> selectedTaus;

        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){

		MyTrack leadingTrack = (*i)->leadingTrack();

		bool neutralsFound = false;

		vector<MyTrack>::const_iterator iTrackEnd = (*i)->tracks_end();
		for(vector<MyTrack>::const_iterator iTrack = (*i)->tracks_begin();
                                                    iTrack!= iTrackEnd; ++iTrack){
                        //if(iTrack->Pt() < 1) continue;
                        if(iTrack->Pt() < 2) continue;
			if(fabs(iTrack->pfType()) != 5) continue;
			double DR = deltaR(leadingTrack.eta(),iTrack->eta(),  
                                           leadingTrack.phi(),iTrack->phi());
			if(DR > cuts->getCutValue("isolationCone")) continue;
			neutralsFound = true;
		}

		if(neutralsFound) continue;
		eventCounter->addSubCount("tau pf neutral hadron rejection");

		selectedTaus.push_back(*i);
        }

	return selectedTaus;
}

