#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::muonSelection(MyEvent* event){

	vector<const MyJet*> muons;

	histograms->book("h_muonPt",100,0,250);
	histograms->book("h_muonEta",100,-5,5);
	histograms->book("h_muonChi2",100,0,50);
	histograms->book("h_muonIp2D",100,-5,5);
	histograms->book("h_muonIpz",100,-5,5);

        histograms->book("h_ptMcMuonFromW", 100, 0, 250);
        histograms->book("h_etaMcMuonFromW", 100, -5, 5);

        histograms->book("h_ptMcMuonFromWSelected", 100, 0, 250);
        histograms->book("h_etaMcMuonFromWSelected", 100, -5, 5);

        vector<const MyMCParticle *> mcMuonsFromW;
        for(vector<MyMCParticle>::const_iterator imc = event->mcParticles_begin();
            imc != event->mcParticles_end(); ++imc) {
                
                int mother = 0;
                if(imc->mother.size() > 0)
                        mother = imc->mother[0];
                if(abs(mother) == 24) { // W
                        if(abs(imc->pid) == 13) { // muon
                                histograms->fill("h_ptMcMuonFromW", imc->Pt());
                                histograms->fill("h_etaMcMuonFromW", imc->Eta());
                                mcMuonsFromW.push_back(&(*imc));
                        }
                }
        }

	vector<MyJet>::const_iterator iMuonEnd = event->muons_end();
	
        for(vector<MyJet>::const_iterator iMuon = event->muons_begin();
	    iMuon != iMuonEnd; ++iMuon) {
                eventCounter->addSubCount("muon all muons");

		histograms->fill("h_muonPt",iMuon->Pt());
		histograms->fill("h_muonEta",iMuon->eta());

		bool isolated = isolation(&(*iMuon),cuts->getCutValue("leptonIsolCone"),0);
                if(!isolated) continue;
                eventCounter->addSubCount("muon isolated muons");

		if( iMuon->Pt() < cuts->getCutValue("muonPtCut")) continue;
		eventCounter->addSubCount("muon pt cut ");

		MyTrack muon = iMuon->leadingTrack();

		double muonChi2 = muon.normalizedChi2();
		histograms->fill("h_muonChi2",muonChi2);
                if(!cuts->applyCut("muonChi2Cut", muonChi2)) continue;
		eventCounter->addSubCount("muon muonChi2Cut");

		double muonIp2D = muon.impactParameter().impactParameter2D().value();
		histograms->fill("h_muonIp2D",muonIp2D);
                if(!cuts->applyCut("muonIp2DCut", fabs(muonIp2D))) continue;
		eventCounter->addSubCount("muon muonIp2DCut");

		double muonIpz = muon.impactParameter().impactParameterZ().value();
                histograms->fill("h_muonIpz",muonIpz);
                if(!cuts->applyCut("muonIpzCut", fabs(muonIpz))) continue;
		eventCounter->addSubCount("muon muonIpzCut");

		muons.push_back(&(*iMuon));
	}

        for(vector<const MyJet *>::const_iterator iMuon = muons.begin(); iMuon != muons.end(); ++iMuon) {
                for(vector<const MyMCParticle *>::const_iterator imc = mcMuonsFromW.begin(); imc != mcMuonsFromW.end(); ++imc) {
                        const MyJet *recoMuon = *iMuon;
                        const MyMCParticle *mcMuon = *imc;

                        double DR = deltaR(recoMuon->eta(), mcMuon->Eta(),
                                           recoMuon->phi(), mcMuon->Phi());

                        if(DR < 0.2) {
                                histograms->fill("h_ptMcMuonFromWSelected", mcMuon->Pt());
                                histograms->fill("h_etaMcMuonFromWSelected", mcMuon->Eta());
                        }
                }
        }

	return muons;
}
