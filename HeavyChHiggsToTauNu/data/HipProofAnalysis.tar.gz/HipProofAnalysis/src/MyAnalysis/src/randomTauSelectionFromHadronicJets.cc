#include "MyAnalysis/interface/MyAnalysis.h"

MyJet MyAnalysis::randomTauSelectionFromHadronicJets(MyEvent* event, double etcut){

	vector<MyJet> hadronicJets = event->getJets("MCJetCorrectorMcone5");
	vector<const MyJet*> jets;
	for(vector<MyJet>::const_iterator iJet = hadronicJets.begin();
                                          iJet!= hadronicJets.end(); ++iJet){
                jets.push_back(&(*iJet));
        }
	
	return randomTauSelection(jets,etcut);
}


MyJet MyAnalysis::randomTauSelectionFromTauCandidateJets(MyEvent* event, double etcut, string tauType){

        vector<const MyJet*> tauCandidates = tauEnergyCorrectionSelection(event,tauType);
	return randomTauSelection(tauCandidates,etcut);
}

MyJet MyAnalysis::randomTauSelection(vector<const MyJet*> jets, double etcut){

        double max = 0;
        int i = 0;
        int njets = 0;
        vector<const MyJet*>::const_iterator selected = jets.end();
        for(vector<const MyJet*>::const_iterator iJet = jets.begin();
                                                 iJet!= jets.end(); iJet++){
                if((*iJet)->Et() < etcut) continue;
                if(!cuts->applyCut("tauEtaCut", fabs((*iJet)->Eta()))) continue;

                njets++;

                double randomNumber = randomGenerator->Rndm(i++);
                if(randomNumber > max){
                        max = randomNumber;
                        selected = iJet;
                }
        }
        histograms->book("h_NrandomTauCandidates",50,0,20);
        histograms->fill("h_NrandomTauCandidates",njets);

        MyJet theTau(0,0,0,0);
        if(selected != jets.end()){
                theTau = **selected;

                histograms->book("h_randomTauJetEt",100,0,500);
                histograms->fill("h_randomTauJetEt",theTau.Et());

                histograms->book("h_randomTauJetEta",100,-5,5);
                histograms->fill("h_randomTauJetEta",theTau.Eta());
        }
        return theTau;
}
