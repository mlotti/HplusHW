#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::njets(MyEvent* event){

	vector<MyJet> jets = event->getJets();

	int nJets = 0;

	vector<MyJet>::const_iterator iJet;
	for(iJet = jets.begin(); iJet != jets.end(); iJet++){
                if(!cuts->applyCut("jetEtaCut", fabs(iJet->eta()))) continue;
                if(!cuts->applyCut("jetEtCut", iJet->Et())) continue;
		if(iJet->getTracks().size() == 0) continue;
		nJets++;
cout << "jet et,eta,phi,ntracks,discr " << iJet->Et() << " " 
<< iJet->Eta() << " "
<< iJet->Phi() << " "
<< iJet->getTracks().size() << " "
<< iJet->tag("discriminator") << endl;
	}

        if(!histograms->booked("h_njets")) histograms->book("h_njets",10,0,10);
        histograms->fill("h_njets",nJets);	

        return cuts->applyCut("nJetsCut", nJets);
}
