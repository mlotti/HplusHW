#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::pfChargedIsolation(vector<const MyJet*> taus,double PVz){

        vector<const MyJet*> selectedTaus;

        if(!histograms->booked("h_leadingTrackPt") ) histograms->book("h_leadingTrackPt",100,0,500);

        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){

             // option 1
		MyTrack leadingTrack = (*i)->leadingTrack(cuts->getCutValue("matchingCone"));

		histograms->fill("h_leadingTrackPt",leadingTrack.Pt());
		//		cout << " pf track pt " << leadingTrack.Pt() << "id " <<  leadingTrack.pfType() << endl;
                if(leadingTrack.charge() == 0) continue;

		if(leadingTrack.Pt() < cuts->getCutValue("leadingTrackPtCut")) continue;
                eventCounter->addSubCount("tau pf leading track");


                bool isolated = isolation(&(**i),cuts->getCutValue("isolationCone"),cuts->getCutValue("signalCone"),cuts->getCutValue("isolationTrackPt") );

                if(!isolated) continue;
                eventCounter->addSubCount("tau pf isolation");

	     // option 2
		/*
		bool isolated = (*i)->tag("d_trackIsolation"); // for pftaus also "d_pftrackIsolation"

                if(!isolated) continue;
                eventCounter->addSubCount("pf_isolation tau isolation(d)");
		*/

                selectedTaus.push_back(*i);
        }
	return selectedTaus;
}
