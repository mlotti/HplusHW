#include "MyAnalysis/interface/MCRecoQCDJet.h"

#include <TMath.h>
#include <iostream>

double deltaR(double, double, double, double);

MCRecoQCDJet::MCRecoQCDJet(MyEvent* event, const MyJet* jet) {
  using namespace TMath;
  
  vector<const MyMCParticle*> myCandidates;  
  
  vector<MyMCParticle>::const_iterator iMCEnd = event->mcParticles_end();
  for (vector<MyMCParticle>::const_iterator iMC = event->mcParticles_begin(); iMC != iMCEnd; ++iMC) {
    int myAbsPid = Abs(iMC->pid);
    if ((myAbsPid >= 1 && myAbsPid <= 5) || myAbsPid == 21) myCandidates.push_back(&(*iMC));
  }
  // Find best matching MC candidate to the jet in terms of deltaR
  double myMatchValue = 9999;
  const MyMCParticle* myMatchedJet = 0;
  for (vector<const MyMCParticle*>::const_iterator iMC = myCandidates.begin(); iMC != myCandidates.end(); ++iMC) {
    double myDeltaR = deltaR((*iMC)->eta(), jet->eta(), (*iMC)->phi(), jet->phi());
    if (myDeltaR < myMatchValue) {
      myMatchValue = myDeltaR;
      myMatchedJet = *iMC;
    }
  }
  if (myMatchValue > 0.20) {
    fFoundStatus = false;
    return;
  }
  fFoundStatus = true;
  fJet = *myMatchedJet;
  fPid = myMatchedJet->pid;

  // Collect energy

  // implement later

}


MCRecoQCDJet::~MCRecoQCDJet() {
  
}

void MCRecoQCDJet::print() {
  if (isQCDJet()) {
    cout << "Object is a MC ";
    switch (fPid) {
    case 1: cout << "u"; break;
    case 2: cout << "d"; break;
    case 3: cout << "s"; break;
    case 4: cout << "c"; break;
    case 5: cout << "b"; break;
    case 21: cout << "g"; break;
    }
    cout << "-jet, eta=" << fJet.Eta() << ", phi=" << fJet.Phi() << " pt=" << fJet.Perp() << endl;  
  } else {
    cout << "  object does not match to a QCD jet" << endl;
  }
}
