#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::tauSecondaryVertexCut(MyJet& tau){

	vector<MyVertex> vertices = tau.getSecVertices();

	if(vertices.size() == 0) return false;

	MyVertex secVertex = *(tau.getSecVertices().begin());
	double signif = secVertex.significance();

        histograms->book("h_tauSecVertexSignif",100,0,500);
        histograms->fill("h_tauSecVertexSignif",signif);

        cuts->bookGreaterThanCut("tauSecVertexSignif", 0);
        return cuts->applyCut("tauSecVertexSignif", signif);
}
