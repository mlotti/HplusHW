#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::tauMETtriggerEmulator(MyEvent* event){
        bool triggerDecision = triggerTausFound(event);
	if(!triggerDecision) return false;

	MyMET rawMET = event->getMET();
	rawMET.useCorrection("none");
        if(!cuts->applyCut("triggerMETcut", rawMET.value())) triggerDecision = false;
	return triggerDecision;
}
