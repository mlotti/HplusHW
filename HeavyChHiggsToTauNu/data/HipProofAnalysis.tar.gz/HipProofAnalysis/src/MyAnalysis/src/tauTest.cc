#include "MyAnalysis/interface/MyAnalysis.h"
vector<const MyJet*> MyAnalysis::tauTest(vector<const MyJet*> taus, double PVz,string tauType){
        vector<const MyJet*> selectedTaus;

        if(!histograms->booked("h_tauTracks") ) histograms->book("h_tauTracks",50,0,50);
        if(!histograms->booked("h_Rtau_nocuts") ) histograms->book("h_Rtau_nocuts",100,0,1.5);
        if(!histograms->booked("h_etaTauCandidates") ) histograms->book("h_etaTauCandidates",100,-5,5);
        if(!histograms->booked("h_etTauCandidates") ) histograms->book("h_etTauCandidates",100,0,500);
        if(!histograms->booked("h_pfElectrons") ) histograms->book("h_pfElectrons",100,0,200);

        vector<const MyJet*>::const_iterator i;
        for(i = taus.begin(); i!= taus.end(); ++i){

                eventCounter->addSubCount("tautest  tau-jet candidates");  
 
                vector<MyTrack> tauTracks = (*i)->getTracks(); 
		//                histograms->fill("h_tauTracks",tauTracks.size());
                histograms->fill("h_etaTauCandidates",(*i)->eta());
                histograms->fill("h_etTauCandidates",(*i)->Et());

                if ( (*i)->E() > 0 ) {
                   double rtau = (*i)->leadingTrack(cuts->getCutValue("matchingCone")).E()/(*i)->E();;
	           histograms->fill("h_Rtau_nocuts",rtau);
                }

          
	        vector<MyTrack>::const_iterator iTrackEnd = (*i)->tracks_end();
	        vector<MyTrack>::const_iterator iTrackBegin = (*i)->tracks_begin();
                MyTrack leadingTrack = (*i)->leadingTrack(cuts->getCutValue("matchingCone"));
	        
	        for(vector<MyTrack>::const_iterator iTrack = iTrackBegin;
	                                            iTrack != iTrackEnd; ++iTrack) {
		  //		   cout << " track in tau cand " << iTrack->pfType() << " iTrack->pt() " <<  iTrack->pt() << endl;
                     if(fabs(iTrack->pfType()) == 2) histograms->fill("h_pfElectrons",iTrack->pt());
	        }
              
                selectedTaus.push_back(*i);
	}
	return selectedTaus;
}
