#include "MyAnalysis/interface/MyAnalysis.h"

vector<MyJet> MyAnalysis::recalculatePFlowEnergyUsingPFtracks(MyEvent* event){
	vector<MyJet> newTaus;

	vector<MyJet> taus = event->getPFTaus();
	vector<MyJet>::const_iterator i;
	for(i = taus.begin(); i!= taus.end(); i++){

		vector<MyTrack> pflowTracks = i->getTracks();
                MyTrack leadingPFTrack;
                MyTrack momentum(0,0,0,0);
		//                  cout << " pflow tracks " << pflowTracks.size() << endl;
		vector<MyTrack>::const_iterator itrack;
                for(itrack = pflowTracks.begin();
                    itrack!= pflowTracks.end(); itrack++){
	        	//double pt = itrack->pt();
                       	//double pftype = itrack->pfType();
                       	//double charge = itrack->charge();
		        //cout << " pf track pt " << pt <<  " pftype "  << itrack->pfType() << " charge " << charge << endl;
                       	double DR=deltaR( i->eta(),itrack->eta(),
                                          i->phi(),itrack->phi()); 
	               	if( DR < 0.5) {
				momentum += *itrack;
		       	}   
                } 

		MyJet newTau = *i;
		newTau.setP4(momentum);
		newTaus.push_back(newTau);
	}
	return newTaus;
}

