#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::isolation(const MyJet *lepton, double isolationCone, double signalCone, double ptmin){

        bool isolated = false;

	double matchingCone = cuts->getCutValue("matchingCone");
	//	double ptmin        = cuts->getCutValue("isolationTrackPt");
	double dzip         = cuts->getCutValue("track_Zip");

        int tracks_in_cone = 0;

	vector<MyTrack>::const_iterator iTrackEnd = lepton->tracks_end();
	vector<MyTrack>::const_iterator iTrackBegin = lepton->tracks_begin();
////	if( iTrackBegin != iTrackEnd ) return false;

        MyTrack leadingTrack = lepton->leadingTrack(matchingCone);
	if(leadingTrack.pt() == 0) return false;

	for(vector<MyTrack>::const_iterator iTrack = iTrackBegin;
	    iTrack != iTrackEnd; ++iTrack) {
                if(iTrack->charge() == 0) continue;
		if(iTrack->pt() < ptmin) continue;

		double z = fabs(iTrack->impactParameter().impactParameterZ().value());
		if(z > dzip) continue;

		double DR = deltaR(leadingTrack.eta(),iTrack->eta(),
                                   leadingTrack.phi(),iTrack->phi());
		if(DR < isolationCone && DR > signalCone ) tracks_in_cone++;
                //if(DR < isolationCone) tracks_in_cone++;
	}

        /**
         * Why the isolation must be done with signalCone < DR < isolationCone (isolation 1) 
         * with muons, and not with DR < isolationCone (isolation 2)?
         *
         * It can happen (and happens, with W+3jet tail data) that the
         * z (or pt) cut removes the leading track of muon, but there
         * exists another track with 0 < DR < 0.3. In this case the
         * isolation 2 gives false positive, while isolation 1 gives
         * negative.
         */

        if(tracks_in_cone == 0) isolated = true;
        return isolated;
}

bool MyAnalysis::ECALIsolation(MyJet jet, double isolationCone, double signalCone, double Etmin){

        bool isolated = false;

	TLorentzVector isoEnergy    = jet.ecalClusterMomentum(isolationCone);
        TLorentzVector signalEnergy = jet.ecalClusterMomentum(signalCone);

	TLorentzVector energy = isoEnergy - signalEnergy;
	if(energy.Perp() < Etmin) isolated = true;

        return isolated;
}

bool MyAnalysis::HCALIsolation(MyJet jet, double isolationCone, double signalCone, double Etmin){

        bool isolated = false;

        TLorentzVector isoEnergy    = jet.hcalClusterMomentum(isolationCone);
        TLorentzVector signalEnergy = jet.hcalClusterMomentum(signalCone);

        TLorentzVector energy = isoEnergy - signalEnergy;
        if(energy.Perp() < Etmin) isolated = true;

        return isolated;
}

bool MyAnalysis::caloIsolation(MyJet jet, double isolationCone, double signalCone, double Etmin){
	return ECALIsolation(jet,isolationCone,signalCone,Etmin) && 
               HCALIsolation(jet,isolationCone,signalCone,Etmin);
}

bool MyAnalysis::isolationSum(const MyJet *lepton, double isolationCone, double signalCone, double ptmin){

        bool isolated = false;

	double matchingCone = cuts->getCutValue("matchingCone");
	double dzip         = cuts->getCutValue("track_Zip");

        //int tracks_in_cone = 0;


        if(!histograms->booked("h_trackSum") ) histograms->book("h_trackSum",100,0,200);
        if(!histograms->booked("h_isolationSum") ) histograms->book("h_isolationSum",100,0,50);


        double isolationChargedSum = 0;

	vector<MyTrack>::const_iterator iTrackEnd = lepton->tracks_end();
	vector<MyTrack>::const_iterator iTrackBegin = lepton->tracks_begin();

        MyTrack leadingTrack = lepton->leadingTrack(matchingCone);
	if(leadingTrack.pt() == 0) return false;

        //double drMin = 9999;
	for(vector<MyTrack>::const_iterator iTrack = iTrackBegin;
	    iTrack != iTrackEnd; ++iTrack) {
                if(iTrack->charge() == 0) continue;
 
		 if(iTrack->pt() < ptmin) continue;

		double z = fabs(iTrack->impactParameter().impactParameterZ().value());
		if(z > dzip) continue;

		if( iTrack->numberOfValidHits() < 9 ) continue;

		double DR = deltaR(leadingTrack.eta(),iTrack->eta(),
                                   leadingTrack.phi(),iTrack->phi());
	      	     if(  DR < isolationCone  ) {
                     isolationChargedSum += iTrack->pt();
                }
	}
        histograms->fill("h_trackSum",isolationChargedSum);
	histograms->fill("h_isolationSum",isolationChargedSum-leadingTrack.Pt());
        if( (isolationChargedSum-leadingTrack.Pt()) < 3 ) isolated = true;
  
        return isolated;
}
