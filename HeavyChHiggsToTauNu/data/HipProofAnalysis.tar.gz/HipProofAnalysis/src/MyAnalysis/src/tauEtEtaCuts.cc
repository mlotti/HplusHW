#include "MyAnalysis/interface/MyAnalysis.h"

vector<const MyJet*> MyAnalysis::tauEtEtaCuts(vector<const MyJet*> taus){
        vector<const MyJet*> selectedTaus;
	vector<const MyJet*>::const_iterator i;
	for(i = taus.begin(); i!= taus.end(); ++i){

		if(!cuts->applyCut("tauEtCut", (*i)->Et())) continue;
		eventCounter->addSubCount("tau Et cut");

                if(!cuts->applyCut("tauEtaCut", fabs((*i)->Eta()))) continue;
		eventCounter->addSubCount("tau Eta cut");

		selectedTaus.push_back(*i);
	}
	return selectedTaus;
}

