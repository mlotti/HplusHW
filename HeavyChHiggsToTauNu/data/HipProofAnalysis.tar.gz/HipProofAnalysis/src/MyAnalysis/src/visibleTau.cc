#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"

vector<MyMCParticle> visibleTaus(MyEvent* event, int motherId){

	vector<MyMCParticle> visibleTaus;

        vector<MyMCParticle>::const_iterator mcParticlesBegin = event->mcParticles_begin();
        vector<MyMCParticle>::const_iterator mcParticlesEnd   = event->mcParticles_end();

        for(vector<MyMCParticle>::const_iterator i = mcParticlesBegin; i!= mcParticlesEnd; i++){

                int id = i->pid;

                if(abs(id) != 15) continue;

		bool motherSelection = false;
		vector<int>::const_iterator motherListEnd = i->mother_end();
		for(vector<int>::const_iterator iMother = i->mother_begin();
                                                iMother!=motherListEnd; ++iMother){
			if(abs(*iMother) == abs(motherId)) motherSelection = true;
		}
		if(!motherSelection && motherId != 0) continue;

                TLorentzVector visibleTau = i->p4();

		int nElectron     = 0;
		int nMuon	  = 0;
		int nChargedPions = 0;
		int nNeutralPions = 0;
                vector<MyMCParticle>::const_iterator j;

                for(j=i; j!= mcParticlesEnd; j++){

			bool fromTau = false;
			vector<int>::const_iterator motherListEnd = j->mother_end();
			for(vector<int>::const_iterator iMother = j->mother_begin();
                                                        iMother!= motherListEnd; ++iMother){
				if(*iMother == id) fromTau = true;
			}
			if(!fromTau) continue;

			bool fromThisTau = false;
			vector<int>::const_iterator barCodesEnd = j->motherBarcodes_end();
			for(vector<int>::const_iterator iBar = j->motherBarcodes_begin();
                                                        iBar!= barCodesEnd; ++iBar){
				if(*iBar == i->barcode) fromThisTau = true;
			}
			if(!fromThisTau) continue;

                        int daughter = abs(j->pid);
                        if(daughter == 12 || daughter == 14 || daughter == 16) visibleTau -= j->p4();
                        if(daughter == 11) nElectron++;
                        if(daughter == 13) nMuon++;
			if(daughter == 211 || daughter == 321) nChargedPions++;
			if(daughter == 22) nNeutralPions++; // NOTE! includes also brem photons from tau
                }

		int topology = 0;
		if(nChargedPions == 1 && nNeutralPions == 0) topology = 1;
		if(nChargedPions == 1 && nNeutralPions > 0)  topology = 2;
		if(nChargedPions == 3 && nNeutralPions == 0) topology = 3;
		if(nChargedPions == 3 && nNeutralPions > 0)  topology = 4;
		if(nChargedPions == 5 && nNeutralPions == 0) topology = 5;
		if(nElectron > 0) 			     topology = 11;
		if(nMuon > 0)                                topology = 13;

		int newPid = 1500+topology;
		if(id < 0) newPid = -newPid;
		MyMCParticle tau = *i;
		             tau.setP4(visibleTau);
		             tau.pid = newPid;
                visibleTaus.push_back(tau);
        }
	return visibleTaus;
}
