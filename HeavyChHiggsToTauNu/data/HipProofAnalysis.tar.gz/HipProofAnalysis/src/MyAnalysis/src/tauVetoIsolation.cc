#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::tauVetoIsolation(const MyJet *lepton, double isolationCone, double signalCone, double ptmin){

        bool isolated = false;

	double matchingCone = cuts->getCutValue("matchingCone");
	double dzip         = cuts->getCutValue("track_Zip");

        int tracks_in_cone = 0;

        histograms->book("h_isolationTrackHitsVeto",20,0,20);
        histograms->book("h_isolationTrackChi2",100,0,20);
        histograms->book("h_isolationHitsVSpt",100,0,100,20,0,20);
        histograms->book("h_isolationTrackIpz",100,0,0.01);
        histograms->book("h_isolationTrackIp2D",100,0,0.01);
        histograms->book("h_IsolationTracksVeto",50,0,50);

	vector<MyTrack>::const_iterator iTrackEnd = lepton->tracks_end();
	vector<MyTrack>::const_iterator iTrackBegin = lepton->tracks_begin();

        MyTrack leadingTrack = lepton->leadingTrack(matchingCone);
	if(leadingTrack.pt() == 0) return false;

        //double drMin = 9999;
	for(vector<MyTrack>::const_iterator iTrack = iTrackBegin;
	    iTrack != iTrackEnd; ++iTrack) {
                if(iTrack->charge() == 0) continue;
 
		 if(iTrack->pt() < ptmin) continue;
		 //		 cout << " track ipz" << iTrack->impactParameter().impactParameterZ().value() << " hits " << iTrack->numberOfValidHits() << endl;
                histograms->fill("h_isolationTrackIpz",fabs(iTrack->impactParameter().impactParameterZ().value()));
		double z = fabs(iTrack->impactParameter().impactParameterZ().value());
		if(z > dzip) continue;

                histograms->fill("h_isolationTrackChi2",iTrack->normalizedChi2());
                histograms->fill("h_isolationTrackHitsVeto",iTrack->numberOfValidHits());
                histograms->fill("h_isolationHitsVSpt",iTrack->pt(),iTrack->numberOfValidHits());
                histograms->fill("h_isolationTrackIp2D",fabs(iTrack->impactParameter().impactParameter2D().value()));

		//		if( iTrack->numberOfValidHits() < 9 ) continue;
                if( iTrack->numberOfValidHits() > 8 ) eventCounter->addSubCount("tauveto_isolation hit cut"); 
		double DR = deltaR(leadingTrack.eta(),iTrack->eta(),
                                   leadingTrack.phi(),iTrack->phi());
		if(DR < isolationCone && DR > signalCone ) {
		  //	      	if(  DR < isolationCone  ) {
                         tracks_in_cone++;                    
                }
	}

        if(tracks_in_cone == 0) isolated = true;  
        return isolated;

}




bool MyAnalysis::vetoIsolationSum(const MyJet *lepton, double isolationCone, double signalCone, double ptmin){

        bool isolated = false;

	double matchingCone = cuts->getCutValue("matchingCone");
	double dzip         = cuts->getCutValue("track_Zip");

        //int tracks_in_cone = 0;


        histograms->book("h_trackSumVeto",100,0,40);
        histograms->book("h_isolationSumVeto",100,0,50);


        double isolationChargedSum = 0;

	vector<MyTrack>::const_iterator iTrackEnd = lepton->tracks_end();
	vector<MyTrack>::const_iterator iTrackBegin = lepton->tracks_begin();

        MyTrack leadingTrack = lepton->leadingTrack(matchingCone);
	if(leadingTrack.pt() == 0) return false;

        //double drMin = 9999;
	for(vector<MyTrack>::const_iterator iTrack = iTrackBegin;
	    iTrack != iTrackEnd; ++iTrack) {
                if(iTrack->charge() == 0) continue;
 
		 if(iTrack->pt() < ptmin) continue;

		double z = fabs(iTrack->impactParameter().impactParameterZ().value());
		if(z > dzip) continue;

		//		if( iTrack->numberOfValidHits() < 9 ) continue;

		double DR = deltaR(leadingTrack.eta(),iTrack->eta(),
                                   leadingTrack.phi(),iTrack->phi());
	      	if(  DR < isolationCone && DR > signalCone ) {
                     isolationChargedSum += iTrack->pt();
                }
	}
        histograms->fill("h_trackSumVeto",isolationChargedSum);
	//	histograms->fill("h_isolationSumVeto",isolationChargedSum-leadingTrack.Pt());
	histograms->fill("h_isolationSumVeto",isolationChargedSum);
        if( isolationChargedSum < 1 ) isolated = true;
  
        return isolated;
}

bool MyAnalysis::vetoIsolationTrackSum(const MyJet *lepton, double isolationCone, double signalCone) {
	double matchingCone = cuts->getCutValue("matchingCone");

        MyTrack leadingTrack = lepton->leadingTrack(matchingCone);
	if(leadingTrack.pt() == 0) return false;
    
        double isolationTrackSum = 0;

        histograms->book("h_isolationTrackSumVeto",100,0,30);
        //if(!histograms->booked("h_isolationTrackSumVetoTau") ) histograms->book("h_isolationTrackSumVetoTau",100,0,30);

        for(vector<MyTrack>::const_iterator iTrack = lepton->tracks_begin();
                                            iTrack!= lepton->tracks_end(); ++iTrack){
                double DR = deltaR(leadingTrack.eta(),iTrack->eta(),
                                   leadingTrack.phi(),iTrack->phi());
                if(fabs(iTrack->pfType()) == 5) continue;
                if(fabs(iTrack->charge()) == 0) continue; 				
                if(DR > isolationCone) continue;
                if(DR < signalCone) continue;

                isolationTrackSum += iTrack->Pt();
        }

        histograms->fill("h_isolationTrackSumVeto",isolationTrackSum);
        //if (visibleTau.Pt() > 0 ) histograms->fill("h_isolationTrackSumVetoTau",isolationTrackSum);

        return isolationTrackSum <= 2;
}

bool MyAnalysis::vetoIsolationGammaSum(const MyJet *lepton, double isolationCone, double signalCone) {
	double matchingCone = cuts->getCutValue("matchingCone");

        MyTrack leadingTrack = lepton->leadingTrack(matchingCone);
	if(leadingTrack.pt() == 0) return false;
    
        double isolationGammaSum = 0;
        
        histograms->book("h_isolationGammaSumVeto",100,0,30);

        for(vector<MyTrack>::const_iterator iTrack = lepton->tracks_begin();
                                            iTrack!= lepton->tracks_end(); ++iTrack){
                double DR = deltaR(leadingTrack.eta(),iTrack->eta(),
                                   leadingTrack.phi(),iTrack->phi());
                if(fabs(iTrack->pfType()) == 5) continue;
                if(fabs(iTrack->charge()) != 0) continue; 				
                if(DR > isolationCone) continue;
                if(DR < signalCone) continue;

                isolationGammaSum += iTrack->Pt();
        }

        histograms->fill("h_isolationGammaSumVeto",isolationGammaSum);

        return isolationGammaSum <= 5;
}
