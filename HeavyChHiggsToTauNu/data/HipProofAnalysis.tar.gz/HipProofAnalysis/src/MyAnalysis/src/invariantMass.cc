#include "MyAnalysis/interface/MyAnalysis.h"

void MyAnalysis::invariantMass(vector<TauPair> tauPairs){

	// mass assuming a0 mass
        double m_a = cuts->getCutValue("a1mass");
	//double m_a = cut["a1mass"];
//	double max_a1mass = 0;

	vector<TauPair>::const_iterator iTau = tauPairs.begin();
	TauPair tauPair1 = *iTau;
	iTau++;
        TauPair tauPair2 = *iTau;
//cout << "taupair1 " << tauPair1.p4().Px() << " " << tauPair1.p4().Py() << " " << tauPair1.p4().Pz() << endl;
//cout << "taupair1,2 : " << tauPair1.p4().Pt() << " " << tauPair2.p4().Pt() << endl;
	tauPair1.estimateNeutrinoEnergy(m_a);
        tauPair2.estimateNeutrinoEnergy(m_a);

        if(!histograms->booked("h_a_mass")) histograms->book("h_a_mass",50,0,10);
	histograms->fill("h_a_mass",tauPair1.getInvMass());
        histograms->fill("h_a_mass",tauPair2.getInvMass());

	TLorentzVector higgs = tauPair1.p4() + tauPair2.p4();
	double m_h = higgs.M();


	if(!histograms->booked("h_invmass")) histograms->book("h_invmass",50,0,500);
        histograms->fill("h_invmass",m_h);
        cout << "Higgs mass (inv) " << m_h << endl;



	// mass without neutrinos
	bool useNeutrinos = false;
        TLorentzVector higgs_nonus = tauPair1.p4(useNeutrinos) + tauPair2.p4(useNeutrinos);
	double m_h_nonus = higgs_nonus.M();
        if(!histograms->booked("h_invmass_nonus")) histograms->clone("h_invmass_nonus","h_invmass");
        histograms->fill("h_invmass_nonus",m_h_nonus);
        cout << "Higgs mass (nonus) " << m_h_nonus << endl;



	// mass with collinear approximation
	double m_h_coll = massCollinearApproximation(theMET,
                                                     tauPair1.p4(useNeutrinos),
                                                     tauPair2.p4(useNeutrinos));
        if(!histograms->booked("h_m_coll")) histograms->clone("h_m_coll","h_invmass");
        histograms->fill("h_m_coll",m_h_coll);
        cout << "Higgs mass (coll) " << m_h_coll << endl;


	if(!histograms->booked("h_invmass_vs_met")) histograms->book("h_invmass_vs_met",50,0,500,100,0,200);
	histograms->fill("h_invmass_vs_met",m_h,theMET.value());

        if(!histograms->booked("h_m_coll_vs_met")) histograms->clone("h_m_coll_vs_met","h_invmass_vs_met");

        histograms->fill("h_m_coll_vs_met",m_h_coll,theMET.value());


	double DR_tautau = deltaR(tauPair1.p4(false).Eta(),tauPair2.p4(false).Eta(),
                                  tauPair1.p4(false).Phi(),tauPair2.p4(false).Phi());
        if(!histograms->booked("h_DRtautau")) histograms->book("h_DRtautau",50,0,5);
        histograms->fill("h_DRtautau",DR_tautau);

        if(!histograms->booked("h_invmass_vs_DR")) histograms->book("h_invmass_vs_DR",50,0,500,50,0,5);
        histograms->fill("h_invmass_vs_DR",m_h,DR_tautau);

	double higgsPt = higgs.Pt();
	if(!histograms->booked("h_higgsPt")) histograms->book("h_higgsPt",50,0,500);
        histograms->fill("h_higgsPt",higgsPt);

        if(!histograms->booked("h_invmass_vs_pt")) histograms->book("h_invmass_vs_pt",50,0,500,50,0,500);
        histograms->fill("h_invmass_vs_pt",m_h,higgsPt);

	if(higgsPt > 200) return;
        if(!histograms->booked("h_invmass_ptcut")) histograms->clone("h_invmass_ptcut","h_invmass");
        histograms->fill("h_invmass_ptcut",m_h);

}



