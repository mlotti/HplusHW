#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyJet.h"

MyTrack leadingTrack(MyJet jet){
	MyTrack theLeadingTrack;
	double ptmax = 0;
	vector<MyTrack> tracks = jet.getTracks();
	for(vector<MyTrack>::const_iterator i = tracks.begin(); 
	                                    i!= tracks.end(); i++){
		if(i->Pt() > ptmax){
			ptmax = i->Pt();
			theLeadingTrack = *i;
		}
	}
	return theLeadingTrack;
}
