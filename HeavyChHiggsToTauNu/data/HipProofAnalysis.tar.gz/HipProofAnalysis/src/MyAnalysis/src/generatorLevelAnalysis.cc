#include "MyAnalysis/interface/MyAnalysis.h"

void MyAnalysis::generatorLevelAnalysis(MyEvent* event){

	// replacing reco info with generator level info

        vector<MyMCParticle>::const_iterator imcEnd = event->mcParticles_end();
        vector<MyMCParticle>::const_iterator i;


        vector<MyTrack> tracks;
	for(i = event->mcParticles_begin(); i != imcEnd; ++i){
		int pid = abs(i->pid);
		if(! (pid == 11 || pid == 13 || 
                      pid == 211 || pid == 321 || 
                      pid == 2122) ) continue; // e,mu,pi+,K+,proton

		if(i->charge() == 0) continue;
		if(i->pt() > 0.8 && fabs(i->eta()) < 2.5){
			//cout << "check mcTrack " << i->pid << " " << i->status << " " << i->pt() << " " << i->eta() << endl;
			myTrackConverter(&(*i), &tracks);
		}
	}


	vector<MyJet> electrons;
        vector<MyJet> muons;
        vector<MyJet> taus;
	for(i = event->mcParticles_begin(); i != imcEnd; ++i){

		if(abs(i->pid) == 11){
			MyJet electron;
			myJetConverter(&(*i),&tracks, &electron);
			electrons.push_back(electron);
		}

		if(abs(i->pid) == 13){
		        MyJet muon;
			myJetConverter(&(*i),&tracks, &muon);
			muons.push_back(muon);
                }
//cout << " pid " << i->pid << " " << i->status << " " << i->pt() << endl;
                if(abs(i->pid) == 15 || abs(i->pid) == 4 || abs(i->pid) == 5){
		        MyJet tau;
			myJetConverter(&(*i),&tracks, &tau);
			taus.push_back(tau);
                }
        }

	event->electrons 	= electrons;
        event->muons		= muons;
	event->taujets		= taus;
        event->MET 		= event->getMCMET();
}

void MyAnalysis::myTrackConverter(const MyMCParticle* mcParticle, vector<MyTrack> *tracks){

        MyTrack track;
        track.SetPx(mcParticle->px());
        track.SetPy(mcParticle->py());
        track.SetPz(mcParticle->pz());
        track.SetE(mcParticle->P());

	int charge = 1;
	int pid = mcParticle->pid;
	if(pid == 11 || pid == 13 || pid == -211 || pid == -321 || pid == -2122) charge = -1;

        track.trackCharge = charge;
	tracks->push_back(track);
}

void MyAnalysis::myJetConverter(const MyMCParticle *mcParticle, const vector<MyTrack> *tracks, MyJet *jet){
        jet->SetPx(mcParticle->px());
        jet->SetPy(mcParticle->py());
        jet->SetPz(mcParticle->pz());
        jet->SetE(mcParticle->P());

	getTracks(jet,tracks);
}

void MyAnalysis::getTracks(MyJet* jet,const vector<MyTrack> *tracks){
	vector<MyTrack>::const_iterator iTrack;
	vector<MyTrack>::const_iterator iTrackEnd = tracks->end();
        for(iTrack = tracks->begin(); iTrack != iTrackEnd; ++iTrack){

                double DR = deltaR(jet->eta(),iTrack->eta(),
                                   jet->phi(),iTrack->phi());
                if(DR < 0.4){
                        jet->tracks.push_back(*iTrack);
                }
        }
}
