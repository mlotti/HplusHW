#include "MyAnalysis/interface/MyAnalysis.h"

bool MyAnalysis::rtauCut(const MyJet& tau){
	if(tau.E() == 0) return false;
	double rtau = tau.leadingTrack().E()/tau.E();
	histograms->book("h_Rtau",100,0,1.5);
	histograms->fill("h_Rtau",rtau);

        return cuts->applyCut("Rtau", rtau);
}
