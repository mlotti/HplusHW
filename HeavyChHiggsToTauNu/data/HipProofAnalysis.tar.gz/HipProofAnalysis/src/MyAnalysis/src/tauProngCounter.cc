#include "MyAnalysis/interface/MyAnalysis.h"

int MyAnalysis::tauProngCounter(MyJet tau,double signalCone, double matchingCone){

        double ptmin        = cuts->getCutValue("isolationTrackPt");

	int ntracks = 0;
	vector<MyTrack> tracks = tau.getTracks();

	MyTrack leadingTrack = tau.leadingTrack(matchingCone);

	for(vector<MyTrack>::const_iterator itrack = tracks.begin();
                                            itrack!= tracks.end(); itrack++){

		if(itrack->pt() < ptmin) continue;
		double DR=deltaR(leadingTrack.Eta(),itrack->eta(),
                                 leadingTrack.Phi(),itrack->phi());
		if( DR > signalCone ) continue;
		ntracks++;
	}
	return ntracks;
}
