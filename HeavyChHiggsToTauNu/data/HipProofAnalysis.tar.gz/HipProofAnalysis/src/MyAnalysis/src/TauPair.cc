#include "MyAnalysis/interface/TauPair.h"

double deltaR(double,double,double,double);

TauPair::TauPair(){
        tau1.SetXYZT(0,0,0,0);
        tau2.SetXYZT(0,0,0,0);
        nuE = 0;
	scaleFactor = 1;
}

void TauPair::addTau(TLorentzVector v){

        if(tau1.E() == 0) {
                tau1 = v;
                return;
        }

        double DRv = deltaR(tau1.Eta(),v.Eta(),tau1.Phi(),v.Phi());
        if(tau2.E() == 0){
                if(DRv < 0.4) tau2 = v;
        }else{
                double DRtaus = deltaR(tau1.Eta(),tau2.Eta(),tau1.Phi(),tau2.Phi());
                if(DRv < DRtaus) tau2 = v;
        }
}

TLorentzVector TauPair::p4(bool useNeutrinos) const {
//cout << "check useNeutrinos " << useNeutrinos << " " << scaleFactor << endl;
        if(useNeutrinos) return tau1+tau2*scaleFactor;
        else             return tau1+tau2;
}

void TauPair::estimateNeutrinoEnergy(double m_a) {
        // assuming nu in tau2 direction
        if(tau1.E() == 0 || tau2.E() == 0){
                cout << "tau energy = 0! " <<  endl;
                return;
        }
//cout << "check tau1 Et " << tau1.E() << " " << tau1.X() << " " << tau1.Y() << " " << tau1.Z() << endl;
//cout << "check tau2 Et " << tau2.E() << " " << tau2.X() << " " << tau2.Y() << " " << tau2.Z() << endl;

        double dotProduct = tau1.X()*tau2.X() + tau1.Y()*tau2.Y() + tau1.Z()*tau2.Z();
        dotProduct = dotProduct/(tau1.E()*tau2.E());
//cout << "check dot product " << dotProduct << endl;
        double m_tau = 1.777;
        nuE = ((m_a*m_a - 2*m_tau*m_tau)/(2*tau1.E()*(1-dotProduct))) - tau2.E();
//cout << "check nuE " << nuE << endl;
        scaleFactor = (tau2.E() + nuE)/tau2.E();
//cout << "check scaleFactor " << scaleFactor << endl;
}

double TauPair::getNeutrinoEnergy() const{
        return nuE;
}

double TauPair::getInvMass() const {
        return p4(false).M();
}

bool TauPair::bothTausFound() const {
	if(tau1.E() == 0 || tau2.E() == 0) return false;
	return true;
}

