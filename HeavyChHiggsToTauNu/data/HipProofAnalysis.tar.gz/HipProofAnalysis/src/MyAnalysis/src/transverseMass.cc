#include "MyAnalysis/interface/MyAnalysis.h"

double MyAnalysis::transverseMass(MyJet& jet,MyMET& met){
	double metX = met.getX();
	double metY = met.getY();
	double mt = transverseMassRecoAlgo(jet.p4(),metX,metY);

	if(!histograms->booked("h_transversemass") ) histograms->book("h_transversemass",50,0,500);
        histograms->fill("h_transversemass",mt);

	if(jet.Pt() > 0 && met.value() > 0){

                double dphi = 180/3.14159*deltaPhi(jet.Phi(),met.getPhi());

                histograms->book("h_dphi_tau_MET",180,0,180);
                histograms->fill("h_dphi_tau_MET",dphi);
        }

	return mt;
}

double MyAnalysis::transverseMassRecoAlgo(TLorentzVector j1, double& Exmiss, double& Eymiss) {

        double Etmiss = sqrt(Exmiss*Exmiss + Eymiss*Eymiss);

        double cosPhi = 100;
        if(Etmiss > 0 && j1.Et() > 0)
        cosPhi = (j1.Px()*Exmiss + j1.Py()*Eymiss)/(j1.Et()*Etmiss);

        double tmas = -999;
        double tmas2 = 0;

        if(cosPhi < 1) tmas2 = 2 *j1.Et() * Etmiss * (1-cosPhi);
        if(tmas2 >= 0) tmas = sqrt(tmas2);

        return tmas;
}

