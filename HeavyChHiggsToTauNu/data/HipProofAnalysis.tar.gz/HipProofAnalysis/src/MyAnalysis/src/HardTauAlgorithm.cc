#include "MyAnalysis/interface/HardTauAlgorithm.h"

HardTauAlgorithm::HardTauAlgorithm(){
	init();
        bookHistograms();
        eventCounter = 0;
}

HardTauAlgorithm::HardTauAlgorithm(MyHistogram* histo, Counter *counter){
	init();
        histograms = histo;
        eventCounter = counter;
}


HardTauAlgorithm::~HardTauAlgorithm(){
        if(plot) plotHistograms();
}

void HardTauAlgorithm::init(){
        all    = 0;
        passed = 0;
}

void HardTauAlgorithm::bookHistograms(){
	histograms = new MyHistogram("hardTauAlgorithm.root");
	plot = true;
}

void HardTauAlgorithm::plotHistograms(){
	delete histograms;
}

double HardTauAlgorithm::getAlgorithmEfficiency(){
        if(all == 0) return 0;
        return passed/double(all);
}

void HardTauAlgorithm::setPrimaryVertex(const TVector3& vertex){
        primaryVertex = vertex;
}

TLorentzVector HardTauAlgorithm::recalculateEnergy(const MyJet& theJet){
        TLorentzVector p4(0,0,0,0);
        TLorentzVector p4photons(0,0,0,0);

	MyJet jet = theJet;
	MyTrack* leadTk = new MyTrack(jet.leadingTrack());


	if(leadTk->Pt() == 0) return p4;

        vector<MyTrack> tracks = jet.getTracks();
        MyTrack momentum(0,0,0,0);
	vector<MyTrack>::const_iterator itrack;
	for(itrack = tracks.begin();
            itrack!= tracks.end(); itrack++){
		double DR=deltaR( leadTk->eta(),itrack->eta(),
                                  leadTk->phi(),itrack->phi());
		if( DR < 0.04 ) {
                     momentum += *itrack;
                }
	}
	if(momentum.Pt() == 0) return p4;

        vector<MyCaloTower> towers = jet.getCaloInfo();
        if(towers.size() == 0) return p4;


        TVector3 trackEcalHitPoint = leadTk->ecalHitPoint().tvector3();
        if(! (trackEcalHitPoint.Perp() > 0 && trackEcalHitPoint.Perp() < 9999) ) return p4;

        //pair<TVector3,TVector3> caloClusters = getClusterEnergy(towers,trackEcalHitPoint);
        //TVector3 EcalCluster = caloClusters.first;
        //TVector3 HcalCluster = caloClusters.second;
	//double etCaloOverTrack = (EcalCluster.Pt()+HcalCluster.Pt()-momentum.pt())/momentum.pt();
	TLorentzVector HcalCluster  = jet.hcalClusterMomentum(0.2,0.1);
	TLorentzVector EcalCluster  = jet.ecalClusterMomentum(0.2,0.1);
	TLorentzVector EcalCluster05  = jet.ecalClusterMomentum(0.5,0.1);

        p4photons.SetXYZT( EcalCluster05.X() - EcalCluster.X(),
                           EcalCluster05.Y() - EcalCluster.Y(),
                           EcalCluster05.Z() - EcalCluster.Z(),
                           EcalCluster05.Mag() - EcalCluster.Mag());

  	histograms->book("h_ecalEt0205algo",100,0,20);
 	histograms->fill("h_ecalEt0205algo",p4photons.Pt());          
  	histograms->book("h_ecalEt05algo",100,0,200);
 	histograms->fill("h_ecalEt05algo",EcalCluster05.Pt());    
 	histograms->book("h_ecalEt02algo",100,0,200);
 	histograms->fill("h_ecalEt02algo",EcalCluster.Pt());    


	double etCaloOverTrack = (EcalCluster.Pt()+HcalCluster.Pt()-momentum.Pt())/momentum.Pt();


	histograms->book("hEtCaloOverTrack",100,-2,6);
	histograms->fill("hEtCaloOverTrack",etCaloOverTrack);

        double DRhitpoint = deltaR(trackEcalHitPoint.Eta(), leadTk->eta(),
                                   trackEcalHitPoint.Phi(), leadTk->phi());
        if(eventCounter) eventCounter->addSubCount("hardTau  all algo cands");
	histograms->book("h_DRhitpoint",100,0,1);
        histograms->fill("h_DRhitpoint",DRhitpoint);

	if( etCaloOverTrack > -0.9  && etCaloOverTrack < -0.1 ) {
		p4.SetXYZT(momentum.px(),
                           momentum.py(),
                           momentum.pz(),
                           momentum.p());
                // add photons
                p4 += p4photons;
                if(eventCounter) eventCounter->addSubCount("hardTau algo caloTrackMatch");
        }
        else if( etCaloOverTrack < -0.9 && eventCounter) eventCounter->addSubCount("hardTau algoRej calo<track");
        else if( etCaloOverTrack  > -0.1 ) {
                if(eventCounter) eventCounter->addSubCount("hardTau algo calo>track");
		double etHcalOverTrack = (HcalCluster.Pt()-momentum.pt())/momentum.pt();
		histograms->book("hEtHcalOverTrack",100,-2,6);
                histograms->fill("hEtHcalOverTrack",etHcalOverTrack);

		//if ( fabs( etHcalOverTrack ) < 0.8 ) {
                if( etHcalOverTrack > -0.3 && etHcalOverTrack < 0.5) {
                        if(eventCounter) eventCounter->addSubCount("hardTau algo HcalMatch");
                        p4.SetXYZT(EcalCluster.X()   + momentum.px(),
                                   EcalCluster.Y()   + momentum.py(),
                                   EcalCluster.Z()   + momentum.pz(),
                                   EcalCluster.Mag() + momentum.p());
                        // add photons
                        p4 += p4photons;
                }
                else if( etHcalOverTrack < -0.3) {
                        if(eventCounter) eventCounter->addSubCount("hardTau algo calojet");
                        p4.SetXYZT(jet.px(),jet.py(),jet.pz(),jet.energy());
                }
                else if(eventCounter) eventCounter->addSubCount("hardTau algoRej Hcal>track");

                //if ( momentum.pt() > HcalCluster.Pt()* 0.8 * momentum.pt() ) {
                //  p4.SetXYZT(jet.px(),jet.py(),jet.pz(),jet.energy());
                // }
        }

        return p4;
}


pair<TVector3,TVector3> HardTauAlgorithm::getClusterEnergy(vector<MyCaloTower> towers, TVector3& trackEcalHitPoint){

        TVector3 ecalCluster(0,0,0);
        TVector3 hcalCluster(0,0,0);

	for(vector<MyCaloTower>::const_iterator iTower = towers.begin();
	                                        iTower != towers.end(); iTower++){
		vector<TVector3> ecalCells = iTower->ECALCells;
                vector<TVector3> hcalCells = iTower->HCALCells;

		vector<TVector3>::const_iterator i;
		for(i = ecalCells.begin(); i != ecalCells.end(); i++) {
                        double DR = deltaR(trackEcalHitPoint.Eta(),i->Eta(),
                                           trackEcalHitPoint.Phi(),i->Phi());
			if( DR < 0.4 ) ecalCluster += *i;
		}
                for(i = hcalCells.begin(); i != hcalCells.end(); i++) {
                        double DR = deltaR(trackEcalHitPoint.Eta(),i->Eta(),
                                           trackEcalHitPoint.Phi(),i->Phi());
			if( DR < 0.4 ) hcalCluster += *i;
		}
	}
        return pair<TVector3,TVector3> (ecalCluster,hcalCluster);
}
