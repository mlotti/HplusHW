#ifndef TAUIDANALYSIS_H
#define TAUIDANALYSIS_H

/**
Class for analysing and optimizing the tau identification parameters
Provides parameter file TauIdAnalysis.root

@author Lauri A. Wendland
*/

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"
#include "Framework/interface/Cuts.h"

#include "MyAnalysis/interface/RecoTauJetCandidate.h"

#include <TFile.h>
#include <TTree.h>

typedef struct {
  float jetEt;        // jet parameters
  float jeteta;
  float jetphi;
  int jetTrackCount;
  float jetTrackPtMin;
  // Tracker isolation
  float matchingCone; // tracker isolation parameters
  float signalCone;
  int signalTracks;
  float signalExcessPt; // Pt of tracks other than ldg track in signal cone
  float isolPt;       // Pt of tracks in isolation cone
  int isolTracks;
  int isolMinHits;
  int isolMaxHits;
  float isolMinPt;
  float isolMaxPt;
  float isolMinDr;
  float isolMaxDr;
  // Leading track
  float ldgPt;        // leading track parameters
  float ldgeta;
  float ldgphi;
  int   ldgHits;
  float ldgChi2;
  float ldgHitChi2;
  float ldgHitChi2Radius;
  float ldgIpz;
  float ldgIpt;
  float ldgIp3D;
  float ldgIp3DSig;
  // Multiple tracks
  int   chargeSum;
  float ptSum;
  float deltaE;
  float ctau;
  float minPt;
  float minIpt;
  float maxIpt;
  float minIp3D;
  float maxIp3D;
  float minIp3Dsig;
  float maxIp3Dsig;
  float minIpz;
  float maxIpz;
  float maxChi2;
  float maxHitChi2;
  float maxHitChi2Radius;
  float multipleTrackRtau;
  float flightpathSig;
  float flightpath;
  float flightpathT;
  
  // Calorimetry
  float ecalIsolEt;       // ECAL isolation parameters
  float hcalEt;
  float ecalEt;
  float totalEt;
  float hcalRatio;    // Calorimetry ratio
  float energyRatio;  
  float rtau;         // other track parameters
  float rtauT;        // transverse rtau
  // MC  
  int   ldgPid;
  int   istau;
  int   tauprongs;    // number of prongs coming from the MC tau
  int   taugammas;    // number of gammas coming from the MC tau
  int   tauDecayType; // origin of tau (1=Z, 2=W, 4=H+)
  int   tautype;      // tau decay type e:1 mu:2 semi-leptonic:4 hadr.:8 pi0s:16
  int   qtype;        // quark type uds:1 c=2 b=3 g=5 )
  int   passedtau;    // all cuts

  float ldge4;
  float ldge6;
  float ldge8;
  float ldge10;
  float mass4;
  float mass6;
  float mass8;
  float mass10;
  float mass;
  int evt;

} TrIsolationStruct;

class TauIdAnalysis{
 public:
  TauIdAnalysis();
  ~TauIdAnalysis();

  void analyze(RecoTauJetCandidate* tau, Cuts* cuts, bool passed, int evt);
  void updateCounter(bool* pass);
  
 private:
  void clear();
  void fillTree();
 public:
  TrIsolationStruct data;
  
 private: 
  TFile* theRootFile;
  TTree* theRootTree;
  
  int fPassTable[TAUID_COUNTERS];
};

#endif
