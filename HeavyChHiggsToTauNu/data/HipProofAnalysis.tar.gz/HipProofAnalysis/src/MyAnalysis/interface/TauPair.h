#ifndef __TauPair__
#define __TauPair__

#include "TLorentzVector.h"
#include <iostream>

using namespace std;

class TauPair {
  public:
        TauPair();
        ~TauPair(){};

        void addTau(TLorentzVector);
        TLorentzVector p4(bool useNeutrinos = true) const;
        void estimateNeutrinoEnergy(double);
        double getNeutrinoEnergy() const;
        double getInvMass() const;

	bool bothTausFound() const;

  private:
        TLorentzVector tau1,
                       tau2;

        double nuE;
        double scaleFactor;
};
#endif
