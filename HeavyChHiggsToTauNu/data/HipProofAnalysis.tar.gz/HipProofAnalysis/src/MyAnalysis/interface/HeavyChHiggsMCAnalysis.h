#ifndef HeavyChHiggsMCAnalysis_H
#define HeavyChHiggsMCAnalysis_H

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"
#include "Framework/interface/MyHistogram.h"

#include "TopMassRecoPartons.h"

vector<MyMCParticle> visibleTaus(MyEvent*,int);
double deltaR(double,double,double,double);

class HeavyChHiggsMCAnalysis {

    public:

	HeavyChHiggsMCAnalysis(MyHistogram*);
	~HeavyChHiggsMCAnalysis();

	void analyse(MyEvent*);


	vector<MyMCParticle> visibleTaus();
	vector<MyMCParticle> bquarks();
        vector<MyMCParticle> neutrinos();
        vector<MyMCParticle> muons();
        vector<MyMCParticle> taus();

	MyMCParticle visibleTau(MyJet);
        MyMCParticle mcJet(MyJet);
        MyJet mcParton(MyMCParticle);

	MyMCParticle leadingMuon();
	MyMCParticle leadingBQuark();
	MyMCParticle neutrinoSum();

        int topJetPartonMatch(std::vector<MyJet>& jets);

    private:

	MyEvent* theEventPointer;

	MyHistogram* histograms;

        vector<MyMCParticle> visible_taus;
	vector<MyMCParticle> bQuarks;
        vector<MyMCParticle> bQuarksFromTop;
        vector<MyMCParticle> bQuarksNotFromTop;
        vector<MyMCParticle> mcNeutrinos;
        vector<MyMCParticle> mcMuons;
        vector<MyMCParticle> mcTaus;

        std::map<TopMassRecoPartons::Partons, MyMCParticle> topPartons;
};
#endif
