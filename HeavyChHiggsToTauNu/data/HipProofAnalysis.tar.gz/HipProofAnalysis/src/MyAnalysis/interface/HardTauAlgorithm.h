#ifndef HardTauAlgorithm_H
#define HardTauAlgorithm_H

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"

#include "TFile.h"
#include "TH1F.h"
#include "TLorentzVector.h"
#include "Framework/interface/MyHistogram.h"

using namespace std;

double deltaR(double,double,double,double);

class HardTauAlgorithm {

    public:

        HardTauAlgorithm();
        HardTauAlgorithm(MyHistogram*, Counter*);
        ~HardTauAlgorithm();

        TLorentzVector recalculateEnergy(const MyJet&);
        double getAlgorithmEfficiency();
        void setPrimaryVertex(const TVector3&);

    private:
	void init();
	void bookHistograms();
        void plotHistograms();

        pair<TVector3,TVector3> getClusterEnergy(vector<MyCaloTower>,TVector3&);

        int all,
            passed;

        bool plot;

        TVector3 primaryVertex;

        MyHistogram* histograms;
        Counter*     eventCounter;
};
#endif
