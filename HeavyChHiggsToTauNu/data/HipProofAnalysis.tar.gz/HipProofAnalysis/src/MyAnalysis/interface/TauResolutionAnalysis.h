#ifndef TAURESOLUTIONANALYSIS_H
#define TAURESOLUTIONANALYSIS_H

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"
#include "Framework/interface/MyHistogram.h"

vector<MyMCParticle> visibleTaus(MyEvent*,int);

class TauResolutionAnalysis {
  public:
  	TauResolutionAnalysis();
        TauResolutionAnalysis(MyHistogram*);
  	virtual ~TauResolutionAnalysis();

	bool analyse(MyEvent*,double ptcut = 20, int motherId = 0);
	void analyse(const MyJet,const MyMCParticle,string label = "tau");
        void chargedTrackCounter(MyEvent*);
	void print();

  private:
	void init();

	int eventCounter;
	int mcHadronicTauCounter;
	int mcVisibleTauCounter;
	int mcTauPtCutCounter;
	int caloTauCounter;
	int caloTauWithLeadingTrackCounter;
	int isolatedCaloTauCounter;
	int pfTauCounter;
	int pfTauWithLeadingTrackCounter;
	int isolatedPfTauCounter;

	int nAllTaus;
	int nFakeTaus;

	MyHistogram* histograms;
}; 
#endif 

