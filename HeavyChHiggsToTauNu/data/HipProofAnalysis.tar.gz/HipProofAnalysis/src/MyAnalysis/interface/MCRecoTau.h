#ifndef MCRECOTAU_H
#define MCRECOTAU_H

/**
ThisThis class provides MC info for tau objects class provides MC info for tau objects

@author Lauri A. Wendland
*/

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"

#include <TLorentzVector.h>

class MCRecoTau {
 public:
  MCRecoTau(MyEvent* event, const MyJet* jet);
  ~MCRecoTau();

  void print();
  
  // Getters  
  bool isTau() { return fTauStatus; }
  bool decaysToHadrons() { return (!fContainsElectron && !fContainsMuon && (fContainsPion || fContainsKaon || fContainsProton)); }
  bool decaysToElectrons() { return (fContainsElectron && !fContainsMuon && !decaysToHadrons()); }
  bool decaysToMuons() { return (fContainsMuon && !fContainsElectron && !decaysToHadrons()); }
  bool decaysSemiLeptonically() { return ((fContainsElectron || fContainsMuon) && (fContainsPion || fContainsKaon || fContainsProton)); }
  int prongs() { return fProngCount; }
  int pi0Count() { return fPi0Count; }
  int gammaCount() { return fGammaCount; }
  bool originatesFromZ() { return fOriginZ; }
  bool originatesFromW() { return fOriginW; }
  bool originatesFromHplus() { return fOriginHplus; }
  int ldgPid() { return fLdgPid; }
  
 public:
  TLorentzVector fVisibleEnergy;
  TLorentzVector fInvisibleEnergy;
  TLorentzVector fChargedEnergy;
  TLorentzVector fEMEnergy;
  TLorentzVector fTau;
  
 private:
  bool fTauStatus;
  int fProngCount;
  int fPi0Count;
  int fGammaCount;
  bool fContainsElectron;
  bool fContainsMuon;
  bool fContainsPi0;
  bool fContainsGamma;
  bool fContainsPion;
  bool fContainsKaon;
  bool fContainsProton;
  bool fOriginZ;
  bool fOriginW;
  bool fOriginHplus;
  int  fLdgPid;
    
};

#endif
