#ifndef RECOTAUJETCANDIDATE_H
#define RECOTAUJETCANDIDATE_H

/**
This class collects the tau identification into a single class

@author Lauri A. Wendland
*/ 

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"
#include "MyAnalysis/interface/MCRecoTau.h"
#include "MyAnalysis/interface/MCRecoQCDJet.h"
#include "Framework/interface/Cuts.h"
#include "Framework/interface/Counter.h"

#include <iostream>
#include <vector>

#include <TMath.h>

double deltaR(double, double, double, double);
double deltaPhi(double, double);

enum TauIDCounterTypes {
  TAUID_PASSED_NOTHING,
  TAUID_PASSED_ET,
  TAUID_PASSED_ETA,
  TAUID_PASSED_RTAU,
  TAUID_PASSED_RTAUT,
  TAUID_PASSED_MRTAUCUT,
  TAUID_PASSED_TRISO,
  TAUID_PASSED_EMISO,
  TAUID_PASSED_TRNO,
  TAUID_PASSED_CHARGESUMCUT,
  TAUID_PASSED_DELTAE,
  TAUID_PASSED_LDGPT,
  TAUID_PASSED_LDGIP,
  TAUID_PASSED_LDGIPT,
  TAUID_PASSED_LDGHITS,
  TAUID_PASSED_LDGCHI2,
  TAUID_PASSED_LDGHITCHI2,
  TAUID_PASSED_PTSUM,
  TAUID_PASSED_MCHI2CUT,
  TAUID_PASSED_MHITCHI2CUT,
  TAUID_PASSED_MIPTCUT,
  TAUID_PASSED_MIP3DSIGCUT,
  TAUID_PASSED_MIP3DCUT,
  TAUID_PASSED_TRKQUAL,
  TAUID_PASSED_NEUTRHADR,
  TAUID_PASSED_ELECTRONCUT,
  TAUID_PASSED_VERTEX,
  TAUID_PASSED_CTAU,
  TAUID_PASSED_INVMASS,
  TAUID_PASSED_ALL
};
#define TAUID_COUNTERS 50

class RecoTauJetCandidate {
 public:
  RecoTauJetCandidate(string counterPrefix, MyEvent* event, const MyJet* jet); // do tau selection
  ~RecoTauJetCandidate();

  bool doSelection(Cuts* cuts, Counter* eventCounter, bool isPFtau); // ask for tau id result
  int getPassedSelectionCount() { return fPassCount; }
  void updateCounters(Counter* eventCounter, int passedJetCount); // update event counters
  bool* getPassTable() { return &(fPassTable[0]); }
  
  // Kinematical cuts
  bool EtCut(double min);
  bool etaCut(double max);
  bool ldgPtCut(double min);
  bool ldgHitCut(int n);
  bool ldgChi2Cut(double value);
  bool ldgHitChi2Cut(double value);
  bool ldgIptCut(double min, double max);
  bool ldgIp3DCut(double min, double max);
  bool ldgIpSigCut(double min, double max);
  // Multiple track kinematical cuts
  bool ptSumCut(double min);
  bool chi2Cut(double max);
  bool hitChi2Cut(double max);
  bool iptCut(double min, double max);
  bool ip3DCut(double min, double max);
  bool ipSigCut(double min, double max);
  bool chargeSumCut(int value);
  bool multipleTrackRtau(double min, double max);
    
  // Vertexing and mass reco
  
  
  
  // Isolation cuts  
  bool signalTrackNumberCut(int n);
  bool trackerIsolationCut(double annulusMin, double annulusMax, double minPt, double maxDz);
  // Calorimetry cuts
  bool ECALIsolation(double annulusMin, double annulusMax, double maxEt);
  bool pfTauECALIsolation(double annulusMin, double annulusMax, double maxPt);
  bool neutralHadronCut(double annulusMin, double annulusMax, double max);
  bool pfTauNeutralHadronCut(double annulusMin, double annulusMax, double MaxPt);
  bool electronCut(double annulusMin, double annulusMax, double mix);
  //bool totalRatio(double min) { return (fTotalRatio >= min); }
  bool rtauCut(double min);
  bool rtauTCut(double min);

  bool tauComesFromWorZ();
  
  // Getters
  bool isMCtau() { return getMCTau()->isTau(); }
  bool isMCQCD() { return getMCQCDJet()->isQCDJet(); }
  MCRecoTau* getMCTau() { analyzeQCD(); return fMCTau; }
  MCRecoQCDJet* getMCQCDJet() { analyzeQCD(); return fMCQCD; }

 private:
  void calculateIsolation(double annulusMin, double annulusMax, double minPt, double maxDz);
  void energySumming(double annulusMin, double annulusMax);
  void analyzeQCD();
  double calculateInvariantMass(double annulusMin, double annulusMax);
  double energyInAnnulus(double rMin, double rMax, const MyJet *jet,
			 double eta, double phi, bool ecal, bool hcal);
    
 public:  
  //  double fPF


  double fRtau;
  double fRtauT;
  double fJetEt;
  double fJeteta;
  double fJetphi;
  
  // Properties of the leading track
  double fLdgPt;
  double fLdgphi;
  double fLdgeta;
  int    fLdgHits;
  double fLdgChi2;
  double fLdgMaxHitChi2;
  double fLdgMaxHitChi2Radius;
  double fLdgIpt;
  double fLdgIp3D;
  double fLdgIp3Dsig;
  double fLdgIpz;
  
  // Properties of all signal tracks
  int fChargeSum;
  double fPtSum;
  double fctau;
  double fMinPt;
  double fMinIpt;
  double fMaxIpt;
  double fMinIp3D;
  double fMaxIp3D;
  double fMinIp3Dsig;
  double fMaxIp3Dsig;
  double fMinIpz;
  double fMaxIpz;
  double fMaxChi2;
  double fMaxHitChi2;
  double fMaxHitChi2Radius;
  double fMultipleTrackRtau;
  double fDeltaE;
  
  // Isolation data
  int fSignalTrackNumber;
  double fSignalConeExcessPt;
  double fIsolationPt;
  int fIsolationTrackNumber;
  int fIsolationMinHits;
  int fIsolationMaxHits;
  double fIsolationMinPt;
  double fIsolationMaxPt;  
  double fIsolationMinDr;
  double fIsolationMaxDr;

  // calorimetry data
  double fEcalIsolEt;
  double fEcalEt;
  double fHcalEt;
  double fTotalEt;
  double fHcalRatio;
  double fTotalRatio;

  // vertex data
  bool fVertex;
  double fFlightpathSig;
  double fFlightpath;
  double fFlightpathT;
  
  // mass reco data, EXPERIMENTAL CODE
  double fLdgEnergy004;
  double fLdgEnergy006;
  double fLdgEnergy008;
  double fLdgEnergy010;
  double fInvMass;
  double fInvMass004;
  double fInvMass006;
  double fInvMass008;
  double fInvMass010;

 private:
  string fCounterPrefix;
  MCRecoTau*    fMCTau;
  MCRecoQCDJet* fMCQCD;
  const MyJet* fJet; // stored for calo energy data only
  MyEvent* fEvent;  // stored for MC data only
  double fLdgSinTheta;
    
  bool fEnergyIsSummed;
  bool fQCDAnalyzed;
  bool fIsolationCalculated;
  bool fCalculateAll;
  bool fCalculateInvariantMass;
  bool fPassTable[TAUID_COUNTERS];
  bool fPassedStatus; // current status of  selection
  int fPassCount; // counter for number selections passed
  //bool fPassedC;
    
  vector<const MyTrack*> fTracks;
  vector<const MyTrack*> fSignalTracks;
  
};

#endif
