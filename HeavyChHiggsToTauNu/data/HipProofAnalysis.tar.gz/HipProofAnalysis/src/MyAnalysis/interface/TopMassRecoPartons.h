#ifndef TopMassRecoPartons_h
#define TopMassRecoPartons_h

namespace TopMassRecoPartons {
  enum Partons {bQuark=10000, lightQuark, lightQuarkBar, bQuarkNotFromTop};
};

#endif /* TopMassRecoPartons_h */
