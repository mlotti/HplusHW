#ifndef __MyAnalysis__
#define __MyAnalysis__

#include "Framework/interface/BaseAnalysis.h"
#include "TauPair.h"
#include "TauResolutionAnalysis.h"
#include "HardTauAlgorithm.h"
#include "TopMassReco.h"
#include "HeavyChHiggsMCAnalysis.h"
#include "MyAnalysis/interface/TauIdAnalysis.h"

class MyAnalysis : public BaseAnalysis {
  public:
	MyAnalysis(MyInput);
	~MyAnalysis();

        void    setDefaultCuts();
	void    bookHistograms();
        void    beginEvent(MyEvent*);
	void    analyse(MyEvent*);
	void    print();
	void    plotHistograms();

  private:
        void 	signalAnalysis(MyEvent*);
        void 	signalAnalysisPrint(MyEvent*);
        void    backgroundAnalysisUsingMuons_tt(MyEvent*);
        void 	backgroundAnalysisUsingMuons_w3j(MyEvent*);
        void 	backgroundAnalysisQCD(MyEvent*);
        void 	pflowAnalysis(MyEvent*);
	void 	nmssmAnalysis(MyEvent*);
        void    backgroundAnalysisUsingMuonsPrint(MyEvent*);
        void    topAnalysis(MyEvent*);


	bool 		triggerLeptons(MyEvent*);
        bool 		triggerTausFound(MyEvent*);
	bool		tauMETtriggerEmulator(MyEvent*);
	vector<const MyJet*> triggerTaus(MyEvent*);
       
	//bool            isolation(MyJet);
	bool            isolation(const MyJet*, double isolationCone = 0.4, double signalCone = 0, double isolationPtCut = 1);
        bool            isolationSum(const MyJet*, double isolationCone = 0.4, double signalCone = 0, double isolationPtCut = 1);
        bool            tauVetoIsolation(const MyJet*, double isolationCone = 0.4, double signalCone = 0, double isolationPtCut = 1);
        bool            vetoIsolationSum(const MyJet*, double isolationCone = 0.4, double signalCone = 0, double isolationPtCut = 1);
        bool            vetoIsolationTrackSum(const MyJet*, double isolationCone = 0.4, double signalCone = 0);
        bool            vetoIsolationGammaSum(const MyJet*, double isolationCone = 0.4, double signalCone = 0);
        bool            caloIsolation(MyJet,double,double,double);
        bool            ECALIsolation(MyJet,double,double,double);
	bool 		HCALIsolation(MyJet,double,double,double);
//	void 	          mcAnalysis(MyEvent*);
	vector<TauPair> nOfflineTausWithLeptonInCone(MyEvent*);
	void 		invariantMass(vector<TauPair>);
	double 		massCollinearApproximation(MyMET,TLorentzVector,TLorentzVector);
	double 		massCollinearApproximation(double[2],double[4],double[4]);
        bool            metCut(MyMET);
	bool 		met(MyEvent*,vector<const MyJet*>);
        bool            metIsolation(MyEvent*, MyJet&, MyMET&, double&);
	bool 		rtauCut(const MyJet&);
	bool		tauSecondaryVertexCut(MyJet&);
	bool 		njets(MyEvent*);
	bool 		jetVeto(MyEvent*,vector<TauPair>);

        bool            electronVeto(MyEvent*,double);
	bool 		muonVeto(MyEvent*,double);
	bool 		ltrackPtOverHcalClusterEt(const MyJet*,double);
	double 		ltrackPtOverHcalClusterEtDiscriminator(const MyJet*,double);
        vector<const MyJet*> muonPtCut(MyEvent*,double);
	vector<const MyJet*> muonIsolation(MyEvent*);
	vector<const MyJet*> muonSelection(MyEvent*);
	vector<const MyJet*> tauSelection(MyEvent*,string);
	vector<const MyJet*> tauEnergyCorrectionSelection(MyEvent*,string);
        vector<const MyJet*> tauTest(vector<const MyJet*>,double,string);
        vector<const MyJet*> pftauElectronVeto(vector<const MyJet*>);
//        vector<const MyJet*> caloTaus(MyEvent*);
	vector<const MyJet*> caloTaus(MyEvent*,string correction = "");
        vector<const MyJet*> pfTaus(MyEvent*);
        vector<const MyJet*> hardTaus(MyEvent*,string correction = "");
        vector<const MyJet*> hardTaus(MyEvent* ,vector<const MyJet*>);
	vector<const MyJet*> tauVeto(MyEvent*,string,MyJet);
        vector<const MyJet*> newtauVeto(MyEvent*,string,MyJet);
        vector<const MyJet*> bjetSelection(MyEvent*,vector<MyJet>::const_iterator,vector<MyJet>::const_iterator);
	vector<const MyJet*> tauEtEtaCuts(vector<const MyJet*>);
        vector<const MyJet*> pftauNeutralHadronVeto(vector<const MyJet*>);
        vector<const MyJet*> pfChargedIsolation(vector<const MyJet*>,double);
        vector<const MyJet*> tauTrackerIsolation(vector<const MyJet*>,double);
        vector<const MyJet*> ecalFiducialCuts(vector<const MyJet*>);
        vector<const MyJet*> tauEcalIsolation(vector<const MyJet*>,string);
        vector<const MyJet*> tauHcalJetRejection(vector<const MyJet*>);
        vector<const MyJet*> tauHcalElectronRejection(vector<const MyJet*>);
	vector<const MyJet*> tauOneOrThreeProngSelection(vector<const MyJet*>,int);

	int 		tauProngCounter(MyJet,double, double);
	vector<MyJet> 	recalculateTauEnergyUsingHardTauAlgorithm(MyEvent*,string correction = "");
        vector<MyJet>   recalculatePFlowEnergyUsingPFtracks(MyEvent*);
        vector<MyJet>   recalculateTauEnergy(vector<const MyJet*>);


	MyMET 		type1MET(MyEvent*,double,string);
	MyMET 		type1METtau(MyEvent*,vector<const MyJet*>,double,string);
	void 		metResolutionAnalysis(MyMET,MyMET);
	void		jetResolutionAnalysis(vector<MyJet>,MyEvent*);
	int 		tauOriginFromLabel(Counter*);


//	bool 		topMassReco();
//	double 		topMassChi2(double&);
	bool 		transverseMassReco(string);
	double 		transverseMass(MyJet&,MyMET&);
	double 		transverseMassRecoAlgo(TLorentzVector,double&,double&);
	TLorentzVector 	getLeadingMuon();

	bool 		bjetVeto(double);
        bool 		hadronicJetCounter(MyEvent*,int,double etcut = 20);
	MyJet 		randomTauSelectionFromHadronicJets(MyEvent*,double);
	MyJet 		randomTauSelectionFromTauCandidateJets(MyEvent*,double,string);
	MyJet		randomTauSelection(vector<const MyJet*>,double);
	void 		removeTausFromHadronicJets(MyEvent*);

	void 		generatorLevelAnalysis(MyEvent*);
	void 	        myTrackConverter(const MyMCParticle*,vector<MyTrack>*);
	void      	myJetConverter(const MyMCParticle*,const vector<MyTrack>*,MyJet*);
	void            getTracks(MyJet*,const vector<MyTrack>*);

	TauResolutionAnalysis* tauResolutionAnalysis;
	HardTauAlgorithm* hardTauAlgorithm;
	TopMassReco* topMassReco;
	HeavyChHiggsMCAnalysis* mcAnalysis;
	MyMET theMET;
        TauIdAnalysis* tauIdAnalysis; // pointer to TauIdAnalysis object

        bool hardTauAlreadyCorrected;
};
#endif
