#ifndef TopMassReco_h
#define TopMassReco_h


#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"
#include "Framework/interface/MyHistogram.h"
#include "Framework/interface/Counter.h"
#include "Framework/interface/Cuts.h"
#include "HeavyChHiggsMCAnalysis.h"
//#include "TMVA/Reader.h"

/**
 * Helper function for reconstructing the mass of two jets.
 *
 * @param jet1  First jet
 * @param jet2  Second jet
 *
 * @return reconstructed mass
 */
double mass2jets(TLorentzVector jet1, TLorentzVector jet2);

/**
 * Helper function for reconstructing the mass of three jets.
 *
 * @param jet1  First jet
 * @param jet2  Second jet
 * @param jet3  Third jet
 *
 * @return reconstructed mass
 */
double mass3jets(TLorentzVector jet1, TLorentzVector jet2, TLorentzVector jet3);

/**
 * Top mass reconstruction class
 */
class TopMassReco {

    public:
        //TopMassReco(MyHistogram*,Counter*);
        /**
         * Constructor
         *
         * @param histo    MyHistogram object to use for histograms
         * @param counter  Counter object to use for event counter
         * @param cuts     Cuts object to query cuts
         */
	TopMassReco(MyHistogram *histo, Counter *counter, Cuts *cuts);

        /**
         * Destructor
         */
	~TopMassReco();

        /**
         * Enumeration for top reconstruction algorithm selection
         */
        enum recoAlgo {kSimple=1, /**< Simple algorithm */
                       kKinfit=2  /**< Kinematic fit algorithm */
        };

        /**
         * Top mass reconstruction for given event. Allowed algorithm names are
         * - simple, which is mapped to kSimple
         * - an2006, which is mapped to kKinfit
         * - kinfit, which is also mapped to kKinfit
         *
         * @see analyse(const MyJet*, MyEvent *, int, HeavyChHiggsMCAnalysis*)
         * 
         * @param tau          Identified tau jet
         * @param event        Pointer to event to be analysed
         * @param algo         Reconstruction algorithm name
         * @param mcAnalysis   Pointer to MC Analysis, if 0, MC information is not used
         *
         * @return true        If succesfully reconstructed top
         *         false       Otherwise
         */
	void    analyse(const MyJet *tau, MyEvent *event, const char *algo, HeavyChHiggsMCAnalysis *mcAnalysis=0);

        /**
         * Top mass reconstruction for given event. The output of the
         * reconstruction is meant to be fetched via methods.
         *
         * @param tau          Identified tau jet
         * @param event        Pointer to event to be analysed
         * @param algo         Reconstruction algorithm number as specified by recoAlgo enum
         * @param mcAnalysis   Pointer to MC Analysis, if 0, MC information is not used
         *
         * @return true        If succesfully reconstructed top
         *         false       Otherwise
         */
        void    analyse(const MyJet *tau, MyEvent *event, int algo, HeavyChHiggsMCAnalysis *mcAnalysis=0);

        /**
         * Number of jets which have been used for top
         * reconstruction. The jets are filtered from all event jets
         * by jetPreSelection
         *
         * @see jetPreSelection(const vector<MyJet>&, string, const MyJet*, bool)
         *
         * @return Number of jets
         */
	int 	njets();

        /**
         * Number of forward jets.
         *
         * @see jetPreSelection(const vector<MyJet>&, string, const MyJet*, bool)
         * 
         * @return Number of jets
         */
	int	nforwardJets();

        /**
         * Jet with greatest b jet discriminator value.
         *
         * @see findBestBjet(BjetAlgorithm, bool)
         *
         * @return Jet object
         */ 
	MyJet 	bestBJet();

        /**
         * Jet with second greatest b jet discriminator value.
         *
         * @see findBestBjet(BjetAlgorithm, bool)
         *
         * @return Jet object
         */ 
	MyJet 	secondbestBJet();

	vector<MyJet> jets();

        /**
         * @return  Reconstructed top mass
         */
	double 	topMass();

        /**
         * @return  pT of reconstructed top
         */
        double  topPt();

        /**
         * @return Reconstructed W mass
         */
        double  WMass();

        /**
         * @return Angle (DR) between light quark pair jets used for W reconstruction
         */
        double  thetaQQbar();

        /**
         * @return Angle (DR) between b-jet and reconstructed W
         */
        double  thetaWb();

        /**
         * @return \f$\chi^2\f$ of mass-energy fit
         */
        double  fitChi2();
        int     bJetCounter(double);
        bool    twoBtagging(double);
        bool    bJetVeto(double);

    private:
        /**
         * Simple fit algorithm. Searches the jet combination which
         * minimizes 
         * \f$ \chi^2 = \frac{(m_W - M_W)^2}{(\sigma_W)^2} + \frac{(m_\mathit{top}-M_\mathit{top})}{(\sigma_\mathit{top})^2} \f$
         * where
         * - \f$ m_W^2 = (p_1+p_2)^2 \f$
         * - \f$ m_\mathit{top}^2 = (p_1+p_2+p_3)^2 \f$
         * - \f$ M_W = 81 \f$ literature value
         * - \f$ M_\mathit{top} = 175 \f$ literature value
         * - \f$ \sigma_W = 20 \f$ literature value
         * - \f$ \sigma_\mathit{top} = 30 \f$ literature value
         *
         * @param bjet  b jet
         * @param jets  other jets
         *
         * @return true, if reconstruction was succesful
         *         false, otherwise
         */
        bool    topMassRecoAlgo(const MyJet& bjet, const vector<MyJet>& jets);

        /**
         * Kinematic fit algorithm. Searches the jet combination which
         * has the lowest 
         * \f$ \chi^2 = \frac{(m_W - M_W)^2}{(\sigma_W/2)^2} + \frac{(m_\mathit{top}-M_\mathit{top})}{(\sigma_\mathit{top})^2} + \sum_{i=1}^3 \frac{(E_i^m - E_i)^2}{\sigma_i^2}
         * with constraints
         * \f$ m_W^2 - (p_1+p_2)^2 = 0 \f$
         * \f$ m_\mathit{top}^2 - (p_1+p_2+p_3)^2 = 0 \f$
         *
         * @param bjet   b jet
         * @param jets   other jets
         *
         * @return true, if reconstruction was succesful
         *         false, otherwise
         */
        bool    topMassRecoAlgo2(const MyJet& bjet, const vector<MyJet>& jets);

        void    computeMVAvariables(const MyJet *, const MyJet&, const MyJet&, const MyJet&);
        void    computeVariables(const MyJet *, const MyJet&, const MyJet&, const MyJet&);
        //double  topMassRecoAlgoMVA(const MyJet *);
        void    topMassCombTrainMVA(const MyJet *, bool);

        /**
         * Jet (hadronic?) preselection
         *
         * @param jets            Jet candidates
         * @param jetCalibration  Jet calibration string
         * @param mcJetsOnly      If true, select only jets with definitive MC type
         */
        void    jetPreSelection(const vector<MyJet>& jets, string jetCalibration, const MyJet* tau, bool mcJetsOnly);

        /**
         * Enumeration for specifying b jet selection algorithm
         */
        enum    BjetAlgorithm {kBestDiscriminator,       /**< Select jet with greatest discriminator value */
                               kSecondBestDiscriminator  /**< Select jet with second greatest discriminator value */
        };

        /**
         * Find best B-jet for top reconstruction
         *
         * Best match is stored to bestBjet, and second best match to
         * secondbestBjet.
         *
         * @param algo        b jet identification algorithm
         * @param useMCinfo   If true, assigns b jets from MC info
         *
         * @return  true, if found b jet
         *          false, otherwise
         */
        bool    findBestBjet(BjetAlgorithm algo, bool useMCinfo);
        void    MCverify(HeavyChHiggsMCAnalysis *, double, int);

	MyHistogram*  histograms;                     /**< Histogram */
	Counter*      eventCounter;                   /**< Event counter */
        vector<MyJet> jetcontainer;                   /**< Hadronic(?) jets */
	vector<MyJet> forwardjetcontainer;            /**< Forward jets */
	vector<MyJet>::const_iterator bestBjet;       /**< B jet with greatest discriminator value.
                                                       *   Iterator points to jetcontainer item */
	vector<MyJet>::const_iterator secondbestBjet; /**< B jet with second greatest discriminator value.
                                                       *   Iterator points to jetcontainer item */
        vector<MyJet>::const_iterator bestQ1jet;      /**< Light quark jet used for W reconstruction.
                                                       *   Iterator points to otherJets (in analysis() item, 
                                                       *   which is a bad, error-prone solution */
        vector<MyJet>::const_iterator bestQ2jet;       /**< Light quark jet used for W reconstruction.
                                                       *   Iterator points to otherJets (in analysis() item, 
                                                       *   which is a bad, error-prone solution */
	double        topmass;                         /**< Reconstructed top mass */
	double	      wmass;                           /**< Reconstructe W mass */
        double        top_pt;                          /**< Top pT */
        double        top_eta;                         /**< Top \f$ \eta \f$ */
        double        theta_q_qbar;                    /**< Angle (DR) between light quarks (forming W) */
        double        theta_w_b;                       /**< Angle (DR) between W and b jet */
        double        fit_chi2;                        /**< Fit \f$ \chi^2 \f$ */
        Cuts*         cuts;                            /**< Cuts object */

        //TMVA::Reader *reader;
        //std::vector<double> mvaVariables;
        std::map<string, Float_t> mvaVariables;
        //std::vector<std::pair<std::string, double> > mvaVariables;
};
#endif
