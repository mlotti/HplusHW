#ifndef MCRECOQCDJET_H
#define MCRECOQCDJET_H

/**
This class provides MC info for hadronic jets from QCD multi-jet events

@author Lauri A. Wendland
*/

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"

#include <TLorentzVector.h>

class MCRecoQCDJet{
 public:
  MCRecoQCDJet(MyEvent* event, const MyJet* jet);
  ~MCRecoQCDJet();

  void print();
  
  // Getters
  bool isQCDJet() { return fFoundStatus; }
  
  bool isudsJet() { return (fPid >= 1 && fPid <= 3); }
  bool iscJet() { return (fPid == 4); }
  bool isbJet() { return (fPid == 5); }
  bool isgJet() { return (fPid == 21); }
  
      
 public:
  TLorentzVector fJet;
  
  
 private:
  bool fFoundStatus;
  int fPid;
  
};

#endif
