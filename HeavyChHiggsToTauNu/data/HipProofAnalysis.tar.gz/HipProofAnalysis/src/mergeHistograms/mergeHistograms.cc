#include<iostream>
#include<string>
#include<vector>
#include<map>
#include<iomanip>

#include <TFileMerger.h>
#include <TFile.h>
#include <TH1.h>
#include <TH1I.h>
#include <TList.h>
#include <TKey.h>
#include <TIterator.h>
#include <TCanvas.h>
#include <TObject.h>
#include <TAxis.h>

void print_usage(char*);

int main(int argc, char **argv) {
  char* rootInputFile[argc-1];
  char* outputFile = "histograms-merged.root";

  // Read input
  int nRoot = 0;
  for(int iarg = 1; iarg < argc; iarg++) {
    if(std::string(argv[iarg-1]) == "-o") {
      outputFile = argv[iarg];
    }
    else {
      std::string rootTest(argv[iarg]);
      if(rootTest.length() > 5 && rootTest != std::string(outputFile) &&
         rootTest.substr(rootTest.length()-4,4) == "root") 
        rootInputFile[nRoot++] = argv[iarg];
    }
  }

  if(nRoot == 0) {
    print_usage(argv[0]);
    return 0;
  }

  // Merge
  TFileMerger *merger = new TFileMerger();
  for(int i=0; i<nRoot; i++) {
    merger->AddFile(rootInputFile[i]);
  }
  merger->OutputFile(outputFile);
  merger->Merge();
  delete merger;
  merger = 0;

  // Rescale few histos
  TFile *file = TFile::Open(outputFile, "UPDATE");
  TList *keyList = file->GetListOfKeys();
  TIter next(keyList);
  TKey *key = 0;
  std::vector<TH1 *> hvec;

  double cross_section = 0;
  double luminosity = 0;
  double preselectionEff = 0;

  while(key = dynamic_cast<TKey *>(next())) {
    //std::cout << key->GetName() << std::endl;
    std::string name(key->GetName());
    if(name.substr(0, 13) == "cross_section" ||
       name.substr(0, 10) == "luminosity" ||
       name.substr(0, 15) == "preselectionEff") {

      std::cout << "Rescaling " << name << std::endl;

      TH1 *histo = dynamic_cast<TH1 *>(key->ReadObj());
      histo->Scale(1/double(nRoot));

      hvec.push_back(histo);

      if(name.substr(0, 13) == "cross_section") {
        cross_section = histo->GetBinContent(1);
      }
      else if(name.substr(0, 10) == "luminosity") {
        luminosity = histo->GetBinContent(1);
      }
      else {
        preselectionEff = histo->GetBinContent(1);
      }

      
      //TCanvas *canvas = new TCanvas(name.c_str(), "foo", 600, 600);
      //histo->Draw();
      //canvas->SaveAs(".eps");

      //histo->Write(); //"", TObject::kOverwrite);
    }
  }

  for(std::vector<TH1 *>::iterator iter = hvec.begin(); iter != hvec.end(); ++iter) {
    (*iter)->Write("", TObject::kOverwrite);
  }

  file->Write();
  file->Close();

  std::cout << "  cross section (pb) " << cross_section << std::endl;
  std::cout << "  luminosty (pb)     " << luminosity << std::endl;
  std::cout << "  preselection eff.  " << preselectionEff << std::endl;
  std::cout << std::endl;


  // Merge counters
  typedef std::vector<std::pair<std::string, int> > CounterContainer;
  CounterContainer counter;
  std::string events_name;
  for(int i=0; i<nRoot; i++) {
    TFile *ifile = TFile::Open(rootInputFile[i]);

    TIter next(ifile->GetListOfKeys());
    TKey *key;
    while(key = dynamic_cast<TKey *>(next())) {
      std::string name(key->GetName());
      if(name.substr(0, 7) == "nEvents") {
        events_name = name;

        TH1 *histo = dynamic_cast<TH1 *>(key->ReadObj());
        TAxis *xaxis = histo->GetXaxis();

        CounterContainer::iterator iter = counter.begin();

        for(int j=1; j <= xaxis->GetNbins(); ++j) {
          std::string label(xaxis->GetBinLabel(j));
          int c = int(histo->GetBinContent(j));

          std::cout << "   Label: " << label << std::endl;
          if(iter == counter.end()) {
            std::cout << "Adding " << label << std::endl;
            counter.push_back(std::make_pair(label, c));
            iter = counter.end();
          }
          else if(iter->first == label) {
              iter->second += c;
              ++iter;
          }
          else {
            std::cerr << "File " << rootInputFile[i] << " gives label " << label
                      << ", but was expecting " << iter->first << std::endl;
            return 1;
          }
        }
      }
    }
  }

  file = TFile::Open(outputFile, "UPDATE");
  file->cd();
  TH1I *histo = new TH1I(events_name.c_str(), events_name.c_str(), counter.size(), 0, counter.size());

  std::cout << "Merged event counter:" << std::endl;
  int i = 1;
  for(CounterContainer::const_iterator iter = counter.begin(); iter != counter.end(); ++iter) {
    std::cout << "  " << std::setw(30) << std::left << iter->first << " " << iter->second << std::endl;
    histo->GetXaxis()->SetBinLabel(i, iter->first.c_str());
    histo->SetBinContent(i, iter->second);
    ++i;
  }
  std::cout << std::endl;
  
  histo->Write("", TObject::kOverwrite);
  file->Write();
  file->Close();

  double allEvents = counter.begin()->second;
  

  std::cout << "Merged normalized events:" << std::endl;
  double norm = luminosity*cross_section*preselectionEff/allEvents;
  for(CounterContainer::const_iterator iter = counter.begin(); iter != counter.end(); ++iter) {
    std::cout << "  " << std::setw(30) << std::left << iter->first << " " << iter->second * norm << std::endl;
  }
  std::cout << std::endl;


  std::cout << "Merged cross section (pb):" << std::endl;
  norm = cross_section*preselectionEff/allEvents;
  for(CounterContainer::const_iterator iter = counter.begin(); iter != counter.end(); ++iter) {
    std::cout << "  " << std::setw(30) << std::left << iter->first << " " << iter->second * norm << std::endl;
  }
  std::cout << std::endl;
}


void print_usage(char* executable) {
  std::cout << "Usage: " << executable 
            << " file1 file2.. [-o outputfile]" << std::endl;
}
