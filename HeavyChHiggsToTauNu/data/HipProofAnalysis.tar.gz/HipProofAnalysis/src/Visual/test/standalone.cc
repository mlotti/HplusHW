#include "Visual/interface/TVisMainFrame.h"

#include "TROOT.h"

#include <iostream>
using namespace std;

int main(int argc, char **argv) {
  cout << "Starting visualization" << endl;
  /*
  if (argc > 1) {
    // Presume that first argument is root file
    myFileList.push_back(string(argv[1]));
    cout << "Using file: " << argv[1] << endl;
  } else {
    cout << "Using input from analysis.in" << endl;
    MyInput input;
    MyVisualAnalysis* myAnalysis = new MyVisualAnalysis(input);
    myFileList = myAnalysis->getFileList();
    delete myAnalysis;
  }
  */
  TApplication myApp("app", &argc, argv);
  TVisMainFrame myMainfame(gClient->GetRoot());
  // Run application
  myApp.Run();

  return 0;
}

