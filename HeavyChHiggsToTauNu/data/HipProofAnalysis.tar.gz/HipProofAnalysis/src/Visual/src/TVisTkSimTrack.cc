#include "Visual/interface/TVisTkSimTrack.h"

#include <TMath.h>
#include "TEveVSDStructs.h"

TVisTkSimTrack::TVisTkSimTrack(Double_t eta, Double_t phi, Double_t pt, Int_t hits, Double_t chi2)
: TVisTkTrack(eta,phi,pt,hits,chi2) {
  sprintf(fInfo, "SimTrack: pt=%3.2f GeV", fpt);

  fMatched = kFALSE;
  fpid = 0;
  fSimType = 0;
  fSimTrackId = 0;
  // Set drawable type to sim track
  fDrawableType = TKSIMTRACK_TYPE;
  fColor = kMagenta;
}

TVisTkSimTrack::~TVisTkSimTrack() {

}


//void TVisTkSimTrack::CalculateHits() {
  
  //TParticlePDG* myParticle = fDatabasePDG->GetParticle(fpid);
  // Double_t m = myParticle->Mass();
  // Double_t charge = myParticle->Charge();
  // Construct the helix
  /*
  TEveMCTrack* mySimTrack = new TEveMCTrack();
  mySimTrack->SetPdg(fpid);
  // Set charge
  if (fpid) > 0
    mySimTrack->SetCharge(1);
  else
    mySimTrack->SetCharge(-1);
  
  
  
  
  
  Double_t x = 0;
  Double_t y = 0;
  Double_t z = 0;
  
  // Calculate here track starting from production vertex
  Double_t t = 0;
  TVector3 myMomentum(fMomentum);
  TVector3 myPos(fVertex);
  Double_t phi0 = myMomentum.phi();
  Double_t phistep = TMath::Pi() / 180;
  Double_t timestep = 1e-10;
  Double_t phi = phi0;
  Double_t m = GetParticleMass(fpid);
  Double_t B = 4.0; // magnetic field in Teslas
  Bool_t myStatus = kTRUE;
  if (m > 0) {
    // Charged particles
    while (myStatus) {
      Double_t gamma = TMath::Sqrt(myMomentum.Mag2() + m*m) / m;
      Double_t r = myMomentum.Perp() / 0.3 / B;
      Double_t dx = r * (TMath::Cos(phi+phistep) - TMath::Cos(phistep));
      Double_t dy = r * (TMath::Sin(phi+phistep) - TMath::Sin(phistep));
      Double_t dz = r / m * TMath::Tan(phistep) * timestep / gamma;
      myPos->Set
      
    }
  } else {
    // Neutral particle - need to calculate only exit / decay point
  
  }
  */
  // CONTINUE HERE!
//}

/*
Double_t TVisTkSimTrack::GetParticleMass(Int_t pid) {
  // Returns particle mass in GeV/c^2
  
  switch (TMath::Abs(pid)) {
  case 11:  return   0.000511; // e-
  case 211: return 139.57; // pi-
  case 321: return 493.68; // K-
  case 2212: return 938.27; // p+
  }
  return 0;
}
*/

/*
void TVisTkSimTrack::Create() {
  // Clear previous
  fObjects->Clear();
  // Fill with points from TEveTrack
}
*/
/*
TVisTkSimTrack* TVisTkSimTrack::CloneTkSimTrack() {
  //
  return 0;
}
*/
void TVisTkSimTrack::MakeTrack(TGVisOptions* options) {
  Double_t mass = options->GetParticleMass(fpid);
  Double_t charge = options->GetParticleCharge(fpid);
  
  // Construct info string
  char myName[10];
  options->GetParticleName(fpid, myName);
  if (fSimTrackId < 0) {
    sprintf(fInfo, "MC particle: %s, pt=%.2f eta=%.2f phi=%2.f",
            myName, fMomentum.Pt(), fMomentum.Eta(), fMomentum.Phi());
  } else {
    sprintf(fInfo, "SimTrack: %s, pt=%.2f eta=%.2f phi=%2.f",
            myName, fMomentum.Pt(), fMomentum.Eta(), fMomentum.Phi());
  }
  TVisTrackPropagator myPropagator(&fVertex, &fMomentum, mass, charge, options->GetSimMagField(), fHits);
}

void TVisTkSimTrack::SetProdMomentum(Double_t x, Double_t y, Double_t z) {
  fMomentum.SetX(x);
  fMomentum.SetY(y);
  fMomentum.SetZ(z);
}

void TVisTkSimTrack::SetProdVertex(Double_t x, Double_t y, Double_t z) {
  fVertex.SetX(x);
  fVertex.SetY(y);
  fVertex.SetZ(z);
}

void TVisTkSimTrack::SetSimParameters(Int_t pid, Int_t type, Int_t trackId) {
  fpid = pid;
  fSimType = type;
  fSimTrackId = trackId;  
}
