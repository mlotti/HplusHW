#include "Visual/interface/VisGeoLookup.h"

#include <TMath.h>

#include <iostream>
using namespace std;


VisGeoLookup::VisGeoLookup() {
  fEtaBase = 0.08726646; // five degrees
  fScale = 100.0;

  // Fill in eta start sectors
  // Caution! There is an overlap at towers 28 and 29 in eta
  fHCALetaStart[0] = 0;
  for (Int_t i = 1; i < 20; ++i)
    fHCALetaStart[i] = fHCALetaStart[i-1] + 0.087;
  fHCALetaStart[20] = 1.74;
  fHCALetaStart[21] = 1.83;
  fHCALetaStart[22] = 1.93;
  fHCALetaStart[23] = 2.043;
  fHCALetaStart[24] = 2.172;
  fHCALetaStart[25] = 2.322;
  fHCALetaStart[26] = 2.5;
  fHCALetaStart[27] = 2.65;
  fHCALetaStart[28] = 2.853;
  fHCALetaStart[29] = 2.964;
  fHCALetaStart[30] = 3.139;
  fHCALetaStart[31] = 3.314;
  fHCALetaStart[32] = 3.489;
  fHCALetaStart[33] = 3.664;
  fHCALetaStart[34] = 3.839;
  fHCALetaStart[35] = 4.013;
  fHCALetaStart[36] = 4.191;
  fHCALetaStart[37] = 4.363;
  fHCALetaStart[38] = 4.538;
  fHCALetaStart[39] = 4.716;
  fHCALetaStart[40] = 4.889;
  fHCALetaStart[41] = 5.191; // this is actually f end of tower 41

  // Fill in phi resolution as function of eta towers
  for (Int_t i = 0; i < 20; ++i) fHCALphiRes[i] = fEtaBase;
  for (Int_t i = 20; i < 39; ++i) fHCALphiRes[i] = fEtaBase*2.0;
  for (Int_t i = 39; i < 41; ++i) fHCALphiRes[i] = fEtaBase*4.0;

  cout << "Visualization GeometryLookup initialized" << endl;
}

VisGeoLookup::~VisGeoLookup() {

}

Double_t VisGeoLookup::HCALEtaWidth(Double_t eta) {
  Int_t myEtaIndex = getHCALCellByEta(TMath::Abs(eta));
  return fHCALetaStart[myEtaIndex+1]-fHCALetaStart[myEtaIndex];
}

Double_t VisGeoLookup::HCALPhiWidth(Double_t eta) {
  Int_t myEtaIndex = getHCALCellByEta(TMath::Abs(eta));
  return fHCALphiRes[myEtaIndex];
}

/*
Double_t VisGeoLookup::getPhiWidth(Double_t eta) {
  if 
}
*/

Int_t VisGeoLookup::getHCALCellByPhi(Int_t etaIndex, Double_t phi) {
  Double_t myPhi = phi + 0.0001; // fix decimal clips
  Double_t myPhiRes = fHCALphiRes[etaIndex];
  Double_t myPhiIndex = myPhi / myPhiRes;
  return (Int_t)myPhiIndex; // suppose this floors f value
}

Int_t VisGeoLookup::getHCALCellByEta(Double_t eta) {
  Double_t myEta = eta + 0.0001; // fix decimal clips
  Int_t myIndex = 0;
  while (myIndex < 42) {
    if (myEta >= fHCALetaStart[myIndex] &&
	myEta < fHCALetaStart[myIndex+1])
      return myIndex;
    ++myIndex;
  }
  //cout << "getHCALCellByEta: Failed to evaluate cell index (eta="
  //<< eta << ")" << endl;
  return 41; // return maximum index in case of cell index overflow
}

/*
void VisGeoLookup::getGeoWidth(Double_t eta, Double_t phi, TVector3 *width) {
  Int_t myEtaIndex = getHCALCellByEta(eta);
  Double_t myPhiIndex = (Double_t)getHCALCellByPhi(myEtaIndex, phi);
  Double_t myPhiWidth = fHCALphiRes[myEtaIndex];

  width->SetXYZ(fHCALetaStart[myEtaIndex+1]-fHCALetaStart[myEtaIndex],
		myPhiWidth, 0);
}
*/
/*
TGeoTranslation* VisGeoLookup::getGeoTranslation(Double_t eta, Double_t phi, Double_t E) {
  Int_t myEtaIndex = getHCALCellByEta(eta);
  Double_t myPhiIndex = (Double_t)getHCALCellByPhi(myEtaIndex, phi);
  Double_t myPhiWidth = fHCALphiRes[myEtaIndex];

  Double_t dEta = fHCALetaStart[myEtaIndex];
  Double_t dPhi = myPhiWidth * myPhiIndex;
  
  return new TGeoTranslation(eta * dScale, phi * dScale, E * dScale);
}
*/
