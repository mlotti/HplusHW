#include "Visual/interface/TVisCaloTrackMarker.h"

#include <TMath.h>

#include <iostream>
using namespace std;

ClassImp(TVisCaloTrackMarker)

TVisCaloTrackMarker::TVisCaloTrackMarker(const char *name,
		                         Double_t eta, Double_t phi,
                                         Double_t pt, Int_t hits,
                                         Double_t chi2,
                                         Double_t deta, Double_t dphi)
: TVisDrawableBase(CALOTRACKMARKER_TYPE) {
  //cout << "creating marker at eta=" << eta
    //   << " phi=" << phi << endl;
  feta = eta;
  fphi = phi;
  fdeta = deta;
  fdphi = dphi;
  fpt = pt;
  fHits = hits;
  fchi2 = chi2;
  this->SetColorFromRange(0.0, 100.0, pt);
  if (pt >= 0) {
    sprintf(fInfo, "%s: pt=%3.2f GeV, hits=%d, chi2=%3.2f",
	    name, pt, hits, chi2);
  } else {
    sprintf(fInfo, "%s direction eta=%3.2f phi=%3.2f",
	    name, eta, phi);
  }
}

TVisCaloTrackMarker::TVisCaloTrackMarker(const char *info, Int_t color,
                                         Double_t eta, Double_t phi,
					 Double_t pt, Int_t hits,
					 Double_t chi2,
                                         Double_t deta, Double_t dphi)
 : TVisDrawableBase(CALOTRACKMARKER_TYPE, color) {
  //cout << "creating marker at eta=" << eta
    //   << " phi=" << phi << endl;
  feta = eta;
  fphi = phi;
  fdeta = deta;
  fdphi = dphi;
  fpt = pt;
  fHits = hits;
  fchi2 = chi2;
  sprintf(fInfo, "%s", info);
}

TVisCaloTrackMarker::~TVisCaloTrackMarker() {
  // Objects destroyed when pad is destroyed
}

TVisCaloTrackMarker* TVisCaloTrackMarker::CloneCaloTrackMarker() {
  TVisCaloTrackMarker *myMarker = 
    new TVisCaloTrackMarker(fInfo, fColor, feta, fphi, 
                            fpt, fHits, fchi2, fdeta, fdphi);
  if (!fSelectable) myMarker->SetSelectable(kFALSE);
  return myMarker;
}

void TVisCaloTrackMarker::Print() {
  cout << "  - marker (" << fSelectable 
       <<")(" << feta << ", " << fphi << "): " << fInfo << endl;
}

void TVisCaloTrackMarker::Create() {
  if (!fVisible) return;
  // Clear previous objects
  this->Clear();  
  
  Double_t d = 0.03;
  TPolyLine3D* fLine = new TPolyLine3D(5);
  fLine->SetPoint(0, feta-d, fphi, 0); // Left
  fLine->SetPoint(1, feta+d, fphi, 0); // Right
  fLine->SetPoint(2, feta, fphi, 0); // Center
  fLine->SetPoint(3, feta, fphi+d, 0); // Up
  fLine->SetPoint(4, feta, fphi-d, 0); // Down
  this->AddObject(fLine);
  if (fdeta > 0) {
    TPolyLine3D* fErrors[4];
    for (Int_t i = 0; i < 4; ++i) fErrors[i] = new TPolyLine3D(2);
    fErrors[0]->SetPoint(0, feta-fdeta, fphi+d, 0); // Left
    fErrors[0]->SetPoint(1, feta-fdeta, fphi-d, 0);
    fErrors[1]->SetPoint(0, feta+fdeta, fphi+d, 0); // Right
    fErrors[1]->SetPoint(1, feta+fdeta, fphi-d, 0);
    fErrors[2]->SetPoint(0, feta-d, fphi+fdphi, 0); // Up
    fErrors[2]->SetPoint(1, feta+d, fphi+fdphi, 0);
    fErrors[3]->SetPoint(0, feta-d, fphi-fdphi, 0); // Down
    fErrors[3]->SetPoint(1, feta+d, fphi-fdphi, 0);
    for (Int_t i = 0; i < 4; ++i) this->AddObject(fErrors[i]);
  }
}
 
Bool_t TVisCaloTrackMarker::IsWithinRadius(Double_t eta, Double_t phi, Double_t radius) {
  return GetDeltaR(eta,phi) < radius;
}

Double_t TVisCaloTrackMarker::GetDeltaR(Double_t eta, Double_t phi) {
  Double_t deta = feta-eta;
  Double_t dphi = fphi-phi;
  return (TMath::Sqrt(deta*deta + dphi*dphi));
}

