#include "Visual/interface/TVisEmbeddedCanvas.h"

#include <TROOT.h>
#include <TCanvas.h>

#include <iostream>
using namespace std;

ClassImp(TVisEmbeddedCanvas)

TVisEmbeddedCanvas::TVisEmbeddedCanvas(Int_t windowid,
				       const char* name,
				       const TGWindow* p,
				       UInt_t w,
				       UInt_t h,
				       UInt_t options,
				       Pixel_t back) : TRootEmbeddedCanvas(name, p, w, h, options, back) {
  fWindowId = windowid;
  isDoubleClickSensitive = kFALSE;
  isButtonClickSensitive = kTRUE;
}

TVisEmbeddedCanvas::~TVisEmbeddedCanvas() {

}

Bool_t TVisEmbeddedCanvas::HandleContainerDoubleClick(Event_t *event) {
  if (!fCanvas) return kTRUE;

  Int_t button = event->fCode;
  Int_t x = event->fX;
  Int_t y = event->fY;
  
  if (button == kButton1) {
    if (isDoubleClickSensitive)
      DoubleClicked(fWindowId);
    //cout << " double click pressed !" << endl;
    //fCanvas->HandleInput(kButton1Double, x, y);
  }
  if (button == kButton2)
    fCanvas->HandleInput(kButton2Double, x, y);
  if (button == kButton3)
    fCanvas->HandleInput(kButton3Double, x, y);
  
  return kTRUE;
}

Bool_t TVisEmbeddedCanvas::HandleContainerMotion(Event_t *event) {
   // Handle mouse motion event in the canvas container.

   if (!fCanvas) return kTRUE;

   Int_t x = event->fX;
   Int_t y = event->fY;

   if (fButton == 0) {
      fCanvas->HandleInput(kMouseMotion, x, y);
      // Emit signal of active window
      MouseEntered(fWindowId);
   }
   if (isButtonClickSensitive) {
     if (fButton == kButton1)
       fCanvas->HandleInput(kButton1Motion, x, y);
   }

   return kTRUE;
}

Bool_t TVisEmbeddedCanvas::HandleContainerButton(Event_t *event)
{
   // Handle mouse button events in the canvas container.
  fCanvas->cd();
   
   if (!fCanvas) return kTRUE;

   Int_t button = event->fCode;
   Int_t x = event->fX;
   Int_t y = event->fY;

   if (event->fType == kButtonPress) {
      fButton = button;
      //cout << " button pressed " << endl;
      if (isButtonClickSensitive) {
	if (button == kButton1)
	  fCanvas->HandleInput(kButton1Down, x, y);
	if (button == kButton2)
	  fCanvas->HandleInput(kButton2Down, x, y);
      }
      if (button == kButton3) {
         fCanvas->HandleInput(kButton3Down, x, y);
         fButton = 0;  // button up is consumed by TContextMenu
      }

   } else if (event->fType == kButtonRelease) {
      if (isButtonClickSensitive) {
	if (button == kButton1)
	  fCanvas->HandleInput(kButton1Up, x, y);
	if (button == kButton2)
	  fCanvas->HandleInput(kButton2Up, x, y);
      }
      if (button == kButton3)
         fCanvas->HandleInput(kButton3Up, x, y);

      fButton = 0;
   }

   return kTRUE;
}
