#include "Visual/interface/TVisTrackPropagator.h"

#include <iostream>
using namespace std;

ClassImp(TVisTrackPropagator)

TVisTrackPropagator::TVisTrackPropagator(TVector3* x, TVector3* p, Double_t m, Double_t q, Double_t Bz, TObjArray* hits)
: TObject() {
  // Takes as parameters the production vertex (x, in cm), production momentum (p, in GeV),
  // particle mass (m) and the particle charge (q)
  // The magnetic field is assumed to be uniform and along the z-axis

  fCurX = *x;
  fCurP = *p;
  fCurT = 0;
  fCurAngle = 0;
  Double_t fPt = p->Perp();
  
  Double_t E = TMath::Sqrt(p->Mag2() + m*m);
  fBeta = p->Mag() / E;
  fVelocity = TMath::C() * fBeta;
  fCharge = q;
  fQBz = fCharge * Bz * TMath::C() * 1.0e-9;
  fPRatio = p->Z() / fPt;
  fRadius = fPt / fQBz;
  fBz = Bz;
  SetPhiStep(5.0);  

  // Set boundary conditions
  fMaxZ = 2.94;
  fMaxR = 1.23;
  fMaxOrbitals = 10.0 * 2 * TMath::Pi();
  fHits = hits;
  
  cout << endl << "New track, mass=" << m << ", charge=" << q << endl;
  // Build track
  BuildTrack();
}

TVisTrackPropagator::~TVisTrackPropagator() {
  //fPoints->Clear();
  //delete fPoints;
}

/*
TPolyLine3D* TVisTrackPropagator::MakePolyLine3D() {
  Int_t iEnd = fPoints->GetEntriesFast();
  TPolyLine3D* myLine = new TPolyLine3D(iEnd);
  for (Int_t i = 0; i < iEnd; ++i) {
    TVector3* myPoint = (TVector3*)fPoints->At(i);
    myLine->SetPoint(i, myPoint->X(), myPoint->Y(), myPoint->Z());
  }
  return myLine;
}
*/
void TVisTrackPropagator::BuildTrack() {
  // Add production point
  fHits->Add(new TVector3(fCurX));
  Print();
  Bool_t myStatus = kFALSE;
  while (!myStatus) {
    Bool_t myVertexStatus = kFALSE;
    Int_t vertexCounter = 0;
    while (!myVertexStatus && vertexCounter <= 2) {
      CalculateStepForVertex(fCurX, fCurP);
      if (CheckVertexBoundary(fCurX)) {
        myVertexStatus = kTRUE;
      } else {
        ++vertexCounter;
      }
      cout << "vertex boundary print" << endl;
      Print();
    }
    cout << "- vertex boundary count=" << vertexCounter << endl;
    PropagateNextStep(fCurX, fCurP);
    Print();
    fHits->Add(new TVector3(fCurX));
    if (vertexCounter > 0 || fCurAngle <= fMaxOrbitals)
      myStatus = kTRUE;
  }
  cout << "Track builder: hit count=" << fHits->GetEntriesFast() << endl;
}

void TVisTrackPropagator::CalculateStepForVertex(TVector3& x, TVector3& p) {
  using namespace TMath;
  //if (fCurAngle + fPhiStep >= fMaxOrbitals) return kFALSE;
  Double_t stepX = (p.x()*fSinStep - p.y()*(1-fCosStep))/fQBz;
  Double_t stepY = (p.x()*(1-fCosStep) + p.y()*fSinStep)/fQBz;
  Double_t stepZ = fPRatio * Abs(fRadius*fPhiStep);
  fVertexStep.SetXYZ(stepX, stepY, stepZ);
}

Bool_t TVisTrackPropagator::CheckVertexBoundary(TVector3& x) {
  TVector3 newX(x);
  newX += fVertexStep;
  // Scale down phi step, if boundary conditions are not fulfilled
  Bool_t myBoundaryStatus = kFALSE;
  Double_t ratio = 1;
  Double_t newRadius = newX.Perp();
  Double_t newZ = TMath::Abs(newX.Z());
  if (newZ < fMaxZ && newRadius < fMaxR) {
    if (newZ - fMaxZ > newRadius - fMaxR) {
      ratio = (newZ - fMaxZ) / fMaxZ;
    } else {
      ratio = (newRadius - fMaxR) / fMaxR;
    }
  } else if (newZ < fMaxZ) {
    ratio = (newZ - fMaxZ) / fMaxZ;
  } else if (newRadius - fMaxR) {
    ratio = (newRadius - fMaxR) / fMaxR;
  }
  if (ratio < 1.0) {
    SetPhiStep(fPhiStep / TMath::Pi() * 180 * ratio);
  } else {
    myBoundaryStatus = kTRUE;
  }
  return myBoundaryStatus;  
}

void TVisTrackPropagator::Print() {
  cout << "PropInfo: p=(" << fCurP.x() << "," << fCurP.y() << "," << fCurP.z()
       << "), x=(" << fCurX.x() << "," << fCurX.y() << "," << fCurX.z()
       << "), angle=" << fCurAngle << endl;
}

void TVisTrackPropagator::PropagateNextStep(TVector3& x, TVector3& p) {
  Double_t px = p.x()*fCosStep - p.y()*fSinStep;
  Double_t py = p.x()*fSinStep + p.y()*fCosStep;
  p.SetX(px);
  p.SetY(py);
  x += fVertexStep;
  fCurAngle += fPhiStep;
}

void TVisTrackPropagator::SetPhiStep(Double_t step) {
  using namespace TMath;
  fPhiStep = step / 180.0 * Pi();
  fSinStep = Sin(fPhiStep);
  fCosStep = Cos(fPhiStep);
  fTimeStep = 0.01 * Abs(fRadius*fPhiStep) * Sqrt(1+fPRatio*fPRatio) / fVelocity; // cm to m
}
