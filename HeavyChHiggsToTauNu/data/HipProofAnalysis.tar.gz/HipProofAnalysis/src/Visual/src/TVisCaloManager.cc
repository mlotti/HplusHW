#include "Visual/interface/TVisCaloManager.h"

//#include <TPolyLine3D.h>
#include <TMath.h>

#include <iostream>
using namespace std;

ClassImp(TVisCaloManager)

TVisCaloManager::TVisCaloManager(const char *shortName, TGVisOptions* options) : TVisManagerBase(shortName, options, CALO_MANAGER) {
  // Set default drawing options
  fDrawJetCones = kFALSE;
  fDrawTrackMarkers = kFALSE;
  fDrawCells = kFALSE;
}

TVisCaloManager::~TVisCaloManager() {
  Clear();
}

void TVisCaloManager::AddJet(const MyJet* jet, Int_t type) {
  char myBuffer[30];
  sprintf(myBuffer, "Jet (%s)", fOptions->GetJetName(type));
  TVisCaloJet *myJet = new TVisCaloJet(myBuffer, type, jet->eta(), jet->phi(),
                                       fOptions);
  myJet->SetId(fObjects->GetEntriesFast());
  Int_t myJetId = myJet->JetId();
  SetJetDrawOptions(myJet);
  fObjects->Add(myJet);
  
  // Loop over calo towers
  vector<MyCaloTower>::const_iterator iCaloEnd = jet->caloInfo_end();
  for (vector<MyCaloTower>::const_iterator iCalo = jet->caloInfo_begin();
       iCalo != iCaloEnd; ++iCalo) {
    // Loop over HCAL cells
    vector<TVector3>::const_iterator iVectorEnd = iCalo->HCALCells_end();
    vector<TVector3>::const_iterator iVector;
    for (iVector = iCalo->HCALCells_begin(); iVector != iVectorEnd; ++iVector) {
      this->AddHcalCell(myJetId, (*iVector).Eta(), (*iVector).Phi(),
			(*iVector).Mag());
    }
    iVectorEnd = iCalo->ECALCells_end();
    for (iVector = iCalo->ECALCells_begin(); iVector != iVectorEnd; ++iVector) {
      this->AddEcalCell(myJetId, (*iVector).Eta(), (*iVector).Phi(),
			(*iVector).Mag());
    }
  }
  // Loop over tracks
  vector<MyTrack>::const_iterator iTrackEnd = jet->tracks_end();
  for (vector<MyTrack>::const_iterator iTrack = jet->tracks_begin();
       iTrack != iTrackEnd; ++iTrack) {
    if (TMath::Abs(iTrack->trackEcalHitPoint.eta()) > 0.00001) {
      this->AddTrackMarker(myJetId, "track", iTrack->trackEcalHitPoint.eta(),
			   iTrack->trackEcalHitPoint.phi(),
			   iTrack->pt(), (Int_t)iTrack->numberOfValidHits(),
			   iTrack->normalizedChi2(),
                           0, 0);
    } else {
      //cout << "Rejected anomalous track" << endl;
    }
  }
  if (myJet->GetMaxEnergy()) this->SetViewable();
  this->SetViewMaxZ(myJet->GetMaxEnergy());
}

void TVisCaloManager::AddJet(TVisCaloJet* jet) {
  SetJetDrawOptions(jet);
  jet->SetId(fObjects->GetEntriesFast());
  fObjects->Add(jet);
  this->SetViewMaxZ(jet->GetMaxEnergy());
}

void TVisCaloManager::AddEcalCell(Int_t id, Double_t eta, Double_t phi, Double_t E) {
  if (!CheckJetIndex(id)) return;
  TVisCaloJet *jet = (TVisCaloJet*)fObjects->At(id);
  Double_t deta = GetGeometry()->HCALEtaWidth(eta) / 5.0; // approx. with this
  Double_t dphi = GetGeometry()->HCALPhiWidth(eta) / 5.0;
  jet->AddEcalCell(eta-deta/2.0, phi-dphi/2.0, deta, dphi, E);
  SetViewMaxZ(E);
}

void TVisCaloManager::AddHcalCell(Int_t id, Double_t eta, Double_t phi, Double_t E) {
  if (!CheckJetIndex(id)) return;
  TVisCaloJet *jet = (TVisCaloJet*)fObjects->At(id);
  Double_t deta = GetGeometry()->HCALEtaWidth(eta);
  Double_t dphi = GetGeometry()->HCALPhiWidth(eta);
  jet->AddHcalCell(eta+deta/2.0, phi+dphi/2.0, deta, dphi, E);
  this->SetViewMaxZ(E);
}

void TVisCaloManager::AddTrackMarker(Int_t id, const char *name,
				     Double_t eta, Double_t phi,
				     Double_t pt, Int_t hits,
				     Double_t chi2,
                                     Double_t deta, Double_t dphi) {
  if (!CheckJetIndex(id)) return;
  TVisCaloJet *jet = (TVisCaloJet*)fObjects->At(id);
  jet->AddTrackMarker(name, eta, phi, pt, hits, chi2, deta, dphi);
}

Bool_t TVisCaloManager::CheckJetIndex(Int_t id) {
  if (id >= fObjects->GetEntriesFast()) {
    cout << "Error: Asked for invalid jet index! (index=" << id
	 << ", jetcount=" << fObjects->GetEntriesFast() << endl;
    return kFALSE;
  }
  return kTRUE;
}

void TVisCaloManager::Clear() {
  Int_t lastJet = fObjects->GetEntriesFast();
  for (Int_t iJet = 0; iJet < lastJet; ++iJet) {
    TVisCaloJet *myJet = (TVisCaloJet*)fObjects->At(iJet);
    myJet->Clear();
  }
  BaseClear();
}
  
void TVisCaloManager::Draw() {
  if (fDrawFullCaloGrid) {
    CreateFullCaloGrid();
    DrawGrid();
  }
  if (fDrawJetCaloGrid) {
    // Take direction from first jet
    TVisCaloJet *myJet = (TVisCaloJet*)fObjects->At(0);
    CreateCaloGrid(myJet->Jeteta(), myJet->Jetphi());
    DrawGrid();
  }
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t iJet = 0; iJet < iEnd; ++iJet) {
    TVisCaloJet *myJet = (TVisCaloJet*)fObjects->At(iJet);
    myJet->Draw();
  }
}

Int_t TVisCaloManager::PointingDistance(Int_t px, Int_t py) {
  //if (!fVisible) return kFALSE;
  // Check previously selected object
  
  if (fActiveId >= 0) {
    Int_t myValue = ((TVisCaloJet*)fObjects->At(fActiveId))->PointingDistance(px,py);
    fInfo = ((TVisCaloJet*)fObjects->At(fActiveId))->GetInfo();
    if (myValue < 9999) return myValue;
  }
  
  // Loop over jets
  Int_t lastJet = fObjects->GetEntriesFast();
  for (Int_t iJet = 0; iJet < lastJet; ++iJet) {
    TVisCaloJet *myJet = (TVisCaloJet*)fObjects->At(iJet);
    if (myJet->IsDirty()) myJet->CalculateInfo();
    Int_t myValue = myJet->PointingDistance(px,py);
    if (myValue == 0) {  
      // Unselect previous selection
      if (fSelectWholeJet) {
        if (fActiveId >= 0) ((TVisCaloJet*)fObjects->At(fActiveId))->SelectAllObjects(kFALSE);
      }
      fActiveId = iJet;
      fInfo = myJet->GetInfo();
      return 0;
    }
    if (myValue == -1) {
      fActiveId = iJet;
      return -1; 
    }
  }
  return 9999;
}

void TVisCaloManager::Print(Int_t id) {
  TVisCaloJet *myJet = (TVisCaloJet*)fObjects->At(id);
  myJet->Print();
}

void TVisCaloManager::Print() {
  Int_t lastJet = fObjects->GetEntriesFast();
  cout << "Printing jets (jet count=" << lastJet << ")" << endl;
  for (Int_t iJet = 0; iJet < lastJet; ++iJet) {
    TVisCaloJet *myJet = (TVisCaloJet*)fObjects->At(iJet);
    myJet->Print();
  }
}

void TVisCaloManager::SetJetDrawOptions(TVisCaloJet* jet) {
  jet->SetDrawCaloCircles(fDrawJetCones);
  jet->SetDrawCaloTrackMarkers(fDrawTrackMarkers);
  jet->SetDrawCaloCells(fDrawCells);
  jet->SetSelectWholeJet(fSelectWholeJet);
}

void TVisCaloManager::Unselect() {
  if (fActiveId < 0) return;
  if (fSelectWholeJet) {
    ((TVisCaloJet*)fObjects->At(fActiveId))->SelectAllObjects(kFALSE);
  } else {
    ((TVisCaloJet*)fObjects->At(fActiveId))->SelectSingleObject(kFALSE);
  }
  fActiveId = -1;
}
