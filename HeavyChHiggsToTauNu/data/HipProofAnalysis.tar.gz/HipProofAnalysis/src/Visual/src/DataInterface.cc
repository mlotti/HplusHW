#include "Visual/interface/DataInterface.h"
#include "Framework/interface/MyInput.h"
#include "Framework/interface/Dataset.h"

#include <TBranch.h>
#include <TTree.h>
#include <TFile.h>
#include <TXNetFile.h>

#include <iostream>
#include <vector>
using namespace std;

DataInterface::DataInterface() {
  int myCounter = 0;
  MyInput myInput;
  vector<Dataset> myDatasets = myInput.getDatasets();
  vector<Dataset>::const_iterator iDataset;
  vector<Dataset>::const_iterator iDatasetEnd = myDatasets.end();
  for(iDataset = myDatasets.begin(); 
      iDataset!= iDatasetEnd; ++iDataset){
    cout << "Examining dataset: " << (*iDataset).getName().c_str() << endl;
    theURLStatus = (*iDataset).isURL();
    vector<string> files = iDataset->getFiles();
    vector<string>::const_iterator iFile;
    vector<string>::const_iterator iFileEnd = files.end();
    for (iFile = files.begin(); iFile != files.end(); ++iFile) {
      theFiles.push_back(*iFile);
      ++myCounter;
    }
  }
  cout << "Found " << myCounter << " file(s) in datasets" << endl;
  theEvent = new MyEvent();
  iCurrentFile = theFiles.begin();
  iCurrentFileEvent = -1;
}

DataInterface::~DataInterface() {
  theFiles.clear();
  delete theEvent;
}

bool DataInterface::nextEvent() {
  vector<string>::const_iterator iFile;
  vector<string>::const_iterator iFileEnd = theFiles.end();
  Int_t pos = iCurrentFileEvent+1;
  if (theFiles.begin() == iFileEnd) return false;

  if (iCurrentFileEvent < 0) {
    iFile = theFiles.begin();
  } else {
    iFile = iCurrentFile;
  }
  // Open file
  cout << (*iFile).c_str() << endl;
  TFile *file;
  if (theURLStatus) {
    file = new TXNetFile((*iFile).c_str());
  } else {
    file = new TFile((*iFile).c_str());
  }
  if (!file) return false;

  TTree* rootTree = (TTree*)file->Get("rootTree;1");
  Int_t myEntries = int(rootTree->GetEntries());
  if (pos > myEntries) {
    // Open next file
    ++iFile;
    pos = 0;
    if (iFile == iFileEnd) {
      // Rewind to first file
      iFile = theFiles.begin();
    }
    // Close previous file and open next one
    file->Close();
    delete file;
    if (theURLStatus) {
      file = new TXNetFile((*iFile).c_str());
    } else {
      file = new TFile((*iFile).c_str());
    }
    if (!file) return false;
  }
  rootTree = (TTree*)file->Get("rootTree;1");
  TBranch* branch = rootTree->GetBranch("MyEvent");
  branch->SetAddress(&theEvent);
  rootTree->GetEvent(pos);
  file->Close();
  delete file;

  iCurrentFile = iFile;
  iCurrentFileEvent = pos;

  return true;
}

bool DataInterface::readEvent(int run, int event) {
  Bool_t myFoundStatus = kFALSE;
  vector<string>::const_iterator iFile;
  vector<string>::const_iterator iFileEnd = theFiles.end();
  if (theFiles.begin() == iFileEnd) return false;

  for(iFile = theFiles.begin(); iFile != iFileEnd; ++iFile){
    TFile* file;
    if (theURLStatus) {
      file = new TXNetFile((*iFile).c_str());
    } else {
      file = new TFile((*iFile).c_str());
    }
    if (!file) return false;
    TTree* rootTree = (TTree*)file->Get("rootTree;1");
    Int_t myEntries = int(rootTree->GetEntries());
    Int_t myCount = 0; 
    while (!myFoundStatus && myCount < myEntries) {
      TBranch* branch = rootTree->GetBranch("MyEvent");
      branch->SetAddress(&theEvent);
      rootTree->GetEvent(myCount);
      if (theEvent->run() == run &&
	  theEvent->event() == event) {
	iCurrentFile = iFile;
	iCurrentFileEvent = myCount;
	delete file;
	return true;
      } else {
	++myCount;
      }
    } 
    file->Close();
    delete file;
  }
  return false;
}

char* DataInterface::getFilename() {
  sprintf(theFilename, "%s", (*iCurrentFile).c_str());
  return theFilename;
}
