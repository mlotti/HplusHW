#include "Visual/interface/TVisTkManager.h"
#include "Visual/interface/TVisTkSimTrack.h"

//#include <TEveManager.h>

#include <iostream>
#include <vector>
using namespace std;

ClassImp(TVisTkManager)

TVisTkManager::TVisTkManager(const char* shortName, TGVisOptions *options)
: TVisManagerBase(shortName, options, TRACK_MANAGER) {
  // Default settings for options
  fDrawTracks = kFALSE;
  fSimTracks = new TObjArray();
  cout << "fsimtracks created" << endl;
  cout << "simobjarray: " << fSimTracks << endl;  
}

TVisTkManager::~TVisTkManager() {
  delete fSimTracks;
}

void TVisTkManager::AddJet(const MyJet* jet, Int_t type) {
  char myBuffer[30];
  sprintf(myBuffer, "Jet (%s)", fOptions->GetJetName(type));
  TVisTkJet *myJet = new TVisTkJet(myBuffer, type, jet->eta(), jet->phi(),
                                   fOptions);
  myJet->SetId(fObjects->GetEntriesFast());
  //Int_t myJetId = myJet->JetId();
  SetJetDrawOptions(myJet);
  fObjects->Add(myJet);
                                         
  // Loop over tracks
  vector<MyTrack>::const_iterator iTrackEnd = jet->tracks_end();
  for (vector<MyTrack>::const_iterator iTrack = jet->tracks_begin();
       iTrack != iTrackEnd; ++iTrack) {
    if (TMath::Abs(iTrack->trackEcalHitPoint.eta()) > 0.00001) {
      TVisTkTrack* myTrack = new TVisTkTrack(iTrack->trackEcalHitPoint.eta(),
                                             iTrack->trackEcalHitPoint.phi(),
                                             iTrack->pt(), (Int_t)iTrack->numberOfValidHits(),
                                             iTrack->normalizedChi2());
      cout << "Adding track" << endl;
      // Loop over hits
      if (iTrack->hits_end()-iTrack->hits_begin()) this->SetViewable();
      vector<MyHit>::const_iterator iHitEnd = iTrack->hits_end();
      for (vector<MyHit>::const_iterator iHit = iTrack->hits_begin();
           iHit != iHitEnd; ++iHit) {
        cout << ".. adding hit" << endl;
        myTrack->AddHit(iHit->getX(), iHit->getY(), iHit->getZ());
        // Set minima and maxima for view
        this->SetViewX(iHit->getX());
        this->SetViewY(iHit->getY());
        this->SetViewZ(iHit->getZ());
      }
    } else {
      //cout << "Rejected anomalous track" << endl;
    }
  }
  /*
  Double_t min[3], max[3];
  GetViewDimensions(min,max);
  cout << "view: min(" << min[0] << "," << min[1] << "," << min[2] << ")"
       << " max(" << max[0] << "," << max[1] << "," << max[2] << ")" << endl;
       */
}

void TVisTkManager::AddSimInfo(MyEvent* event) {
  cout << "- MC particle count: "
       << event->mcParticles_end() - event->mcParticles_begin() << endl;
       
  MyGlobalPoint myGlobalPoint = event->getMCPrimaryVertex();
  TVector3 myMCPV(myGlobalPoint.getX(),myGlobalPoint.getY(),myGlobalPoint.getZ());
  cout << "MCPV = (" << myMCPV.x() << "," << myMCPV.y() << "," << myMCPV.z() << ")" << endl;
  // Loop over MC particles
  vector<MyMCParticle>::const_iterator iMCEnd = event->mcParticles_end();
  for (vector<MyMCParticle>::const_iterator iMC = event->mcParticles_begin();
       iMC != iMCEnd; ++iMC) {
/*    cout << "MC:pdg=" << iMC->pid
         << " status=" << iMC->status
         << " bcode=" << iMC->barcode
         << " p=(" << iMC->px()
         << ", " << iMC->py()
         << ", " << iMC->pz()
         << ")" << endl;*/
    // NOTE: continue here!
    if (iMC->status == 1 && TMath::Abs(iMC->Eta()) < 5) {
      TVisTkSimTrack* myTk = new TVisTkSimTrack(iMC->Eta(), iMC->Phi(), iMC->Perp(), -1, -1);
      myTk->SetProdMomentum(iMC->X(), iMC->Y(), iMC->Z());
      myTk->SetProdVertex(myMCPV.x(), myMCPV.y(), myMCPV.z());
      myTk->SetSimParameters(iMC->pid, 0, -1);
      myTk->MakeTrack(fOptions);
      fSimTracks->Add(myTk);
      this->SetViewable();
    }
    
    // Cannot use currently properly, because no production vertex is stored !
  }
  // Loop over sim tracks
  cout << "- SimTrack count: "
       << event->simTracks_end() - event->simTracks_begin() << endl;

  vector<MySimTrack>::const_iterator iSimEnd = event->simTracks_end();
  for (vector<MySimTrack>::const_iterator iSim = event->simTracks_begin();
       iSim != iSimEnd; ++iSim) {
    if (TMath::Abs(iSim->Eta()) < 5 && iSim->Perp() > 1.0) {
      TVisTkSimTrack* myTk = new TVisTkSimTrack(iSim->Eta(), iSim->Phi(), iSim->Perp(), -1, -1);
      myTk->SetProdMomentum(iSim->X(), iSim->Y(), iSim->Z());
      myTk->SetProdVertex(iSim->thePosition.X(), iSim->thePosition.Y(), iSim->thePosition.Z());
      myTk->SetSimParameters(iSim->theGenPID, iSim->theType, iSim->theTrackID);
      myTk->MakeTrack(fOptions);
      fSimTracks->Add(myTk);
      // View setting
      this->SetViewable();
    }
  }
   

  this->SetViewX(1.3);
  this->SetViewY(1.3);
  this->SetViewZ(3.00);
  this->SetViewX(-1.3);
  this->SetViewY(-1.3);
  this->SetViewZ(-3.00);
  
  //Double_t min[3], max[3];
/*  GetViewDimensions(min,max);
  cout << "view: min(" << min[0] << "," << min[1] << "," << min[2] << ")"
       << " max(" << max[0] << "," << max[1] << "," << max[2] << ")" << endl;*/
  cout << "- SimTracks stored for viewing: " << fSimTracks->GetEntriesFast() << endl;
}

void TVisTkManager::Clear() {
  Int_t lastJet = fObjects->GetEntriesFast();
  for (Int_t iJet = 0; iJet < lastJet; ++iJet) {
    TVisTkJet *myJet = (TVisTkJet*)fObjects->At(iJet);
    myJet->Clear();
  }
  BaseClear();
  Int_t iEnd = fSimTracks->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    delete ((TVisTkSimTrack*)fSimTracks->At(i));
  }
  fSimTracks->Clear();
}

void TVisTkManager::Draw() {
  /*
  if (fDrawFullCaloGrid) {
    CreateFullCaloGrid();
    DrawGrid();
  }
  if (fDrawJetCaloGrid) {
    // Take direction from first jet
    TVisTkJet *myJet = (TVisTkJet*)fObjects->At(0);
    CreateCaloGrid(myJet->Jeteta(), myJet->Jetphi());
    DrawGrid();
  }
  */
  // Loop over jets
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t iJet = 0; iJet < iEnd; ++iJet) {
    TVisTkJet *myJet = (TVisTkJet*)fObjects->At(iJet);
    myJet->Draw();
  }
  // Loop over sim tracks
  iEnd = fSimTracks->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    TVisTkSimTrack* myTk = (TVisTkSimTrack*)fSimTracks->At(i);
    // Create object and draw
    Bool_t myStatus = kFALSE;
    if (myTk->pt() >= fOptions->GetSimMinPt() && myTk->pt() <= fOptions->GetSimMaxPt()) {
      if (fSelectWholeJet) myStatus = kTRUE;
      if (!fSelectWholeJet) {
        // Check compatibility with jet radius
        Int_t iJetEnd = fObjects->GetEntriesFast();
        for (Int_t iJet = 0; iJet < iJetEnd; ++iJet) {
          TVisTkJet *myJet = (TVisTkJet*)fObjects->At(iJet);
          if (myTk->IsWithinRadius(myJet->Jeteta(), myJet->Jetphi(), fOptions->GetJetRadius()))
            myStatus = kTRUE;
        }
      }
      if (myStatus) {
        cout << "creating sim track" << endl;
        myTk->Create();
        myTk->Draw();
        myTk->SetVisible();
      }
    }
    if (!myStatus) { 
      myTk->SetVisible(kFALSE);
    }
    //cout << "sim track draw status=" << myStatus << ", pt=" << myTk->pt() << endl;
  }
}

Int_t TVisTkManager::PointingDistance(Int_t px, Int_t py) {
  if (fActiveId >= 0) {
    Int_t myValue = ((TVisTkJet*)fObjects->At(fActiveId))->PointingDistance(px,py);
    if (myValue < 9999) return myValue;
  }

  // Loop over jets
  Int_t lastJet = fObjects->GetEntriesFast();
  for (Int_t iJet = 0; iJet < lastJet; ++iJet) {
    TVisTkJet *myJet = (TVisTkJet*)fObjects->At(iJet);
    if (myJet->IsDirty()) myJet->CalculateInfo();
    Int_t myValue = myJet->PointingDistance(px,py);
    if (myValue == 0) {  
      // Unselect previous selection
      if (fSelectWholeJet) {
        if (fActiveId >= 0) ((TVisTkJet*)fObjects->At(fActiveId))->SelectAllObjects(kFALSE);
      }
      fActiveId = iJet;
      fInfo = myJet->GetInfo();
      return 0;
    }
    if (myValue == -1) {
      fActiveId = iJet;
      return -1; 
    }
  }
  return 9999;

}

void TVisTkManager::Print() {
  cout << "Printing jets" << endl;
  Int_t lastJet = fObjects->GetEntriesFast();
  for (Int_t iJet = 0; iJet < lastJet; ++iJet) {
    TVisTkJet *myJet = (TVisTkJet*)fObjects->At(iJet);
    myJet->Print();
  }
}

void TVisTkManager::Print(Int_t id) {
  TVisTkJet *myJet = (TVisTkJet*)fObjects->At(id);
  myJet->Print();
}

void TVisTkManager::Unselect() {
  if (fActiveId < 0) return;
  if (fSelectWholeJet) {
    ((TVisTkJet*)fObjects->At(fActiveId))->SelectAllObjects(kFALSE);
  } else {
    ((TVisTkJet*)fObjects->At(fActiveId))->SelectSingleObject(kFALSE);
  }
  fActiveId = -1;

}

void TVisTkManager::SetJetDrawOptions(TVisTkJet *jet) {
  jet->SetDrawTkTracks(fDrawTracks);
  jet->SetDrawTkSimTracks(fDrawSimTracks);
  jet->SetSelectWholeJet(fSelectWholeJet);
}
