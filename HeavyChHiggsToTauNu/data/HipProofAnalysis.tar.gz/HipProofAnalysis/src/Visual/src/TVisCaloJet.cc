#include "Visual/interface/TVisCaloJet.h"

#include <TMath.h>

#include <iostream>
using namespace std;

ClassImp(TVisCaloJet)

TVisCaloJet::TVisCaloJet(const char* name, Int_t type,
			 Double_t eta, Double_t phi,
			 TGVisOptions* options)
: TVisJetBase(name, type, eta, phi, options) {
  Clear();
  // Create jet circles using TVisDrawableBase objects
  char myBuffer[80];
  // Jet radius  
  sprintf(myBuffer, "Jet radius of %.2f around (eta=%.2f,phi=%.2f)",
          fOptions->GetJetRadius(), fJetEta, fJetPhi);
  TVisCircle* myCone = new TVisCircle(fJetEta, fJetPhi, fOptions->GetJetRadius());
  myCone->SetInfo(myBuffer);
  fObjects->Add(myCone);
  // Isolation cone 
  sprintf(myBuffer, "Jet isolation cone of %.2f around (eta=%.2f,phi=%.2f)",
          fOptions->GetTrIsolationCone(), fJetEta, fJetPhi);
  myCone = new TVisCircle(fJetEta, fJetPhi, fOptions->GetTrIsolationCone());
  myCone->SetInfo(myBuffer);
  fObjects->Add(myCone);
  // Signal cone 
  sprintf(myBuffer, "Jet signal cone of %.2f around (eta=%.2f,phi=%.2f)",
          fOptions->GetTrSignalCone(), fJetEta, fJetPhi);
  myCone = new TVisCircle(fJetEta, fJetPhi, fOptions->GetTrSignalCone());
  myCone->SetInfo(myBuffer);
  fObjects->Add(myCone);
}

TVisCaloJet::~TVisCaloJet() {
}

TVisCaloJet* TVisCaloJet::CloneCaloJet() {
  TVisCaloJet *myJet = new TVisCaloJet(fName, fJetType,
                                       fJetEta, fJetPhi, fOptions);
  this->CloneBaseJet(myJet);
  return myJet;
}

void TVisCaloJet::CalculateInfo() {
  fEcalEnergy = 0;
  fHcalEnergy = 0;
  fTotalEcalEnergy = 0;
  fTotalHcalEnergy = 0;
  fIsolationTracks = 0;
  fSignalTracks = 0;

  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    if (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType() == CALOCELL_TYPE) {
      TVisCaloCell* myCell = (TVisCaloCell*)fObjects->At(i);
      // Check option thresholds
      if (fOptions->SatisfiesEnergyThreshold(myCell->Energy(), myCell->IsEcal()) &&
          myCell->IsWithinRadius(fJetEta, fJetPhi, fOptions->GetJetRadius())) {
        if (myCell->IsEcal()) {
          fEcalEnergy += myCell->Energy();
        } else {
          fHcalEnergy += myCell->Energy();
        }
      }
      if (myCell->IsEcal()) {
        fTotalEcalEnergy += myCell->Energy();
      } else {
        fTotalHcalEnergy += myCell->Energy();
      }
    }
    // Tracks
    if (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType() == CALOTRACKMARKER_TYPE) {
      TVisCaloTrackMarker* myMarker = (TVisCaloTrackMarker*)fObjects->At(i);
      if (myMarker->IsWithinRadius(fJetEta, fJetPhi, fOptions->GetTrSignalCone())) {
        ++fSignalTracks;
      } else if (myMarker->IsWithinRadius(fJetEta, fJetPhi, fOptions->GetTrIsolationCone())) {
        ++fIsolationTracks;
      }
    }
  }
  
  // Compose jet info string
  sprintf(fInfo, "Jet (%s) (eta=%.2f, phi=%.2f), ECAL=%.2f/%2.f GeV, HCAL=%.2f/%2.f GeV, nSgnTrk=%d, nIsoTrk=%d",
    fOptions->GetJetName(fJetType), fJetEta, fJetPhi, fEcalEnergy, fTotalEcalEnergy, fHcalEnergy,
    fTotalHcalEnergy, fSignalTracks, fIsolationTracks);
  fDirty = kFALSE;
}

void TVisCaloJet::AddEcalCell(Double_t eta, Double_t phi,
			      Double_t deta, Double_t dphi, Double_t dE) {
  // check first, if a HCAL cell is located beneath the ECAL cell
  Double_t zcorr = 0.0;
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    if (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType() == CALOCELL_TYPE) {
      TVisCaloCell* oCell = (TVisCaloCell*)fObjects->At(i);
      if (oCell->IsOverlapping(eta, phi, deta, dphi))
        zcorr = oCell->Energy();
    }
  }
  fObjects->Add(new TVisCaloCell(eta,phi,zcorr,deta,dphi,dE,kTRUE));
  fDirty = kTRUE;
}
 
void TVisCaloJet::AddHcalCell(Double_t eta, Double_t phi,
			      Double_t deta, Double_t dphi, Double_t dE) {
  fObjects->Add(new TVisCaloCell(eta,phi,0,deta,dphi,dE,kFALSE));
  fDirty = kTRUE;
}

void TVisCaloJet::AddTrackMarker(const char *name,
				 Double_t eta, Double_t phi,
				 Double_t pt, Int_t hits,
				 Double_t chi2,
                                 Double_t deta, Double_t dphi) {
  TVisCaloTrackMarker *myMarker =
    new TVisCaloTrackMarker(name, eta, phi, pt, hits, chi2, deta, dphi);
  fObjects->Add(myMarker);
  fDirty = kTRUE;
}

Double_t TVisCaloJet::GetMaxEnergy() {
  Double_t max = 0;
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    if (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType() == CALOCELL_TYPE) {
      TVisCaloCell* myCell = (TVisCaloCell*)fObjects->At(i);
      if (myCell->Energy() > max)
        max = myCell->Energy();
      }
  }
  return max;
}

