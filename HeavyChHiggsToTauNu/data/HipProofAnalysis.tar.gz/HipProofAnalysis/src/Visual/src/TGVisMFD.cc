#include "Visual/interface/TGVisMFD.h"
#include "Visual/interface/TVisCaloManager.h"
#include "Visual/interface/TVisTkManager.h"

#include <TGFileDialog.h>
#include <TAxis3D.h>

#include <iostream>
using namespace std;


TGVisMFD::TGVisMFD(Int_t id, TObjArray *array, const TGWindow* p, Int_t w, Int_t h) : TGCompositeFrame(p, w, h, kVerticalFrame | kSunkenFrame) {
  fActiveManagerId = -1;
  fCanvasEmpty = kTRUE;
  fManagers = array;
  fManagerButtons = new TObjArray();

  // Create layout hints
  fButtonFrameLayout = new TGLayoutHints(kLHintsTop | kLHintsLeft | kLHintsExpandX, 0, 0, 0, 0);
  fButtonLayout = new TGLayoutHints(kLHintsTop | kLHintsLeft, 2, 2, 2, 2);
  fECanvasLayout = new TGLayoutHints(kLHintsTop | kLHintsLeft | kLHintsExpandX | kLHintsExpandY, 0, 0, 0, 0);

  // Label
  //fTitle = new TGLabel(this, "dummy");
  //AddFrame(fTitle, fButtonFrameLayout);

  // Buttons for managers
  fManagerButtonFrame = new TGCompositeFrame(this, w, 30, kHorizontalFrame);
  Int_t lastManager = fManagers->GetEntriesFast();
  for (Int_t iMgr = 0; iMgr < lastManager; ++iMgr) {
    TVisManagerBase *myManager = (TVisManagerBase*)fManagers->At(iMgr);
    // Create button
    TGTextButton* myButton =
      new TGTextButton(fManagerButtonFrame, myManager->GetShortName(), iMgr);
    myButton->Connect("Clicked()", "TGVisMFD", this, "DoManagerSelect()");
    myButton->AllowStayDown(kTRUE);
    fManagerButtonFrame->AddFrame(myButton, fButtonLayout);
    fManagerButtons->Add(myButton);
  }
  AddFrame(fManagerButtonFrame, fButtonFrameLayout);

  // Canvas
  char myBuffer[80];
  sprintf(myBuffer, "ecanvas%d", id);
  // Create embedded canvas
  fECanvas = new TVisEmbeddedCanvas(id, myBuffer, this, w, h-60);
  fECanvas->Connect("DoubleClicked(Int_t)","TGVisMFD",this,
		    "DoDoubleClicked(Int_t)");
  fECanvas->Connect("MouseEntered(Int_t)","TGVisMFD",this,
		    "MouseEntered(Int_t)");
  fCanvas = fECanvas->GetCanvas();
  fCanvas->SetBorderMode(0);
  fCanvas->SetSupportGL(kTRUE);
  AddFrame(fECanvas, fECanvasLayout);

  // Create button frame
  fButtonFrame = new TGCompositeFrame(this, w, 30, kHorizontalFrame);
  fZoomInButton = new TGTextButton(fButtonFrame, "Zoom", M_ZOOM_IN);
  fZoomInButton->Associate(this);
  fZoomInButton->SetToolTipText("Zooms in on the view (j)");
  fZoomInButton->Connect("Clicked()", "TGVisMFD", this,
			 "DoZoomIn()");
  fButtonFrame->AddFrame(fZoomInButton, fButtonLayout);
  fZoomOutButton = new TGTextButton(fButtonFrame, "Unzoom", M_ZOOM_OUT);
  fZoomOutButton->Associate(this);
  fZoomOutButton->SetToolTipText("Zooms out the view (k)");
  fZoomOutButton->Connect("Clicked()", "TGVisMFD", this,
			  "DoZoomOut()");
  fButtonFrame->AddFrame(fZoomOutButton, fButtonLayout);
  
  fPrintButton = new TGTextButton(fButtonFrame, "Print", M_PRINT);
  fPrintButton->Associate(this);
  fPrintButton->SetToolTipText("Prints the canvas contents to a file");
  fPrintButton->Connect("Clicked()", "TGVisMFD", this,
			  "DoPrint()");
  fButtonFrame->AddFrame(fPrintButton, fButtonLayout);

  fDefaultViewButton = new TGTextButton(fButtonFrame, "Default", M_DEFAULTVIEW);
  fDefaultViewButton->Associate(this);
  fDefaultViewButton->SetToolTipText("Sets view to top view");
  fDefaultViewButton->Connect("Clicked()", "TGVisMFD", this,
			  "DoDefaultView()");
  fButtonFrame->AddFrame(fDefaultViewButton, fButtonLayout);

  fFrontViewButton = new TGTextButton(fButtonFrame, "Front", M_FRONTVIEW);
  fFrontViewButton->Associate(this);
  fFrontViewButton->SetToolTipText("Sets view to top view");
  fFrontViewButton->Connect("Clicked()", "TGVisMFD", this,
			  "DoFrontView()");
  fButtonFrame->AddFrame(fFrontViewButton, fButtonLayout);

  fSideViewButton = new TGTextButton(fButtonFrame, "Side", M_SIDEVIEW);
  fSideViewButton->Associate(this);
  fSideViewButton->SetToolTipText("Sets view to top view");
  fSideViewButton->Connect("Clicked()", "TGVisMFD", this,
			  "DoSideView()");
  fButtonFrame->AddFrame(fSideViewButton, fButtonLayout);

  fTopViewButton = new TGTextButton(fButtonFrame, "Top", M_TOPVIEW);
  fTopViewButton->Associate(this);
  fTopViewButton->SetToolTipText("Sets view to top view");
  fTopViewButton->Connect("Clicked()", "TGVisMFD", this,
			  "DoTopView()");
  fButtonFrame->AddFrame(fTopViewButton, fButtonLayout);

  f3DButton = new TGTextButton(fButtonFrame, "3D", M_3DVIEW);
  f3DButton->Associate(this);
  f3DButton->SetToolTipText("Opens the canvas in an external 3D viewer");
  f3DButton->Connect("Clicked()", "TGVisMFD", this,
                     "Do3D()");
  fButtonFrame->AddFrame(f3DButton, fButtonLayout);
  AddFrame(fButtonFrame, fButtonFrameLayout);

  //cout << " MFD created" << endl;
  UpdateButtons();
}

TGVisMFD::~TGVisMFD() {

}

void TGVisMFD::Clear() {
  fCanvas->Clear();
  fActiveManagerId = -1;
  fCanvasEmpty = kTRUE;
}

void TGVisMFD::Draw() {
  Double_t min[3];
  Double_t max[3];
  
  fCanvas->cd();  
  fCanvas->Clear(); // This deletes all the objects drawn to the pad
  //fCanvas->Update();
  fCanvas->Update();
  if (fActiveManagerId < 0) return;
  TVisManagerBase* myBase = (TVisManagerBase*)fManagers->At(fActiveManagerId);
  // Draw manager content
  if (!myBase->IsViewable()) return;
  switch (myBase->GetManagerType()) {
  case CALO_MANAGER:
    ((TVisCaloManager*)fManagers->At(fActiveManagerId))->Draw();
    break;
  case TRACK_MANAGER:
    ((TVisTkManager*)fManagers->At(fActiveManagerId))->Draw();
    break;
  }
  // Set options
  //myBase->GetViewDimensions(min,max);
  //SetRange(min,max);
  fCanvas->Update();
  if (myBase->IsTopViewOnly()) {
    DoTopView();
    SetEnableMouseClicks(kFALSE);
  } else {
    SetEnableMouseClicks();
    if (fCanvasEmpty) {
      DoDefaultView();
      fCanvasEmpty = kFALSE;
    }
  }
  fECanvas->SetDoubleClickSensitivity(myBase->IsDoubleClickable());
  
  myBase->GetViewDimensions(min,max);
  if (max[2]>0) {
    SetRange(min,max);
    ShowAxis();
    fCanvas->Update();
  }
  UpdateButtons();
}

void TGVisMFD::Unselect() {
  if (fActiveManagerId < 0) return;
   TVisManagerBase* myBase = (TVisManagerBase*)fManagers->At(fActiveManagerId);
   switch (myBase->GetManagerType()) {
  case CALO_MANAGER:
    ((TVisCaloManager*)fManagers->At(fActiveManagerId))->Unselect();
    break;
  case TRACK_MANAGER:
    ((TVisTkManager*)fManagers->At(fActiveManagerId))->Unselect();
    break;
  }

}

Int_t TGVisMFD::PointingDistance(Int_t px, Int_t py) {
  if (fActiveManagerId < 0) return -1;
  fCanvas->cd();
  //TVisManagerBase* myBase = ;
  // Draw manager content
  Int_t myValue = 9999;
  switch (((TVisManagerBase*)fManagers->At(fActiveManagerId))->GetManagerType()) {
  case CALO_MANAGER:
    myValue = ((TVisCaloManager*)fManagers->At(fActiveManagerId))->PointingDistance(px,py);
    break;
  case TRACK_MANAGER:
    myValue = ((TVisTkManager*)fManagers->At(fActiveManagerId))->PointingDistance(px,py);
    break;
  }
  
  return myValue;
}

void TGVisMFD::DoZoomIn() {
  fCanvas->cd();
  fCanvas->GetView()->ZoomView(0, 1.25);
  fCanvas->Update();
}

void TGVisMFD::DoZoomOut() {
  fCanvas->cd();
  fCanvas->GetView()->UnzoomView(0, 1.25);
  fCanvas->Update();
}

void TGVisMFD::DoPrint() {
  fCanvas->cd();
  
  const Char_t *filetypes[] = {
    "EPS  files",    "*.eps",
    "PS   files",    "*.ps",
    "GIF  files",    "*.gif",
    "ROOT files",    "*.root",
    "ROOT macros",   "*.C",
    "All files",     "*",
    0,               0
  };
  TGFileInfo fi;
  fi.fFileTypes = filetypes;
  new TGFileDialog(fClient->GetRoot(), this, kFDSave,&fi);
  if (!fi.fFilename) return;

  fCanvas->Print(fi.fFilename);
}

void TGVisMFD::DoDefaultView() {
  fCanvas->cd();
  fCanvas->GetView()->RotateView(250.0,50.0,0);
}

void TGVisMFD::DoFrontView() {
  fCanvas->cd();
  fCanvas->GetView()->Front();
}

void TGVisMFD::DoSideView() {
  fCanvas->cd();
  fCanvas->GetView()->Side();
}

void TGVisMFD::DoTopView() {
  fCanvas->cd();
  fCanvas->GetView()->Top();
}

void TGVisMFD::Do3D() {
  fCanvas->cd();
  //fCanvas->GetViewer3D("ogl");
}

void TGVisMFD::SetEnabled(Bool_t status) {
  fZoomInButton->SetEnabled(status);
  fZoomOutButton->SetEnabled(status);
  fPrintButton->SetEnabled(status);
}

void TGVisMFD::SetRange(Double_t *min, Double_t *max) {
  fCanvas->cd();
  fCanvas->GetView()->SetRange(min, max);
  //fCanvas->Update();
}

void TGVisMFD::SetEnableMouseClicks(Bool_t status) {
  fECanvas->SetButtonClickSensitivity(status);
}

void TGVisMFD::ShowAxis() {
  fCanvas->GetView()->ShowAxis();

  TAxis3D* myAxis = TAxis3D::GetPadAxis(fCanvas);
  //cout << "axis x title" << myAxis->GetXTitle() << endl;
  myAxis->SetXTitle("eta");
  myAxis->SetYTitle("phi");
  myAxis->SetZTitle("E (GeV)");
  myAxis->Paint();

}

void TGVisMFD::DoManagerSelect() {
  // Find out what has changed
  Int_t lastButton = fManagerButtons->GetEntriesFast();
  for (Int_t iButton = 0; iButton < lastButton; ++iButton) {
    TGTextButton *myButton = (TGTextButton*)fManagerButtons->At(iButton);
    if (myButton->IsDown() && iButton != fActiveManagerId) {
      // new button has been invoked
      if (fActiveManagerId >= 0) {
	myButton = (TGTextButton*)fManagerButtons->At(fActiveManagerId);
	myButton->SetDown(kFALSE);
      }
      fActiveManagerId = iButton;
      Draw();
      DoPadChanged(fECanvas->GetId());
    } else if (iButton == fActiveManagerId && !myButton->IsDown()) {
      myButton->SetDown();
      myButton->SetState(kButtonEngaged);
    }
  }
  //UpdateButtons();
}

void TGVisMFD::DoDoubleClicked(Int_t a) {
  if (fActiveManagerId < 0) return;
  Emit("DoDoubleClicked(Int_t)", 
       ((TVisManagerBase*)fManagers->At(fActiveManagerId))->GetDoubleClickAction());
}

TVisManagerBase* TGVisMFD::GetActiveManager() {
  if (fActiveManagerId < 0) return (TVisManagerBase*)0;
  return (TVisManagerBase*)fManagers->At(fActiveManagerId);
}

void TGVisMFD::UpdateButtons() {
  // Set visibility of managers
  Int_t iEnd = fManagers->GetEntriesFast();
  for (Int_t iMgr = 0; iMgr < iEnd; ++iMgr) {
    TVisManagerBase *myManager = (TVisManagerBase*)fManagers->At(iMgr);
    TGTextButton* myButton = (TGTextButton*)fManagerButtons->At(iMgr);
    myButton->SetEnabled(myManager->IsViewable());
    if (iMgr == fActiveManagerId) {
      myButton->SetDown();
      myButton->SetState(kButtonEngaged);
    }
  }
  // Set visibility of option buttons
  if (fActiveManagerId < 0) {
    fZoomInButton->SetEnabled(kFALSE);
    fZoomOutButton->SetEnabled(kFALSE);
    fPrintButton->SetEnabled(kFALSE);
    fDefaultViewButton->SetEnabled(kFALSE);
    fFrontViewButton->SetEnabled(kFALSE);
    fSideViewButton->SetEnabled(kFALSE);
    fTopViewButton->SetEnabled(kFALSE);
    f3DButton->SetEnabled(kFALSE);
  } else {
    TVisManagerBase *myManager = (TVisManagerBase*)fManagers->At(fActiveManagerId);
    fECanvas->SetDoubleClickSensitivity(myManager->IsDoubleClickable());
    fZoomInButton->SetEnabled(kTRUE);
    fZoomOutButton->SetEnabled(kTRUE);
    fPrintButton->SetEnabled(kTRUE);
    fDefaultViewButton->SetEnabled(kTRUE);
    fFrontViewButton->SetEnabled(kTRUE);
    fSideViewButton->SetEnabled(kTRUE);
    fTopViewButton->SetEnabled(kTRUE);
    f3DButton->SetEnabled(myManager->Allows3D());
  }
      
}

