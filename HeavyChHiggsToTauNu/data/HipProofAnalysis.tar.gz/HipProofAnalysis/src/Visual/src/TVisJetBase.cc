#include "Visual/interface/TVisJetBase.h"

TVisJetBase::TVisJetBase(const char* name, Int_t type, Double_t eta, Double_t phi, TGVisOptions* options)
: TVisDrawableBase(JET_TYPE) {
  sprintf(fName, "%s", name);
  fJetType = type;
  fJetEta = eta;
  fJetPhi = phi;
  fOptions = options;
  fJetId = -1;
  
  for (Int_t j = 0; j < VIS_DRAWABLE_TYPE_COUNT; ++j) {
    fDrawObjectType[j] = kFALSE;
  }
  fActiveObjectId = -1;
  fSelectWholeJet = kFALSE;
  fDirty = kTRUE;
}

TVisJetBase::~TVisJetBase() {
  //for (Int_t j = 0; j < VIS_DRAWABLE_TYPE_COUNT; ++j) {
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    switch (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType()) {
    case CALOCELL_TYPE: delete ((TVisCaloCell*)fObjects->At(i)); break;
    case CALOTRACKMARKER_TYPE: delete ((TVisCaloTrackMarker*)fObjects->At(i)); break;
    case CIRCLE_TYPE: delete ((TVisCircle*)fObjects->At(i)); break;
    case TKTRACK_TYPE: delete ((TVisTkTrack*)fObjects->At(i)); break;
    }
  }
}

void TVisJetBase::Clear() {
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    switch (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType()) {
    case CALOCELL_TYPE: ((TVisCaloCell*)fObjects->At(i))->Clear(); break;
    case CALOTRACKMARKER_TYPE: ((TVisCaloTrackMarker*)fObjects->At(i))->Clear(); break;
    case CIRCLE_TYPE: ((TVisCircle*)fObjects->At(i))->Clear(); break;
    case TKTRACK_TYPE: ((TVisTkTrack*)fObjects->At(i))->Clear(); break;
    }
  }
  fObjects->Clear();
  fActiveObjectId = -1;
}

void TVisJetBase::CloneBaseJet(TVisJetBase* jet) {
  CloneBaseDrawable(jet);
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    switch (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType()) {
    case CALOCELL_TYPE:
      jet->Add(((TVisCaloCell*)fObjects->At(i))->CloneCaloCell());
      break;
    case CALOTRACKMARKER_TYPE:
      jet->Add(((TVisCaloTrackMarker*)fObjects->At(i))->CloneCaloTrackMarker());
      break;
    case CIRCLE_TYPE:
      //jet->Add(((TVisCircle*)fObjects->At(i))->CloneCircle());
      // A circle is created in the constructor
      break;
    case TKTRACK_TYPE:
      jet->Add(((TVisTkTrack*)fObjects->At(i))->CloneTkTrack());
      break;
    }
  }
  // Don't clone drawing settings, since they are set from the manager
  // Don't clone sim tracks, they are owned by the manager, not the jet
  fDirty = kTRUE;
  fActiveObjectId = -1;
}

/*
virtual void TVisJetBase::Create() {
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    switch (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType()) {
    case CALOCELL_TYPE: ((TVisCaloCell*)fObjects->At(i))->Create(); break;
    case CALOTRACKMARKER_TYPE: ((TVisCaloTrackMarker*)fObjects->At(i))->Create(); break;
    case CALOCIRCLE_TYPE: ((TVisCircle*)fObjects->At(i))->Create(); break;
    case CALOTKTRACK_TYPE: ((TVisTkTrack*)fObjects->At(i))->Create(); break;
    }
  }
}
*/

void TVisJetBase::Draw() {
  // Check jet visibility
  if (!fOptions->GetJetVisibility(fJetType)) return;
  // Loop over drawable objects and draw them
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    TVisDrawableBase* myDrawable = ((TVisDrawableBase*)fObjects->At(i));
    Int_t myType = myDrawable->GetDrawableType();
    if (DrawingRequested(myType)) {
      switch (myType) {
      case CALOCELL_TYPE:
        TVisCaloCell* myCell = (TVisCaloCell*)fObjects->At(i);
        if (fOptions->SatisfiesCaloVisibility(myCell->IsEcal()) &&
            fOptions->SatisfiesEnergyThreshold(myCell->Energy(), myCell->IsEcal()) &&
            myCell->IsWithinRadius(fJetEta, fJetPhi, fOptions->GetJetRadius())) {
          myCell->SetVisible();
          myCell->Create();
          myCell->Draw();
        } else {
          myCell->SetVisible(kFALSE);
        }
        break;
      case CALOTRACKMARKER_TYPE:
        TVisCaloTrackMarker* myMarker = (TVisCaloTrackMarker*)fObjects->At(i);
        if (myMarker->IsWithinRadius(fJetEta, fJetPhi, fOptions->GetJetRadius())) {
          myMarker->SetVisible();
          myMarker->Create();
          myMarker->Draw();
        } else {
          myMarker->SetVisible(kFALSE);
        }
        break;
      case CIRCLE_TYPE:
        TVisCircle* myCone = (TVisCircle*)fObjects->At(i);
        myCone->SetVisible();
        myCone->Create();
        myCone->Draw();
        break;
      case TKTRACK_TYPE:
        TVisTkTrack* myTrack = (TVisTkTrack*)fObjects->At(i);
        myTrack->SetVisible();
        myTrack->Create();
        myTrack->Draw();
        break;
      }
    }
  } 
}

Int_t TVisJetBase::PointingDistance(Int_t px, Int_t py) {
  // Check jet visibility
  if (!fOptions->GetJetVisibility(fJetType)) return 9999;
  // Check active object (speeds up search in lots of cases)
  Int_t myValue = 9999;
  if (fActiveObjectId >= 0) {
    switch (((TVisDrawableBase*)fObjects->At(fActiveObjectId))->GetDrawableType()) {
    case CALOCELL_TYPE: myValue = ((TVisCaloCell*)fObjects->At(fActiveObjectId))->PointingDistance(px,py); break;
    case CALOTRACKMARKER_TYPE: myValue = ((TVisCaloTrackMarker*)fObjects->At(fActiveObjectId))->PointingDistance(px,py); break;
    case CIRCLE_TYPE: myValue = ((TVisCircle*)fObjects->At(fActiveObjectId))->PointingDistance(px,py); break;
    case TKTRACK_TYPE: myValue = ((TVisTkTrack*)fObjects->At(fActiveObjectId))->PointingDistance(px,py); break;
    }
    if (myValue < 9999) return myValue;
  }
  // Check all drawable objects
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    TVisDrawableBase* myDrawable = ((TVisDrawableBase*)fObjects->At(i));
    Int_t myType = myDrawable->GetDrawableType();
    if (DrawingRequested(myType)) {
      switch (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType()) {
      case CALOCELL_TYPE: myValue = ((TVisCaloCell*)fObjects->At(i))->PointingDistance(px,py); break;
      case CALOTRACKMARKER_TYPE: myValue = ((TVisCaloTrackMarker*)fObjects->At(i))->PointingDistance(px,py); break;
      case CIRCLE_TYPE: myValue = ((TVisCircle*)fObjects->At(i))->PointingDistance(px,py); break;
      case TKTRACK_TYPE: myValue = ((TVisTkTrack*)fObjects->At(i))->PointingDistance(px,py); break;
      }
      if (myValue == -1) {
        return -1;
      }
      if (myValue == 0) {
        if (!fSelectWholeJet) {
          SelectSingleObject(kFALSE);
          fActiveObject = myDrawable;
          fActiveObjectId = i;
          SelectSingleObject(kTRUE);
          fJetInfo = fActiveObject->GetInfo();
        } else {
          // Select whole jet
          SelectAllObjects();
          fActiveObjectId = 0;
          fJetInfo = fInfo;
        }
        return 0;
      }
    }
  }
  return myValue;  
}

void TVisJetBase::Print() {
  cout << "jet info: type=" << fName 
       << " id=" << fJetId
       << " activeid=" << fActiveObjectId
       << " visible=" << fVisible
       << " selectable=" << fSelectable
       << " selected=" << fSelected << endl;
  //if (!fDirty) cout << fJetInfo << endl;
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    switch (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType()) {
    case CALOCELL_TYPE: ((TVisCaloCell*)fObjects->At(i))->Print(); break;
    case CALOTRACKMARKER_TYPE: ((TVisCaloTrackMarker*)fObjects->At(i))->Print(); break;
    case CIRCLE_TYPE: ((TVisCircle*)fObjects->At(i))->Print(); break;
    case TKTRACK_TYPE: ((TVisTkTrack*)fObjects->At(i))->Print(); break;
    }
  }    

}

void TVisJetBase::SelectSingleObject(Bool_t status) {
  // Select/deselect active object
  if (fActiveObjectId < 0) return;
  
  ((TVisDrawableBase*)fObjects->At(fActiveObjectId))->SetSelected(status);
  if (!status) fActiveObjectId = -1;
}

void TVisJetBase::SelectAllObjects(Bool_t status) {
  // Select/deselect all drawable objects
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    TVisDrawableBase* myDrawable = ((TVisDrawableBase*)fObjects->At(i));
    if (DrawingRequested(myDrawable->GetDrawableType())) {
        //myDrawable->IsSelectable()) {
      myDrawable->SetSelected(status);
    }
  }
  if (!status) fActiveObjectId = -1;
}
