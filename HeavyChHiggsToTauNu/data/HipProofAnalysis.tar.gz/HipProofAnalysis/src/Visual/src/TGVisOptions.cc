#include "Visual/interface/TGVisOptions.h"

#include <TMath.h>

#include <iostream>
using namespace std;

ClassImp(TGVisOptions)

TGVisOptions::TGVisOptions(const TGWindow* p, Int_t w, Int_t h, TObject* main) :
  TGCompositeFrame(p, w, h, kVerticalFrame)
{
  sprintf(VisJetTypeName[0], "L1 object");
  sprintf(VisJetTypeName[1], "HLT object");
  sprintf(VisJetTypeName[2], "electron");
  sprintf(VisJetTypeName[3], "photon");
  sprintf(VisJetTypeName[4], "muon");
  sprintf(VisJetTypeName[5], "tau");
  sprintf(VisJetTypeName[6], "PF tau");

  // Layout settings
  fItemLayout = new TGLayoutHints(kLHintsTop | kLHintsLeft, 2, 2, 0, 0);
  fFrameLayout = new TGLayoutHints(kLHintsTop | kLHintsLeft | kLHintsExpandX, 2, 2, 0, 0);

  fButtonLayout = new TGLayoutHints(kLHintsTop | kLHintsCenterX, 2, 2, 5, 0);
  

  // Event selection group
  fEventSelectionGroup = new TGGroupFrame(this, "Event selection");
  fRunNumberLabel = new TGLabel(fEventSelectionGroup, "Run number");
  fEventSelectionGroup->AddFrame(fRunNumberLabel, fItemLayout);
  fRunNumber = new TGNumberEntry(fEventSelectionGroup, 0, 8, -1, TGNumberFormat::kNESInteger);
  fRunNumber->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  fEventSelectionGroup->AddFrame(fRunNumber, fItemLayout);

  fEventNumberLabel = new TGLabel(fEventSelectionGroup, "Event number");
  fEventSelectionGroup->AddFrame(fEventNumberLabel, fItemLayout);
  fEventNumber = new TGNumberEntry(fEventSelectionGroup, 0, 8, -1, TGNumberFormat::kNESInteger);
  fEventNumber->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  fEventSelectionGroup->AddFrame(fEventNumber, fItemLayout);

  fReadEventButton = new TGTextButton(fEventSelectionGroup, "Read event");
  fReadEventButton->Connect("Clicked()", "TVisMainFrame",main,"DoReadEvent()");
  fEventSelectionGroup->AddFrame(fReadEventButton, fButtonLayout);

  fNextEventButton = new TGTextButton(fEventSelectionGroup, "Next event");
  fNextEventButton->Connect("Clicked()", "TVisMainFrame",main,"DoNextEvent()");
  fEventSelectionGroup->AddFrame(fNextEventButton, fButtonLayout);
  this->AddFrame(fEventSelectionGroup, fFrameLayout);

  // Jet visibility group
  fJetVisibilityGroup = new TGGroupFrame(this, "Jet types");
  char myBuffer[30];
  for (Int_t i = 0; i < JET_TYPE_COUNT; ++i) {
    sprintf (myBuffer, "Show %ss", VisJetTypeName[i]);
    fJetVisibilityButton[i] =
      new TGCheckButton(fJetVisibilityGroup, myBuffer, i);
    fJetVisibilityButton[i]->SetDown(kFALSE);
    fJetVisibilityButton[i]->Connect("Clicked()","TVisMainFrame",main,"DoUpdateCanvases()");
    fJetVisibilityGroup->AddFrame(fJetVisibilityButton[i], fItemLayout);
  }
  fJetVisibilityButton[JET_TAU]->SetDown(kTRUE);

  this->AddFrame(fJetVisibilityGroup, fFrameLayout);

  // Calorimeter visibility group
  fCaloGroup = new TGGroupFrame(this, "Object visibility");
  fEcalVisibleButton = new TGCheckButton(fCaloGroup, "ECAL visible", 10);
  fEcalVisibleButton->SetDown(kTRUE);
  fEcalVisibleButton->Connect("Clicked()", "TVisMainFrame", main,"DoUpdateCanvases()");
  fCaloGroup->AddFrame(fEcalVisibleButton, fItemLayout);
  fHcalVisibleButton = new TGCheckButton(fCaloGroup, "HCAL visible", 11);
  fHcalVisibleButton->SetDown(kTRUE);
  fHcalVisibleButton->Connect("Clicked()", "TVisMainFrame", main,"DoUpdateCanvases()");
  fCaloGroup->AddFrame(fHcalVisibleButton, fItemLayout);
  fTrackVisibleButton = new TGCheckButton(fCaloGroup, "Tracks visible", 12);
  fTrackVisibleButton->SetDown(kTRUE);
  fTrackVisibleButton->Connect("Clicked()", "TVisMainFrame", main,"DoUpdateCanvases()");
  fCaloGroup->AddFrame(fTrackVisibleButton, fItemLayout);
  fSimTrackVisibleButton = new TGCheckButton(fCaloGroup, "SimTracks visible", 12);
  fSimTrackVisibleButton->SetDown(kTRUE);
  fSimTrackVisibleButton->Connect("Clicked()", "TVisMainFrame", main,"DoUpdateCanvases()");
  fCaloGroup->AddFrame(fSimTrackVisibleButton, fItemLayout);
  this->AddFrame(fCaloGroup, fFrameLayout);

  // Tab selector for cuts
  fTab = new TGTab(this, w, 300);
  TGCompositeFrame *myFrame;
  
  // Calorimeter cuts
  myFrame = fTab->AddTab("Calo");
  fJetRadiusLabel = new TGLabel(myFrame, "Jet radius");
  myFrame->AddFrame(fJetRadiusLabel, fItemLayout);
  fJetRadius = new TGNumberEntry(myFrame, 0.70, 8, -1, TGNumberFormat::kNESRealTwo);
  fJetRadius->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fJetRadius, fItemLayout);

  fTrIsolationRadiusLabel = new TGLabel(myFrame, "Tracker isolation cone");
  myFrame->AddFrame(fTrIsolationRadiusLabel, fItemLayout);
  fTrIsolationRadius = new TGNumberEntry(myFrame, 0.45, 8, -1, TGNumberFormat::kNESRealTwo);
  fTrIsolationRadius->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fTrIsolationRadius, fItemLayout);

  fTrSignalRadiusLabel = new TGLabel(myFrame, "Tracker signal cone");
  myFrame->AddFrame(fTrSignalRadiusLabel, fItemLayout);
  fTrSignalRadius = new TGNumberEntry(myFrame, 0.07, 8, -1, TGNumberFormat::kNESRealTwo);
  fTrSignalRadius->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fTrSignalRadius, fItemLayout);

  fEcalThresholdLabel = new TGLabel(myFrame, "ECAL threshold (GeV)");
  myFrame->AddFrame(fEcalThresholdLabel, fItemLayout);
  fEcalThreshold = new TGNumberEntry(myFrame, 1.0, 8, -1, TGNumberFormat::kNESRealOne);
  fEcalThreshold->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fEcalThreshold, fItemLayout);

  fHcalThresholdLabel = new TGLabel(myFrame, "HCAL threshold (GeV)");
  myFrame->AddFrame(fHcalThresholdLabel, fItemLayout);
  fHcalThreshold = new TGNumberEntry(myFrame, 3.0, 8, -1, TGNumberFormat::kNESRealOne); 
  fHcalThreshold->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fHcalThreshold, fItemLayout);
  // End of calorimeter cuts

  // Reco track cuts
  
  // End of reco track cuts
  
  // Sim track cuts
  myFrame = fTab->AddTab("Sim");
  fSimMagFieldLabel = new TGLabel(myFrame, "Magnetic field (T)");
  myFrame->AddFrame(fSimMagFieldLabel, fItemLayout);
  fSimMagField = new TGNumberEntry(myFrame, 4.0, 5, -1, TGNumberFormat::kNESRealTwo);
  fSimMagField->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fSimMagField, fItemLayout);
  
  fSimPtLabel = new TGLabel(myFrame, "SimTrack Pt min and max");
  myFrame->AddFrame(fSimPtLabel, fItemLayout);
  fSimMinPt = new TGNumberEntry(myFrame, 6.0, 5, -1, TGNumberFormat::kNESRealTwo);
  fSimMinPt->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fSimMinPt, fItemLayout);
  fSimMaxPt = new TGNumberEntry(myFrame, 9999.0, 5, -1, TGNumberFormat::kNESRealTwo);
  fSimMaxPt->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fSimMaxPt, fItemLayout);
  
  fSimTrackMatchingDeltaRLabel = new TGLabel(myFrame, "SimTrack matching DR");
  myFrame->AddFrame(fSimTrackMatchingDeltaRLabel, fItemLayout);
  fSimTrackMatchingDeltaR = new TGNumberEntry(myFrame, 0.01, 5, -1, TGNumberFormat::kNESRealTwo);
  fSimTrackMatchingDeltaR->SetLimits(TGNumberFormat::kNELLimitMin, 0);
  myFrame->AddFrame(fSimTrackMatchingDeltaR, fItemLayout);
  
  // End of Sim track cuts
  
  
    
  // Insert tab object  
  this->AddFrame(fTab, fFrameLayout);

  // Button for applying selections
  fUpdateButton = new TGTextButton(this, "Apply selections");
  fUpdateButton->Connect("Clicked()", "TVisMainFrame", main, "DoUpdateCanvases()");
  this->AddFrame(fUpdateButton, fButtonLayout);

  // Particle database
  fDatabasePDG = new TDatabasePDG();
}

TGVisOptions::~TGVisOptions() {
  for (Int_t i = 0; i < JET_TYPE_COUNT; ++i) delete fJetVisibilityButton[i];

}

Bool_t TGVisOptions::SatisfiesEnergyThreshold(Double_t e, Bool_t isECAL) {
  if (isECAL)
    return e > this->GetEcalThreshold();
  else
    return e > this->GetHcalThreshold();
}

Bool_t TGVisOptions::SatisfiesCaloVisibility(Bool_t isECAL) {
  if (isECAL)
    return this->GetEcalVisibility();
  else
    return this->GetHcalVisibility();
}

Double_t TGVisOptions::GetParticleMass(Int_t pdg) {
  TParticlePDG* myParticle = fDatabasePDG->GetParticle(pdg);
  if (!myParticle) return -1;
  return myParticle->Mass();
}

Double_t TGVisOptions::GetParticleCharge(Int_t pdg) {
  char buffer[40];
  GetParticleName(pdg, buffer);
  TParticlePDG* myParticle = fDatabasePDG->GetParticle(pdg);
  cout << "getting particle: pdg=" << pdg
       << " (" << buffer << ")" 
       << " charge=" << myParticle->Charge()
       << " mass=" << myParticle->Mass()
       << endl;

  if (!myParticle) return 0;
  return myParticle->Charge() / 3.0;
}

void TGVisOptions::GetParticleName(Int_t pdg, char *name) {
  char mySign = '-';
  if (pdg < 0) mySign = '+';
  TParticlePDG* myParticle = fDatabasePDG->GetParticle(pdg);
  if (!myParticle) {
    sprintf(name, "?? (%d)", pdg);
  } else {
    sprintf(name, "%s", myParticle->GetName());
    /*switch(TMath::Abs(pdg)) {
    case 11: sprintf(name,"e%c",mySign); break;
    case 12: sprintf(name,"nu_e"); break;
    case 13: sprintf(name,"mu%c",mySign); break;
    case 14: sprintf(name,"nu_mu"); break;
    case 15: sprintf(name,"tau%c",mySign); break;
    case 16: sprintf(name,"nu_tau"); break;
    case 22: sprintf(name,"gamma"); break;
    case 130: sprintf(name,"K_L0"); break;
    case 211: sprintf(name,"pi%c",mySign); break;
    case 310: sprintf(name,"K_S0"); break;
    case 321: sprintf(name,"K%c",mySign); break;
    case 411: sprintf(name,"D%c",mySign); break;
    case 413: sprintf(name,"D*%c",mySign); break;
    case 521: sprintf(name,"B%c",mySign); break;
    case 523: sprintf(name,"B*%c",mySign); break;
    case 2112: sprintf(name,"n"); break;
    case 2212: sprintf(name,"p%c",mySign); break;
    default: sprintf(name,"(%d)", pdg); break;
    }*/
  }
}
