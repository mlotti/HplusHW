#include "Visual/interface/TVisCaloCell.h"

#include <TMath.h>

#include <iostream>
using namespace std;

ClassImp(TVisCaloCell)

TVisCaloCell::TVisCaloCell(Double_t x, Double_t y, Double_t z,
			 Double_t dx, Double_t dy, Double_t dz, Bool_t isECAL)
: TVisDrawableBase(CALOCELL_TYPE) {
  fECAL = isECAL;
  if (fECAL) {
    fColor = kBlue+2;
    sprintf(fInfo, "ECAL cell at eta=%2.3f, phi=%2.3f: %2.2f GeV",
	    x+dx/2.0, y+dy/2.0, dz);
  } else {
    fColor = kBlue;
    sprintf(fInfo, "HCAL cell at eta=%2.3f, phi=%2.3f: %2.2f GeV",
	    x+dx/2.0, y+dy/2.0, dz);
  }
  fEnergyOffset = z;
  fEnergy = dz;
  fEta = x;
  fPhi = y;
  fEtaEnd = x+dx;
  fPhiEnd = y+dy;
}

TVisCaloCell::~TVisCaloCell() {
  //delete fTop;
  //for (Int_t i = 0; i < 4; ++i)
  //delete fSide[i];
}

TVisCaloCell* TVisCaloCell::CloneCaloCell() {
  TVisCaloCell* myCell = new TVisCaloCell(fEta, fPhi, fEnergyOffset,
                                       fEtaEnd-fEta, fPhiEnd-fPhi, fEnergy,
                                       fECAL);
  return myCell;  
}

void TVisCaloCell::Create() {
  if (!fVisible) return;
  // Clear previous objects
  this->Clear();
  
  Double_t dzcorr = fEnergy;
  TPolyLine3D* fSide[4];
  TPolyLine3D* fTop;
  for (Int_t i = 0; i < 4; ++i) fSide[i] = new TPolyLine3D(2);

  // Create cell sides
  fSide[0]->SetPoint(0,fEta,fPhi,fEnergyOffset);
  fSide[0]->SetPoint(1,fEta,fPhi,fEnergyOffset+dzcorr);
  fSide[1]->SetPoint(0,fEtaEnd,fPhi,fEnergyOffset);
  fSide[1]->SetPoint(1,fEtaEnd,fPhi,fEnergyOffset+dzcorr);
  fSide[2]->SetPoint(0,fEta,fPhiEnd,fEnergyOffset);
  fSide[2]->SetPoint(1,fEta,fPhiEnd,fEnergyOffset+dzcorr);
  fSide[3]->SetPoint(0,fEtaEnd,fPhiEnd,fEnergyOffset);
  fSide[3]->SetPoint(1,fEtaEnd,fPhiEnd,fEnergyOffset+dzcorr);
  for (Int_t i = 0; i < 4; ++i) this->AddObject(fSide[i]);
  
  // Create cell top
  fTop = new TPolyLine3D(8);
  fTop->SetLineColor(fColor);
  // rectangle
  fTop->SetPoint(0,fEta,fPhi,fEnergyOffset+dzcorr);
  fTop->SetPoint(1,fEtaEnd,fPhi,fEnergyOffset+dzcorr);
  fTop->SetPoint(2,fEtaEnd,fPhiEnd,fEnergyOffset+dzcorr);
  fTop->SetPoint(3,fEta,fPhiEnd,fEnergyOffset+dzcorr);
  fTop->SetPoint(4,fEta,fPhi,fEnergyOffset+dzcorr);
  // cross
  fTop->SetPoint(5,fEtaEnd,fPhiEnd,fEnergyOffset+dzcorr);
  fTop->SetPoint(6,fEta,fPhiEnd,fEnergyOffset+dzcorr);
  fTop->SetPoint(7,fEtaEnd,fPhi,fEnergyOffset+dzcorr);
  this->AddObject(fTop);
}

Bool_t TVisCaloCell::IsOverlapping(Double_t eta, Double_t phi,
				  Double_t deta, Double_t dphi) {
  Bool_t status = kFALSE;
  if (eta >= fEta)
    if (phi >= fPhi)
      if (eta+deta <= fEtaEnd)
	if (phi+dphi <= fPhiEnd)
	  status = kTRUE;
  return status;
}

Bool_t TVisCaloCell::IsWithinRadius(Double_t eta, Double_t phi,
				   Double_t radius) {
  // Check four corners
  Double_t deta1 = (eta-fEta);
  Double_t deta2 = (eta-fEtaEnd);
  Double_t dphi1 = (phi-fPhi);
  Double_t dphi2 = (phi-fPhiEnd);
  // Select smallest deltaR
  Double_t deta = deta1;
  if (TMath::Abs(deta2) < TMath::Abs(deta1)) deta = deta2;
  Double_t dphi = dphi1;
  if (TMath::Abs(dphi2) < TMath::Abs(dphi1)) dphi = dphi2;
  return (TMath::Sqrt(deta*deta + dphi*dphi) < radius);
}

void TVisCaloCell::Print() {

}
