#include "Visual/interface/TVisTkJet.h"

#include <iostream>
using namespace std;

ClassImp(TVisTkJet)

TVisTkJet::TVisTkJet(const char* name, Int_t type, Double_t eta, Double_t phi, TGVisOptions* options)
: TVisJetBase(name, type, eta, phi, options) {

}


TVisTkJet::~TVisTkJet() {
}


void TVisTkJet::CalculateInfo() {
  fIsoTracks = 0;
  fSigTracks = 0;
  
  Int_t iEnd = fObjects->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    if (((TVisDrawableBase*)fObjects->At(i))->GetDrawableType() == TKTRACK_TYPE) {
      TVisTkTrack* myTrack = (TVisTkTrack*)fObjects->At(i);
      if (myTrack->IsWithinRadius(fJetEta, fJetPhi, fOptions->GetTrSignalCone()))
        ++fSigTracks;
      if (myTrack->IsWithinRadius(fJetEta, fJetPhi, fOptions->GetTrIsolationCone()))
        ++fIsoTracks;
    }
  }
  
  sprintf(fInfo, "Jet (%s) (eta=%.2f, phi=%.2f), nSigTrk=%d, nIsoTrk=%d",
          fOptions->GetJetName(fJetType), fJetEta, fJetPhi, fSigTracks, fIsoTracks);
  fDirty = kFALSE;
}

TVisTkJet* TVisTkJet::CloneTkJet() {
  TVisTkJet *myJet = new TVisTkJet(fName, fJetType,
                                   fJetEta, fJetPhi, fOptions);
  this->CloneBaseJet(myJet);
  return myJet;
}
