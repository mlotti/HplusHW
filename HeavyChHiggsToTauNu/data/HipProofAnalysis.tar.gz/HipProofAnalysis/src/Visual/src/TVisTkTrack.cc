#include "Visual/interface/TVisTkTrack.h"
#include <TMath.h>

ClassImp(TVisTkTrack)

TVisTkTrack::TVisTkTrack(Double_t eta, Double_t phi, Double_t pt,
                         Int_t hits=0, Double_t chi2=0)
: TVisDrawableBase(TKTRACK_TYPE) {                          
  fHits = new TObjArray();
  this->SetColorFromRange(0.0, 100.0, pt);
  feta = eta;
  fphi = phi;
  fpt = pt;
  fHitNumber = hits;
  fchi2 = chi2;
  sprintf(fInfo, "Track: pt=%3.2f GeV, hits=%d, chi2=%3.2f",
          fpt, fHitNumber, fchi2);
}

TVisTkTrack::~TVisTkTrack() {
  Int_t iEnd = fHits->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    TVector3* myVector = (TVector3*)fHits->At(i);
    delete myVector;
  }  
  delete fHits;
}

void TVisTkTrack::AddHit(Double_t x, Double_t y, Double_t z) {
  TVector3* myVector = new TVector3(x,y,z);
  fHits->Add(myVector);
}

void TVisTkTrack::Create() {
  Int_t iEnd = fHits->GetEntriesFast();
  TPolyLine3D* myLine = new TPolyLine3D(iEnd);
  for (Int_t i = 0; i < iEnd; ++i) {
    TVector3* myVector = (TVector3*)fHits->At(i);
    myLine->SetPoint(i, myVector->X(), myVector->Y(), myVector->Z());
  }
  myLine->SetLineColor(fColor);
  this->AddObject(myLine);
}

void TVisTkTrack::Print() {
  cout << fInfo << endl;
}

TVisTkTrack* TVisTkTrack::CloneTkTrack() {
  TVisTkTrack* myTrack = new TVisTkTrack(feta, fphi, fpt, fHitNumber, fchi2);
  Int_t iEnd = fHits->GetEntriesFast();
  for (Int_t i = 0; i < iEnd; ++i) {
    TVector3* myVector = (TVector3*)fHits->At(i);
    myTrack->AddHit(myVector->X(), myVector->Y(), myVector->Z());
  }
  return myTrack;
}

Bool_t TVisTkTrack::IsWithinRadius(Double_t eta, Double_t phi,
                                   Double_t radius) {
  // Calculate DeltaR
  Double_t deta = (eta-feta);
  Double_t dphi = (phi-fphi);
  return (TMath::Sqrt(deta*deta + dphi*dphi) < radius);
}
