#include "Visual/interface/TVisMainFrame.h"

//#include <stdio.h>
#include <iostream>
#include <vector>
using namespace std;

ClassImp(TVisMainFrame)

enum TVisMenuItems {
  M_FILE_EXIT,
  M_EVENT_NEXT,
  M_EVENT_DEMO,
  M_DEBUG_ACTIVE,
  M_INFO_PRINT
};

TVisMainFrame::TVisMainFrame(const TGWindow* p) : TGMainFrame(p,800,800) {
  // standalone constructor
  //SetBit(kNoContextMenu, kFALSE);
  ConstructInterface();
  fData = new DataInterface();
  Reset();
}

TVisMainFrame::~TVisMainFrame() {

}

void TVisMainFrame::AppendPad(Option_t *option) {
  
  //gROOT->MakeDefCanvas();
  SetBit(kMustCleanup);
  //SetBit(kObjInCanvas);
  gPad->GetListOfPrimitives()->Add(this,option);
  gPad->Modified(kTRUE);
}

// ==================================================================================
// Manager setup and options

void TVisMainFrame::ConstructManagers() {
  // Create view manager arrays for MFD's
  fMainManagers = new TObjArray();
  fSmallManagers = new TObjArray();
  //fCaloJetList = new TObjArray();
  fMFDs = new TObjArray();
  
  // Main calorimetry view
  TVisCaloManager* calo = new TVisCaloManager("Calorimetry", fOptions);
  calo->SetDrawFullCaloGrid();
  calo->SetDoubleClickable(kTRUE, M_CALOVIEW_DOUBLECLICK);
  calo->SetSelectWholeJet();
  calo->SetDrawCells();
  fMainManagers->Add(calo);
  //fCaloJetList->Add(calo); // is this necessary ?
  
  // Calorimetry view for single selected jet
  calo = new TVisCaloManager("Calo jet", fOptions);
  calo->SetDrawJetCaloGrid();
  calo->SetDrawCells();
  calo->SetDrawJetCones();
  fSmallManagers->Add(calo);
  
  // Calorimetry view for single selected jet with track markers
  calo = new TVisCaloManager("Calo jet+trks", fOptions);
  calo->SetDrawJetCaloGrid();
  calo->SetDrawCells();
  calo->SetDrawTrackMarkers();
  calo->SetDrawJetCones();
  calo->SetTopViewOnly();
  fSmallManagers->Add(calo);

  // Main calorimetry view
  TVisTkManager* tk = new TVisTkManager("Tracker", fOptions);
  //tk->SetDrawFullCaloGrid();
  tk->SetDoubleClickable(kTRUE, M_TRACKVIEW_DOUBLECLICK);
  tk->SetSelectWholeJet();
  tk->SetDrawTracks();
  tk->SetDrawSimTracks();
  fMainManagers->Add(tk);
  //fCaloJetList->Add(calo);

}

// ==================================================================================
// Interface building

void TVisMainFrame::ConstructInterface() {
  SetCleanup(kDeepCleanup);
  
  // Layout hints
  TGLayoutHints *myPopupLayout =
    new TGLayoutHints(kLHintsTop | kLHintsLeft, 0, 4, 0, 0);
  TGLayoutHints *myZeroLayout =
    new TGLayoutHints(kLHintsTop | kLHintsLeft, 0, 0, 0, 0);
  TGLayoutHints *myMenuLayout =
    new TGLayoutHints(kLHintsExpandX, 0, 0, 0, 0);
  TGLayoutHints *myZeroExpandingLayout =
    new TGLayoutHints(kLHintsExpandX | kLHintsExpandY, 0, 0, 0, 0);

  // Construct menu bar
  fMenuFile = new TGPopupMenu(gClient->GetRoot());
  fMenuFile->AddEntry("E&xit", M_FILE_EXIT);
  fMenuFile->Connect("Activated(Int_t)","TVisMainFrame",
		     this, "DoProcessMenuEvent(Int_t)");
  fMenuEvent = new TGPopupMenu(gClient->GetRoot());
  fMenuEvent->AddEntry("&Next event", M_EVENT_NEXT);
  fMenuEvent->AddEntry("&Demo event", M_EVENT_DEMO);
  fMenuEvent->Connect("Activated(Int_t)","TVisMainFrame",
		     this, "DoProcessMenuEvent(Int_t)");
  fMenuInfo = new TGPopupMenu(gClient->GetRoot());
  fMenuInfo->AddEntry("&Print", M_INFO_PRINT);
  //fMenuInfo->AddEntry("&Demo event", M_EVENT_DEMO);
  fMenuInfo->Connect("Activated(Int_t)","TVisMainFrame",
		     this, "DoProcessMenuEvent(Int_t)");
  fMenuDebug = new TGPopupMenu(gClient->GetRoot());
  fMenuDebug->AddEntry("&Active object", M_DEBUG_ACTIVE);
  //fMenuInfo->AddEntry("&Demo event", M_EVENT_DEMO);
  fMenuDebug->Connect("Activated(Int_t)","TVisMainFrame",
		      this, "DoProcessMenuEvent(Int_t)");
                     
                     
  fMenuBar = new TGMenuBar(this, 1, 1, kHorizontalFrame | kRaisedFrame);
  fMenuBar->AddPopup("&File", fMenuFile, myPopupLayout);
  fMenuBar->AddPopup("&Event", fMenuEvent, myPopupLayout);
  fMenuBar->AddPopup("&Info", fMenuInfo, myPopupLayout);
  fMenuBar->AddPopup("&Debug", fMenuDebug, myPopupLayout);
  this->AddFrame(fMenuBar, myMenuLayout);

  // Frame for options and embedded canvases
  TGCompositeFrame *myCenterFrame = new TGCompositeFrame(this, 900, 600, kHorizontalFrame);
  // Calorimeter options
  fOptions = new TGVisOptions(myCenterFrame, 100, 600, this);
  myCenterFrame->AddFrame(fOptions, myZeroLayout);
  // Embedded canvases
  TGCompositeFrame *myCanvasFrame = new TGCompositeFrame(myCenterFrame, 800, 600, kVerticalFrame);

  ConstructManagers();
  
  TGVisMFD* myMFD = new TGVisMFD(0, fMainManagers, myCanvasFrame, 800, 200);
  myMFD->Connect("DoDoubleClicked(Int_t)","TVisMainFrame",this,"DoDoubleClicked(Int_t)");
  myMFD->Connect("DoPadChanged(Int_t)","TVisMainFrame",this,"DoPadChanged(Int_t)");
  myMFD->Connect("MouseEntered(Int_t)","TVisMainFrame",this,"DoPadSelected(Int_t)");
  myCanvasFrame->AddFrame(myMFD, myZeroExpandingLayout);
  fMFDs->Add(myMFD);
  
  // Frame for left small display
  TGCompositeFrame* mySubCanvasFrame =
    new TGCompositeFrame(myCanvasFrame, 300, 300, kHorizontalFrame);
  myMFD = new TGVisMFD(1, fSmallManagers, mySubCanvasFrame, 300, 300);
  myMFD->Connect("DoDoubleClicked(Int_t)","TVisMainFrame",this,"DoDoubleClicked(Int_t)");
  myMFD->Connect("DoPadChanged(Int_t)","TVisMainFrame",this,"DoPadChanged(Int_t)");
  myMFD->Connect("MouseEntered(Int_t)","TVisMainFrame",this,"DoPadSelected(Int_t)");
  mySubCanvasFrame->AddFrame(myMFD, myZeroExpandingLayout);
  fMFDs->Add(myMFD);
  
  // Frame for right small display
  myMFD = new TGVisMFD(2, fSmallManagers, mySubCanvasFrame, 300, 300);
  myMFD->Connect("DoDoubleClicked(Int_t)","TVisMainFrame",this,"DoDoubleClicked(Int_t)");
  myMFD->Connect("DoPadChanged(Int_t)","TVisMainFrame",this,"DoPadChanged(Int_t)");
  myMFD->Connect("MouseEntered(Int_t)","TVisMainFrame",this,"DoPadSelected(Int_t)");
  mySubCanvasFrame->AddFrame(myMFD, myZeroExpandingLayout);
  fMFDs->Add(myMFD);
  
  myCanvasFrame->AddFrame(mySubCanvasFrame, myZeroExpandingLayout);

  myCenterFrame->AddFrame(myCanvasFrame, myZeroExpandingLayout);
  this->AddFrame(myCenterFrame, myZeroExpandingLayout);
  
  // Add status bar
  Int_t parts[] = {60,40};
  fStatusBar = new TGStatusBar(this, 50, 800);
  fStatusBar->SetParts(parts,2);
  this->AddFrame(fStatusBar, new TGLayoutHints(kLHintsBottom | kLHintsExpandX,0,0,0,0));

  // Final touch
  this->SetWindowName("HIP Proof Analysis Visualization Package");
  this->MapSubwindows();
  this->Resize(GetDefaultSize());
  this->MapWindow();
  //this->Print();

  AddInput(kKeyPressMask | kKeyReleaseMask);
  //AddInput(kPointerMotionMask | kKeyPressMask | kKeyReleaseMask);
  gVirtualX->SetInputFocus(GetId());
  DoUpdateCanvases();
  //((TGVisMFD*)fMFDs->At(0))->cd();
  //AppendPad();

}

// ==================================================================================
// Activated commands

Int_t TVisMainFrame::DistancetoPrimitive(Int_t px, Int_t py) {
  // Activated, when mouse is moved over an object, on which AppendPad() has been called
  // If this method returns 0, then context menu is somehow disabled and
  // for example rotation of canvases doesn't work anymore
  //
  // Strategy here: return 0, if new object has been selected
  //                      -1, if same object has been selected
  //                    9999, if nothing has been selected
  if (fActiveCanvas < 0) return 999999;
  TGVisMFD* myMFD = (TGVisMFD*)fMFDs->At(fActiveCanvas);
  Int_t myValue = myMFD->PointingDistance(px,py);
  if (myValue == 0) {
    fStatusBar->SetText(myMFD->GetActiveManager()->GetInfo(),1);
    //for (Int_t j = 0; j < iEnd; ++j) {
    //  if (j != iMFD) ((TGVisMFD*)fMFDs->At(j))->Unselect();
    //}
    myMFD->cd();
    myMFD->Update();
    this->AppendPad();
    //return 9999;
  }
  return 999999;
}

void TVisMainFrame::DoClear() {
  cout << "MainFrame::DoClear() has been called" << endl;
  Reset();
  // Clear managers  
  Int_t iEnd = fMainManagers->GetEntriesFast();
  for (Int_t iMgr = 0; iMgr < iEnd; ++iMgr) {
    switch (((TVisManagerBase*)fMainManagers->At(iMgr))->GetManagerType()) {
    case CALO_MANAGER: ((TVisCaloManager*)fMainManagers->At(iMgr))->Clear(); break;
    case TRACK_MANAGER: ((TVisTkManager*)fMainManagers->At(iMgr))->Clear();  break;
    }
    ((TVisManagerBase*)fMainManagers->At(iMgr))->SetViewable(kFALSE);
  }
  iEnd = fSmallManagers->GetEntriesFast();
  for (Int_t iMgr = 0; iMgr < iEnd; ++iMgr) {
    switch (((TVisManagerBase*)fSmallManagers->At(iMgr))->GetManagerType()) {
    case CALO_MANAGER: ((TVisCaloManager*)fSmallManagers->At(iMgr))->Clear(); break;
    case TRACK_MANAGER: ((TVisTkManager*)fSmallManagers->At(iMgr))->Clear(); break;
    }
    ((TVisManagerBase*)fSmallManagers->At(iMgr))->SetViewable(kFALSE);
  }
  // Clear MFD's
  iEnd = fMFDs->GetEntriesFast();
  for (Int_t iMFD = 0; iMFD < iEnd; ++iMFD) {
    TGVisMFD* myMFD = (TGVisMFD*)fMFDs->At(iMFD);
    myMFD->Clear();
    myMFD->UpdateButtons();
  }
}

/*
Bool_t TVisMainFrame::HandleClientMessage(Event_t* event) {
  cout << "client message at (" << event->fX
       << ", " << event->fY << ")" << endl;

  return kFALSE;
}


Bool_t TVisMainFrame::HandleButton(Event_t* event) {
  cout << "Button pressed at (" << event->fX
       << ", " << event->fY << ")" << endl;


  return kFALSE;
}
*/

void TVisMainFrame::DoDoubleClicked(Int_t action) {
  // Seek MFD
  TGVisMFD* myMFD = (TGVisMFD*)fMFDs->At(0);
  switch (action) {
  case M_CALOVIEW_DOUBLECLICK:
    TVisCaloManager* myMgr = (TVisCaloManager*)myMFD->GetActiveManager();
    if (!myMgr->IsActive()) return;
    TVisCaloJet* myJet = myMgr->GetActiveJet();
    Int_t iEnd = fSmallManagers->GetEntriesFast();
    for (Int_t iMgr = 0; iMgr < iEnd; ++iMgr) {
      if (((TVisManagerBase*)fSmallManagers->At(iMgr))->GetManagerType() == CALO_MANAGER) {
        myMgr = (TVisCaloManager*)fSmallManagers->At(iMgr);
        myMgr->Clear();
        TVisCaloJet *myClone = myJet->CloneCaloJet();
        myMgr->AddJet(myClone);
        myMgr->SetViewable();
      }
    }
    break;
  }
  // Update buttons on chavases
  Int_t iEnd = fMFDs->GetEntriesFast();
  for (Int_t iMFD = 0; iMFD < iEnd; ++iMFD) {
    TGVisMFD* myMFD = (TGVisMFD*)fMFDs->At(iMFD);
    myMFD->cd();
    myMFD->UpdateButtons();
  }
  DoUpdateCanvases();
}

void TVisMainFrame::DoExit() {
  // Terminates application
  gApplication->Terminate(0);
  //gSystem->Exit(0);
}

void TVisMainFrame::DoNextEvent() {
  // Seeks next event in files
  fStatusBar->SetText("Seeking next event in file list ...",1);
  if (!fData->nextEvent()) {
    fStatusBar->SetText("File reading error!",1);
    fStatusBar->SetText("Run: - Event: -",0);
    return;
  }
  MyEvent* myEvent = fData->getEvent();

  char myBuffer[300];
  sprintf(myBuffer, "Run: %d Event: %d", myEvent->run(), myEvent->event());
  fStatusBar->SetText(myBuffer,0);

  fOptions->SetRunNumber(myEvent->run());
  fOptions->SetEventNumber(myEvent->event());
  this->ProcessEvent(myEvent);
}

void TVisMainFrame::DoReadEvent() {
  // Tries to seek specified event
  char myBuffer[300];

  sprintf(myBuffer, "Seeking run: %d event: %d ...",
	  (Int_t)fOptions->GetRunNumber(),
	  (Int_t)fOptions->GetEventNumber());
  fStatusBar->SetText(myBuffer,1);
  if (!fData->readEvent((int)fOptions->GetRunNumber(),
			(int)fOptions->GetEventNumber())) {
    fStatusBar->SetText("File reading error or event not found!",1);
    fStatusBar->SetText("Run: - Event: -",0);
    return;
  }
  MyEvent* myEvent = fData->getEvent();
  this->ProcessEvent(myEvent);
}

void TVisMainFrame::DoPadChanged(Int_t id) {
  // Triggered, when a new manager is selected in a MFD
  DoPadSelected(id);
  TGVisMFD* myMFD = (TGVisMFD*)fMFDs->At(id);
  myMFD->cd();
  myMFD->Update();
  //myMFD->cd();
  this->AppendPad();
  //DoUpdateCanvases();
}

void TVisMainFrame::DoPadSelected(Int_t id) {
  // Triggered, when mouse is moved above a TGVisMFD window
  if (id != fActiveCanvas) {
    // deselect previous active pointed object
    if (fActiveCanvas >= 0) {
      TGVisMFD* myMFD = (TGVisMFD*)fMFDs->At(fActiveCanvas);
      if (myMFD->HasActiveManager()) {
        myMFD->cd();
        switch (myMFD->GetActiveManager()->GetManagerType()) {
        case CALO_MANAGER:
          ((TVisCaloManager*)myMFD->GetActiveManager())->Unselect();
          break;
        }
        myMFD->Update();
        
        fStatusBar->SetText("",1);
      }
    }
    fActiveCanvas = id;
  }
  

  /*
  if (id != fActiveCanvas) {
    switch (id) {
    case VIS_CALO_MAIN:
      fStatusBar->SetText("Jet energy deposition in eta-phi",1); break;
    case VIS_CALO_SINGLE_J((TGVisMFD*)fMFDs->At(fActiveCanvas))->HasActiveManager()ET:
      fStatusBar->SetText("Single jet energy deposition in eta-phi",1); break;
    case VIS_CALO_JET_TRACKS:
      fStatusBar->SetText("Single jet energy and tracks in eta-phi",1); break;
    }
  }
  */
  //cout << "Active canvas = " << id << endl;
  
 
}

void TVisMainFrame::DoProcessMenuEvent(Int_t id) {
  switch (id) {
  case M_FILE_EXIT:
    DoExit();
    break;
  case M_EVENT_NEXT:
    DoNextEvent();
    break;
  case M_EVENT_DEMO:
    //CreateDemoEvent();
    break;
  case M_INFO_PRINT:
    cout << "Jet information in run " << fOptions->GetRunNumber()
	 << " event " << fOptions->GetEventNumber() << endl;
    TGVisMFD* myMFD = (TGVisMFD*)fMFDs->At(0);
    if (myMFD->HasActiveManager()) {
      TVisManagerBase* myBase = (TVisManagerBase*)myMFD->GetActiveManager();
      switch (myBase->GetManagerType()) {
      case CALO_MANAGER: ((TVisCaloManager*)myMFD->GetActiveManager())->Print(); break;
      case TRACK_MANAGER: ((TVisTkManager*)myMFD->GetActiveManager())->Print(); break;
      }
    } else {
      cout << "No active manager selected!" << endl;
    }
    break;
  case M_DEBUG_ACTIVE:
    cout << "Calo manager printout:" << endl;
    ((TVisCaloManager*)fMainManagers->At(0))->Print();
    cout << "Tracker manager printout:" << endl;
    ((TVisTkManager*)fMainManagers->At(1))->Print();
  
  /*
    cout << ((TGVisMFD*)fMFDs->At(0))->GetActiveManager()->GetInfo() << endl;
    cout << ((TGVisMFD*)fMFDs->At(1))->GetActiveManager()->GetInfo() << endl;
    cout << ((TGVisMFD*)fMFDs->At(2))->GetActiveManager()->GetInfo() << endl; */
    break;
  }
}

void TVisMainFrame::DoUpdateCanvases() {
  //Double_t min[3], max[3];
  fStatusBar->SetText("Drawing canvases ...",1);
  
  Int_t iEnd = fMFDs->GetEntriesFast();
  for (Int_t iMFD = 0; iMFD < iEnd; ++iMFD) {
    TGVisMFD* myMFD = (TGVisMFD*)fMFDs->At(iMFD);
    myMFD->cd();
    myMFD->Draw();
    myMFD->UpdateButtons();
    this->AppendPad();    
  }

  fStatusBar->SetText("Ready",1);
}


// ==================================================================================
// Event processing to managers

void TVisMainFrame::ProcessEvent(MyEvent* event) {

  fStatusBar->SetText("Processing event ...",1);
  // Clear previous data here
  DoClear();
  // Process sim data
  ProcessSimEvent(event);
  // Begin reading data from MyEvent
  vector<MyJet>::const_iterator iJet;
  vector<MyJet>::const_iterator iJetEnd;
  // Loop over L1objects
  iJetEnd = event->L1objects_end();
  for (iJet = event->L1objects_begin(); iJet != iJetEnd; ++iJet)
    ProcessJet(&(*iJet), JET_L1);
  // Loop over HLTobjects
  iJetEnd = event->HLTobjects_end();
  for (iJet = event->HLTobjects_begin(); iJet != iJetEnd; ++iJet)
    ProcessJet(&(*iJet), JET_HLT);
  // Loop over electrons
  iJetEnd = event->electrons_end();
  for (iJet = event->electrons_begin(); iJet != iJetEnd; ++iJet)
    ProcessJet(&(*iJet), JET_E);
  // Loop over photons
  iJetEnd = event->photons_end();
  for (iJet = event->photons_begin(); iJet != iJetEnd; ++iJet)
    ProcessJet(&(*iJet), JET_PHOTON);
  // Loop over muons
  iJetEnd = event->muons_end();
  for (iJet = event->muons_begin(); iJet != iJetEnd; ++iJet)
    ProcessJet(&(*iJet), JET_MUON);
  // Loop over taujets
  iJetEnd = event->taujets_end();
  for (iJet = event->taujets_begin(); iJet != iJetEnd; ++iJet)
    ProcessJet(&(*iJet), JET_TAU);
  // Loop over pftaus
  iJetEnd = event->pftaus_end();
  for (iJet = event->pftaus_begin(); iJet != iJetEnd; ++iJet)
    ProcessJet(&(*iJet), JET_PFTAU);

  
  // Set status bar
  char buffer[400];
  sprintf(buffer, "Run: %d Event: %d, file:%s", event->run(), event->event(),
	  fData->getFilename());
  fStatusBar->SetText(buffer,0);
  DoUpdateCanvases();
}

void TVisMainFrame::ProcessSimEvent(MyEvent* event) {
  // Create jet to main managers
  Int_t iEnd = fMainManagers->GetEntriesFast();
  for (Int_t iMgr = 0; iMgr < iEnd; ++iMgr) {
    switch (((TVisManagerBase*)fMainManagers->At(iMgr))->GetManagerType()) {
    case CALO_MANAGER:
       //((TVisCaloManager*)fMainManagers->At(iMgr))->AddSimInfo(event); break; // does not exist
      break;
    case TRACK_MANAGER:
      ((TVisTkManager*)fMainManagers->At(iMgr))->AddSimInfo(event); break;
      break;
    }
  }
}

void TVisMainFrame::ProcessJet(const MyJet* jet, Int_t type) {
  // Create jet to main managers
  Int_t iEnd = fMainManagers->GetEntriesFast();
  for (Int_t iMgr = 0; iMgr < iEnd; ++iMgr) {
    switch (((TVisManagerBase*)fMainManagers->At(iMgr))->GetManagerType()) {
    case CALO_MANAGER:
      TVisCaloManager* myCalo = (TVisCaloManager*)fMainManagers->At(iMgr);
      myCalo->AddJet(jet, type);
      break;
    case TRACK_MANAGER:
      TVisTkManager* myTk = (TVisTkManager*)fMainManagers->At(iMgr);
      myTk->AddJet(jet, type);
      break;
    }
  }
  //calo->Print(myJetId);
}

// ==================================================================================
// 

Bool_t TVisMainFrame::ProcessMessage(Long_t msg, Long_t parm1, Long_t parm2){ 
  return kFALSE;
}

void TVisMainFrame::Reset() {
  fActiveCanvas = -1;
}
