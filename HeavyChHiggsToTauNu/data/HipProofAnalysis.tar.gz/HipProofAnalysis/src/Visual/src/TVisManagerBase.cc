#include "Visual/interface/TVisManagerBase.h"
#include "Visual/interface/TVisJetBase.h"

#include <TPolyLine3D.h>
#include <TMath.h>

#include <iostream>
using namespace std;

ClassImp(TVisManagerBase);

TVisManagerBase::TVisManagerBase(const char *shortName, TGVisOptions* options, Int_t type) {
  sprintf(fShortName, "%s", shortName);  Bool_t fDrawFullCaloGrid;
  Bool_t fDrawJetCaloGrid;
  fOptions = options;
  fGeometry = new VisGeoLookup();
  fGridLines = new TObjArray();
  fObjects = new TObjArray();

  fDrawFullCaloGrid = kFALSE;
  fDrawJetCaloGrid = kFALSE;
  fSelectWholeJet = kFALSE;
  
  fDoubleClickable = kFALSE;
  fTopViewOnly = kFALSE;
  fAllow3D = kFALSE;
  fViewable = kFALSE;
  fActiveId = -1;
  fManagerType = type;
  
  for (Int_t i = 0; i < 3; ++i) {
    fMin[i] = 0;
    fMax[i] = 0;
  }
}

TVisManagerBase::~TVisManagerBase() {
  delete fGeometry;
  //fGridLines->Delete();
  delete fGridLines;
}

Int_t TVisManagerBase::PointingDistance(Int_t px, Int_t py) {
  // Has to be implemented in manager deriving from ManagerBase
  // Should return 9999, if no object is pointed
  //                  0, if object is pointed
  //                 -1, if object pointed is already selected
  return 9999;
}

void TVisManagerBase::CreateFullCaloGrid() {
  CreateCaloGrid(-41, 41, 0, 72);
}

void TVisManagerBase::CreateCaloGrid(Double_t eta, Double_t phi) {
  Double_t r = fOptions->GetJetRadius();
  Int_t etaStartIndex = fGeometry->getHCALCellByEta(TMath::Abs(eta-r));
  Int_t   etaEndIndex = fGeometry->getHCALCellByEta(TMath::Abs(eta+r))+1;
  Int_t phiStartIndex = fGeometry->getHCALCellByPhi(0,TMath::Abs(phi-r));
  Int_t   phiEndIndex = fGeometry->getHCALCellByPhi(0,TMath::Abs(phi+r))+1;
  if (etaStartIndex < -fGeometry->getMaxEtaIndex())
    etaStartIndex = -fGeometry->getMaxEtaIndex();
  if (etaEndIndex > fGeometry->getMaxEtaIndex())
    etaEndIndex = fGeometry->getMaxEtaIndex();

  if (eta-r < 0) etaStartIndex *= -1;
  if (eta+r < 0) etaEndIndex *= -1;
  if (phi-r < 0) phiStartIndex *= -1;
  if (phi+r < 0) phiEndIndex *= -1;

  CreateCaloGrid(etaStartIndex, etaEndIndex, phiStartIndex+36, phiEndIndex+36);
}

void TVisManagerBase::CreateCaloGrid(Int_t eta1, Int_t eta2,
				     Int_t phi1, Int_t phi2) {
  // GridLines are deleted, when canvas is deleted; just need to clear
  fGridLines->Clear();

  Double_t *etaTable = fGeometry->HCALetaTable();
  Double_t etaBase = fGeometry->HCALetaBase();
  Double_t minphi = phi1 * etaBase - TMath::Pi();
  Double_t maxphi = phi2 * etaBase - TMath::Pi();

  if (phi1 > phi2) {
    minphi = (phi1-72) * etaBase;
  }
  for (int iEta = eta1; iEta < eta2+1; ++iEta) {
    TPolyLine3D *myLine = new TPolyLine3D(2);
    myLine->SetLineColor(kGray);
    if (iEta < 0) {
      myLine->SetPoint(0, -etaTable[-iEta], minphi, 0.0);
      myLine->SetPoint(1, -etaTable[-iEta], maxphi, 0.0);
    } else {
      myLine->SetPoint(0, etaTable[iEta], minphi, 0.0);
      myLine->SetPoint(1, etaTable[iEta], maxphi, 0.0);
    }
//     cout << "etaline: (" << myLine->GetP()[0] << ", " << myLine->GetP()[1]
// 	 << ")->(" << myLine->GetP()[3] << ", " << myLine->GetP()[4]
// 	 << ")" << endl;
    fGridLines->Add(myLine);
  }

  // Set view size for eta and phi
  fMin[1] = minphi;
  fMax[1] = maxphi;
  if (eta1 < 0)
    fMin[0] = -etaTable[-eta1];
  else
    fMin[0] = etaTable[eta1];
  if (eta2 < 0)
    fMax[0] = -etaTable[-eta2];
  else
    fMax[0] = etaTable[eta2];

  // Draw lines at each tower phi
  for (int iPhi = phi1; iPhi < phi2+1 ; ++iPhi) {
    Bool_t saveStatus = kTRUE;
    TPolyLine3D *myLine = new TPolyLine3D(2);
    myLine->SetLineColor(kGray);
    Int_t mineta = eta1;
    Int_t maxeta = eta2;
    if ((iPhi % 4) == 0) {
      // Endcap coarse
      if (mineta < 0)
	myLine->SetPoint(0, -etaTable[-mineta], iPhi*etaBase-TMath::Pi(), 0.0);
      else
	myLine->SetPoint(0,  etaTable[mineta],  iPhi*etaBase-TMath::Pi(), 0.0);
      if (maxeta < 0)
	myLine->SetPoint(1, -etaTable[-maxeta], iPhi*etaBase-TMath::Pi(), 0.0);
      else
	myLine->SetPoint(1,  etaTable[maxeta],  iPhi*etaBase-TMath::Pi(), 0.0);
    } else if ((iPhi % 2) == 0) {
      // Endcap
      if (mineta < 0) {
	if (mineta < -39) mineta = -39;
	myLine->SetPoint(0, -etaTable[-mineta], iPhi*etaBase-TMath::Pi(), 0.0);
      } else {
	myLine->SetPoint(0,  etaTable[mineta],  iPhi*etaBase-TMath::Pi(), 0.0);
      }
      if (maxeta < 0) {
	myLine->SetPoint(1, -etaTable[-maxeta], iPhi*etaBase-TMath::Pi(), 0.0);
      } else {
	if (maxeta > 39) maxeta = 39;
	myLine->SetPoint(1,  etaTable[maxeta],  iPhi*etaBase-TMath::Pi(), 0.0);
      }
    } else {
      // Barrel
      if (mineta < 0) {
	if (mineta < -20) mineta = -20;
	myLine->SetPoint(0, -etaTable[-mineta], iPhi*etaBase-TMath::Pi(), 0.0);
      } else {
	if (mineta > 20) saveStatus = kFALSE;
	myLine->SetPoint(0,  etaTable[mineta],  iPhi*etaBase-TMath::Pi(), 0.0);
      }
      if (maxeta < 0) {
	if (maxeta < -20) saveStatus = kFALSE;
	myLine->SetPoint(1, -etaTable[-maxeta], iPhi*etaBase-TMath::Pi(), 0.0);
      } else {
	if (maxeta > 20) maxeta = 20;
	myLine->SetPoint(1,  etaTable[maxeta],  iPhi*etaBase-TMath::Pi(), 0.0);
      }
    }
    if (saveStatus) {
//       cout << "philine: (" << myLine->GetP()[0] << ", " << myLine->GetP()[1]
// 	   << ")->(" << myLine->GetP()[3] << ", " << myLine->GetP()[4]
// 	   << ")" << endl;
      fGridLines->Add(myLine);
    } else {
      delete myLine;
    }
  }
  //cout << "Calorimeter grid consists of " << fGridLines->GetEntriesFast()
  //<< " lines" << endl;
}

void TVisManagerBase::BaseClear() {
  fActiveId = -1;
  for (Int_t i = 0; i < 3; ++i) {
    fMin[i] = 0;
    fMax[i] = 0;
  }
  fObjects->Clear();
  fViewable = kFALSE;
}

void TVisManagerBase::Clear() {
  BaseClear();
}

void TVisManagerBase::Draw() {

}

void TVisManagerBase::DrawGrid() {
  Int_t lastLine = fGridLines->GetEntriesFast();
  for (Int_t iLine = 0; iLine < lastLine; ++iLine) {
    TPolyLine3D *myLine = (TPolyLine3D*)fGridLines->At(iLine);
    myLine->Draw();
  }
}

void TVisManagerBase::SetDoubleClickable(Bool_t status, Int_t value) { 
  fDoubleClickable = status;
  fDoubleClickAction = value;
}


void TVisManagerBase::GetViewDimensions(Double_t *min, Double_t *max) {
  for (Int_t i = 0; i < 3; ++i) {
    min[i] = fMin[i];
    max[i] = fMax[i];
  }
}

void TVisManagerBase::SetViewMaxZ(Double_t z) {
  if (z > fMax[2]) fMax[2] = z;
}

void TVisManagerBase::SetViewX(Double_t x) {
  if (x < fMin[0]) fMin[0] = x;
  if (x > fMax[0]) fMax[0] = x;
}

void TVisManagerBase::SetViewY(Double_t y) {
  if (y < fMin[1]) fMin[1] = y;
  if (y > fMax[1]) fMax[1] = y;
}

void TVisManagerBase::SetViewZ(Double_t z) {
  if (z < fMin[2]) fMin[2] = z;
  if (z > fMax[2]) fMax[2] = z;
}
