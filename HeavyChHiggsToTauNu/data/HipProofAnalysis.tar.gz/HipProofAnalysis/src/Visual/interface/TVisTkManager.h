#ifndef TVISTKMANAGER_H
#define TVISTKMANAGER_H

#include "Visual/interface/TVisManagerBase.h"
#include "Visual/interface/TVisTkJet.h"

//#include <TEveTrack.h>
//#include <TEveTrackPropagator.h>
#include <TObjArray.h>

/**
Class for tracker manager

@author Lauri A. Wendland
*/
class TVisTkManager : public TVisManagerBase {
 public:
  TVisTkManager(const char* shortName, TGVisOptions *options);
  ~TVisTkManager();

  void AddJet(const MyJet* jet, Int_t type);
  void AddSimInfo(MyEvent* event);
  void Clear();
  void Draw();
  virtual Int_t PointingDistance(Int_t px, Int_t py);
  void Print();
  void Print(Int_t id);
  void Unselect();

  // Getters
  inline TVisTkJet* GetActiveJet() { return (TVisTkJet*)fObjects->At(fActiveId); }

  // Setters
  inline void SetDrawTracks(Bool_t status = kTRUE) { fDrawTracks = status; }
  inline void SetDrawSimTracks(Bool_t status = kTRUE) { fDrawSimTracks = status; }
  void SetJetDrawOptions(TVisTkJet *jet);

 private:
  // Options
  Bool_t fDrawTracks;
  Bool_t fDrawSimTracks;
  TObjArray *fSimTracks;
 
 ClassDef(TVisTkManager, 0);
};

#endif
