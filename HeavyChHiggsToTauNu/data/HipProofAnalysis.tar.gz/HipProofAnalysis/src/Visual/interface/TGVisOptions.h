#ifndef TGVISOPTIONS_H
#define TGVISOPTIONS_H

#include <TGTab.h>
#include <TGFrame.h>
#include <TGLabel.h>
#include <TGButton.h>
#include <TGNumberEntry.h>
#include <TGLayout.h>
#include <TDatabasePDG.h>

enum VisJetType {
  JET_L1,
  JET_HLT,
  JET_E,
  JET_PHOTON,
  JET_MUON,
  JET_TAU,
  JET_PFTAU
  //JET_QCD
  //  JET_MC
};

#define JET_TYPE_COUNT 7
// if changed, remember to update jettypename in constructor code

class TGVisOptions : public TGCompositeFrame {
 public:
  //TGVisOptions();
  TGVisOptions(const TGWindow* p, Int_t w, Int_t h, TObject* main);

  ~TGVisOptions();
  
  // Testing of option cuts
  Bool_t SatisfiesEnergyThreshold(Double_t e, Bool_t isECAL);
  Bool_t SatisfiesCaloVisibility(Bool_t isECAL);
  
  // Getters
  Bool_t GetJetVisibility(Int_t type) { return fJetVisibilityButton[type]->IsDown(); }
  Bool_t GetEcalVisibility() { return fEcalVisibleButton->IsDown(); }
  Bool_t GetHcalVisibility() { return fHcalVisibleButton->IsDown(); }
  Bool_t GetTrackVisibility() { return fTrackVisibleButton->IsDown(); }
  Bool_t GetSimTrackVisibility() { return fSimTrackVisibleButton->IsDown(); }
  // calo options
  Double_t GetJetRadius() { return fJetRadius->GetNumber(); }
  Double_t GetTrIsolationCone() { return fTrIsolationRadius->GetNumber(); }
  Double_t GetTrSignalCone() { return fTrSignalRadius->GetNumber(); }
  Double_t GetEcalThreshold() { return fEcalThreshold->GetNumber(); }
  Double_t GetHcalThreshold() { return fHcalThreshold->GetNumber(); }
  // reco track options
  
  // sim track options
  Double_t GetSimMagField() { return fSimMagField->GetNumber(); }
  Double_t GetSimMinPt() { return fSimMinPt->GetNumber(); }
  Double_t GetSimMaxPt() { return fSimMaxPt->GetNumber(); }
  Double_t GetSimTrackMatchingDeltaR() { return fSimTrackMatchingDeltaR->GetNumber(); }
  // other
  TGTextButton *GetUpdateButton() { return fUpdateButton; }
  const char* GetJetName(Int_t type) { return VisJetTypeName[type]; }
  Double_t GetRunNumber() { return fRunNumber->GetNumber(); }
  Double_t GetEventNumber() { return fEventNumber->GetNumber(); }
  
  // Particle properties
  Double_t GetParticleMass(Int_t pdg);
  Double_t GetParticleCharge(Int_t pdg);
  void GetParticleName(Int_t pdg, char *name);
  
  // Setters
  void SetRunNumber(Int_t run) { fRunNumber->SetNumber((Double_t)run); }
  void SetEventNumber(Int_t event) { fEventNumber->SetNumber((Double_t)event);}
  
 private:
  char VisJetTypeName[7][40];
  // Event selection
  TGGroupFrame 	*fEventSelectionGroup;
  TGLabel 	*fRunNumberLabel;
  TGNumberEntry *fRunNumber;
  TGLabel 	*fEventNumberLabel;
  TGNumberEntry *fEventNumber;
  TGTextButton  *fReadEventButton;
  TGTextButton  *fNextEventButton;

  // Jet visibility
  TGGroupFrame  *fJetVisibilityGroup;
  TGCheckButton *fJetVisibilityButton[JET_TYPE_COUNT];
  // Calo visibility
  TGGroupFrame  *fCaloGroup;
  TGCheckButton *fEcalVisibleButton;
  TGCheckButton *fHcalVisibleButton;
  TGCheckButton *fTrackVisibleButton;
  TGCheckButton *fSimTrackVisibleButton;

  // Options tab
  TGTab         *fTab;
  
  // Calorimetry tab options
  TGLabel 	*fJetRadiusLabel;
  TGNumberEntry *fJetRadius;
  TGLabel 	*fTrIsolationRadiusLabel;
  TGNumberEntry *fTrIsolationRadius;
  TGLabel 	*fTrSignalRadiusLabel;
  TGNumberEntry *fTrSignalRadius;
  TGLabel 	*fEcalThresholdLabel;
  TGNumberEntry *fEcalThreshold;
  TGLabel 	*fHcalThresholdLabel;
  TGNumberEntry *fHcalThreshold;

  // Reco track options
  
  
  // Sim track options
  TGLabel 	*fSimMagFieldLabel;
  TGNumberEntry *fSimMagField;
  TGLabel 	*fSimPtLabel;
  TGNumberEntry *fSimMinPt;
  TGNumberEntry *fSimMaxPt;
  TGLabel 	*fSimTrackMatchingDeltaRLabel;
  TGNumberEntry *fSimTrackMatchingDeltaR;
  
  // Other objects  
  TGTextButton  *fUpdateButton;

  TGLayoutHints *fItemLayout;
  TGLayoutHints *fFrameLayout;
  TGLayoutHints *fButtonLayout;
  
  // Particle data object
  TDatabasePDG* fDatabasePDG; // Pointer to particle data object

  ClassDef(TGVisOptions,0)
};

#endif
