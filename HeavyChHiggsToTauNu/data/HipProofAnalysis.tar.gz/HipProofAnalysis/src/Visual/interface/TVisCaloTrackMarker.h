 #ifndef TVISCALOTRACKMARKER_H
#define TVISCALOTRACKMARKER_H

#include <TObject.h>
#include <TPolyLine3D.h>
#include "Visual/interface/TVisDrawableBase.h"

class TVisCaloTrackMarker : public TVisDrawableBase {
 public:
  TVisCaloTrackMarker(const char *name,
		      Double_t eta, Double_t phi,
		      Double_t pt, Int_t hits = 0, Double_t chi2 = 0,
                      Double_t deta = 0, Double_t dphi = 0);
  // Constructor for cloning
  TVisCaloTrackMarker(const char *info, Int_t color,
                      Double_t eta, Double_t phi,
                      Double_t pt, Int_t hits = 0,
                      Double_t chi2 = 0,
                      Double_t deta = 0, Double_t dphi = 0);

  ~TVisCaloTrackMarker();

  TVisCaloTrackMarker* CloneCaloTrackMarker();
  void Create();
  void Print();
  
  Double_t GetDeltaR(Double_t eta, Double_t phi); // to be moved
  Bool_t IsWithinRadius(Double_t eta, Double_t phi, Double_t radius);
  
  Double_t eta() { return feta; }
  Double_t phi() { return fphi; }
  Double_t chi2() { return fchi2; }
  Double_t pt() { return fpt; }
  
 private:
  Double_t feta;
  Double_t fphi;
  Double_t fdeta;
  Double_t fdphi;
  Double_t fpt;
  Int_t    fHits;
  Double_t fchi2;
  
  ClassDef(TVisCaloTrackMarker, 0)
};

#endif
