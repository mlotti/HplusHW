#ifndef TVISCALOCELL_H
#define TVISCALOCELL_H

#include "Visual/interface/TVisDrawableBase.h"

class TVisCaloCell : public TVisDrawableBase {
 public:
  TVisCaloCell(Double_t x, Double_t y, Double_t z,
	       Double_t dx, Double_t dy, Double_t dz,
	       Bool_t isECAL);
  virtual ~TVisCaloCell();

  TVisCaloCell* CloneCaloCell();
  void Create();
  void Print();
  Bool_t IsOverlapping(Double_t eta, Double_t phi,
		       Double_t deta, Double_t dphi);
  Bool_t IsWithinRadius(Double_t eta, Double_t phi, Double_t radius);

  Bool_t IsEcal() { return fECAL; }
  Double_t Energy() { return fEnergy; }
  Double_t eta() { return fEta; }
  Double_t phi() { return fPhi; }
  Double_t deta() { return fEtaEnd - fEta; }
  Double_t dphi() { return fPhiEnd - fPhi; }

 private:
  //TPolyLine3D *fSide[4];
  //TPolyLine3D *fTop;
  //Bool_t isTopActive;
  //Bool_t isSelected;
  //Bool_t isVisible;
  Bool_t fECAL;
  //char fMsg[60];
  Double_t fEta;
  Double_t fPhi;
  Double_t fEtaEnd;
  Double_t fPhiEnd;
  Double_t fEnergy;
  Double_t fEnergyOffset;

  //void SetColor();

  ClassDef(TVisCaloCell, 0)
};

#endif
