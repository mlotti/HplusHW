#ifndef TGVISMFD_H
#define TGVISMFD_H

// Multi-function display (MFD) creates a selection interface
// for embedded canvases

#include "Visual/interface/TVisEmbeddedCanvas.h"
#include "Visual/interface/TVisManagerBase.h"

#include <TGFrame.h>
#include <TCanvas.h>
#include <TGButton.h>
#include <TGLayout.h>
#include <TGLabel.h>
#include <TView.h>

enum VisEmbeddedMessages {
  M_ZOOM_IN,
  M_ZOOM_OUT,
  M_PRINT,
  M_DEFAULTVIEW,
  M_FRONTVIEW,
  M_SIDEVIEW,
  M_TOPVIEW,
  M_3DVIEW
};

class TGVisMFD : public TGCompositeFrame {
 public:
  TGVisMFD(Int_t id, TObjArray *array, const TGWindow* p, Int_t w, Int_t h);
  ~TGVisMFD();

  TCanvas* GetCanvas() { return fCanvas; }
  void cd() { fCanvas->cd(); }
  void Clear();
  void Draw();
  void Unselect();
  void Update() { fCanvas->Update(); }
  void UpdateButtons();
  Int_t PointingDistance(Int_t px, Int_t py);
  
  // View properties
  void SetRange(Double_t *min, Double_t *max);
  void ShowAxis();

  void SetEnableMouseClicks(Bool_t status = kTRUE);
  
  void DoZoomIn();
  void DoZoomOut();
  void DoPrint();
  void DoDefaultView();
  void DoFrontView();
  void DoSideView();
  void DoTopView();
  void Do3D();
  
  void DoManagerSelect();
  
  void SetEnabled(Bool_t status = kTRUE);
  Bool_t HasActiveManager() { return (fActiveManagerId >= 0); }
  TVisManagerBase* GetActiveManager();
  
  // Signals
  void HandleManager() { this->Emit("HandleManager()"); } // *SIGNAL*
  void DoDoubleClicked(Int_t a);  // *SIGNAL*
  void MouseEntered(Int_t id) { Emit("MouseEntered(Int_t)",id); } // *SIGNAL*
  void DoPadChanged(Int_t id) { Emit("DoPadChanged(Int_t)",id); } // *SIGNAL*

 private:
  TObjArray *fManagers;
  TObjArray *fManagerButtons;

  Int_t fActiveManagerId;
  Bool_t fCanvasEmpty;
  
  TVisEmbeddedCanvas *fECanvas;
  TCanvas *fCanvas;

  TGTextButton *fZoomInButton;
  TGTextButton *fZoomOutButton;
  TGTextButton *fPrintButton;
  TGTextButton *fFrontViewButton;
  TGTextButton *fSideViewButton;
  TGTextButton *fTopViewButton;
  TGTextButton *fDefaultViewButton;
  TGTextButton *f3DButton;
  TGCompositeFrame *fButtonFrame;
  TGCompositeFrame *fManagerButtonFrame;
  TGLabel *fTitle;

  TGLayoutHints *fButtonFrameLayout;
  TGLayoutHints *fButtonLayout;
  TGLayoutHints *fECanvasLayout;


  ClassDef(TGVisMFD,0)
};

#endif
