#ifndef TVISMANAGERBASE_H
#define TVISMANAGERBASE_H

#include <TObject.h>
#include <TObjArray.h>
#include <TDatabasePDG.h>

#include "Visual/interface/VisGeoLookup.h"
#include "Visual/interface/TGVisOptions.h"
#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"

enum VisManagerTypes {
  CALO_MANAGER,
  TRACK_MANAGER
};

enum VisMFDDoubleClickActions {
  M_CALOVIEW_DOUBLECLICK,
  M_TRACKVIEW_DOUBLECLICK
};

class TVisManagerBase : public TObject {
 public:
  TVisManagerBase(const char *shortName, TGVisOptions* options, Int_t type);
  ~TVisManagerBase();

  void BaseClear();
  virtual void Clear();
  void CreateFullCaloGrid();
  void CreateCaloGrid(Double_t eta, Double_t phi);
  virtual void Draw();
  void DrawGrid();
  virtual Int_t PointingDistance(Int_t px, Int_t py);
  
  // Getters
  inline Int_t GetDoubleClickAction() { return fDoubleClickAction; }
  inline VisGeoLookup* GetGeometry() { return fGeometry; }
  inline Int_t GetJetCount() { return fObjects->GetEntriesFast(); }
  inline const char* GetInfo() { return fInfo; }
  inline Int_t GetManagerType() { return fManagerType; }
  inline const char* GetShortName() { return fShortName; }
  void GetViewDimensions(Double_t *min, Double_t *max);
  
  inline Bool_t Allows3D() { return fAllow3D; }
  inline Bool_t IsActive() { return fActiveId >= 0; }
  inline Bool_t IsDoubleClickable() { return fDoubleClickable; }
  inline Bool_t IsTopViewOnly() { return fTopViewOnly; }
  inline Bool_t IsViewable() { return fViewable; }
  
  // Setters
  inline void SetAllow3D(Bool_t status = kTRUE) { fAllow3D = status; }
  void SetDoubleClickable(Bool_t status = kTRUE, Int_t value = 0);
  inline void SetDrawFullCaloGrid(Bool_t status = kTRUE) { fDrawFullCaloGrid = status; }
  inline void SetDrawJetCaloGrid(Bool_t status = kTRUE) { fDrawJetCaloGrid = status; }
  inline void SetSelectWholeJet(Bool_t status = kTRUE) { fSelectWholeJet = status; }
  inline void SetTopViewOnly(Bool_t status = kTRUE) { fTopViewOnly = status; }
  inline void SetViewable(Bool_t status = kTRUE) { fViewable = status; }
  void SetViewMaxZ(Double_t z);
  void SetViewX(Double_t x);
  void SetViewY(Double_t y);
  void SetViewZ(Double_t z);
  
 private:
  // eta-phi grid
  void CreateCaloGrid(Int_t eta1, Int_t eta2,
		      Int_t phi1, Int_t phi2);
  
 protected:
  // Options
  Bool_t fDoubleClickable; // Double click action for selecting
  Int_t fDoubleClickAction; // Action id for double click
  Bool_t fTopViewOnly;     // TView3D set to top view only
  Bool_t fAllow3D;         // Allow 3D viewer
  Bool_t fViewable;        // Viewable in MFD

  Bool_t fDrawFullCaloGrid;
  Bool_t fDrawJetCaloGrid;
  Bool_t fSelectWholeJet;
  
  // Data containers and internal variables
  Int_t fManagerType;      // Manager type ID
  Int_t fActiveId;         // Active (i.e. pointed) object id
  TObjArray *fObjects;     // Collection of drawable objects
  TGVisOptions *fOptions;  // Pointer to options, copy of object
  const char* fInfo;       // Pointer to info string
  
  // Dimensions for viewer
  Double_t fMin[3];    // minimum view size
  Double_t fMax[3];    // maximum view size

 private:
  // Geometry interface, owner of object
  VisGeoLookup *fGeometry;
  // eta-phi grid lines, collection of TPolyLine3D objects
  TObjArray *fGridLines;

    
  char fShortName[40];  // Short name  
 
  ClassDef(TVisManagerBase, 0)
};


#endif
