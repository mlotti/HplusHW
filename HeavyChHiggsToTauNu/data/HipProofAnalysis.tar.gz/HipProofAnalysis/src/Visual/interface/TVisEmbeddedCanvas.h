#ifndef TVISEMBEDDEDCANVAS_H
#define TVISEMBEDDEDCANVAS_H

#include <TRootEmbeddedCanvas.h>

// Hack to TRootEmbeddedCanvas to use double click method for jet selection

class TVisEmbeddedCanvas : public TRootEmbeddedCanvas {
 public:
  TVisEmbeddedCanvas(Int_t windowid = -1,
		     const char* name = 0,
		     const TGWindow* p = 0,
		     UInt_t w = 10,
		     UInt_t h = 10,
		     UInt_t options = kSunkenFrame|kDoubleBorder,
		     Pixel_t back = GetDefaultFrameBackground());
  virtual ~TVisEmbeddedCanvas();

  Bool_t HandleContainerDoubleClick(Event_t *event);
  Bool_t HandleContainerMotion(Event_t *event);
  Bool_t HandleContainerButton(Event_t *event);

  virtual void DoubleClicked(Int_t id) { Emit("DoubleClicked(Int_t)",id); } // *SIGNAL*
  virtual void MouseEntered(Int_t id) { Emit("MouseEntered(Int_t)",id); } // *SIGNAL*

  Int_t GetId() { return fWindowId; }
  void SetDoubleClickSensitivity(Bool_t status = kTRUE) { isDoubleClickSensitive = status; }
  void SetButtonClickSensitivity(Bool_t status = kTRUE) { isButtonClickSensitive = status; }

 private:
  Int_t fWindowId;
  Bool_t isDoubleClickSensitive; 
  Bool_t isButtonClickSensitive;

  ClassDef(TVisEmbeddedCanvas,0)

};

#endif
