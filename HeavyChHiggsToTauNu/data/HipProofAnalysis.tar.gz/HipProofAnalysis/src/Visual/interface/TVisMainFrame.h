#ifndef CLASSTVISMAINFRAME
#define CLASSTVISMAINFRAME

#include <TROOT.h>
#include <TSystem.h>
#include <TMath.h>
#include <TVirtualX.h>
#include <TApplication.h>
#include <TGButton.h>
#include <TGFrame.h>
#include <TGListTree.h>
#include <TGMenu.h>
#include <TGLayout.h>
#include <TGNumberEntry.h>
#include <TGStatusBar.h>
#include <TVector3.h>

/*
#include <TGeoManager.h>
#include <TGeoVolume.h>
#include <TGeoMatrix.h>
#include <TGeoMedium.h>
#include <TGeoMaterial.h>
*/

//#include "TPad.h"

#include "Visual/interface/TGVisMFD.h"
#include "Visual/interface/TVisCaloManager.h"
#include "Visual/interface/TVisTkManager.h"
#include "Visual/interface/TGVisOptions.h"
#include "Visual/interface/DataInterface.h"
//#include "Visual/interface/TGVisEventSelection.h"

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"


#include <TCanvas.h>
#include <TView.h>

#include <TGraphErrors.h>

#include <vector>

enum VisWindowId {
  VIS_CALO_MAIN,
  VIS_CALO_SINGLE_JET,
  VIS_CALO_JET_TRACKS
};

#define VIS_WINDOW_COUNT 3

class TVisMainFrame : public TGMainFrame {
  //SetBit(kMustCleanup);
 public:
  //TVisMainFrame();
  TVisMainFrame(const TGWindow* p);
  virtual ~TVisMainFrame();
  
  void AppendPad(Option_t *option = "");
  //SetBit(kMustCleanup);
  
  void ConstructInterface();
  void ConstructManagers();
  
  virtual Int_t DistancetoPrimitive(Int_t px, Int_t py);

  void DoClear();
  void DoNextEvent();
  void DoReadEvent();
  void DoExit();
  void DoDoubleClicked(Int_t action);
  void DoUpdateCanvases();
  void DoPadSelected(Int_t id);
  void DoPadChanged(Int_t id);
  void DoProcessMenuEvent(Int_t id);
    
  void ProcessEvent(MyEvent* event);
  void ProcessJet(const MyJet* jet, Int_t type);
  void ProcessSimEvent(MyEvent* event);
  //void CreateDemoEvent();
  virtual Bool_t ProcessMessage(Long_t msg, Long_t parm1, Long_t parm2);
  
  void Reset();
  
  //virtual Bool_t HandleClientMessage(Event_t* event);
  //virtual Bool_t HandleButton(Event_t* event);
  //virtual void ProcessMenuEvent(Int_t id);

 private:
  // GUI objects
  TGStatusBar *fStatusBar;
  TGMenuBar   *fMenuBar;
  TGPopupMenu *fMenuFile;
  TGPopupMenu *fMenuEvent;
  TGPopupMenu *fMenuInfo;
  TGPopupMenu *fMenuDebug;
  //TGVisMFD *fECanvas1;
  //TGVisMFD *fECanvas2;
  //TGVisMFD *fECanvas3;
  TObjArray *fMFDs;
  //TGVisMFD *fECanvases[VIS_WINDOW_COUNT];

  TGraphErrors *graph; // temporary

  // array for MFDs
  TObjArray *fMainManagers;
  TObjArray *fSmallManagers; // viewable in lower MFD's

  // arrays for filling managers with data
  //TObjArray *fCaloJetList;
  //TObjArray *fTkJetList;
  
  //TVisCaloManager *calo;
  //TVisCaloManager *calo2;
  //TVisCaloManager *calo3;
  TGVisOptions *fOptions;
  DataInterface *fData;
  
  Int_t fActiveCanvas;

  ClassDef(TVisMainFrame, 0)
};

#endif
