#ifndef VISGEOLOOKUP_H
#define VISGEOLOOKUP_H

// Class for converting measure units Int_to geometry units

#include <TROOT.h>
//#include <TGeoTranslation.h>

class VisGeoLookup {
 public:
  VisGeoLookup();
  virtual ~VisGeoLookup();  

  Double_t HCALEtaWidth(Double_t eta);
  Double_t HCALPhiWidth(Double_t eta);

  Int_t getHCALCellByPhi(Int_t etaIndex, Double_t phi);
  Int_t getHCALCellByEta(Double_t eta);
  //Double_t getPhiWidth(Double_t eta);
  /*
  Double_t getGeoEta(Double_t eta);
  Double_t getGeoEtaWidth(Double_t eta);
  Double_t getGeoPhi(Double_t eta, Double_t phi);
  Double_t getGeoPhiWidth(Double_t eta);
  */
  //void getGeoWidth(Double_t eta, Double_t phi, TVector3 *width);
  //TGeoTranslation getGeoTranslation(Double_t eta, Double_t phi, Double_t E);

  Double_t* HCALetaTable() { return fHCALetaStart; }
  Double_t* HCALphiTable() { return fHCALphiRes; }
  Double_t HCALetaBase() { return fEtaBase; }
  Int_t getMaxEtaIndex() { return 41; }

 private:
  Double_t fHCALetaStart[42]; // starting eta of tower
  Double_t fHCALphiRes[41]; // phi resolution at eta tower

  Double_t fEtaBase; // eta width of HCAL barrel tile 
  Double_t fScale; // scale factor


};

#endif
