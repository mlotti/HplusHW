#ifndef TVISTRACKPROPAGATOR_H
#define TVISTRACKPROPAGATOR_H

#include <TObject.h>
#include <TObjArray.h>
#include <TPolyLine3D.h>
#include <TVector3.h>
#include <TMath.h>


/**
Class for calculating track points for MC and simulated tracks based on their production vertex and momentum and particle type (charge and mass).

@author Lauri A. Wendland
*/
class TVisTrackPropagator : public TObject {
 public:
  TVisTrackPropagator(TVector3* x, TVector3* p, Double_t m, Double_t q, Double_t Bz, TObjArray* hits);
  ~TVisTrackPropagator();

  //TPolyLine3D* MakePolyLine3D();
  
 private: 
  void BuildTrack();
  void CalculateStepForVertex(TVector3& x, TVector3& p);
  Bool_t CheckVertexBoundary(TVector3& x);
  void Print(); // for debugging purposes only
  void PropagateNextStep(TVector3& x, TVector3& p);
  void SetPhiStep(Double_t step);
  
  Double_t fTimeStep;
  Double_t fPhiStep;
  Double_t fSinStep;
  Double_t fCosStep;
  TVector3 fCurX;
  TVector3 fCurP;
  TVector3 fVertexStep;
  Double_t fCurT;
  Double_t fCurAngle; // in radians
  Double_t fVelocity;
  Double_t fBeta;
  Double_t fCharge;
  Double_t fRadius;
  Double_t fPRatio; // pZ / pT
  Double_t fQBz; // Q * Bz * c * 1e-9
  Double_t fBz; // Magnetic field strength in z direction (T)
  TObjArray* fHits;
  
  // Constraints for CMS
  Double_t fMaxZ;
  Double_t fMaxR;
  Double_t fMaxOrbitals;
      
  ClassDef(TVisTrackPropagator,0)
};

#endif
