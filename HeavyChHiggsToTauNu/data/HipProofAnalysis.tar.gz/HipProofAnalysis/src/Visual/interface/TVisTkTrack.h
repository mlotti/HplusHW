#ifndef TVISTKTRACK_H
#define TVISTKTRACK_H

#include "Visual/interface/TVisDrawableBase.h"

#include <TVector3.h>
#include <TObjArray.h>

#include <iostream>
using namespace std;

/**
Class for tracker track objects

@author Lauri A. Wendland
*/
class TVisTkTrack : public TVisDrawableBase {
 public:
  TVisTkTrack(Double_t eta, Double_t phi, Double_t pt, Int_t hits, Double_t chi2);
  ~TVisTkTrack();

  void AddHit(Double_t x, Double_t y, Double_t z);
  void Create();
  void Print();
  TVisTkTrack* CloneTkTrack();
  Bool_t IsWithinRadius(Double_t eta, Double_t phi, Double_t radius);
      
  inline Double_t pt() { return fpt; }
  inline Int_t HitNumber() { return fHitNumber; }
  inline Double_t chi2() { return fchi2; }
  inline Double_t eta() { return feta; }
  inline Double_t phi() { return fphi; }
  
 protected:
  Double_t fpt;
  Int_t fHitNumber;
  Double_t fchi2;
  // Calorimeter hit point
  Double_t feta;
  Double_t fphi;
  // Hit positions
  TObjArray* fHits;
 
 private:
 ClassDef(TVisTkTrack,0)
};

#endif
