#ifndef TVISCALOJET_H
#define TVISCALOJET_H

#include "Visual/interface/TVisJetBase.h"
#include "Visual/interface/TVisCaloCell.h"
#include "Visual/interface/TVisCaloTrackMarker.h"
#include "Visual/interface/TVisCircle.h"

#include <TObjArray.h>

class TVisCaloJet : public TVisJetBase {
 public:
  //TVisCaloJet();
  TVisCaloJet(const char* name, Int_t type,
	      Double_t eta, Double_t phi,
	      TGVisOptions* options);
  ~TVisCaloJet();

  void AddEcalCell(Double_t eta, Double_t phi,
		   Double_t deta, Double_t dphi, Double_t dE);
  void AddHcalCell(Double_t eta, Double_t phi,
		   Double_t deta, Double_t dphi, Double_t dE);
  void AddTrackMarker(const char *name, Double_t eta, Double_t phi,
		      Double_t pt, Int_t hits,
		      Double_t chi2, Double_t deta = 0, Double_t dphi = 0);
  TVisCaloJet* CloneCaloJet();
  void CalculateInfo();
  
  Double_t GetMaxEnergy();

  
 private:
  Double_t fEcalEnergy;
  Double_t fHcalEnergy;
  Double_t fTotalEcalEnergy;
  Double_t fTotalHcalEnergy;
  Int_t fIsolationTracks;
  Int_t fSignalTracks;
  
  ClassDef(TVisCaloJet, 0)
};

#endif
