#ifndef TVISTKJET_H
#define TVISTKJET_H

#include "Visual/interface/TVisJetBase.h"
#include "Visual/interface/TVisTkTrack.h"
#include "Visual/interface/TGVisOptions.h"

#include <TObjArray.h>

/**
Class for tracker jet containing tracks, hits and simtracks

@author Lauri A. Wendland
*/
class TVisTkJet : public TVisJetBase {
 public:
  TVisTkJet(const char* name, Int_t type, Double_t eta, Double_t phi, TGVisOptions* options);
  ~TVisTkJet();

  //void AddTrackHit(
  void CalculateInfo();
  TVisTkJet* CloneTkJet();
    
 private:
  Int_t fIsoTracks;
  Int_t fSigTracks;
  
  ClassDef(TVisTkJet,0) 
};

#endif
