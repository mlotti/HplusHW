#ifndef DATAINTERFACE_H
#define DATAINTERFACE_H

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"

class DataInterface {
 public:
  DataInterface();
  ~DataInterface();

  //vector<string> *getFiles() { return &theFiles; }
  MyEvent* getEvent() { return theEvent; }
  bool nextEvent();
  bool readEvent(int run, int event);
  char* getFilename();

 private:
  bool theURLStatus;
  vector<string> theFiles;
  vector<string>::const_iterator iCurrentFile;
  int iCurrentFileEvent;
  MyEvent *theEvent;
  char theFilename[400];
};

#endif
