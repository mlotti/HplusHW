#ifndef TVISJETBASE_H
#define TVISJETBASE_H

#include "Visual/interface/TGVisOptions.h"
#include "Visual/interface/TVisDrawableBase.h"
#include "Visual/interface/TVisCaloCell.h"
#include "Visual/interface/TVisCaloTrackMarker.h"
#include "Visual/interface/TVisCircle.h"
#include "Visual/interface/TVisTkTrack.h"

#include <TObject.h>
//#include <TDatabasePDG.h>

/**
Base class for deriving jet objects

@author Lauri A. Wendland
*/
class TVisJetBase : public TVisDrawableBase {
 public:
  TVisJetBase(const char* name, Int_t type, Double_t eta, Double_t phi, TGVisOptions* options);
  ~TVisJetBase();

  void Add(TVisCaloCell* obj) { fObjects->Add(obj); }
  void Add(TVisCaloTrackMarker* obj) { fObjects->Add(obj); }
  void Add(TVisCircle* obj) { fObjects->Add(obj); }
  void Add(TVisTkTrack* obj) { fObjects->Add(obj); }
  
  virtual void Clear();
  void CloneBaseJet(TVisJetBase* jet);
  //virtual void Create();
  virtual void Draw();
  virtual Int_t PointingDistance(Int_t px, Int_t py);
  virtual void Print(); 
  
  void SelectSingleObject(Bool_t status = kTRUE);
  void SelectAllObjects(Bool_t status = kTRUE);

  // Getters
  inline const char* GetInfo() { return fJetInfo; }
  inline Bool_t IsDirty() { return fDirty; }
  inline Bool_t IsType(Int_t type) { return type == fJetType; }
  inline Double_t Jeteta() { return fJetEta; }
  inline Int_t JetId() { return fJetId; }
  inline Double_t Jetphi() { return fJetPhi; }
  inline Int_t JetType() { return fJetType; }
  
  // Setters
  inline void SetId(Int_t id) { fJetId = id; }
  inline void SetSelectWholeJet(Bool_t status = kTRUE) { fSelectWholeJet = status; }
  
  inline void SetDrawCaloCells(Bool_t status = kTRUE) { fDrawObjectType[CALOCELL_TYPE] = status; }
  inline void SetDrawCaloTrackMarkers(Bool_t status = kTRUE) { fDrawObjectType[CALOTRACKMARKER_TYPE] = status; }
  inline void SetDrawCaloCircles(Bool_t status = kTRUE) { fDrawObjectType[CIRCLE_TYPE] = status; }
  inline void SetDrawTkTracks(Bool_t status = kTRUE) { fDrawObjectType[TKTRACK_TYPE] = status; }
  inline void SetDrawTkSimTracks(Bool_t status = kTRUE) { fDrawObjectType[TKSIMTRACK_TYPE] = status; }
  inline void SetDrawItem(Int_t item, Bool_t status) { fDrawObjectType[item] = status; }
  
  
 private:
  Bool_t DrawingRequested(Int_t type) { return fDrawObjectType[type]; }
  
 protected:
  char fName[80];
  char* fJetInfo;
  Int_t fJetId;
  Int_t fJetType;
  Double_t fJetEta;
  Double_t fJetPhi;
  
  TGVisOptions* fOptions;
  //TDatabasePDG* fDatabasePDG;
  // Data containers
  //TObjArray fDrawableObjects[VIS_DRAWABLE_TYPE_COUNT];
  Int_t fActiveObjectId;
  TVisDrawableBase* fActiveObject;
  
  // Drawing options
  Bool_t fDrawObjectType[VIS_DRAWABLE_TYPE_COUNT];
  Bool_t fSelectWholeJet;
  
  Bool_t fDirty; // Tells if objects have been added
  
  ClassDef(TVisJetBase,0)
};

#endif
