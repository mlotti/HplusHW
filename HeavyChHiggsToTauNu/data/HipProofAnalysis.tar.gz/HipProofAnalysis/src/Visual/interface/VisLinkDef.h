#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class TVisDrawableBase;
#pragma link C++ class TVisManagerBase;
#pragma link C++ class TVisJetBase;
#pragma link C++ class TVisCaloCell;
#pragma link C++ class TVisCaloTrackMarker;
#pragma link C++ class TVisCircle;
#pragma link C++ class TVisCaloJet;
#pragma link C++ class TVisCaloManager;
#pragma link C++ class TVisTkSimTrack;
#pragma link C++ class TVisTkTrack;
#pragma link C++ class TVisTkJet;
#pragma link C++ class TVisTkManager;
#pragma link C++ class TVisEmbeddedCanvas;
#pragma link C++ class TVisMFD;
#pragma link C++ class TVisTrackPropagator;
#pragma link C++ class TGVisOptions;
#pragma link C++ class TVisMainFrame;

#endif
