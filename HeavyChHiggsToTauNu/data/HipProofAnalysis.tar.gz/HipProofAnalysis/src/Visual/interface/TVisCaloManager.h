#ifndef TVISCALOMANAGER_H
#define TVISCALOMANAGER_H

#include "Visual/interface/TVisManagerBase.h"
#include "Visual/interface/TVisCaloJet.h"
#include "Visual/interface/TGVisOptions.h"

#include <TObjArray.h>

class TVisCaloManager : public TVisManagerBase {
 public:
  TVisCaloManager(const char *shortName, TGVisOptions* options);
  ~TVisCaloManager();

  void AddEcalCell(Int_t id, Double_t eta, Double_t phi, Double_t E);
  void AddHcalCell(Int_t id, Double_t eta, Double_t phi, Double_t E);
  void AddJet(TVisCaloJet* jet);
  void AddJet(const MyJet* jet, Int_t type);
  void AddTrackMarker(Int_t id, const char *name, Double_t eta, Double_t phi,
		      Double_t pt, Int_t hits, Double_t chi2,
                      Double_t deta = 0, Double_t dphi = 0);
  void Clear();
  void Draw();
  virtual Int_t PointingDistance(Int_t px, Int_t py);
  void Print();
  void Print(Int_t id);
  void Unselect();
  
  // Getters
  inline TVisCaloJet* GetActiveJet() { return (TVisCaloJet*)fObjects->At(fActiveId); }
    
  // Option setters
  inline void SetDrawCells(Bool_t status = kTRUE) { fDrawCells = status; }
  inline void SetDrawTrackMarkers(Bool_t status = kTRUE) { fDrawTrackMarkers = status; }
  inline void SetDrawJetCones(Bool_t status = kTRUE) { fDrawJetCones = status; }  
  void SetJetDrawOptions(TVisCaloJet *jet);
    
 private:
  // Options
  Bool_t fDrawCells;
  Bool_t fDrawTrackMarkers;
  Bool_t fDrawJetCones;
  
  Bool_t CheckJetIndex(Int_t id);
  
  ClassDef(TVisCaloManager,0)
};

#endif
