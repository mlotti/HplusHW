#ifndef TVISTKSIMTRACK_H
#define TVISTKSIMTRACK_H

#include "Visual/interface/TVisTkTrack.h"
#include "Visual/interface/TGVisOptions.h"
#include "Visual/interface/TVisTrackPropagator.h"

#include <TVector3.h>
//#include <TEveTrack.h>

/**
Class for sim track objects

@author Lauri A. Wendland
*/
class TVisTkSimTrack : public TVisTkTrack {
 public:
  TVisTkSimTrack(Double_t eta, Double_t phi, Double_t pt, Int_t hits, Double_t chi2 = -1);
  ~TVisTkSimTrack();
  
  //void CalculateHits();
  //TVisTkSimTrack* CloneTkSimTrack();
  //void Print();
  void MakeTrack(TGVisOptions* options);
    
  // Getters
  //Double_t GetParticleMass(Int_t pid);
  
  // Setters
  void SetProdMomentum(Double_t x, Double_t y, Double_t z);
  void SetProdVertex(Double_t x, Double_t y, Double_t z);
  void SetSimParameters(Int_t pid, Int_t type, Int_t trackId);

 private:
  TVector3 fVertex;
  TVector3 fMomentum;
  Int_t fpid;
  Int_t fSimType;
  Int_t fSimTrackId;
  Bool_t fMatched;
 
  //TEveTrack* fEveTrack;
  
  ClassDef(TVisTkSimTrack,0)  
};

#endif
