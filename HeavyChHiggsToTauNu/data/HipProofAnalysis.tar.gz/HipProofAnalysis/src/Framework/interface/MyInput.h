#ifndef __MyInput__
#define __MyInput__

#include "Framework/interface/Dataset.h"
#include "Framework/interface/Cut.h"

#include <iostream>   //IO library
#include <fstream>
#include <vector>
#include <map>
#include <string>

#include "TChain.h"

using namespace std;

class MyInput {
  public:
      MyInput();
     ~MyInput();

	vector<Dataset>  	getDatasets();

//      	vector<string>     	getDatafiles();
      	//map<string,double> 	getCuts();
      	//double 		 	getCut(string);
        map<string, Cut>        getCuts();
        Cut                     getCut(string);
      	vector<string>     	getOptimizeCuts();
      	vector<int>        	getSignalChannels();
      	bool               	optimizeSignificance();
      	bool               	useScanner();
      	string             	getCommandString();
	string			getScanVariableName();
	TChain*			getChain();

  private:
	bool 			readAndCompressLine(ifstream&,string&);
	string 			compressLine(string);
	void 			fillDatasets(string);
        void                    fillDataset(string);
	string 			removeCurlys(string);


	vector<Dataset> 	datasets;

      	vector<string>     	dataSetNames;
      	//map<string,double> 	cut;
        map<string, Cut>        cut;
      	vector<string>     	optimizeCuts;
      	vector<int>        	signalChannels;
      	string          	commandString;

	TChain*			chain;
};

#endif


