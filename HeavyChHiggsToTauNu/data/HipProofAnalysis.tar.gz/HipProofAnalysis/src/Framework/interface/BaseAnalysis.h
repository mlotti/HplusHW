#ifndef __BaseAnalysis__
#define __BaseAnalysis__

#include "Framework/interface/MyInput.h"
#include "Counter.h"
#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"
#include "MyHistogram.h"
#include "MyEventFilter.h"
#include "Framework/interface/Timer.h"
#include "Framework/interface/Cuts.h"

#include <iostream>   //IO library

#include "TFile.h"
#include "TXNetFile.h"
#include "TTree.h"
#include "TH1F.h"
#include "TRandom3.h"
#include "TSelector.h"


using namespace std;

double deltaR(double,double,double,double);
double phi(double,double);
double deltaPhi(double,double);
double etafun(double,double,double);

class BaseAnalysis : public TSelector {
  public:
	BaseAnalysis();
	BaseAnalysis(MyInput);
	virtual ~BaseAnalysis();

        void Init(TTree*);
        void Begin(TTree*);
        void SlaveBegin(TTree*);
        Bool_t Notify();
        Bool_t ProcessCut(Long64_t);
        void   ProcessFill(Long64_t);
	void   Terminate();


	void    init(MyInput);
        virtual void setDefaultCuts() = 0;
	virtual void bookHistograms() = 0;
	virtual void analyse(MyEvent*) = 0;
	virtual void print() = 0;
	virtual void plotHistograms() = 0;

        virtual void beginEvent(MyEvent*);
        virtual void endEvent(MyEvent*);

	double 	getSignificance();
	double  getScanVariable();
	void    setCut(string,double);
        void    setCuts(map<string,double>);
        void    setCuts(map<string,Cut>);
	void 	disableHistogramming();

	bool    visualStatus(); // Visualization
	vector<string> getFileList(); // Visualization
	
  protected:

	void    setAnalysisBaseCuts();
        void    setNormalisation(TH1F*);
	void    scannerFill(string,double);

	TFile*  open(string,bool,int);

	vector<Dataset> datasets;
        vector<string> dataFiles;
	vector<int>    signalChannels;

	double signif;

        TTree* fChain;
	MyEvent* event;
        TBranch* b_event;

	Counter* eventCounter;
	MyHistogram* histograms;
	MyEventFilter* eventFilter;
	Timer* timer;

        Cuts *cuts;

	TRandom* randomGenerator;

	double scanVariable;

	string oldFileName; // To prevent Notify from being called twice in the beginning
        
	ClassDef(BaseAnalysis, 1)  // ClassDef macro for ROOT.
};
#endif
