#ifndef __Counter__
#define __Counter__

//////////////////////////////////////////////////////////
//	Subcounter: sorts counters according to the      
//	first string in the cut name separated by blancs 
//////////////////////////////////////////////////////////

#include "Framework/interface/Dataset.h"

#include <iostream>   //IO library
#include <iomanip>
#include <string>
#include <vector>
#include <math.h>

using namespace std;

const int maxIBG = 20;
const int maxCut = 100;

double efficiencyError(int,double);

class Counter {
  public:
	Counter();
	virtual ~Counter();

        void   		setLuminosity(double);
        void   		setCrossSection(int,double,double cnor = 1,double events = 1);
	void   		addCount(string,int factor = 1);
        void   		addCount(string,double);
        void            addSubCount(string,int factor = 1);
        void            addSubCount(string,double);

        void   		setSignal(int);
        double 		getSignificance();
        double          getSignalOverBackgr();
	double		getNormalizedNumberOfEventsPassingCuts();
        void   		reset();
	void   		print();
        void   		combineChannels(string,int,int stop = 0);
	void 		addInFinalReport(const Dataset&);

        vector<Dataset> getChannels();
	Dataset		getChannel(int);
	int		getNChannels();
	string		getName(int);
        string          getName();
	vector<string>  getCutNames();
        int             getLabel(int);
	int		getLabel();
        double		getNormalization(int);
	double		getNAllEvents(int);
	int		getNevents(int,int);
	double 		getLuminosity();
        int             getIbgCounter(int);

	void		setName(string);
	void            setLabel(int);
	void 		setCrossSection(double);
	void		setPreselectionEfficiency(double);
	void		setSignal(bool);

	void 		setDataset(const Dataset&);
        void            setDataset(string);

  private:
//        double          getPreSeleEfficiency(int);
	double		normalization(int);
        double		significance(double,double);

        void		printSummary(double luminosity = 1);
	void		printSubCounters(int);

	vector<Dataset>	IBGs;
	vector<string> 	names;
	vector<string>  subCounterNames;
        int		counter[maxIBG][maxCut];
        int             subcounter[maxIBG][maxCut];

	int 		ibgCounter;

//        double          crossSections[maxIBG];
//        double          preSeleEfficiencies[maxIBG];

        double 		luminosity;

        vector<int> 	signalIbgs;

        class Sorting {
          public:
                Sorting(){ reset();}
                virtual ~Sorting(){}
                void reset(){ 
                  for(int i = 0; i < maxCut; i++) {
                    counter[i]         = 0;
                    stats_for_error[i] = 0;
                  }
                }
                void add(double count,int N,int iCut) { 
                  counter[iCut]         += count;
                  stats_for_error[iCut] += N;
                }
                double getCounter(int iCut) const { return counter[iCut];}
                double getError(int iCut) const {
                  double error = 0;
                  if(stats_for_error[iCut] > 0) {
                    error = counter[iCut]/sqrt(double(stats_for_error[iCut]));
                  }
                  return error;
                }
                double getEfficError(int iCut) const { 
                  if(iCut == 0) return 0;
                  double eff = counter[iCut]/counter[iCut-1];
                  double error = efficiencyError(stats_for_error[iCut],eff);
                  return error;
                }

                string name;
                int    start,
                       stop;
                double counter[maxCut];
                int    stats_for_error[maxCut];
        };

        vector<Sorting> channelSorting;
};
#endif
