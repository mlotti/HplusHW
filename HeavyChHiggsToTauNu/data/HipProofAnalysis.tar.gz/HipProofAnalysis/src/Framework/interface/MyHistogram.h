#ifndef __MyHistogram__
#define __MyHistogram__

#include <iostream>   //IO library
#include <fstream>
#include <vector>
#include <map>
#include <set>
#include <string>

#include "TFile.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TTree.h"

#include "Counter.h"

using namespace std;

//////////////////////////////////////////////////////
// histogram booking: histo->book("name",nBins,xlow,xup);
// histogram cloning: histo->clone("name","histo_to_be_cloned");
// histogram filling: histo->fill("name",theValue);
// tree filling: 
//	histo->setTreeVariable("name1",theValue1);
//	histo->setTreeVariable("name2",theValue2);
//	histo->fillTree();
//////////////////////////////////////////////////////

class MyHistogram {
  public:
        MyHistogram(string);
       ~MyHistogram();

	void init(string);
	void setDatasetName(string);
	void book(string,int,double,double);
        void book(string,int,double,double,int,double,double);
        bool booked(string);
        void clone(string,string);
        void fill(string,double);
        void fill(string,double,double);
	void fill(string,double,double,double);
	void fill(string,string,int,double);
        void fillLuminosity(double);
        void fillCrossSection(const Dataset&);
////        void fillCrossSections(vector<Dataset>);
	void fillNevents(Counter*,int);
	void normalize(Counter*);
	void dontNormalize(string);
	void dontNormalize();
	void save();
	void add(TH1F*);
	void disableHistogramming();
	void list();
	void setTreeTitle(string);
	void setTreeVariable(string,double);
	void fillTree();

  private:
	void checkExistence(string);

        bool booked1D(string);
        bool booked2D(string);

	TFile* 		   outFile;
	map<string,TH1F*>  myHistograms;
        map<string,TH2F*>  myHistograms2D;
	set<string>	   noNormalization;
	string 		   dataset;
	string 		   histogramName(string);
	string		   outFileName;

	bool		   disabled;
	bool		   disableNormalization;
	TTree*		   tree;
	map<string,int>    treeVariableNameIndex;
	int		   maxNTreeVariables;
	float*		   treeVariables;
};
#endif
