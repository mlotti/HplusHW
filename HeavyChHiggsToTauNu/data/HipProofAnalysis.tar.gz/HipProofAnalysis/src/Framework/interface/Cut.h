#ifndef __Cut__
#define __Cut__

#include<iostream>
#include<string>

using std::string;
using std::ostream;
using std::pair;

/**
 * Class for representing a single cut. The motivations for using a
 * class for a cut instead of writing the cut explicitly into the
 * analysis code are:
 * - Ability to disable cuts at run-time. 
 * - Getting run-time information about which cuts were actually used
 */

class Cut {
 public:
        /**
         * Enumeration representing the cut type. It could be cleaner
         * to implement different cuts via inheritance, but single
         * class with enumeration was the quick solution.
         */
        enum CutType {kLt=1,   /**< Less than (cut < value)  */
                      kGt,     /**< Greater than (value < cut) */
                      kIn,     /**< Inside or inclusive (value < cut && cut < value */
                      kOut,    /**< Outside or exclusive (cut < value || value < cut */
                      kUnkown  /**< Unkown or unspecified cut. This
                                  type is used to deliver cut values
                                  from e.g. MyInput */
        };

        /**
         * Default constructor. Intended for interoperability with map.
         */
        Cut();
        
        /**
         * Constructor for single parameter cut. 
         *
         * @param type     type of the cut (not checked)
         * @param value    value of cut
         * @param enabled  is the cut enabled by default?
         */
        Cut(CutType type, double value, bool enabled);

        /**
         * Constructor for two parameter cut.
         *
         * @param type     type of the cut (not checked)
         * @param low      lower limit of the cut
         * @param high     upper limit of the cut
         * @param enabled  is the cut enabled by default?
         */
        Cut(CutType type, double low, double high, bool enabled);

        /**
         * Set the value of single parameter cut. The cut type is
         * checked.
         *
         * @param value  new value of the cut
         */
        void setValue(double value);

        /**
         * Sets the limits for two parameter cut. The cut type is
         * checked.
         *
         * @param low    lower limit
         * @param high   upper limit
         */
        void setValues(double low, double high);

        /**
         * Sets the limits for two parameter cut. The cut type is
         * checked.
         * 
         * @param values   pair (lower, upper) limit
         */
        void setValues(const pair<double, double>& values);

        /**
         * Enables the cut.
         */
        void enable(void);

        /**
         * Disables the cut.
         */
        void disable(void);

        /**
         * Gets the value of single parameter cut. Cut type is
         * checked.
         *
         * @return value of cut
         */
        double getValue(void);

        /**
         * Gets the value of two parameter cut. Cut type is checked.
         * @param low   low limit of cut
         * @param high  high limit of cut
         *
         */
        pair<double, double> getValues(void);

        /**
         * Gets the value of two parameter cut. Cut type is checked.
         * @param returns   pair (lower,higher) limit
         *
         */
        void getValues(double* l, double* h);

        /**
         * Sets the cut type.
         *
         * @param type  new type of the cut
         */
        void setType(CutType type);

        /**
         * Gets the cut type.
         *
         * @return cut type
         */
        CutType getType(void) const;

        /**
         * @return is the cut enabled?
         */
        bool isEnabled(void) const;

        /**
         * @return has the cut been applied?
         */
        bool isApplied(void) const;

        /**
         * Applies the cut
         *
         * @param value to be cutted
         *
         * @return true, if value passes the cut
         *         false, if not
         */
        bool apply(double value);

        /**
         * Prints the cut
         *
         * @param s      ostream reference (e.h. std::cout)
         * @param name   name of the cut (the cut object doesn't know it's name, but the name is needed for pretty printing)
         *
         * @return s     ostream reference
         */
        ostream& print(ostream& s, string name) const;

 private:
        CutType type;  /**< Type of the cut */
        double low;    /**< Lower limit of the cut (for kGt, kIn, kOut) */
        double high;   /**< Upper limit of the cut (for kLt, kIn, kOut) */
        bool enabled;  /**< Is the cut enabled? */
        bool applied;  /**< Has the cut been applied? */
};

#endif /* __Cut__ */
