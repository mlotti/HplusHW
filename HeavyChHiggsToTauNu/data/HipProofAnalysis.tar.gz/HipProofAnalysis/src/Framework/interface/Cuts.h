#ifndef __Cuts__
#define __Cuts__

#include<iostream>
#include<map>

#include "Framework/interface/Cut.h"

using std::string;
using std::map;
using std::pair;

/**
 * Class for managing set of cuts. 
 *
 */

class Cuts {
 public:
        /**
         * Prints the cuts in the following categories:
         * - Cuts which have been booked and applied
         * - Cuts which have been booked but not been applied
         * - Cuts which have been disabled
         * - Cuts which have been set in the input file but not been booked
         */
        void print(void);

        /**
         * Books "less than" cut, which is enabled by default
         *
         * @see bookLessThanCut(string, double, bool)
         *
         * @param name         name of the cut
         * @param defaultCut   default value of the cut
         */
        void bookLessThanCut(string name, double defaultCut);

        /**
         * Books "greater than" cut, which is enabled by default
         *
         * @see bookGreaterThanCut(string, double, bool)
         *
         * @param name         name of the cut
         * @param defaultCut   default value of the cut
         */
        void bookGreaterThanCut(string name, double defaultCut);

        /**
         * Books "inside" or "inclusive" cut, which is enabled by default
         *
         * @see bookInsideCut(string, double, double, bool)
         *
         * @param name         name of the cut
         * @param defaultLow   default lower limit
         * @param defaultHigh  default upper limit
         */
        void bookInsideCut(string name, double defaultLow, double defaultHigh);

        /**
         * Books "outside" or "exclusive" cut, which is enabled by default
         *
         * @see bookInsideCut(string, double, double, bool)
         *
         * @param name         name of the cut
         * @param defaultLow   default lower limit
         * @param defaultHigh  default upper limit
         */
        void bookOutsideCut(string name, double defaultLow, double defaultHigh);

        /**
         * Books "less than" cut
         *
         * Cut of this type gives true, if "cut < x", where "cut" is
         * the name and "x" is the value of event.
         *
         * @param name         name of the cut
         * @param defaultCut   default value of the cut
         * @param enabled      is the cut enabled by default?
         */
        void bookLessThanCut(string name, double defaultCut, bool enabled);

        /**
         * Books "greater than" cut
         *
         * Cut of this type gives true, if "x < cut", where "cut" is
         * the name and "x" is the value of event.
         *
         * @param name         name of the cut
         * @param defaultCut   default value of the cut
         * @param enabled      is the cut enabled by default?
         */
        void bookGreaterThanCut(string name, double defaultCut, bool enabled);

        /**
         * Books "inside" or "inclusive" cut
         *
         * Cut of this type gives true, if "x_low < cut && cut < x_high", where
         * "cut" is the name and "x" is the value of event.
         *
         * @param name         name of the cut
         * @param defaultLow   default lower limit
         * @param defaultHigh  default upper limit
         * @param enabled      is the cut enabled by default?
         */
        void bookInsideCut(string name, double defaultLow, double defaultHigh, bool enabled);

        /**
         * Books "outside" or "exclusive" cut
         *
         * Cut of this type gives true, if "cut < x_low || x_high < cut", where
         * "cut" is the name and "x" is the value of event.
         *
         * @param name         name of the cut
         * @param defaultLow   default lower limit
         * @param defaultHigh  default upper limit
         * @param enabled      is the cut enabled by default?
         */
        void bookOutsideCut(string name, double defaultLow, double defaultHigh, bool enabled);

        /**
         * Apply the cut.
         *
         * @param name    name of the cut
         * @param value   value to be cutted
         *
         * @return true, if value passes the cut
         *         false, if not
         */
        bool applyCut(string name, double value);

        /**
         * Set cut value. The cut type is taken from the existing
         * object, and values and enabled status are taken from the
         * given cut object.
         *
         * If the cut has not yet been booked, the cut is inserted to
         * unusedCuts. If the cut has been booked, the state of the
         * cut is modified.
         *
         * The properties of two parameter cut named "cut" are
         * modified by using here cut names "cutLow" for the lower
         * limit and "cutHigh" for the upper limit. If either limit is
         * disabled, the cut type is transformed to corresponding
         * single parameter cut. In order to fully disable the cut,
         * both limits must be explicitly disabled.
         *
         * @param name   name of the cut
         * @param cut    Cut object where the cut values are taken
         */
        void setCutValue(string name, Cut cut);

        /**
         * Set cut value for single parameter cut.
         *
         * @see setCutValue(string, Cut)
         *
         * @param name   name of the cut
         * @param value  new value of the cut
         */
        void setCutValue(string name, double value);
        
        /**
         * Set cut values for two parameter cut.
         *
         * @see setCutValue(string, Cut)
         *
         * @param name   name of the cut
         * @param value  pair (lower, upper) limit
         */
        void setCutValue(string name, pair<double, double> value);

        /**
         * Set multiple cut values.
         *
         * @see setCutValue(string, Cut)
         *
         * @param cutValues   list of (name, cut) pairs to be set
         */
        void setCutValues(map<string, Cut> cutValues);

        /**
         * Set multiple cut values.
         *
         * @see setCutValue(string, Cut)
         *
         * @param cutValues   list of (name, value) pairs to be set
         */
        void setCutValues(map<string, double> cutValues);

        /**
         * Get single parameter cut value
         *
         * @param name   name of the cut
         *
         * @return value of the cut
         */
        double getCutValue(string name);

        /**
         * Get two parameter cut value
         *
         * @param name   name of the cut
         * @param l      low value of cut
         * @param h      high value of cut
         */
	void getCutValues(string name, double *l, double *h);

        /**
         * Get two parameter cut value
         *
         * @param name   name of the cut
         *
         * @return pair (lower, upper) limits of the cut
         */
        pair<double, double> getCutValues(string name);

 private:
        /**
         * Books cut, which is enabled by default
         *
         * @param name   name of the cut
         * @param type   type of the cut
         * @param low    lower limit of the cut
         * @param high   upper limit of the cut
         */
        void bookCut(string& name, Cut::CutType type, double low, double high);

        /**
         * Books cut
         *
         * @param name     name of the cut
         * @param type     type of the cut
         * @param low      lower limit of the cut
         * @param high     upper limit of the cut
         * @param enabled  is the cut enabled by default?
         */
        void bookCut(string& name, Cut::CutType type, double low, double high, bool enabled);

        map<string, Cut> cuts;         /**< booked cuts */
        map<string, Cut> unusedCuts;   /**< cuts which values have been set, but have not yet been booked */
};

#endif /* __Cuts__ */
