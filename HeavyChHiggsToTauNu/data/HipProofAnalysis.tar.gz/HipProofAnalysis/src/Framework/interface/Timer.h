#ifndef TIMER_H
#define TIMER_H

#include "TStopwatch.h"

class Timer {
    public:
        Timer();
        ~Timer();

    private:
        TStopwatch* theTimer;
};
#endif
