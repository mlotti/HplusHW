#ifndef __Dataset__
#define __Dataset__

#include <iostream>   //IO library
#include <fstream>
#include <vector>
#include <string>

using namespace std;

class Dataset {
  public:
	Dataset();
	~Dataset();

	void clear();

	double getCrossSection() const;
	double getPreselectionEfficiency() const;
	bool 	isSignal() const;
	bool	isURL() const;
	string	getName() const;
	string getPath() const;
	vector<string> getFiles() const;
	int getLabel() const;
	int getMaxEvents() const;
        int getMaxFiles() const;

	void setCrossSection(string);
	void setPreselectionEfficiency(string);
	void setSignal(string);
	void setName(string);
	void setLabel(string);
	void setDirectory(string);
	void setMaxEvents(string);
        void setMaxFiles(string);

  private:
	string name;
	int label;
	string dataDirectory;
        double cross_section;
	double preSeleEfficiency;
        bool signal;
	int maxEvents;
	int maxFiles;
	bool URL;
};
#endif
