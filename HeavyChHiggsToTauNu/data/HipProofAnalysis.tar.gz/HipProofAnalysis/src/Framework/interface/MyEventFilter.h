#ifndef __MyEventFilter__
#define __MyEventFilter__

#include <iostream>   //IO library
#include <fstream>
#include <vector>
#include <map>
#include <string>

#include "TFile.h"
#include "TH1F.h"
#include "TTree.h"

#include "Framework/interface/MyInput.h"
#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"

using namespace std;

class MyEventFilter {
  public:
        MyEventFilter(MyInput&);
       ~MyEventFilter();

	void saveEventInfo(TH1F*);
	void saveEvent(MyEvent*);

  private:
	void init(MyInput&);
	void write();

	TFile*  filterFile;
	TTree*  rootTree;
	TH1F*	sumInfo;

	MyEvent* myEvent;

	int filteredEvents;
	bool filter;
	int nFiles;
};
#endif
