#ifndef __CutScanner__
#define __CutScanner__

#include "MyAnalysis/interface/MyAnalysis.h"
#include "Framework/interface/MyInput.h"
#include "Framework/interface/Cut.h"
#include "TObject.h"
#include "TChain.h"
#include "TH1F.h"

#include <iostream>
using namespace std;

const int NPoints = 25;

class CutScanner {
  public:
        CutScanner(MyInput&, TChain *chain, MyAnalysis *anAnalysis);
	virtual ~CutScanner();

	void scan();
	
  private:
      	void setBegin(double);
      	void setEnd(double);
      	void setSteps(double);
	void setValues(double,double);
	//void setCuts(map<string,double>);
        void setCuts(map<string, Cut>);
	void plot();

	void setDefaultCuts();

        //map<string,double> cuts;
        map<string, Cut> cuts;

	string theCut;
	double begin,
               end;
	int    steps;

	int iPoint;
	double graphX[NPoints];
	double graphY[NPoints];
	MyAnalysis *analysis;
	TChain *chain;
};
#endif
