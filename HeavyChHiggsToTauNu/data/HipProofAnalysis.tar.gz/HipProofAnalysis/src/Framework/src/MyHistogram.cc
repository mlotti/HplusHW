#include "Framework/interface/MyHistogram.h"

MyHistogram::MyHistogram(string fileName){
	init(fileName);
}

MyHistogram::~MyHistogram(){
	save();
}

void MyHistogram:: init(string fileName){
	outFileName = fileName;
	outFile = new TFile(fileName.c_str(),"RECREATE");
        outFile->cd();
	dataset = "";
	disabled = false;
	disableNormalization = false;

	maxNTreeVariables = 50;
	tree = new TTree("tree","");
	treeVariables = new float[maxNTreeVariables];
}

void MyHistogram::setDatasetName(string datasetName){
	dataset = datasetName;
}

string MyHistogram::histogramName(string name){
	if(dataset != "") return name + "_" + dataset;
	return name;
}

void MyHistogram::book(string name,int nBins,double begin,double end){
	if(!booked(name)){
		outFile->cd();
		string hName = histogramName(name);
		TH1F* test = new TH1F(hName.c_str(),"",nBins,begin,end);
		myHistograms[hName] = test;
	}
}

void MyHistogram::book(string name,int nBinsX,double beginX,double endX,int nBinsY,double beginY,double endY){
        if(!booked(name)){
                outFile->cd();
		string hName = histogramName(name);
                TH2F* test = new TH2F(hName.c_str(),"",nBinsX,beginX,endX,nBinsY,beginY,endY);
                myHistograms2D[hName] = test;
        }
}


bool MyHistogram::booked(string name){
	string hName = histogramName(name);
	if(booked1D(hName) || booked2D(hName)) return true;
	return false;
}

bool MyHistogram::booked1D(string hName){
        if(myHistograms.find(hName) != myHistograms.end()) return true;
        return false;
}

bool MyHistogram::booked2D(string hName){
	if(myHistograms2D.find(hName) != myHistograms2D.end() ) return true;
        return false;
}


void MyHistogram::clone(string name,string modelHistogramName){

	string hModel = histogramName(modelHistogramName);
        checkExistence(modelHistogramName);

        if(!booked(name)){
                outFile->cd();

		string hName = histogramName(name);
		if(booked2D(hModel)){
                  TH2F* modelHisto = myHistograms2D[hModel];
                  TH2F* test = (TH2F*)modelHisto->Clone(hName.c_str());
		  test->Reset();
		  test->SetTitle(hName.c_str());
		  myHistograms2D[hName] = test;
		}else{
		  TH1F* modelHisto = myHistograms[hModel];
                  TH1F* test = (TH1F*)modelHisto->Clone(hName.c_str());
		  test->Reset();
		  test->SetTitle(hName.c_str());
                  myHistograms[hName] = test;
		}
        }
}


void MyHistogram::fill(string name,double value){
	fill(name,value,1);
}

void MyHistogram::fill(string name,double valueX, double valueY){

        checkExistence(name);

	string hName = histogramName(name);
	if(booked1D(hName)){
		outFile->cd();
		double weight = valueY;

	        TH1F* my_histo = myHistograms[hName];
	        my_histo->Fill(valueX,weight);
	        myHistograms[hName] = my_histo;		
	}else{
		fill(name,valueX,valueY,1);
	}
}

void MyHistogram::fill(string name,double valueX, double valueY, double weight){

        checkExistence(name);

        outFile->cd();

        string hName = histogramName(name);
        TH2F* my_histo = myHistograms2D[hName];
        my_histo->Fill(valueX,valueY,weight);
        myHistograms2D[hName] = my_histo;
}

void MyHistogram::fill(string name,string binName,int binIndex,double value){

	checkExistence(name);

        string hName = histogramName(name);
        if(booked1D(hName)){
                outFile->cd();

                TH1F* my_histo = myHistograms[hName];
                my_histo->SetBinContent(binIndex,value);
		my_histo->GetXaxis()->SetBinLabel(binIndex,binName.c_str());
		
                myHistograms[hName] = my_histo;

        }	
}
void MyHistogram::fillLuminosity(double value){
        string name = "luminosity";

        int nbins = 1;
        book(name,nbins,0,nbins);
        fill(name,0.,value);

        dontNormalize(name);
}

void MyHistogram::fillNevents(Counter* eventCounter,int iChannel){

	vector<string> cuts = eventCounter->getCutNames();

	string name = "nEvents";
	int nbins = cuts.size();
	book(name,nbins,0,nbins);
	dontNormalize(name);

	for(unsigned int i = 0; i < cuts.size(); ++i){
		string cutname = cuts[i];
		int value   = eventCounter->getNevents(iChannel,i);
		fill(name,cutname,i+1,value);
	}

/*

        string name = "nAllEvents";

        int nbins = 1;
        book(name,nbins,0,nbins);
        fill(name,0.,value);

        dontNormalize(name);
*/
}

void MyHistogram::fillCrossSection(const Dataset& dataset){

        int nbins = 1;

        book("cross_section",nbins,0,nbins);
        fill("cross_section",0.,dataset.getCrossSection());
        dontNormalize("cross_section");

        book("preselectionEff",nbins,0,nbins);
        fill("preselectionEff",0.,dataset.getPreselectionEfficiency());
        dontNormalize("preselectionEff");
}

void MyHistogram::dontNormalize(string name){
	string hName = histogramName(name);
	noNormalization.insert(hName);
}

void MyHistogram::dontNormalize(){
	disableNormalization = true;
}

void MyHistogram::normalize(Counter* eventCounter){

	float luminosity = eventCounter->getLuminosity()/1000;
        char* yTitle = Form("%s%g%s","Events for ",luminosity," fb-1");

	int nChannels = eventCounter->getNChannels();
	for(int i = 0; i < nChannels; i++){

		string name = eventCounter->getName(i);
		setDatasetName(name);

		fillCrossSection(eventCounter->getChannel(i));
                fillNevents(eventCounter,i);

		if(disableNormalization) continue;

		double cnor = eventCounter->getNormalization(i);

		map<string,TH1F*>::const_iterator iHisto;
		for(iHisto = myHistograms.begin(); iHisto != myHistograms.end(); iHisto++){
			TH1F* my_histo = iHisto->second;
			string histogramName = string(my_histo->GetName());

			if(noNormalization.find(histogramName) != noNormalization.end() ) continue;

			my_histo->GetYaxis()->SetTitle(yTitle);
			if(histogramName.find(name) < histogramName.length()) my_histo->Scale(cnor);
		}

		map<string,TH2F*>::const_iterator iHisto2D;
		for(iHisto2D = myHistograms2D.begin(); iHisto2D != myHistograms2D.end(); iHisto2D++){
	                TH2F* my_histo = iHisto2D->second;
			string histogramName = string(my_histo->GetName());

			if(noNormalization.find(histogramName) != noNormalization.end() ) continue;

                        my_histo->GetYaxis()->SetTitle(yTitle);
                        if(histogramName.find(name) < histogramName.length()) my_histo->Scale(cnor);
                }
	}
}

void MyHistogram::save(){

	if(!disabled || tree->GetEntries() > 0) {;

		// very inelegant way of playing with dummy.root, but since the normal way
                // stopped working with very large number of histograms, and this works...
		////outFile = new TFile(outFileName.c_str(),"RECREATE");
	        outFile->cd();

		if(!disabled){
		  map<string,TH1F*>::const_iterator iHisto;
		  for(iHisto = myHistograms.begin(); 
                      iHisto != myHistograms.end(); iHisto++){
			TH1F* my_histo = iHisto->second;
			my_histo->Write();
			delete my_histo;
		  }
	          map<string,TH2F*>::const_iterator iHisto2D;
	          for(iHisto2D = myHistograms2D.begin(); 
                      iHisto2D != myHistograms2D.end(); iHisto2D++){
	                TH2F* my_histo = iHisto2D->second;
			my_histo->SetMarkerStyle(7);
	                my_histo->Write();
                        delete my_histo;
	          }
		}

                if(tree->GetEntries() > 0) tree->Write();

	        outFile->ls();
	        outFile->Close();

	        delete outFile;
		////string command = "rm -f dummy.root";
                ////system(command.c_str());

	}else{
	        string fileName = string(outFile->GetName());
                delete outFile;
                string command = "rm -f " + fileName;
                system(command.c_str());
	}
}

void MyHistogram::disableHistogramming(){
	disabled = true;
}

void MyHistogram::list(){
	map<string,TH1F*>::const_iterator iHisto;
	for(iHisto = myHistograms.begin();
            iHisto != myHistograms.end(); iHisto++){
        	string name = iHisto->first;
		cout << "    " << name << endl;
        }

        map<string,TH2F*>::const_iterator iHisto2D;
        for(iHisto2D = myHistograms2D.begin();
            iHisto2D != myHistograms2D.end(); iHisto2D++){
		string name = iHisto->first;
                cout << "    " << name << endl;
	}
}

void MyHistogram::checkExistence(string name){
        if(!booked(name)) {
		cout << endl;
                cout << "**** Unknown histogram " << name << ", exiting..." << endl;
		cout << endl;
                exit(0);
        }
}

void MyHistogram::setTreeTitle(string title) {
	tree->SetTitle(title.c_str());
}

void MyHistogram::setTreeVariable(string name,double value) {
	if(!tree->GetBranchStatus(name.c_str())) {
		treeVariableNameIndex[name] = treeVariableNameIndex.size() - 1;
		string type = name + "/F";
		tree->Branch(name.c_str(),&treeVariables[treeVariableNameIndex[name]],type.c_str());
	}
	treeVariables[treeVariableNameIndex[name]] = float(value);
}

void MyHistogram::fillTree() {
	tree->Fill();
}

