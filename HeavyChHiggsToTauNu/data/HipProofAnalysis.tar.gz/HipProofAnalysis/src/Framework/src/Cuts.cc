#include<algorithm>
#include<vector>
#include<iomanip>
#include<string>

#include "Framework/interface/Cuts.h"
#include "Framework/interface/Cut.h"

using namespace std;

void Cuts::print(void) {
        string prefix("   ");

        cout << endl << " Following cuts were booked and applied:" << endl;
        vector<string> notApplied;
        vector<string> disabled;
        for(map<string, Cut>::const_iterator iter = cuts.begin(); iter != cuts.end(); ++iter) {
                if(!iter->second.isApplied()) {
                        notApplied.push_back(iter->first);
                        continue;
                }
                else if(!iter->second.isEnabled()) {
                        disabled.push_back(iter->first);
                        continue;
                }
                cout << prefix;
                iter->second.print(cout, iter->first);
                cout << endl;
        }

        if(notApplied.size() > 0) {
                cout << endl << " Following cuts were booked, but not applied" << endl;
                for(vector<string>::const_iterator iter = notApplied.begin(); iter != notApplied.end(); ++iter) {
                        cout << prefix << *iter << endl;
                }
        }

        if(disabled.size() > 0) {
                cout << endl << " Following cuts were disabled" << endl;
                for(vector<string>::const_iterator iter = disabled.begin(); iter != disabled.end(); ++iter) {
                        cout << prefix << *iter << endl;
                }
        }

        if(!unusedCuts.empty()) {
                cout << endl 
                     << " !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
                     << " !! Warning: following cuts were specified in the input file, but were not booked in the code:" << endl;
                for(map<string, Cut>::const_iterator iter = unusedCuts.begin(); iter != unusedCuts.end(); ++iter) {
                        cout << " !!   " << iter->first << endl;
                }
                cout << " !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
        }
}

void Cuts::bookCut(string& name, Cut::CutType type, double low, double high, bool ena) {
        if(cuts.find(name) == cuts.end()) {
                bool enabled = ena;
                if(type == Cut::kLt || type == Cut::kGt) {
                        map<string, Cut>::iterator cut = unusedCuts.find(name);
                        if(cut != unusedCuts.end()) {
                                enabled = cut->second.isEnabled();
                                low = cut->second.getValue();
                                unusedCuts.erase(cut);
                        }
                        cuts.insert(make_pair(name, Cut(type, low, enabled)));
                }
                else if(type == Cut::kIn || type == Cut::kOut) {
                        bool enabledHigh = ena;
                        map<string, Cut>::iterator cut = unusedCuts.find(name+"High");
                        if(cut != unusedCuts.end()) {
                                enabledHigh = cut->second.isEnabled();
                                high = cut->second.getValue();
                                unusedCuts.erase(cut);
                        }

                        bool enabledLow = ena;
                        cut = unusedCuts.find(name+"Low");
                        if(cut != unusedCuts.end()) {
                                enabledLow = cut->second.isEnabled();
                                low = cut->second.getValue();
                                unusedCuts.erase(cut);
                        }

                        if(enabledHigh || enabledLow)
                                enabled = true;

                        /**
                         * Transform the type of the cut, if only one
                         * side is disabled. Don't know whether this
                         * is a good idea or not, but let's see.
                         */
                        if(enabledHigh && !enabledLow) {
                                if(type == Cut::kIn) type = Cut::kLt;
                                else if(type == Cut::kOut) type = Cut::kGt;
                        }
                        else if(!enabledHigh && enabledLow) {
                                if(type == Cut::kIn) type = Cut::kGt;
                                else if(type == Cut::kOut) type = Cut::kLt;
                        }
                        else if(!enabledHigh && !enabledLow)
                                enabled = false;
                        cuts.insert(make_pair(name, Cut(type, low, high, enabled)));
                }
        }
}

void Cuts::bookCut(string& name, Cut::CutType type, double low, double high) {
        bookCut(name, type, low, high, true);
}

void Cuts::bookLessThanCut(string name, double defaultCut) {
        bookCut(name, Cut::kLt, defaultCut, 0);
}

void Cuts::bookGreaterThanCut(string name, double defaultCut) {
        bookCut(name, Cut::kGt, defaultCut, 0);
}
 
void Cuts::bookInsideCut(string name, double defaultLow, double defaultHigh) {
        bookCut(name, Cut::kIn, defaultLow, defaultHigh);
}

void Cuts::bookOutsideCut(string name, double defaultLow, double defaultHigh) {
        bookCut(name, Cut::kOut, defaultLow, defaultHigh);
}

void Cuts::bookLessThanCut(string name, double defaultCut, bool enabled) {
        bookCut(name, Cut::kLt, defaultCut, 0, enabled);
}

void Cuts::bookGreaterThanCut(string name, double defaultCut, bool enabled) {
        bookCut(name, Cut::kGt, defaultCut, 0, enabled);
}
 
void Cuts::bookInsideCut(string name, double defaultLow, double defaultHigh, bool enabled) {
        bookCut(name, Cut::kIn, defaultLow, defaultHigh, enabled);
}

void Cuts::bookOutsideCut(string name, double defaultLow, double defaultHigh, bool enabled) {
        bookCut(name, Cut::kOut, defaultLow, defaultHigh, enabled);
}


bool Cuts::applyCut(string name, double value) {
        map<string, Cut>::iterator cut = cuts.find(name);
        if(cut == cuts.end()) {
                cout << "ERROR: tried to apply cut " << name << " which is not booked yet!" << endl;
                exit(0);
        }
        return cut->second.apply(value);
}

void Cuts::setCutValue(string name, Cut cut) {
        // Check if the cut is already booked
        map<string, Cut>::iterator iter = cuts.find(name);
        if(iter != cuts.end()) {
                if(iter->second.getType() == Cut::kLt || iter->second.getType() == Cut::kGt) 
                        iter->second.setValue(cut.getValue());
                else
                        iter->second.setValues(cut.getValues());
                if(cut.isEnabled()) iter->second.enable();
                else                iter->second.disable();

                return;
        }

        string::size_type pos = name.find("High");
        if(pos != string::npos) {
                string n = name.substr(0, pos);
                iter = cuts.find(n);
                if(iter != cuts.end()) {
                        if(!cut.isEnabled()) {
                                if(iter->second.getType() == Cut::kIn) iter->second.setType(Cut::kGt);
                                else if(iter->second.getType() == Cut::kOut) iter->second.setType(Cut::kLt);
                                else iter->second.disable();
                                return;
                        }

                        if(iter->second.getType() == Cut::kLt || iter->second.getType() == Cut::kGt) {
                                cout << "Cut " << n << " is booked as single parameter cut, " 
                                     << name << " was set in input file!" << endl;
                                exit(0);
                        }
                        pair<double, double> val = iter->second.getValues();
                        val.second = cut.getValue();
                        iter->second.setValues(val);
                        return;
                }
        }

        pos = name.find("Low");
        if(pos != string::npos) {
                string n = name.substr(0, pos);
                iter = cuts.find(n);
                if(iter != cuts.end()) {
                        if(!cut.isEnabled()) {
                                if(iter->second.getType() == Cut::kIn) iter->second.setType(Cut::kLt);
                                else if(iter->second.getType() == Cut::kOut) iter->second.setType(Cut::kGt);
                                else iter->second.disable();
                                return;
                        }

                        if(iter->second.getType() == Cut::kLt || iter->second.getType() == Cut::kGt) {
                                cout << "Cut " << n << " is booked as single parameter cut, " 
                                     << name << " was set in input file!" << endl;
                                exit(0);
                        }
                        pair<double, double> val = iter->second.getValues();
                        val.first = cut.getValue();
                        iter->second.setValues(val);

                        return;
                }
        }

        // Cut was not booked yet, add/modify unused cuts
        iter = unusedCuts.find(name);
        if(iter == unusedCuts.end())
                unusedCuts.insert(make_pair(name, cut));
        else {
                if(iter->second.getType() == Cut::kLt || iter->second.getType() == Cut::kGt)
                        iter->second.setValue(cut.getValue());
                else
                        iter->second.setValues(cut.getValues());
                if(cut.isEnabled()) iter->second.enable();
                else                iter->second.disable();
        }
}

void Cuts::setCutValue(string name, double value) {
        setCutValue(name, Cut(Cut::kUnkown, value, 0, true));
}

void Cuts::setCutValue(string name, pair<double, double> value) {
        setCutValue(name, Cut(Cut::kUnkown, value.first, value.second, true));
}


void Cuts::setCutValues(map<string, double> cutValues) {
        for(map<string, double>::const_iterator iter = cutValues.begin(); iter != cutValues.end(); ++iter) {
                //cout << iter->first << endl;
                setCutValue(iter->first, iter->second);
        }
}

void Cuts::setCutValues(map<string, Cut> cutValues) {
        for(map<string, Cut>::const_iterator iter = cutValues.begin(); iter != cutValues.end(); ++iter) {
                setCutValue(iter->first, iter->second);
        }
}

double Cuts::getCutValue(string name) {
        map<string, Cut>::iterator cut = cuts.find(name);
        if(cut == cuts.end()) {
                cout << "ERROR: tried to query value of cut " << name << " which is not booked yet!" << endl;
                exit(0);
        }
        return cut->second.getValue();
}

void Cuts::getCutValues(string name, double *l, double *h) {
        map<string, Cut>::iterator cut = cuts.find(name);
        if(cut == cuts.end()) {
                cout << "ERROR: tried to query value of cut " << name << " which is not booked yet!" << endl;
                exit(0);
        }
	cut->second.getValues(l, h);
}

pair<double, double> Cuts::getCutValues(string name) {
        map<string, Cut>::iterator cut = cuts.find(name);
        if(cut == cuts.end()) {
                cout << "ERROR: tried to query value of cut " << name << " which is not booked yet!" << endl;
                exit(0);
        }
        return cut->second.getValues();
}
