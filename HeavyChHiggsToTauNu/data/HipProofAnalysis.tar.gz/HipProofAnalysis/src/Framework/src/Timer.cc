#include "Framework/interface/Timer.h"

Timer::Timer(){
        theTimer = new TStopwatch;
        theTimer->Start();
}
Timer::~Timer(){
        theTimer->Stop();
        theTimer->Print("-u");
}
