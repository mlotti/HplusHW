#include "Framework/interface/BaseAnalysis.h"

#include "TXNetFile.h"

ClassImp(BaseAnalysis)  // Implementation of BaseAnalysis. Note: NO ";" at the end of line!

BaseAnalysis::BaseAnalysis(){}

BaseAnalysis::BaseAnalysis(MyInput input){
	init(input);
}
BaseAnalysis::~BaseAnalysis(){
	delete eventFilter;
        delete cuts;
}

void BaseAnalysis::Init(TTree* tree){
        if(tree == 0) return;

        fChain = tree;

        event = new MyEvent;
        b_event = fChain->GetBranch("MyEvent");
        fChain->SetBranchAddress("MyEvent",&event,&(b_event) );
}

void BaseAnalysis::Begin(TTree* tree){
        vector<Dataset>::const_iterator iDataset;
        for(iDataset = datasets.begin();
            iDataset!= datasets.end(); iDataset++){
                eventCounter->setDataset(*iDataset);
//                if(histograms != NULL){
//                        histograms->setDatasetName(iDataset->getName());
//                }
	}
}

void BaseAnalysis::SlaveBegin(TTree* tree){
	Init(tree);
}

Bool_t BaseAnalysis::Notify(){
        TFile* file = fChain->GetCurrentFile();
	string name = string(file->GetName());
	if(name != oldFileName) {
	        TH1F* eventInfo = (TH1F*)file->Get("eventInfo");

                eventCounter->setDataset(name);
		if(histograms != NULL) histograms->setDatasetName(eventCounter->getName());
		setNormalisation(eventInfo);
	        eventFilter->saveEventInfo(eventInfo);

		int nev = fChain->GetTree()->GetEntries();
	        cout << "File " << file->GetName()
	             << ", entries " << nev << endl;

		delete eventInfo;
	}
	oldFileName = name;
        return kTRUE;
}

Bool_t BaseAnalysis::ProcessCut(Long64_t entry){
        return kTRUE;
}

void   BaseAnalysis::ProcessFill(Long64_t entry){
        fChain->GetTree()->GetEntry(entry);
        beginEvent(event);
        analyse(event);
        endEvent(event);
}

void BaseAnalysis::Terminate(){
        print();
        plotHistograms();
}

void BaseAnalysis::beginEvent(MyEvent *event) {
}

void BaseAnalysis::endEvent(MyEvent *event) {
}

void BaseAnalysis::init(MyInput input){

    	////////////////////////////////////////////////////////////////////////
    	// Datasets
    	////////////////////////////////////////////////////////////////////////

	datasets = input.getDatasets();

	if(datasets.size() == 0){
       		cout << endl << "No data files found! Exiting... " << endl << endl;
       		exit(0);
    	}

	timer = new Timer;

    ////////////////////////////////////////////////////////////////////////
    // Defining default cuts
    ////////////////////////////////////////////////////////////////////////

        cuts = new Cuts();
        setAnalysisBaseCuts();
        setDefaultCuts();
        cuts->setCutValues(input.getCuts());
        //checkAndSetCuts(input.getCuts());
        //printCuts();

    	////////////////////////////////////////////////////////////////////////
    	// Booking histograms and resetting counters
    	////////////////////////////////////////////////////////////////////////

        eventCounter = new Counter();
        eventCounter->setLuminosity(cuts->getCutValue("luminosity"));

	eventFilter = new MyEventFilter(input);

	randomGenerator = new TRandom3();

        histograms = NULL;
        bookHistograms();
	if(!cuts->getCutValue("normalizeHistograms")) histograms->dontNormalize();

        signif = 0;
	scanVariable = 0;
	oldFileName = "";
}

double  BaseAnalysis::getSignificance(){
	signif = eventCounter->getSignificance();
	return signif;
}

void BaseAnalysis::setAnalysisBaseCuts(){
        cuts->bookLessThanCut("luminosity", 30000);
        cuts->bookLessThanCut("filter", 0);
        cuts->bookLessThanCut("compactInfoHisto", 1);
        cuts->bookLessThanCut("visualize", 0);
	cuts->bookLessThanCut("normalizeHistograms",1);
}

void BaseAnalysis::setCuts(map<string,double> theCuts){
        // Adding or overwriting cuts with theCuts
        cuts->setCutValues(theCuts);
}

void BaseAnalysis::setCuts(map<string, Cut> theCuts) {
        cuts->setCutValues(theCuts);
}

void BaseAnalysis::setCut(string name,double value){
        cuts->setCutValue(name, value);
}

void BaseAnalysis::setNormalisation(TH1F* normalisation){
	for(int i = 5; i <= normalisation->GetXaxis()->GetNbins(); i++){
	      string name = string(normalisation->GetXaxis()->GetBinLabel(i));
	      if(name.size() == 0) name = string(Form("%s%d","bin", i));

              // temporary fix for different sized TH1F's
              if(cuts->getCutValue("compactInfoHisto") && name.find(":") < name.length()) continue;

	      double value = double(normalisation->GetBinContent(i));
	      eventCounter->addCount(name,value);
	}
}

void BaseAnalysis::scannerFill(string name,double value){
	scanVariable = value;

	char* ENV_HIPGRIDANALYSIS = getenv("HIPGRIDANALYSIS");
  	if(ENV_HIPGRIDANALYSIS != NULL){
		ofstream outFile("hipProofAnalysis.txt",ios::out);
		outFile << "scanOptimizationVariableName  = " << name << endl;
		outFile << "scanOptimizationVariableValue = " << value << endl;
		outFile.close();
	}
}

double BaseAnalysis::getScanVariable(){
	eventCounter->reset();
    	return scanVariable;
}

void BaseAnalysis::disableHistogramming(){
	histograms->disableHistogramming();
}

TFile* BaseAnalysis::open(string fileName,bool URL,int retryCount){

	int count = 0;

	TFile* file;
	do {
        	if(URL){
                	file = new TXNetFile(fileName.c_str());
        	}else{
			file = new TFile(fileName.c_str());
        	}
		count++;
		if(count > 1) cout << "Retrying " << endl;
	} while(!file->IsOpen() && count < retryCount);
	return file;
}

// LAW 19.02. BEGIN
bool BaseAnalysis::visualStatus() {
  //return (cut["visualize"] == 1);
  return (cuts->getCutValue("visualize") == 1);
}

vector<string> BaseAnalysis::getFileList() {
  vector<string> myList;
  // Counts the total event number in input files
  vector<Dataset>::const_iterator iDataset;
  for(iDataset = datasets.begin();
      iDataset!= datasets.end(); ++iDataset){
    vector<string> files = iDataset->getFiles();
    vector<string>::const_iterator iFile;
    vector<string>::const_iterator iFileEnd = files.end();
    for (iFile = files.begin(); iFile != files.end(); ++iFile) {
      myList.push_back(*iFile);
    }
  }
  return myList;
}
