#include<iostream>
#include<iomanip>

#include "Framework/interface/Cut.h"

using namespace std;

Cut::Cut(void): type(kUnkown), low(0), high(0), enabled(false), applied(false) {}
Cut::Cut(CutType t, double l, double h, bool e): type(t), low(l), high(h), enabled(e), applied(false) {}
Cut::Cut(CutType t, double value, bool e): type(t), low(0), high(0), enabled(e), applied(false) {
        if(type == kLt) high = value;
        else            low = value;
}


void Cut::setValue(double val) {
        switch(type) {
        case kLt:
                high = val;
                break;
        case kGt:
        case kUnkown:
                low = val;
                break;
        default:
                cout << "Trying to set a value of double parameter cut! (1 parameter)" << endl;
                exit(0);
        }
}

void Cut::setValues(double l, double h) {
        switch(type) {
        case kIn:
        case kOut:
        case kUnkown:
                low = l;
                high = h;
                break;
        default:
                cout << "Trying to set values of single parameter cut! (2 parameters)" << endl;
                exit(0);
        }
}

void Cut::setValues(const pair<double, double>& values) {
        setValues(values.first, values.second);
}

void Cut::enable(void) {
        enabled = true;
}

void Cut::disable(void) {
        enabled = false;
}

double Cut::getValue(void) {
        applied = true;
        switch(type) {
        case kLt:
                return high;
        case kGt:
        case kUnkown:
                return low;
        default:
                cout << "Trying to get a value of double parameter cut! (1 parameter)" << endl;
                exit(0);
        }
}

pair<double, double> Cut::getValues(void) {
        applied = true;
        switch(type) {
        case kIn:
        case kOut:
        case kUnkown:
                return make_pair(low, high);
        default:
                cout << "Trying to get values of single parameter cut! (2 parameters)" << endl;
                exit(0);
        }
}

void Cut::getValues(double* l, double* h) {
	applied = true;
	switch(type) {
	case kIn:
	case kOut:
	case kUnkown:
	  *l = low;
          *h = high;
	  return;
        default:
                cout << "Trying to get values of single parameter cut! (2 parameters)" << endl;
                exit(0);
	}
}


void Cut::setType(CutType t) {
        type = t;
}

Cut::CutType Cut::getType(void) const {
        return type;
}

bool Cut::isEnabled(void) const {
        return enabled;
}

bool Cut::isApplied(void) const {
        return applied;
}

bool Cut::apply(double value) {
        applied = true;
        if(!enabled) return true;

        switch(type) {
        case kLt:
                return value < high;
        case kGt:
                return low < value;
        case kIn:
                return low < value && value < high;
        case kOut:
                return value < low || high < value;
        case kUnkown:
                cout << "Unkown type when applying (basically this means some kind of internal error)" << endl;
                return false;
        }

        return false;
}

ostream& Cut::print(ostream& s, string name) const {
        const int lowCol = 8;
        const int cutCol = 20;
        const int highCol = 8;

        switch(type) {
        case kLt:
                s << setw(lowCol+3) << " "
                  << setw(cutCol) << left << name << " < " 
                  << setw(highCol) << right << high;
                break;
        case kGt:
                s << setw(lowCol) << right << low << " < " 
                  << setw(cutCol) << left << name;
                break;
        case kIn:
                s << setw(lowCol) << right << low << " < " 
                  << setw(cutCol) << left << name << " < " 
                  << setw(highCol) << right << high;
                break;
        case kOut:
                s << setw(lowCol+3) << " "
                  << setw(cutCol) << left << name << " < " 
                  << setw(lowCol) << right << low << " or " 
                  << setw(highCol) << right << high << " <  " 
                  << setw(cutCol) << left << name;
                break;
        case kUnkown:
                s << name << ": unkown type (basically this means some kind of internal error";
                break;
        }

        return s;
}
