#include "Framework/interface/Counter.h"

#include <map>

Counter::Counter(){
    reset();
}

Counter::~Counter(){}

void Counter::reset(){
	channelSorting.clear();
	signalIbgs.clear();
	names.clear();
	subCounterNames.clear();
	IBGs.clear();

	
    for(int i = 0; i < maxIBG; i++){
//      crossSections[i]       = 0;
//      preSeleEfficiencies[i] = 0;
      	for(int j = 0; j < maxCut; j++) {
		counter[i][j]    = 0;
		subcounter[i][j] = 0;
	}
    }
    setLuminosity(30000);
}

void Counter::setLuminosity(double lumi){
    luminosity = lumi;
}

void Counter::setCrossSection(int ibg,double crossSection,double cnor,double events){
/*
    ibgCounter = 0;
    vector<Dataset>::const_iterator iIbg = IBGs.begin();
    while(iIbg != IBGs.end() && iIbg->getLabel() != ibg){
      ibgCounter++;
      iIbg++;
    }
    if( ibgCounter == int(IBGs.size()) ) IBGs.push_back(ibg);

    crossSections[ibgCounter]       = crossSection;
    preSeleEfficiencies[ibgCounter] = cnor;
    // in case more than one sample per IBG, presele == P (notation)
    // P(tot) = Sum(P(i)*N(i))/Sum(N(i))  <- weighted average
    // in getNormalization Sum(cnor*events) is divided by counter[ibg][0]
    // counter[ibg][0] is tot N events
//    preSeleEfficiencies[ibgCounter] += cnor*events; // disabled for CMSSW 5.7.2007/SL
*/
}

void Counter::setSignal(int ibg){
    signalIbgs.push_back(ibg);
}

double Counter::getSignificance(){

    double signalEvents = 0,
           backgrEvents = 0;

    int lastCut = int(names.size()-1);
    for(vector<Dataset>::const_iterator IBG_iter = IBGs.begin();
                                        IBG_iter!= IBGs.end(); IBG_iter++){
      int ibg_counter = getIbgCounter(IBG_iter->getLabel());
      double events = normalization(ibg_counter)*counter[ibg_counter][lastCut];

      if(IBG_iter->isSignal()){
        signalEvents += events;
      }else{
        backgrEvents += events;
      }
    }
    return significance(signalEvents,backgrEvents);
}

double Counter::getSignalOverBackgr(){
/*
    double signalEvents = 0,
           backgrEvents = 0;

    int lastCut = int(names.size()-1);
    for(vector<int>::const_iterator IBG_iter = IBGs.begin();
                                    IBG_iter!= IBGs.end(); IBG_iter++){
      int ibg_counter = getIbgCounter(*IBG_iter);
      double events = normalization(ibg_counter)*counter[ibg_counter][lastCut];
      bool signalChannel = false;
      for(vector<int>::const_iterator i = signalIbgs.begin();
                                      i!= signalIbgs.end(); i++){
        if(*IBG_iter == *i) signalChannel = true;
      }
      if(signalChannel){
        signalEvents += events;
      }else{
        backgrEvents += events;
      }
    }

    if(backgrEvents == 0) return 0;
    return signalEvents/backgrEvents;
*/
return 0;
}

void Counter::addCount(string name,int factor){

    int cutCounter = 0;
    vector<string>::const_iterator iCut = names.begin();
    while(iCut != names.end() && *iCut != name){
      cutCounter++;
      iCut++;
    }

    if( iCut == names.end() ) {
//      if( ibgCounter == 0 ) {
        names.push_back(name);
//      }else{ 
//        cout << " Warning, unknown cut \"" << name << "\", please check your rootFile! " << endl;
//        cout << " Used cuts: " << endl;
//        for( iCut = names.begin(); iCut != names.end(); iCut++) cout << "     " << *iCut << endl;
//      }
    }

    if(ibgCounter >= maxIBG ) cout << "Counter: max ibg reached! " << ibgCounter << endl;
    if(cutCounter >= maxCut ) cout << "Counter: max #of cuts reached! " << cutCounter << endl;

    counter[ibgCounter][cutCounter] += factor;
}

void Counter::addCount(string name,double factor){
    addCount(name,int(factor));
}

void Counter::addSubCount(string name,int factor){

    int cutCounter = 0;
    vector<string>::const_iterator iCut = subCounterNames.begin();
    while(iCut != subCounterNames.end() && *iCut != name){
      cutCounter++;
      iCut++;
    }

    if( iCut == subCounterNames.end() ) {
        subCounterNames.push_back(name);
    }

    if(ibgCounter >= maxIBG ) cout << "Counter: max ibg reached! " << ibgCounter << endl;
    if(cutCounter >= maxCut ) cout << "Counter: max #of cuts reached! " << cutCounter << endl;

    subcounter[ibgCounter][cutCounter] += factor;
}


void Counter::addSubCount(string name,double factor){
    addSubCount(name,int(factor));
}


double Counter::normalization(int pos){

	double sigma = IBGs[pos].getCrossSection() * IBGs[pos].getPreselectionEfficiency();
        double cnor = sigma*luminosity/counter[pos][0];
	return cnor;
}

double Counter::getNormalization(int pos){
	return normalization(pos);
}

double Counter::getNAllEvents(int pos){
	return 1.*counter[pos][0];
}

int Counter::getNevents(int pos,int icut){
        return counter[pos][icut];
}


int Counter::getIbgCounter(int ibg){
    int counter = 0;
    vector<Dataset>::const_iterator i = IBGs.begin();
    while(i!= IBGs.end() && i->getLabel() != ibg){
      i++;
      counter++;
    }
    return counter;
}
/*
double Counter::getPreSeleEfficiency(int ibgCounter){
    return preSeleEfficiencies[ibgCounter];
}
*/
void Print(double number,int precision,int width = 0){
    if(width == 0) width = precision+2;
    cout.setf(ios::showpoint);
    cout << setw(width) << setprecision(precision) << number;
    cout.unsetf(ios::showpoint);
}

void PrintNDecimals(double number,int precision,int width = 0){
    if(width == 0) width = precision+2;
    cout.setf(ios::showpoint);
    cout.setf(ios::fixed,ios::floatfield);
    cout << setw(width) << setprecision(precision) << number;
    cout.unsetf(ios::showpoint);
    cout.unsetf(ios::fixed);
}

void Counter::print(){
    for(vector<Dataset>::const_iterator IBG_iter = IBGs.begin();
                                        IBG_iter!= IBGs.end(); IBG_iter++){

        int iIBG = getIbgCounter(IBG_iter->getLabel());
//        double sigma = crossSections[iIBG]*getPreSeleEfficiency(iIBG);
	double sigma = IBG_iter->getCrossSection()*IBG_iter->getPreselectionEfficiency();

	if(counter[iIBG][0] > 0){

          addInFinalReport(*IBG_iter);

          cout << endl;
          cout << " Acceptances,    label = " << IBG_iter->getLabel() 
	       << ",   name = " << IBG_iter->getName() << endl;
          cout << " cross section (pb) = " << IBG_iter->getCrossSection() << endl;
          cout << " pre-selection (pb) = " << sigma 
               << " (eff = " << IBG_iter->getPreselectionEfficiency() << ")" << endl;
	  cout << " luminosity  (pb-1) = " << luminosity << endl;

//          double cnor = sigma*luminosity/counter[iIBG][0];//normalization(iIBG);
	  double cnor = normalization(iIBG);

          cout << " normalization      = " << cnor << endl;
          cout << "                              " 
               << " MC-events    " << endl;
//               << " for " << luminosity << "pb-1           "
//               << " pb " << endl;

          int iCut = 0;
//          int precision = 0;
          sigma = sigma/counter[iIBG][0];
          for(vector<string>::const_iterator cutName = names.begin();
                                             cutName!= names.end(); cutName++){
            string theName = "   " + *cutName;
            int N = counter[iIBG][iCut];
            while(theName.length() < 38) theName+=' ';
            cout << " " << theName << " " << setw(10) << setprecision(6) << N;

            double norm_counter = N*cnor;
/*
            double error = norm_counter/sqrt(double(N));


            cout << " " << setw(10) << norm_counter;
            cout << "+-"; 
            if(precision == 0) precision = int(log10(error))+1;
            Print(error,precision);

            double cross_section = sigma*N;
            cout << " " << setw(10) << setprecision(6) << cross_section;

            double sigma_error = cross_section/sqrt(double(N));
            cout << "+-";
            Print(sigma_error,3);
*/
            cout << endl;

            // sorting
            vector<Sorting> tmpContainer;
            for(vector<Sorting>::const_iterator s = channelSorting.begin();
                                                s!= channelSorting.end(); s++){
              Sorting sorted = *s;
              if(IBG_iter->getLabel() >= s->start && IBG_iter->getLabel() <= s->stop){
                sorted.add(norm_counter,N,iCut);
              }
              tmpContainer.push_back(sorted);
            }
            channelSorting = tmpContainer;

            iCut++;
          }

	  printSubCounters(iIBG);
        }
        iIBG++;
    }
    printSummary();
    printSummary(luminosity);
}

void Counter::printSubCounters(int iIBG){

	if(subCounterNames.size() == 0) return;

        int iSubCut = 0;
        cout << endl << "  Subcounters " << endl;
        map<string,vector<int> > sortedSubCounters;
        for(vector<string>::const_iterator cutName = subCounterNames.begin();
                                           cutName!= subCounterNames.end(); cutName++){
                string sortName = *cutName;
                while(sortName[0] == ' ') sortName = sortName.substr(1,sortName.length() - 1);
                sortName = sortName.substr(0,sortName.find(' '));

                vector<int> cutNumbers = sortedSubCounters[sortName];
                cutNumbers.push_back(iSubCut);
                sortedSubCounters[sortName] = cutNumbers;

                iSubCut++;
        }

	for(map<string,vector<int> >::const_iterator iLabel = sortedSubCounters.begin();
                                                     iLabel!= sortedSubCounters.end(); ++iLabel){
		vector<int> cutNumbers = iLabel->second;
		for(vector<int>::const_iterator i = cutNumbers.begin();
                                                i!= cutNumbers.end(); ++i){
			int iSubCut = *i;
			string theName = "   " + subCounterNames[iSubCut];
			int N = subcounter[iIBG][iSubCut];
	                while(theName.length() < 38) theName+=' ';
        	        cout << " " << theName << " " << setw(10) << setprecision(6) << N << endl;
		}
		cout << endl;
	}
        cout << endl;
}

void Counter::printSummary(double luminosity){

    if(channelSorting.size() == 0) return;

    cout << endl;
    cout << " Acceptances, summary        ";
    for(vector<Sorting>::const_iterator s = channelSorting.begin();
                                        s!= channelSorting.end(); s++){
      string              theName = s->name + "     (eff)";
      if(luminosity != 1) theName = s->name + "[pb] (eff)";
      while(theName.length() < 18) theName = ' ' + theName;
      while(theName.length() < 37) theName += ' ';
      if(s->getCounter(0) > 0 ) cout << theName;
    }
    cout << endl;

    int iCut = 0;
    int precision1 = 0;
    int precision2 = 0;
    for(vector<string>::const_iterator cutName = names.begin();
                                       cutName!= names.end(); cutName++){
      string theName = *cutName;
      while(theName.length() < 25) theName+=' ';
      cout << "    " << theName << " ";// << setw(15);

      for(vector<Sorting>::const_iterator s = channelSorting.begin();
                                          s!= channelSorting.end(); s++){
        if(s->getCounter(0) > 0 ){
          cout << setw(10) << setprecision(5) << s->getCounter(iCut)/luminosity;
          cout << "+-";
          double error = s->getError(iCut)/luminosity;
          if(precision1 == 0) precision1 = 3+int(log10(error));
          Print(error,precision1);

          //cut efficiency
          double eff = 0;
          if(iCut > 0 ) eff = s->getCounter(iCut)/s->getCounter(iCut-1);
          
          if(precision2 == 0) precision2 = 3;
          if(eff > 0){
            cout << "(";
            Print(eff,precision2);
            cout << "+-";
            PrintNDecimals(s->getEfficError(iCut),5);
            cout << ") ";
          }else{
            for(int i = 0; i < precision2 + 14; i++) cout << " ";
	  }
        }
      }
      cout << endl;
      iCut++;
    }
    cout << endl;

}

void Counter::combineChannels(string name, int start, int stop){

    if(stop == 0) stop = start;

    Sorting sorting;
    sorting.name  = name;
    sorting.start = start;
    sorting.stop  = stop;

    channelSorting.push_back(sorting);
}

void Counter::addInFinalReport(const Dataset& dataset){
	bool ibgFound = false;
        for(vector<Sorting>::const_iterator s = channelSorting.begin();
                                            s!= channelSorting.end(); s++){
		if(dataset.getLabel() >= s->start && 
                   dataset.getLabel() <= s->stop) ibgFound = true;
	}
	if(!ibgFound) combineChannels(dataset.getName(),dataset.getLabel());
}


vector<Dataset> Counter::getChannels(){
    return IBGs;
}

Dataset Counter::getChannel(int pos){
	return IBGs[pos];
}

void Counter::setDataset(const Dataset& dataset){
	ibgCounter = 0;
	vector<Dataset>::const_iterator iIbg = IBGs.begin();
	while(iIbg != IBGs.end() && iIbg->getLabel() != dataset.getLabel()){
		ibgCounter++;
	        iIbg++;
    	}
	if( ibgCounter == int(IBGs.size()) ) IBGs.push_back(dataset);
}

void Counter::setDataset(string fileName){
        ibgCounter = 0;
        vector<Dataset>::const_iterator iIbg = IBGs.begin();
        bool thisDataset = false;
        while(iIbg != IBGs.end() && !thisDataset ){
                vector<string> files = iIbg->getFiles();
                vector<string>::const_iterator i = files.begin();
                while(i != files.end() && !thisDataset ){
                        if(fileName == *i) thisDataset = true;
                        i++;
                }
                if(!thisDataset) ibgCounter++;
                iIbg++;
        }
}

void Counter::setName(string name){}
void Counter::setLabel(int label){}
void Counter::setCrossSection(double value){}
void Counter::setPreselectionEfficiency(double value){}
void Counter::setSignal(bool value){}

int Counter::getNChannels(){
	return IBGs.size();
}

string Counter::getName(int pos){
	return IBGs[pos].getName();
}

string Counter::getName(){
	return getName(ibgCounter);
}

vector<string> Counter::getCutNames(){
	return names;
}

int Counter::getLabel(int pos){
        return IBGs[pos].getLabel();
}

int Counter::getLabel(){
	return getLabel(IBGs.size()-1);
}

double Counter::getLuminosity(){
	return luminosity;
}

double Counter::getNormalizedNumberOfEventsPassingCuts(){
	double events = 0;

	int lastCut = int(names.size()-1);
	for(vector<Dataset>::const_iterator IBG_iter = IBGs.begin();
	                                    IBG_iter!= IBGs.end(); IBG_iter++){
		int ibg_counter = getIbgCounter(IBG_iter->getLabel());
		events += normalization(ibg_counter)*counter[ibg_counter][lastCut];
	}
	return events;
}


