#include "Framework/interface/CutScanner.h"

CutScanner::CutScanner(MyInput& input, TChain *aChain, MyAnalysis *anAnalysis){
        chain = aChain;
	analysis = anAnalysis;
	iPoint = 0;
	setDefaultCuts();

	theCut = input.getScanVariableName();
	cout << " Scanning variable " << theCut << endl;

	setCuts(input.getCuts());
	analysis->setCuts(cuts);
	analysis->disableHistogramming();

	setBegin(cuts["scanRangeBegin"].getValue());
    	setEnd(cuts["scanRangeEnd"].getValue());
    	setSteps(cuts["scanNSteps"].getValue());
}
CutScanner::~CutScanner(){
	plot();
}

void CutScanner::setDefaultCuts(){
        cuts.insert(make_pair("scanRangeBegin", Cut(Cut::kUnkown,  0, true)));
        cuts.insert(make_pair("scanRangeEnd",   Cut(Cut::kUnkown,  1, true)));
        cuts.insert(make_pair("scanNSteps",     Cut(Cut::kUnkown, 10, true)));
        cuts.insert(make_pair("scanDraw",       Cut(Cut::kUnkown,  1, true)));
}


void CutScanner::scan(){
      cout << " scanning in steps " << endl;
      for(int i = 0; i < steps; i++){
        	double value = begin;
		if(steps > 1) value += i*(end-begin)/(steps-1);

        	cout << "   new cut: " << theCut << " = " << value << endl;
		analysis->setCut(theCut,value);

		chain->Process(analysis);

        	analysis->getSignificance();
        	analysis->print();

        	double result = analysis->getScanVariable();

        	setValues(value,result);
        	cout << "   cut " << theCut << " = " << value 
                     << ", result = " << result << endl;
      }
}

void CutScanner::setBegin(double value){
    	begin = value;
}
void CutScanner::setEnd(double value){
    	end = value;
}
void CutScanner::setSteps(double value){
    	steps = int(value);
}
void CutScanner::setValues(double x, double y){
    	graphX[iPoint] = x;
    	graphY[iPoint] = y;
    	iPoint++;
}

void CutScanner::setCuts(map<string, Cut> theCuts) {
        for(map<string, Cut>::const_iterator iMap = theCuts.begin();
                                             iMap!= theCuts.end(); ++iMap) {
                string cutName = iMap->first;
                Cut cutValue   = iMap->second;
                cuts[cutName] = cutValue;
        }
}

#include "TCanvas.h"
#include "TGraph.h"

void CutScanner::plot(){
	if(cuts["scannerDraw"].getValue() != 0) {
      		double xmin = graphX[0],
        	       xmax = graphX[0],
             	       ymin = graphY[0],
             	       ymax = graphY[0];
      		if(iPoint > NPoints) {
        		cout << " Number of points exceeded maximum, increase NPoints in CutScanner.h" << endl;
        		iPoint = NPoints;
      		}
      		for(int i = 0; i < iPoint; i++){
			cout << "scan cut value, result " << graphX[i] << " " 
                                                          << graphY[i] << endl;
        		if(graphX[i] < xmin) xmin = graphX[i];
        		if(graphX[i] > xmax) xmax = graphX[i];
        		if(graphY[i] < ymin) ymin = graphY[i];
        		if(graphY[i] > ymax) ymax = graphY[i];
      		}
      		xmin = xmin - 0.1*(xmax-xmin);
      		xmax = xmax + 0.1*(xmax-xmin);
      		ymin = ymin - 0.1*(ymax-ymin);
      		ymax = ymax + 0.1*(ymax-ymin);
		if(ymax == ymin) {
			ymin = 0.9 * ymin;
			ymax = 1.1 * ymax;
		}

      		TCanvas* scanner = new TCanvas("scanner","",500,500);
      		scanner->cd();

      		TH2F* frame = new TH2F("frame","",1,xmin,xmax,1,ymin,ymax);
      		frame->SetStats(0);
      		frame->Draw();

      		const int N = iPoint;
      		TGraph* graph = new TGraph(N,graphX,graphY);
      		graph->SetMarkerStyle(20);
      		graph->Draw("PSAME");

      		scanner->Print("scanner.C");

      		delete graph;
      		delete frame;
      		delete scanner;
	}
}
