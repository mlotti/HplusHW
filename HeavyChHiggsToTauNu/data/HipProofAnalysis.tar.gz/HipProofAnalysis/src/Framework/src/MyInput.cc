#include "Framework/interface/MyInput.h"

MyInput::MyInput(){

      	char* inputFile = "analysis.in";
      	char* INPUTFILE = getenv("INPUTFILE");
      	if( INPUTFILE != NULL) inputFile = INPUTFILE;
      	cout << " Using inputfile " << inputFile << endl;

      	ifstream inFile(inputFile,ios::in);

      	if(!inFile){ cout << " Cannot open file " << inputFile << endl; exit(0);};

      	string line;
      	commandString = "";

	while (readAndCompressLine(inFile,line)){
          	string fileName = line;

          	size_t comment_begin = line.find("/*");
		if(comment_begin < line.length()){
			fileName = line.substr(0,comment_begin);
			size_t comment_end = line.find("*/");
			while(comment_end > line.length()){
				readAndCompressLine(inFile,line);
				comment_end = line.find("*/");
			}
			fileName += line.substr(comment_end+2);
		}

		size_t c_curlyopen = fileName.find("{");
		if(c_curlyopen < fileName.length()){
			size_t c_curlyclose = fileName.find("}");
			while(c_curlyclose > fileName.length()){
                                readAndCompressLine(inFile,line);
				c_curlyclose = line.find("}");
				fileName += " ";
				fileName += line;
			}
			fileName = compressLine(fileName);
		}

        	if(fileName.length() <= 0) continue;


		size_t c_equal = fileName.find('=');
		if(c_equal > 0 && c_equal < fileName.length()){
			string cutName = fileName.substr(0,c_equal);
			string cut_str = fileName.substr(c_equal+1,fileName.length());

			if(cutName == "datasets") {fillDatasets(cut_str);continue;}
                	if(cutName == "dataset")  {fillDataset(cut_str);continue;}
                        if(cutName.find("grid_") < cutName.length()) continue;

			double cutValue = 0;
                        double enabled = true;
                	if(cut_str == "scan"){
                	        commandString = cutName;
                	}else{
                	        if(cut_str == "true") cutValue = 1;
                        	else if(cut_str == "false") cutValue = 0;
                                else if(cut_str == "disabled") enabled = false;
                                else cutValue = atof(cut_str.c_str());
                	}
                        cut.insert(make_pair(cutName, Cut(Cut::kUnkown, cutValue, 0, enabled)));
        	}
      }
      inFile.close();
}

MyInput::~MyInput(){;}

vector<Dataset> MyInput::getDatasets(){
	return datasets;
}
/*
vector<string> MyInput::getDatafiles(){
      if(dataFiles.size() == 0){
        cout << endl << "No data files determined! Exiting... " << endl << endl;
        exit(0);
      }
      return dataFiles;
}
*/
map<string, Cut> MyInput::getCuts(){
      return cut;
}

Cut MyInput::getCut(string name){
      return cut[name];
}


vector<string> MyInput::getOptimizeCuts(){
      return optimizeCuts;
}

vector<int> MyInput::getSignalChannels(){
      return signalChannels;
}

bool MyInput::optimizeSignificance(){
      bool optimize = false;
      if(optimizeCuts.size() > 0) optimize = true;
      return optimize;
}

bool MyInput::useScanner(){
      bool use = false;
      if(commandString.length() > 0) use = true;
      return use;
}

string MyInput::getCommandString(){
      return commandString;
}

string MyInput::getScanVariableName(){
      return getCommandString();
}

bool MyInput::readAndCompressLine(ifstream& inFile,string& line){
        bool notEOF = getline(inFile,line);
	line = compressLine(line);
	return notEOF;
}

string MyInput::compressLine(string line){
        string theLine = "";
        for(int i = 0; i < int(line.length()); i++){
                if(line[i] != ' ' && line[i] != '\t') theLine += line[i];
        }
	size_t c_comment = theLine.find("//");
	if(c_comment < theLine.length()) theLine = theLine.substr(0,c_comment);
        return theLine;
}

void MyInput::fillDatasets(string cut_str){

	string list = removeCurlys(cut_str);

	while(list.length() > 0){
		size_t c_comma = list.find(',');
		if(c_comma > list.length()) c_comma = list.length();
		string dataSetName = list.substr(0,c_comma);

		dataSetNames.push_back(dataSetName);

		if(c_comma < list.length()){
			list = list.substr(c_comma+1,list.length()-c_comma-1);
		}else{
			list = "";
		}
	}
}

void MyInput::fillDataset(string cut_str){
        string list = removeCurlys(cut_str);

	Dataset dataset;

        while(list.length() > 0){
		size_t c_comma = list.find(',');
		if(c_comma > list.length()) c_comma = list.length();
		string name = list.substr(0,c_comma);

		size_t c_equal = name.find('=');
		if(c_equal > 0 && c_equal < name.length()){
                	string cutName = name.substr(0,c_equal);
                	string cut_str = name.substr(c_equal+1,name.length());

                        if(cutName == "name")           dataset.setName(cut_str);
                        if(cutName == "label")          dataset.setLabel(cut_str);
                        if(cutName == "directory")      dataset.setDirectory(cut_str);
                        if(cutName == "cross_section")  dataset.setCrossSection(cut_str);
                        if(cutName == "preSeleEfficiency") dataset.setPreselectionEfficiency(cut_str);
                        if(cutName == "signal")         dataset.setSignal(cut_str);
                        if(cutName == "maxEvents")      dataset.setMaxEvents(cut_str);
                        if(cutName == "maxFiles")       dataset.setMaxFiles(cut_str);

		}

		if(c_comma < list.length()){
                        list = list.substr(c_comma+1,list.length()-c_comma-1);
                }else{
                        list = "";
                }
	}

	if(dataSetNames.size() == 0){
		datasets.push_back(dataset);
	}else{
		bool useThisDataSet = false;
		vector<string>::const_iterator i;
		for(i = dataSetNames.begin(); i!= dataSetNames.end(); i++){
			if(dataset.getName() == *i) useThisDataSet = true;
		}
		if(useThisDataSet) datasets.push_back(dataset);
	}
}

string MyInput::removeCurlys(string input){
	string list = "";
        for(int i = 0; i < int(input.length()); i++){
                if(input[i] != '{' && input[i] != '}') list += input[i];
        }
	return list;
}

TChain* MyInput::getChain(){
	chain = new TChain("rootTree");

        vector<Dataset>::const_iterator iDataset;
        for(iDataset = datasets.begin();
            iDataset!= datasets.end(); ++iDataset){
		vector<string> files = iDataset->getFiles();

                Long64_t maxEvents = iDataset->getMaxEvents();

                int maxFiles  = iDataset->getMaxFiles();
                int nFiles    = 0;

                vector<string>::const_iterator iFile;
                for(iFile = files.begin(); iFile != files.end(); iFile++){

                        if(maxFiles  != -1 && nFiles >= maxFiles) continue;
                        nFiles++;

			if(maxEvents == -1){
				chain->Add(iFile->c_str());
			}else{
				chain->Add(iFile->c_str(),maxEvents);
			}
		}
	}
	return chain;
}
