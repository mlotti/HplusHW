#include "Framework/interface/Dataset.h"

Dataset::Dataset(){
	clear();
}
Dataset::~Dataset(){}

void Dataset::clear(){
        name 			= "";
	label			= 1;
        dataDirectory		= "";
        cross_section 		= 0;
	preSeleEfficiency 	= 1;
        signal 			= false;
        maxEvents               = -1;
	maxFiles		= -1;
	URL			= false;
}

double Dataset::getCrossSection() const{
	return cross_section;
}

double Dataset::getPreselectionEfficiency() const{
	return preSeleEfficiency;
}

bool Dataset::isSignal() const{
	return signal;
}

string Dataset::getName() const{
	return name;
}

int Dataset::getLabel() const {
	return label;
}

string Dataset::getPath() const{
        return dataDirectory;
}

vector<string> Dataset::getFiles() const {

	char* LS_SUBCWD = getenv("LS_SUBCWD");
	string ls_subcwd = string(LS_SUBCWD);
	if(ls_subcwd[ls_subcwd.length()-1] != '/') ls_subcwd += "/";

	string inFileName = "";
	if(URL){
		inFileName  = ls_subcwd;
		inFileName += "../dataURLs/";
                inFileName += dataDirectory;
	}else{
		string makeFileList = "ls ";
		if(dataDirectory[0] != '/'){
			makeFileList += ls_subcwd;
		}

        	makeFileList += dataDirectory;
        	makeFileList += "/*.root";
        	makeFileList += "> files.txt";
        	system(makeFileList.c_str());
		inFileName = "files.txt";
	}

        // reading file list
        ifstream inFile(inFileName.c_str(),ios::in);

        if(!inFile){ cout << " Cannot open file " << inFile << endl; exit(0);};

        vector<string> files;

        string line;
        while (getline(inFile,line)){
		if(line.length() == 0) continue;
		files.push_back(line);
        }
	system("rm -f files.txt");

	return files;
}

void Dataset::setCrossSection(string strValue){
	const char* chValue = strValue.c_str();
	cross_section = atof(chValue);
}

void Dataset::setPreselectionEfficiency(string strValue){
        const char* chValue = strValue.c_str();
        preSeleEfficiency = atof(chValue);
}

void Dataset::setSignal(string strValue){
	if(strValue == "1" || strValue == "true") signal = true;
	else signal = false;
}

void Dataset::setName(string strValue){
	name = strValue;
}

void Dataset::setLabel(string strValue){
	const char* chValue = strValue.c_str();
        label = atoi(chValue);
}

void Dataset::setDirectory(string strValue){
        dataDirectory = strValue;
        if(dataDirectory.find("URLs") < dataDirectory.length()){
                URL = true;
        }else{
		URL = false;
	}
}

void Dataset::setMaxEvents(string strValue){
        const char* chValue = strValue.c_str();
        maxEvents = atoi(chValue);
}

int Dataset::getMaxEvents() const{
	return maxEvents;
}

void Dataset::setMaxFiles(string strValue){
        const char* chValue = strValue.c_str();
        maxFiles = atoi(chValue);
}

int Dataset::getMaxFiles() const{
        return maxFiles;
}

bool Dataset::isURL() const {
	return URL;
}
