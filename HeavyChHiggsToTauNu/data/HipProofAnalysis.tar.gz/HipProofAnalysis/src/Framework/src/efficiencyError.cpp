#include <math.h>

double efficiencyError(int N,double eff){
    double error = 0;
    if(N != 0) error = sqrt(eff*(1-eff)/N);
    return error;
}
