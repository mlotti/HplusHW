#include "Framework/interface/MyEventFilter.h"

MyEventFilter::MyEventFilter(MyInput& input){
	init(input);
}

MyEventFilter::~MyEventFilter(){
	write();
}

void MyEventFilter::init(MyInput& input){

	string histogramName = "filter.root";

	filter 		= false;
        sumInfo 	= NULL;
        filteredEvents 	= 0;
	nFiles		= 0;

	if(input.getCut("filter").getValue() == 1) filter = true;

	if(filter){
        	filterFile = TFile::Open(histogramName.c_str(),"RECREATE");
		filterFile->cd();

		rootTree = new TTree("rootTree","events");
  		rootTree->SetAutoSave(1000000000);
  		myEvent  = new MyEvent();
  		int bufsize = 256000;
  		int split   = 1;
  		rootTree->Branch("MyEvent","MyEvent",&myEvent,bufsize,split);
	}
}

void MyEventFilter::saveEventInfo(TH1F* histo){

	if(filter){
		nFiles++;
		filterFile->cd();
		if(sumInfo == NULL){
			sumInfo = (TH1F*)histo->Clone("sumInfo");
			int nBins = sumInfo->GetNbinsX();
			for(int i = 0; i < nBins; i++){
				const char* label = sumInfo->GetXaxis()->GetBinLabel(i+1);
				if(string(label) == "filteredEvents") filter = false;
			}
			if(!filter) {
				cout << endl;
				cout << "FILE ALREADY FILTERED, setting filter = false" << endl;
                                cout << endl;

				string fileName = string(filterFile->GetName());
				delete filterFile;
				string command = "rm -f " + fileName;
				system(command.c_str());
			}
		}else{
			sumInfo->Add(histo);
		}
	}
}

void MyEventFilter::saveEvent(MyEvent* event){

	if(filter){
		filteredEvents++;
  		myEvent = event;

  		filterFile->cd();
  		rootTree->Fill();
	}
}

void MyEventFilter::write(){

        if(filter){
	  	cout << endl;
	  	cout << " Number of events filtered " << filteredEvents << endl;
	  	if(filteredEvents > 0){
                	cout << " filter output file = " << filterFile->GetName() << endl;
	        	cout << endl;

	                filterFile->cd();

			int nBins = sumInfo->GetNbinsX();
			TH1F* eventInfo = new TH1F("eventInfo","",nBins+1,0,nBins+1);
			for(int i = 0; i < nBins; i++){
				float binValue = sumInfo->GetBinContent(i+1);
				if(i < 4) binValue = binValue/nFiles;
				eventInfo->SetBinContent(i+1,binValue);
			        eventInfo->GetXaxis()->SetBinLabel(i+1,sumInfo->GetXaxis()->GetBinLabel(i+1));
cout << "check in out " << sumInfo->GetBinContent(i+1) << " " << eventInfo->GetBinContent(i+1) << endl;
			}
			eventInfo->SetBinContent(nBins+1,filteredEvents);
			eventInfo->GetXaxis()->SetBinLabel(nBins+1,"filteredEvents");
			delete sumInfo;

	                eventInfo->Write();
	                rootTree->Write();
	                //filterFile->ls();

	                filterFile->Close();
		}
		cout << endl;
		delete filterFile;
        }
}
