#include "Framework/interface/Counter.h"

double Counter::significance(double nSignal,double nBackgr){

   // calculating Poisson significance using signal and backgr statistics
   double significance = 0;

   if(nBackgr > 0){
     significance = sqrt(2*((nSignal+nBackgr)*log(1+nSignal/nBackgr)-nSignal));
   }
   return significance;
}
