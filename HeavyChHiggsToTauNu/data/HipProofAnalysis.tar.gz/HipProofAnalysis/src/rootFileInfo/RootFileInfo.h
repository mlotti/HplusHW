#ifndef RootFileInfo_H
#define RootFileInfo_H

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyEvent.h"
#include "TFile.h"
#include "TH1F.h"

class RootFileInfo {
    public:
	RootFileInfo(int,char* const*);
	~RootFileInfo();

	void analyse();

    private:
        void init();
        bool test(TFile*);
        void print();
	void print_usage(char*);
	void print_info(TH1F*);
	void analyse(TFile*);

	char** rootInputFile;

	int eventCounter;

        int fullPrint;
	int eventNumber;
	int runNumber;

	int iRoot;

	bool url;
	string urlFile;

	TH1F* sumInfo;
};
#endif

