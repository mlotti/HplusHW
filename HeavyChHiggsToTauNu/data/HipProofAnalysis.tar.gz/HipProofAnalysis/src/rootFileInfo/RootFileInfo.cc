#include "RootFileInfo.h"

#include "TXNetFile.h"
#include "TTree.h"
#include "TH1F.h"

#include <string>
#include <iostream>   //IO library
#include <fstream>

using namespace std;

RootFileInfo::RootFileInfo(int argc, char *const *argv){

	init();

	rootInputFile = new char*[argc-1];

	int iarg        = 1;

	while(iarg < argc){
		if(string(argv[iarg]) == "-h") print_usage(argv[0]);
                if(string(argv[iarg]) == "-FULL") fullPrint = 1;
                if(string(argv[iarg]) == "-FULLEVENTS") fullPrint = 2;
                if(string(argv[iarg]).find(".URLs") < string(argv[iarg]).length()) {
                        url = true;
                        urlFile = string(argv[iarg]);
                }
                if(string(argv[iarg]).find("root://") < string(argv[iarg]).length()) {
                        url = true;
                }
                if(string(argv[iarg-1]) == "-eventNumber") {
                        eventNumber = atoi(argv[iarg]);
                        fullPrint = 2;
                }
		if(string(argv[iarg-1]) == "-runNumber") {
                        runNumber = atoi(argv[iarg]);
                }

		string rootTest = string(argv[iarg]);
		if(rootTest.length() > 5 &&
                   rootTest.substr(rootTest.length()-4,4)=="root"){
                	rootInputFile[iRoot++] = argv[iarg];
		}
		iarg++;
	}

        // no relevant input given, print usage and stop
        if(iRoot == 0 && !url) print_usage(argv[0]);
}

RootFileInfo::~RootFileInfo(){
	print();
}

void RootFileInfo::print_usage(char* executable){
  cout << "Usage: " << executable << " rootfile [-FULL][-FULLEVENTS][-runNumber number][-eventNumber number]" << endl;
  cout << "Usage: " << executable << " rootfile URL [-FULL][-FULLEVENTS][-runNumber number][-eventNumber number]" << endl;
  cout << "Usage: " << executable << " URLs_file [-FULL][-FULLEVENTS][-runNumber number][-eventNumber number]" << endl;
  exit(0);
}


void RootFileInfo::init(){
	fullPrint       =  0;
	eventNumber     = -1;
	runNumber       = -1;
	url		= false;
	urlFile		= "";
	iRoot		= 0;
	eventCounter	= 0;
	sumInfo		= NULL;
}

void RootFileInfo::analyse(){
        if(url){
	   if(urlFile.length() > 5){
                ifstream inFile(urlFile.c_str(),ios::in);
                if(!inFile){ cout << " Cannot open file " << inFile << endl; exit(0);}
                string line;
                while (getline(inFile,line)){
                        if(line.length() < 5) continue;
                        TFile* fINPUT = new TXNetFile(line.c_str());
                        if(!test(fINPUT)) continue;
                        analyse(fINPUT);
                        iRoot++;
                        delete fINPUT;
                }
	   }else{
                for(int iFile = 0; iFile < iRoot; iFile++){
                        TFile* fINPUT = new TXNetFile(rootInputFile[iFile]);
                        if(!test(fINPUT)) continue;
                        analyse(fINPUT);
                        delete fINPUT;
        	}
	   }
        }else{
                for(int iFile = 0; iFile < iRoot; iFile++){
                        TFile* fINPUT = new TFile(rootInputFile[iFile]);
                        if(!test(fINPUT)) continue;
                        analyse(fINPUT);
                        delete fINPUT;
                }
        }
}

bool RootFileInfo::test(TFile* fINPUT){
        bool fileTest = true;
        if(fINPUT->GetStreamerInfoList() == 0 || fINPUT->GetNkeys() < 2){
                fileTest = false;
                if(!url){
                        string theFile = string(fINPUT->GetName());
                        string shell_command = "mv " +
                                       theFile + " " +
                                       theFile + "_Zombie";
                        gSystem->Exec(shell_command.c_str());
                }
        }
        return fileTest;

}

void RootFileInfo::analyse(TFile* fINPUT){

        TTree* rootTree = (TTree*)fINPUT->Get("rootTree;1");
        int entries = rootTree->GetEntries();
        eventCounter += entries;
        cout << "File " << fINPUT->GetName();
        if(fullPrint > 0){
                cout << endl;
                if(fullPrint == 1){
                  TH1F* eventInfo = (TH1F*)fINPUT->Get("eventInfo;1");
                  print_info(eventInfo);
                  cout << "    tree entries                 " << entries << endl;

                  if(sumInfo == NULL){
			TH1::AddDirectory(kFALSE);
                        sumInfo = new TH1F(*eventInfo);
                        sumInfo->Reset();
                  }
                  sumInfo->Add(eventInfo);
                }else{
                  MyEvent* event = new MyEvent;
                  TBranch* branch = rootTree->GetBranch("MyEvent");
                  branch->SetAddress(&event);

                  if(runNumber < 0 && eventNumber < 0) {
                    for(int i = 0; i < entries; ++i){
                        rootTree->GetEvent(i);
                        event->printAll();
                    }
                  }else{
                    bool eventFound = false;
                    int i = 0;
                    while(!eventFound && i < entries){
                        rootTree->GetEvent(i);
                        if((runNumber < 0 && event->event() == eventNumber ) ||
                           (event->run() == runNumber && event->event() == eventNumber ) ){
                                event->printAll();
                                eventFound = true;
                                exit(0);
                        }
                        ++i;
                    }
                  }
                }
        }else{
                cout << ", entries " << entries << endl;
        }

}

void RootFileInfo::print(){
        cout << endl << endl << "Sum of allEvents: " << eventCounter << endl;
        if(fullPrint > 0){
                for(int i = 1; i <= 4; i++){
                	sumInfo->SetBinContent(i,sumInfo->GetBinContent(i)/iRoot);
                }
                print_info(sumInfo);
        }
}

void RootFileInfo::print_info(TH1F* info){
        cout << endl;
        for(int i = 1; i <= info->GetXaxis()->GetNbins(); i++){
                const char* binName = info->GetXaxis()->GetBinLabel(i);
                float binValue      = info->GetBinContent(i);
                string theName = string(binName);
                while(theName.length() < 28) theName+=' ';
                cout << "    " << theName << " " << binValue << endl;
        }
        cout << endl;
}
