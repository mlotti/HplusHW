// 23.4.2008/S.Lehti

#include "RootFileInfo.h"

int main(int argc, char *const *argv){

	RootFileInfo* rootFileInfo = new RootFileInfo(argc,argv);
	rootFileInfo->analyse();
	delete rootFileInfo;
}
