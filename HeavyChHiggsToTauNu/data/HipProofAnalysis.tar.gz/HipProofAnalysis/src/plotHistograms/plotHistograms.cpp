// 28.4.2008/S.Lehti

#include <stdio.h>
#include <stdlib.h>
#include <iostream>   //IO library
#include <fstream>
#include <string>
#include <vector>
#include <map>

#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TH1F.h"
#include "TCanvas.h"


using namespace std;

void print_usage(char*);

int main(int argc, char *const *argv){

  	char* rootInputFile[argc-1];
  	char* outputFile = "thePlot.C";

  	int iarg  = 1,
  	    iRoot = 0;
	bool normalizeToOne = false;

	vector<string> histogramNames;

  	while(iarg < argc){ 
		if(string(argv[iarg]) == "-h") print_usage(argv[0]);
		if(string(argv[iarg-1]) == "-o") outputFile = argv[iarg];
		if(string(argv[iarg-1]) == "-name") histogramNames.push_back(string(argv[iarg]));
                if(string(argv[iarg]) == "-normalizeToOne") normalizeToOne = true;


	        string rootTest = string(argv[iarg]);
	        if(rootTest.length() > 5 &&
	           rootTest.substr(rootTest.length()-4,4)=="root"){
		        rootInputFile[iRoot++] = argv[iarg];
	        }
	        iarg++;
	}


  	// no root files given, print usage and stop
  	if(iRoot == 0) print_usage(argv[0]);

	string canvasName = string(outputFile);
	canvasName = canvasName.substr(0,canvasName.find_last_of("."));

	TCanvas* canvas = new TCanvas(canvasName.c_str(),"",700,500);
	canvas->SetFillColor(0);

	string option = "";
	for(int i = 0; i < iRoot; ++i){

		TFile* fINPUT = TFile::Open(rootInputFile[i]);

		for(vector<string>::const_iterator iHisto = histogramNames.begin();
                                                   iHisto!= histogramNames.end(); ++iHisto){
			TH1F* histo = (TH1F*)fINPUT->Get((*iHisto).c_str());
			if(!histo) continue;
			string rootFileName = string(rootInputFile[i]);

                        bool directory = false;
                        if(rootFileName.find("/") < rootFileName.length()) directory = true;

                        if(directory){
                          rootFileName = rootFileName.substr(0,rootFileName.find_first_of("/"));
                        }else{
                          rootFileName = rootFileName.substr(0,rootFileName.find_last_of("."));
                        }
			string name = *iHisto + "_" + rootFileName;

			histo->SetName(name.c_str());
			canvas->cd();
			histo->SetLineWidth(3);
			if(normalizeToOne) {
				histo->Scale(1/histo->GetMaximum());
				histo->SetStats(0);
				histo->GetYaxis()->SetTitle("Arbitrary units");
			}
			histo->DrawClone(option.c_str());
			option = "same";
		}
		

	}
	canvasName = canvasName + ".C";
	canvas->Print(canvasName.c_str());
}

void print_usage(char* executable){
	cout << "Usage: " << executable << " -name histo1 " 
             << "[-name histo2] "
       	     << " file1 file2.. [-o outputfile] [-normalizeToOne]" << endl;
	exit(0);
}
