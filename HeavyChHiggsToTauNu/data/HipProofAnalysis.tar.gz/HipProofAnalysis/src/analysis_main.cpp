#include "Framework/interface/MyInput.h"
///#include "Visual/interface/TVisMainFrame.h"
#include "MyAnalysis/interface/MyAnalysis.h"
#include "Framework/interface/CutScanner.h"

#include "TROOT.h"
#include "TChain.h"

MyAnalysis* analysis;
TChain* chain;

int main(int argc, char **argv) {

   	MyInput input; // reading the inputfile

	chain = input.getChain();

   	analysis = new MyAnalysis(input);

	chain->Process(analysis);
/*
	if (analysis->visualStatus()) {
	  // invoke application
	  TApplication myApp("app", &argc, argv);
	  vector<string> myFiles = analysis->getFileList();
	  TVisMainFrame myMainfame(gClient->GetRoot(), myFiles);
	  // Run application
	  myApp.Run();
	  
	  return 0; // never reached
	}
*/
/*
	if(input.useScanner()){
		CutScanner* scanner = new CutScanner(input, chain, analysis);
		scanner->scan();
		delete scanner;
	}else{
		analysis->getSignificance();
	}
*/
	delete analysis;
	return 0;
}
