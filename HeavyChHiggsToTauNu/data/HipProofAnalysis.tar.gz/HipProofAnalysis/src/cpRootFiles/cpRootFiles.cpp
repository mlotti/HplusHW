// 1.4.2008/S.Lehti

#include <stdio.h>
#include <stdlib.h>
#include <iostream>   //IO library
#include <fstream>
#include <string>
#include <map>

#include "TROOT.h"
#include "TFile.h"
#include "TXNetFile.h"
#include "TTree.h"
#include "TH1F.h"
#include "TSystem.h"

using namespace std;

void print_usage(char*);
void print_info(TH1F*);
void copy(const char*);

map<int,int> sort_rootFiles(char**,int);

int eventCounter;

const int MAX_LENGTH = 5000;
TH1F* sumInfo;

int main(int argc, char *const *argv){

  	char* rootInputFile[argc-1];// = "";
  	string outputFile    = "";
	string urlFile	     = "";

  	int iarg             = 1,
  	    iRoot            = 0;
  	bool urls	     = false;
  	eventCounter         = 0;


	while(iarg < argc){ 

		if(string(argv[iarg]).find(".URLs") < string(argv[iarg]).length()) {
			urls = true;
			urlFile = string(argv[iarg]);
		}

		string rootTest = string(argv[iarg]);
		if(rootTest.length() > 5 && rootTest != outputFile &&
                   rootTest.substr(rootTest.length()-4,4)=="root"){ 
        		rootInputFile[iRoot++] = argv[iarg];
		}
    		iarg++;
	}

  	// no relevant input given, print usage and stop
	if(iRoot == 0 && !urls) print_usage(argv[0]);
	
	if(urls){
		ifstream inFile(urlFile.c_str(),ios::in);
		if(!inFile){ cout << " Cannot open file " << inFile << endl; exit(0);}
		string line;
		while (getline(inFile,line)){
			if(line.length() < 5) continue;
			copy(line.c_str());
			iRoot++;
		}
	}else{
		for(int iFile = 0; iFile < iRoot; iFile++){
                        copy(rootInputFile[iFile]);
		}
	}
}

//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////

void print_usage(char* executable){
  cout << "Usage: " << executable << " rootfile URL " << endl;
  cout << "Usage: " << executable << " URLs_file " << endl;
  exit(0);
}

void copy(const char* inFileName){
	cout << "Copying file " << inFileName << endl;
	string s_inFileName = string(inFileName);
	int slashPos = s_inFileName.rfind('/');
	string outFileName = s_inFileName.substr(slashPos+1,s_inFileName.length()-slashPos-1);

	TFile::Cp(inFileName,outFileName.c_str());
}
