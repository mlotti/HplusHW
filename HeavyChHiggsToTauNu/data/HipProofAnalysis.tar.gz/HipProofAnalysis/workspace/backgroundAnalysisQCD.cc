#include "MyAnalysis/interface/MyAnalysis.h"
double phifun(double,double);

void MyAnalysis::backgroundAnalysisQCD(MyEvent* event){

	mcAnalysis->analyse(event);


// muon veto
//	if(!muonVeto(event,cut["muonVetoCut"])) return;
   
        if (event->muons.size() > 0 ) return;
        eventCounter->addCount("veto on all reco muons");


// tau selection (random jet Et > 100)

	//MyJet theTau = randomTauSelectionFromHadronicJets(event,cuts->getCutValue("tauEtCut"));

	// tauType = { CaloTau,CaloTauCorrected,HardTau,HardTauCorrected,PFTau }
        // CaloTauCorrected and HardTauCorrected use TauJet jet energy corrections
        string tauType = "HardTauCorrected";
	MyJet theTau = randomTauSelectionFromTauCandidateJets(event,cuts->getCutValue("tauEtCut"),tauType);

	if(theTau.Et() == 0) return;
        eventCounter->addCount("tau candidate found");

	tauResolutionAnalysis->analyse(theTau,mcAnalysis->mcJet(theTau));
 

// MET
 
//        MyMET met   = event->MET;
//        MyMET met   = type1MET(event,15,"MCJetCorrectorMcone5");
        //MyMET met   = event->MET;
        // metCorrection = "CaloMET_Type1Icone5",
        //                 "CaloMET_Type1Mcone5",
        //                 "CaloMET_NoHF",
        //                 "CaloMET_noHF_Type1Icone5",
        //                 "CaloMET_noHF_Type1Mcone5"
        //string metCorrection = "CaloMET_noHF_Type1Mcone5";
        //met.useCorrection(metCorrection);

	vector<const MyJet*> taus;
	taus.push_back(&theTau);
        MyMET met   = type1METtau(event,taus,15,"MCJetCorrectorMcone5");

 
        metResolutionAnalysis(met,event->getMCMET());
        

        if(!metCut(met)) return;
        eventCounter->addCount("MET cut");

// top mass reco

        topMassReco->analyse(&theTau,event, int(cuts->getCutValue("topRecoAlgo")));
        //if(!topFound) return;
        //eventCounter->addCount("top quark found");

        int njets = topMassReco->njets();
        if(njets < 3) return;
        eventCounter->addCount("3 hadronic jets ");

	int nforwardjets = topMassReco->nforwardJets();
	//	if(nforwardjets > 1) return;
	//        eventCounter->addCount("0 or 1 forward jets ");

        double bestDiscriminator = (topMassReco->bestBJet()).tag("discriminator");
        if(!cuts->applyCut("bTagDiscriminator", bestDiscriminator)) return;
        eventCounter->addCount("b jet  discriminator cut");

        if(!cuts->applyCut("bjetEtCut", topMassReco->bestBJet().Et())) return;
	eventCounter->addCount("b jet Et cut");

        if(!cuts->applyCut("topFitChi2", topMassReco->fitChi2())) return;
        if(!cuts->applyCut("wMass", topMassReco->WMass())) return;
        eventCounter->addCount("W mass cut");
  
        if(!cuts->applyCut("topMass", topMassReco->topMass())) return;
        eventCounter->addCount("top mass cut");

// transverseMass reco

        double mt = transverseMass(theTau,met);
	eventFilter->saveEvent(event);


	if ( mt < 100 ) return;
        eventCounter->addCount("mt cut");

	jetResolutionAnalysis(topMassReco->jets(),event);
 


	//////////////////////////////////
       
	string jetCalibration = "MCJetCorrectorMcone5";
	vector<MyJet> calibatedJets = event->getJets(jetCalibration);  


        if(!histograms->booked("h_phiJets100") ) histograms->book("h_phiJets100",90,0,180);
        if(!histograms->booked("h_etaJets100") ) histograms->book("h_etaJets100",100,-5,5);
        if(!histograms->booked("h_eta50Jets100") ) histograms->book("h_eta50Jets100",100,-5,5);

        for(vector<MyJet>::iterator iJet = calibatedJets.begin();
                                       iJet != calibatedJets.end(); iJet++){
	       double phijet = phifun(iJet->Ex(),iJet->Ey());
	       histograms->fill("h_phiJets100",180/3.14159*phijet);
	       histograms->fill("h_etaJets100",iJet->Eta());
	       if( iJet->Et() > 50 ) histograms->fill("h_eta50Jets100",iJet->Eta()); 
        }

        if(!histograms->booked("h_etaTaujet100") ) histograms->book("h_etaTaujet100",100,-5,5);
	histograms->fill("h_etaTaujet100",theTau.Eta()); 

        double phitau = phifun(theTau.Ex(),theTau.Ey());
        if(!histograms->booked("h_phiTaujet100") ) histograms->book("h_phiTaujet100",90,0,180);
	histograms->fill("h_phiTaujet100",180/3.14159*phitau);
 
 
 	if(nforwardjets > 1) return;
	eventCounter->addCount("0 or 1 forward jets ");

        //////////////////////////////////////////////////////////////////////////////


}


