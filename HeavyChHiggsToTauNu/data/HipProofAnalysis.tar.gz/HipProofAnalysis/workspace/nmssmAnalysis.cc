#include "MyAnalysis/interface/MyAnalysis.h"

void MyAnalysis::nmssmAnalysis(MyEvent* event){

        // trigger leptons
        bool triggered = triggerLeptons(event);
        if(!triggered) return;
        eventCounter->addCount("trigger leptons");

        // MC analysis
        //mcAnalysis(event);

        // offline taus
        vector<TauPair> tauPairs = nOfflineTausWithLeptonInCone(event);

        if(tauPairs.size() != 2) return;
        eventCounter->addCount("2 taus with muon in cone");
cout << "event number " << event->eventNumber << endl;

        if(!jetVeto(event,tauPairs)) return;
        eventCounter->addCount("jet veto");


//      njets(event);
//        met(event);

        invariantMass(tauPairs);


        eventFilter->saveEvent(event);
}
