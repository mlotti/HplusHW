export LS_SUBCWD=$PWD
export MY_PATH=$PWD/../libs
export TMVA_PATH=$PWD/../tmva/TMVA/lib

if [ "x$LD_LIBRARY_PATH" != "x" ]; then
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$MY_PATH:$TMVA_PATH
else
    export LD_LIBRARY_PATH=$MY_PATH:$TMVA_PATH
fi
export PATH=$PATH:$PWD/../bin
