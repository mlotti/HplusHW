#include "MyAnalysis/interface/MyAnalysis.h"

void MyAnalysis::pflowAnalysis(MyEvent* event){

	mcAnalysis->analyse(event);


	//	vector<MyJet> taus = triggerTaus(event);
	vector<MyJet> taus = event->getPFTaus();
	//	vector<MyJet>  taus = recalculatePFlowEnergyUsingPFtracks(event);
	//                    	      	vector<MyJet> taus = recalculateTauEnergyUsingHardTauAlgorithm(event);


        if(!histograms->booked("h_tauEt") ) histograms->book("h_tauEt",100,0,500);
        if(!histograms->booked("h_leadingTrackPt") ) histograms->book("h_leadingTrackPt",100,0,500);
        if(!histograms->booked("h_pfParticleResolution") ) histograms->book("h_pfParticleResolution",100,-1.2,1.2);
        if(!histograms->booked("h_taujetResolution") ) histograms->book("h_taujetResolution",100,-1.2,1.2);

	vector<MyJet> selectedTaus;
        for(vector<MyJet>::iterator iJet = taus.begin();
                                    iJet != taus.end(); iJet++){
		eventCounter->addCount("    all tau cands");

		histograms->fill("h_tauEt",iJet->Pt());
		if(!cuts->applyCut("tauEtCut", iJet->Pt())) continue;
		eventCounter->addCount("    tau Et cut");

		MyTrack leadingTrack = iJet->leadingTrack(cuts->getCutValue("matchingCone"));
                histograms->fill("h_leadingTrackPt",leadingTrack.Pt());

                if(leadingTrack.Pt() < 1) continue;
                eventCounter->addCount("    leading track");

		//bool isolated = isolation(&(*iJet),cuts->getCutValue("isolationCone"),cut->getCutValue("signalCone"));
		//		if(!isolated) continue;
		eventCounter->addCount("    tau isolation");


		//int nprongs = tauProngCounter(*iJet,cuts->getCutValue("signalCone"),cuts->getCutValue("matchingCone"));
		//		if(nprongs != 1 ) continue;
		//		if(nprongs != 1 && nprongs != 3) continue;
		//		eventCounter->addCount("    tau 1/3 prong");

	        MyJet theTau = *iJet;

		//                MyMCParticle  visibletau = mcAnalysis->visibleTau(theTau);

		//               if ( visibletau.Pt() == 0 ) continue;

		//              eventCounter->addCount("    MC tau found");

		//                double DR=deltaR( visibletau.Eta(),iJet->eta(),visibletau.Phi(),iJet->phi()); 
		//               if( DR > 0.4 ) continue;
		//                eventCounter->addCount("    matching MC tau");   

		//////////////////////////////////////// tau topology            
		int nChargedPions = 0; 
		int nNeutralPions = 0; 
		int nChargedPionsPlus = 0; 
		int nNeutralPionsPlus = 0; 
		int nChargedPionsMinus = 0; 
		int nNeutralPionsMinus = 0; 
                MyMCParticle visibleTauPlus(0,0,0,0);
                MyMCParticle visibleTauMinus(0,0,0,0);
                MyMCParticle visibletau(0,0,0,0);

                vector<MyMCParticle> mcParticles = event->mcParticles;
                for(vector<MyMCParticle>::iterator imc = mcParticles.begin();
	                               imc!= mcParticles.end(); imc++){

                    TLorentzVector mcParticle(0,0,0,0);
                    mcParticle.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->E());

                    int mother1 = 0;
                    vector<int> motherList = imc->mother; 
                    if(motherList.size() > 0) mother1 = (*motherList.begin());
	  		  cout << " part  " << imc->pid << " mother1 " << mother1 << endl;
 
                    bool fromHplus = false;

                    for(vector<int>::const_iterator iMother = motherList.begin();
                                iMother!=motherList.end(); iMother++){
		      //		     if(abs(*iMother) == 37) fromHplus = true;
		   		     if(abs(*iMother) == 24) fromHplus = true;
                    }

                    if( !fromHplus ) continue;
    
                    for(vector<int>::const_iterator iMother = motherList.begin();
                                iMother!=motherList.end(); iMother++){

	                  if(*iMother == 15) {

		  		  cout << " part from tau " << imc->pid << " mother1 " << mother1 << endl;
	                         if(abs(imc->pid) == 211 || abs(imc->pid) == 321) {
                                         nChargedPionsPlus++; 
				         visibleTauPlus += mcParticle;
					 //        chargedPionsMC.push_back(mcParticle);
                                 }

	                         if(abs(imc->pid) == 22 ) {
                                         nNeutralPionsPlus++; 
				         visibleTauPlus += mcParticle; 
					 //     neutralPionsMC.push_back(mcParticle);
                                }
                          }
        
	                  if(*iMother  == -15) {

		  //		  cout << " part from tau " << imc->pid << " mother1 " << mother1 << endl;
	                         if(abs(imc->pid) == 211 || abs(imc->pid) == 321) {
                                         nChargedPionsMinus++; 
				         visibleTauMinus += mcParticle;
					 //    chargedPionsMC.push_back(mcParticle);
                                 }

	                         if(abs(imc->pid) == 22 ) {
                                         nNeutralPionsMinus++; 
				         visibleTauMinus += mcParticle; 
					 //    neutralPionsMC.push_back(mcParticle);
                                }
                          }
                     }  
                }

                if ( visibleTauMinus.Pt() == 0 &&  visibleTauPlus.Pt() == 0 ) continue;

                eventCounter->addCount("    MC tau found");

                double DR1= 999;
                if( visibleTauPlus.Et() > 0) DR1= deltaR( visibleTauPlus.Eta(),iJet->eta(),visibleTauPlus.Phi(),iJet->phi()); 
                double DR2= 999;
                if(visibleTauMinus.Et() > 0 ) DR2=deltaR( visibleTauMinus.Eta(),iJet->eta(),visibleTauMinus.Phi(),iJet->phi());

                if( DR1 > 0.4 && DR2 > 0.4 ) continue;
                eventCounter->addCount("    matching MC tau"); 


                if( DR1 < 0.4 ) {
                   visibletau = visibleTauPlus;
                   nNeutralPions = nNeutralPionsPlus;
                   nChargedPions = nChargedPionsPlus;
                }
                if( DR2 < 0.4 ) {
                   visibletau = visibleTauMinus;
                   nNeutralPions = nNeutralPionsMinus;
                   nChargedPions = nChargedPionsMinus;
                }
 

		    //                int tauPid = visibletau.pid;
		    //                int topology = abs(tauPid) - 1500;
                int topology = 0;
                if ( nChargedPions == 1 && nNeutralPions == 0 ) {
                     eventCounter->addCount("    tau->pi+nu");
                     topology = 1;
		}
                if ( nChargedPions == 1 && nNeutralPions > 0 ) {
                     eventCounter->addCount("    tau->pi+npi0 + nu");
                     topology = 2;
                }
                if ( nChargedPions == 3 && nNeutralPions == 0  ) eventCounter->addCount("    tau->3pi+nu");
                if ( nChargedPions == 3 && nNeutralPions > 0) eventCounter->addCount("    tau->3pi+npi0 + nu");

		//		cout << " tau topol " << topology << " prongs " << nprongs << endl;

		//		if ( topology != 1 &&  topology != 2 ) continue;
      
		//                if ( nChargedPions == 1 && nNeutralPions > 0 )          
		//		if ( nChargedPions != 1 ) continue;
                eventCounter->addCount("    selected tau jets");

		  double dEt_flow = iJet->Et() - visibletau.Et(); 
		  if(visibletau.Et() > 0) {                       
                       histograms->fill("h_taujetResolution",dEt_flow/visibletau.Et() );
                       if ( fabs(dEt_flow/visibletau.Et()) < 0.15 ) eventCounter->addCount("   resolution < 0.15");
	          }             
     
		tauResolutionAnalysis->analyse(theTau,mcAnalysis->visibleTau(theTau));
                

		////////////////////////////////////////////////////////////////

	       
                MyMCParticle mcTauJet = mcAnalysis->visibleTau(theTau);
		//                cout << " et visibleTau: mcAnalysis->visibleTau(theTau)  " << mcTauJet.Et() << " visibletau et " << visibletau.Et() << endl;
      	        double ptmax = 0;
                MyJet particleFlow;
                particleFlow.SetPx(0);
                particleFlow.SetPy(0);  
                particleFlow.SetPz(0); 

                  vector<MyTrack> pflowTracks = theTau.getTracks();
                  MyTrack leadingPFTrack;
                  MyTrack momentum;
		  momentum.SetPx(0);
                  momentum.SetPy(0);
                  momentum.SetPz(0);
		  //                  cout << " pflow tracks " << pflowTracks.size() << endl;
                  for(vector<MyTrack>::const_iterator itrack = pflowTracks.begin();
                                                itrack!= pflowTracks.end(); itrack++){
	               double pt = itrack->pt();
                       //double pftype = itrack->pfType();
                       double charge = itrack->charge();
		       //                       cout << " pf track pt " << pt <<  " pftype "  << itrack->pfType() << " charge " << charge << endl;
                       double DR=deltaR( theTau.Eta(),itrack->eta(),  theTau.Phi(),itrack->phi()); 
	               if( DR < 0.4) {
			     momentum += *itrack;
		       }
	               if( DR < 0.1 && pt > ptmax && fabs(charge) > 0) {
	                     ptmax = pt;
                             leadingPFTrack = *itrack;
                      }           
                  } 
                  particleFlow.SetPx(momentum.px());
                  particleFlow.SetPy(momentum.py());  
                  particleFlow.SetPz(momentum.pz());

		  dEt_flow = particleFlow.Et() - mcTauJet.Et(); 
		  if(mcTauJet.Et()> 0) {                       
                       histograms->fill("h_pfParticleResolution",dEt_flow/mcTauJet.Pt());
	          }             
     

		  //            cout << "particleFlow  " << particleFlow.Et() << " et visibleTau " << mcTauJet.Et() << endl;
		 
	}
}
