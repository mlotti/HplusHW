#include "MyAnalysis/interface/MyAnalysis.h"


void MyAnalysis::backgroundAnalysisUsingMuons_w3j(MyEvent* event){

	//mcAnalysis->analyse(event);


// isolated electron veto

        double lepton_pt_max = 8;
        if(!electronVeto(event,lepton_pt_max)) return;
        eventCounter->addCount("electron veto");



// muon selection

	vector<const MyJet*> muons = muonSelection(event);

	if(muons.size() != 1) return;
        eventCounter->addCount("one isolated muon");

	MyJet theMuon = **muons.begin();

	if(event->muons.size() != 1) return;
        eventCounter->addCount("veto on other muons");

// tau jet veto

	// tauType = { CaloTau,PFTau,HardTau }
        //string tauType = "HardTau";
        string tauType = "PFTau";

        vector<const MyJet*> taus = tauVeto(event,tauType,theMuon);

	if( taus.size() > 0 ) return;
        eventCounter->addCount("tau-jet veto");

// MET
	MyMET mcMet   = event->mcMET;    
	double MCmet   = mcMet.value();

	histograms->book("h_mcMet",100,0,500);
        histograms->fill("h_mcMet",MCmet);

	//	MyMET met   = event->MET;
	 MyMET met   = type1MET(event,15,"MCJetCorrectorMcone5");
        //MyMET met   = event->MET;
        // metCorrection = "CaloMET_Type1Icone5",
        //                 "CaloMET_Type1Mcone5",
        //                 "CaloMET_NoHF",
        //                 "CaloMET_noHF_Type1Icone5",
        //                 "CaloMET_noHF_Type1Mcone5"
        //string metCorrection = "CaloMET_noHF_Type1Mcone5";
        //met.useCorrection(metCorrection);

	metResolutionAnalysis(met,event->getMCMET());

        if(!metCut(met)) return;
        eventCounter->addCount("MET cut");

// top mass reco

        topMassReco->analyse(&theMuon,event, int(cuts->getCutValue("topRecoAlgo")));
        //if(!topFound) return;
        //eventCounter->addCount("top quark found");

        int njets = topMassReco->njets();
        if(njets < 3) return;
        eventCounter->addCount("3 hadronic jets ");

        //double bestDiscriminator = (topMassReco->bestBJet()).tag("discriminator");
        //if(!cuts->applyCut("bTagDiscriminator", bestDiscriminator)) return;
        //eventCounter->addCount("b jet  discriminator cut");

        int taggedJets = 0;
        string jetCalibration = "MCJetCorrectorMcone5";
        vector<MyJet> bCandidates = event->getJets(jetCalibration);
        for(vector<MyJet>::const_iterator iJet = bCandidates.begin();
            iJet != bCandidates.end(); ++iJet) {
                eventCounter->addSubCount("bjets all cands");

                if(!cuts->applyCut("jetEtCut", iJet->Et())) continue;
                eventCounter->addSubCount("bjets Et cut");

                if(!cuts->applyCut("jetEtaCut", fabs(iJet->Eta()))) continue;
                eventCounter->addSubCount("bjets eta cut");

                if(cuts->applyCut("bVetoDiscriminator", iJet->tag("discriminator"))) continue;
                eventCounter->addSubCount("bjets discriminator");

                ++taggedJets;
        }

        if(taggedJets > 0) return;
        eventCounter->addCount("b jet veto cut");

        double bestDiscriminator = (topMassReco->bestBJet()).tag("discriminator");
        if(bestDiscriminator > 1.5 && !cuts->applyCut("bjetEtCut", topMassReco->bestBJet().Et())) return;
        //if(!cuts->applyCut("bjetEtCut", topMassReco->bestBJet().Et())) return;
	eventCounter->addCount("best b jet, Et cut");

        //if(!cuts->applyCut("bjetEtCut", topMassReco->secondbestBJet().Et())) return;
	//eventCounter->addCount("second best b jet, Et cut");

        //if(! topMassReco->twoBtagging(cuts->getCutValue("bTagDiscriminator"))) return;
	//eventCounter->addCount("two b jets");

        //if(!cuts->applyCut("topFitChi2", topMassReco->fitChi2())) return;
        //if(!cuts->applyCut("wMass", topMassReco->WMass())) return;
        //eventCounter->addCount("W mass cut");
  
        //if(!cuts->applyCut("topMass", topMassReco->topMass())) return;
        //eventCounter->addCount("top mass cut");

        double wMass = topMassReco->WMass();
        double topMass = topMassReco->topMass();

        if(cuts->applyCut("wMass", wMass)) return;
        eventCounter->addCount("W mass veto");

        if(cuts->applyCut("topMass", topMass)) return;
        eventCounter->addCount("top mass veto");

// transverseMass reco

        transverseMass(theMuon,met);
        if ( transverseMass(theMuon,met) > 100 )  eventCounter->addCount("mT > 100");

        eventFilter->saveEvent(event);
}
