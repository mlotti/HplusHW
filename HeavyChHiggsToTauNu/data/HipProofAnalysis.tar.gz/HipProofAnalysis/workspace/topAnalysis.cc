#include "MyAnalysis/interface/MyAnalysis.h"
#include "Framework/interface/Counter.h"

void MyAnalysis::topAnalysis(MyEvent* event){
        bool mcTau = true;
        //bool mcTau = false;

        bool isBkg = false;
        //bool isBkg = true;
        
	mcAnalysis->analyse(event);

// tau identification
        MyJet theTau;
        MyJet *tauPtr = 0;
        if(isBkg) {
                if(mcAnalysis->taus().size() > 0) return;
                eventCounter->addCount("zero MC taus");
        }
        else if(!mcTau) {
                // tauType = { CaloTau,CaloTauCorrected,HardTau,HardTauCorrected,PFTau }
                // CaloTauCorrected and HardTauCorrected use TauJet jet energy corrections
                //string tauType = "HardTauCorrected";
                string tauType = "HardTau";
                vector<const MyJet*> taus = tauSelection(event,tauType);

                if(taus.size() != 1) return;
                eventCounter->addCount("one tau found");
                theTau = **taus.begin();
                tauPtr = &theTau;
        }
        else {
                vector<MyMCParticle> visible_htaus = ::visibleTaus(event,37);
                if(visible_htaus.size() != 1) return;
                eventCounter->addCount("one visible tau");

                MyMCParticle tauParton = *(visible_htaus.begin());
                if(tauParton.Et() == 0) return;
                eventCounter->addCount("nonzero tau Et");
                theTau = mcAnalysis->mcParton(tauParton);
                if(theTau.Et() == 0) return;
                eventCounter->addCount("tau jet found");

                tauPtr = &theTau;
        }

// top mass reco
        topMassReco->analyse(tauPtr,event, int(cuts->getCutValue("topRecoAlgo")), mcAnalysis);
	//bool topFound = topMassReco->analyse(tauPtr,event, "trainMVAcomb", mcAnalysis);
	//bool topFound = topMassReco->analyse(tauPtr,event, "evalMVA", mcAnalysis);
        //if(!topFound) return;
        //eventCounter->addCount("top quark found");

	int njets = topMassReco->njets();
	if(njets < 3) return;
	eventCounter->addCount("3 hadronic jets ");

        if(!cuts->applyCut("bTagDiscriminator", topMassReco->bestBJet().tag("discriminator"))) return;
        eventCounter->addCount("b jet discriminator cut");

        if(!cuts->applyCut("bjetEtCut", topMassReco->bestBJet().Et())) return;
	eventCounter->addCount("best b jet, Et cut");

        if(!cuts->applyCut("topFitChi2", topMassReco->fitChi2())) return;
        if(!cuts->applyCut("wMass", topMassReco->WMass())) return;
        eventCounter->addCount("W mass cut");
  
        if(!cuts->applyCut("topMass", topMassReco->topMass())) return;
        eventCounter->addCount("top mass cut");


        eventFilter->saveEvent(event);
        //std::cerr << "End of topAnalysis, run " << event->runNumber
        //          << " event " << event->eventNumber << std::endl;
}
