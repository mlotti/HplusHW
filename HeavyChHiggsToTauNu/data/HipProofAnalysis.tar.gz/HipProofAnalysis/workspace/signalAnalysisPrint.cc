#include "MyAnalysis/interface/MyAnalysis.h"

double phifun(double,double);

void MyAnalysis::signalAnalysisPrint(MyEvent* event){

	mcAnalysis->analyse(event);


// trigger

//	bool triggerDecision = tauMETtriggerEmulator(event);//triggerTausFound(event);
	//	if(!triggerDecision) return;
	//	eventCounter->addCount("trigger tauMET");

// lepton veto

	double lepton_pt_max = 8;
	if(!electronVeto(event,lepton_pt_max)) return;
	eventCounter->addCount("electron veto");

	//	lepton_pt_max = 4;
	//        if(!muonVeto(event,lepton_pt_max)) return;
    
        if ( event->muons.size() > 0) return;
        eventCounter->addCount("muon veto");


// tau identification

	// tauType = { CaloTau,PFTau,HardTau }
	//        string tauType = "CaloTau";
	string tauType = "HardTau";
	vector<const MyJet*> taus = tauSelection(event,tauType);

	if(taus.size() != 1) return;
	eventCounter->addCount("one tau found");
	MyJet theTau = **taus.begin();

	//	if(!rtauCut(theTau)) return;
	eventCounter->addCount("tau Rtau cut");	

	vector<MyMCParticle> visible_taus = ::visibleTaus(event,37);
        MyMCParticle visibleTau(0,0,0,0);
	for(vector<MyMCParticle>::const_iterator i = visible_taus.begin();
                                                 i!= visible_taus.end(); i++){
		double DR = deltaR(theTau.eta(),i->Eta(),theTau.phi(),i->Phi());
                if(DR > 0.4) continue;
                visibleTau = *i;
        }
        if(!histograms->booked("h_etMcTau_rtau") ) histograms->book("h_etMcTau_rtau",21,80,500);
        if(!histograms->booked("h_etTaujetPurity") ) histograms->book("h_etTaujetPurity",21,80,500);
        if(visibleTau.Pt() > 0 )  histograms->fill("h_etMcTau_rtau",visibleTau.Pt());
        if(visibleTau.Pt() > 0 )  histograms->fill("h_etTaujetPurity",theTau.Et());

	tauResolutionAnalysis->analyse(theTau,mcAnalysis->visibleTau(theTau));


	     ////////////all jets and hard tracks
             if(!histograms->booked("h_trackResolution100") ) histograms->book("h_trackResolution100",100,-5,5);

	      cout <<  "  " << endl; 
    
              vector<MyTrack> tauTracks = theTau.tracks; 

	     cout <<  " tau jet, Et " <<theTau.Et() <<  " tau jet, Eta " <<theTau.Eta()  <<  " tracks " << tauTracks.size() << endl;
        
	       for(vector<MyTrack>::iterator iTrack = tauTracks.begin();
                                    iTrack != tauTracks.end(); iTrack++){
		    if(iTrack->Pt() > 1){
			 double trackEta = iTrack->eta();
			 double trackPhi = iTrack->phi();
            		 double DR = deltaR(theTau.eta(),trackEta,
                                            theTau.phi(),trackPhi);
                         cout << " track in tau, pt " << iTrack->Pt() << " DR " << DR << endl;

                         if( DR < 0.07 ) {
                         double drmin = 9999;
			 //                         MyMCParticle matchingParticle(0,0,0,0);
                         vector<MyMCParticle>::iterator matchingParticle;
                         vector<MyMCParticle> mcParticles = event->mcParticles;
                         for(vector<MyMCParticle>::iterator imc = mcParticles.begin();
	                                                    imc!= mcParticles.end(); imc++){
			   //			       if ( imc->pid == 22 ) continue;
			   //			       if ( imc->pid == 12 ) continue;
			   //                               if ( imc->pid == 14 ) continue;
			   //			       if ( imc->pid == 16 ) continue;
            		       double DR = deltaR(imc->eta(),trackEta,imc->phi(),trackPhi);
                               if ( DR < 0.6 ) cout << " part in 0.6, id " << imc->pid << " pt " << imc->Pt() << " DR " << DR <<  endl;

                               if( abs(imc->pid) != 22 && abs(imc->pid) != 111 && abs(imc->pid) != 12 && abs(imc->pid) != 14  && abs(imc->pid) != 16) {

				 //				 cout << " track,id " << imc->pid << " pt " << imc->Pt() << " DR " << DR <<  endl;  
    
                                    if( DR < drmin && abs(imc->pid) != 22 ) {
				        drmin = DR;
                                        matchingParticle = imc;
                                    }
                               }
                         }
                         if ( drmin < 9999 ) { 
                                   int mother1 = 0;
                                   vector<int> motherList = matchingParticle->mother; 
                                   if(motherList.size() > 0) mother1 = (*motherList.begin());
                                   if ( matchingParticle->Pt() > 0) {
				        double trackResolution = (matchingParticle->Pt()-iTrack->Pt()) / matchingParticle->Pt();
	                                histograms->fill("h_trackResolution100",trackResolution);
					/*
                                        double DRsquark  = 99;
                                        if ( sQuarkFromW.Et() > 0 ) DRsquark=deltaR(matchingParticle->Eta(),sQuarkFromW.Eta(),matchingParticle->Phi(),sQuarkFromW.Phi());

                                        double DRcquark  = 99;
                                        if ( cQuarkFromW.Et() > 0 ) DRcquark  = deltaR(matchingParticle->Eta(),cQuarkFromW.Eta(),matchingParticle->Phi(),cQuarkFromW.Phi());
					*/
				   cout << " matchingParticle, id " << matchingParticle->pid << " pt " << matchingParticle->Pt() << " Min DR " << drmin <<  " mother1  "  << mother1 << endl;
				   }
		         }
	            }
	        }      
	 }




        eventFilter->saveEvent(event);

// tau jet veto

	// tauType = { CaloTau,PFTau,HardTau }
        tauType = "HardTau";

        vector<const MyJet*> vetoTaus = tauVeto(event,tauType,theTau);

	if(vetoTaus.size() > 0 ) return;
        eventCounter->addCount("tau-jet veto");

// MET

//	MyMET met   = event->MET;   
//	MyMET met   = type1METtau(event,taus,15,"MCJetCorrectorMcone5");
        MyMET met   = event->MET;
        // metCorrection = "CaloMET_Type1Icone5",
        //                 "CaloMET_Type1Mcone5",
        //                 "CaloMET_NoHF",
        //                 "CaloMET_noHF_Type1Icone5",
        //                 "CaloMET_noHF_Type1Mcone5"
        string metCorrection = "CaloMET_noHF_Type1Mcone5";
        met.useCorrection(metCorrection);

	/*
        MyGlobalPoint type1METCorr;
	type1METCorr.name = "type1METCorrection";
	type1METCorr.x    = 0;
	type1METCorr.y    = 0;
	vector<MyJet> jets = event->getJets("MCJetCorrectorMcone5");
	for(vector<MyJet>::const_iterator ijet = jets.begin();
                                          ijet!= jets.end(); ijet++){
		double DR = deltaR(theTau.eta(),ijet->eta(),theTau.phi(),ijet->phi());
                if(DR < 0.4) continue;
		double corr = ijet->getCorrectionFactor("MCJetCorrectorMcone5");
		if(ijet->Et()/corr > 15 ){
			type1METCorr.x += -ijet->Ex()/corr*(corr - 1);
			type1METCorr.y += -ijet->Ey()/corr*(corr - 1);
		}
	}

	MyMET met   = event->getMET();
	met.useCorrection("muonCorrection");

	//        cout << " uncorr met " << met.value() << endl;
	met.corrections.push_back(type1METCorr);
	met.useCorrection("type1METCorrection");

        double Met = met.value();
	//        cout << " corr met " << Met << endl;
	*/

	MyMET mcMet   = event->getMCMET();
	cout << " Met "  <<  met.value() << " mcMet "  <<  mcMet.value()  << " mt " <<  transverseMass(theTau,met) << endl;
  
	metResolutionAnalysis(met,event->getMCMET());

	if(!metCut(met)) return;
	eventCounter->addCount("MET cut");

	//	metResolutionAnalysis(met,event->getMCMET());

// top mass reco

	topMassReco->analyse(&theTau,event, int(cuts->getCutValue("topRecoAlgo")));
        //if(!topFound) return;
        //eventCounter->addCount("top quark found");

	int njets = topMassReco->njets();
	if(njets < 3) return;
	eventCounter->addCount("3 hadronic jets ");
        
	double bestDiscriminator = (topMassReco->bestBJet()).tag("discriminator");
        if(!cuts->applyCut("bTagDiscriminator", bestDiscriminator)) return;
        eventCounter->addCount("b jet  discriminator cut");

        if(!cuts->applyCut("bjetEtCut", topMassReco->bestBJet().Et())) return;
	eventCounter->addCount("best b jet, Et cut");

        if(!cuts->applyCut("topFitChi2", topMassReco->fitChi2())) return;
        if(!cuts->applyCut("wMass", topMassReco->WMass())) return;
        eventCounter->addCount("W mass cut");

        if(!cuts->applyCut("topMass", topMassReco->topMass())) return;
        eventCounter->addCount("top mass cut");

// transverseMass reco

        transverseMass(theTau,met);
        if ( transverseMass(theTau,met) > 100 )  eventCounter->addCount("mT > 100");
}
