#include "MyAnalysis/interface/MyAnalysis.h"

MyAnalysis::MyAnalysis(MyInput input){
	init(input);
        hardTauAlreadyCorrected = false;
        
        if ((int)(cuts->getCutValue("TauIDAnalysis")) == 1)
          tauIdAnalysis = new TauIdAnalysis();
        else
          tauIdAnalysis = 0;
        
}
MyAnalysis::~MyAnalysis(){
//	print();
//	plotHistograms();

        if (tauIdAnalysis) delete tauIdAnalysis; // Writes histograms
}

void MyAnalysis::beginEvent(MyEvent *event) {
        hardTauAlreadyCorrected = false;
}

/////////////////////////////////////////////////////////////////////////////

void MyAnalysis::setDefaultCuts(){

    ////////////////////////////////////////////////////////////////////////
    // Defining default cuts
    ////////////////////////////////////////////////////////////////////////

        cuts->bookGreaterThanCut("triggerMETcut", 50);
        cuts->bookLessThanCut("leptonSearchCone", 0.6);
        cuts->bookLessThanCut("leptonIsolCone", 0.3);
        cuts->bookGreaterThanCut("isolationTrackPt", 0.5);

        cuts->bookGreaterThanCut("muonPtCut", 100);
        cuts->bookLessThanCut("matchingCone", 0.1);
        cuts->bookLessThanCut("signalCone", 0.04);
        cuts->bookLessThanCut("isolationCone", 0.45);
        cuts->bookLessThanCut("track_Zip", 0.1);

        cuts->bookLessThanCut("matchingConeVeto", 0.1);
        cuts->bookLessThanCut("signalConeVeto", 0.13);
        cuts->bookLessThanCut("isolationConeVeto", 0.4);
        cuts->bookLessThanCut("isolationTrackPtVeto", 1.0);

        cuts->bookGreaterThanCut("Rtau", 0.8);
        cuts->bookGreaterThanCut("tauEtCut", 100);
        cuts->bookLessThanCut("tauEtaCut", 2.0);
        cuts->bookLessThanCut("tauProngs", 1); // selection: 1,3,any
        cuts->bookGreaterThanCut("leadingTrackPtCut", 20);
        cuts->bookGreaterThanCut("tauEtCutVeto", 10);
        cuts->bookLessThanCut("tauEtaCutVeto", 2.5);
        cuts->bookGreaterThanCut("leadingTrackPtVeto", 8);
        cuts->bookLessThanCut("etHcalOverTracksVeto", 0);
        cuts->bookGreaterThanCut("MET", 100);
        cuts->bookGreaterThanCut("deltaPhiCut", 90);
        cuts->bookLessThanCut("a1mass", 5.3);
        cuts->bookGreaterThanCut("jetEtCut",  20);
        cuts->bookLessThanCut("jetEtaCut", 2.5);
        cuts->bookGreaterThanCut("nJetsCut", 0);

        cuts->bookLessThanCut("topRecoAlgo", 2);
        cuts->bookLessThanCut("topFitChi2", 9.2);
        cuts->bookGreaterThanCut("bTagDiscriminator", 2);
        cuts->bookLessThanCut("bVetoDiscriminator", 1.0);
        cuts->bookGreaterThanCut("bjetEtCut", 30);
        cuts->bookInsideCut("topMass", 170, 180);
        cuts->bookInsideCut("wMass", 75, 85);

        cuts->bookLessThanCut("muonIp2DCut", 0.01);
        cuts->bookLessThanCut("muonChi2Cut", 6);
        cuts->bookLessThanCut("muonIpzCut", 0.05);

        // Tau identification cuts
        cuts->bookGreaterThanCut("tauIDEtCut", 100);
        cuts->bookLessThanCut(   "tauIDetaCut", 2.0);
        cuts->bookGreaterThanCut("tauIDRtauCut", 0.8);
        cuts->bookLessThanCut(   "tauIDSignalCone", 0.07);
        cuts->bookLessThanCut(   "tauIDIsolationCone", 0.45);
        cuts->bookLessThanCut(   "tauIDIsolationPtMin", 0.5);
        cuts->bookLessThanCut(   "tauIDIsolationIPzMax", 0.1); // in cm
        cuts->bookInsideCut(     "tauIDECALIsolationCone", 0.10, 0.45);
        cuts->bookLessThanCut(   "tauIDECALIsolation", 1.5);
        cuts->bookLessThanCut(   "tauIDPFECALIsolation", 1.5);
        cuts->bookLessThanCut(   "tauIDProngs", 1);
        cuts->bookInsideCut(     "tauIDLdgIPtCut", 0.00, 0.03); // in cm
        cuts->bookLessThanCut(   "tauIDLdgPtCut", 20);
        cuts->bookLessThanCut(   "tauIDLdgHitsCut", 8);
        cuts->bookLessThanCut(   "tauIDLdgChi2Cut", 10);
        cuts->bookLessThanCut(   "tauIDLdgHitsChi2Cut", 10);
        cuts->bookInsideCut(     "tauIDNeutralHadronCone", 0.00, 0.45);
        cuts->bookLessThanCut(   "tauIDNeutralHadronCut", 0.1);
        cuts->bookLessThanCut(   "tauIDPFNeutralHadronCut", 2.5);
        cuts->bookGreaterThanCut("tauIDElectronCut", -0.98);
        
        cuts->bookLessThanCut("TauIDAnalysis", 0);

        
        // These cuts are disabled by default
        cuts->bookInsideCut("topThetaQQbar", 0, 10, false);
        cuts->bookInsideCut("topThetaWb", 0, 10, false);
        cuts->bookGreaterThanCut("topPtCut", 0, false);
        

        // These cuts were not used anywhere
        //cuts->bookLessThanCut("etHcalCutElectron", -0.9);
        //cuts->bookLessThanCut("etHcalCutHadron", -0.9);
}

/////////////////////////////////////////////////////////////////////////////

void MyAnalysis::bookHistograms(){

	histograms = new MyHistogram("histograms.root");
	tauResolutionAnalysis = new TauResolutionAnalysis(histograms);
	hardTauAlgorithm = new HardTauAlgorithm(histograms, eventCounter);
	topMassReco = new TopMassReco(histograms,eventCounter, cuts);
	mcAnalysis = new HeavyChHiggsMCAnalysis(histograms);
	histograms->fillLuminosity(eventCounter->getLuminosity());
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////


void MyAnalysis::analyse(MyEvent* event){

//	generatorLevelAnalysis(event);
//	if(event->eventNumber != 623) return;

//	cout << "begin analysis .,. " << event->eventNumber << endl;
  	eventCounter->addCount("all events");

	signalAnalysis(event);
	//		signalAnalysisPrint(event);
        //backgroundAnalysisUsingMuons_tt(event);
        //backgroundAnalysisUsingMuons_w3j(event);
	//    	backgroundAnalysisUsingMuonsPrint(event);
        //backgroundAnalysisQCD(event);
//	pflowAnalysis(event);

//	nmssmAnalysis(event);

        //topAnalysis(event);
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void MyAnalysis::print(){

	// syntax combineChannel("channel_name",first_label,last_label),
	// combined all labels between first_label,..,last_label under channel_name.
//	eventCounter->combineChannels("signal",1,10);
//        eventCounter->combineChannels("tt",40,49);

        cuts->print();

	eventCounter->print();

	//double sOverB = eventCounter->getSignalOverBackgr();
	//double significance = eventCounter->getSignificance();
	double nPassedEvents = eventCounter->getNormalizedNumberOfEventsPassingCuts();
	scannerFill("nPassedEvents",nPassedEvents);

	event->printCorrections();
}

/////////////////////////////////////////////////////////////////////////////

void MyAnalysis::plotHistograms(){

        histograms->normalize(eventCounter);
        delete histograms; // saving
	delete tauResolutionAnalysis;
        delete timer; // timer printout
}
