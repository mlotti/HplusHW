void muonEfficiency(){

	TString dataLabel = "tt0j";


	TFile file("../histograms.root");

	TH1F* h_y1  = (TH1F*)file.Get("h_etaMcMuon_cand_"+dataLabel+";1");
	TH1F* h_y2  = (TH1F*)file.Get("h_etaMcMuon_isolation_"+dataLabel+";1");
        TH1F* h_x   = (TH1F*)file.Get("h_etaMcMuon_"+dataLabel+";1");

	cout << "h_y1 entries    " << h_y1->GetEntries() << endl;
	cout << "h_y2 entries    " << h_y2->GetEntries() << endl;
        cout << "h_x  entries    " << h_x->GetEntries() << endl;

	double maximum = -1E10;
	int nbins = h_x->GetNbinsX();
	const int N = nbins;
	double x[N],y[N],dx[N],dy[N],y2[N],dy2[N],;
	for(int i = 1; i <= nbins; i++){

		double reso1 = 0;
		double reso2 = 0;
		if(h_x->GetBinContent(i) > 0) reso1 = h_y1->GetBinContent(i) / h_x->GetBinContent(i);
		if(h_x->GetBinContent(i) > 0) reso2 = h_y2->GetBinContent(i) / h_x->GetBinContent(i);
		y[i-1]   = reso1;
                y2[i-1]  = reso2;
		x[i-1]   = h_x->GetBinCenter(i); 
		dx[i-1]  = h_x->GetBinWidth(i)/2;
		dy[i-1]  = 0;
		dy2[i-1] = 0;
		//cout << "x = " << x[i-1] << " " << dx[i-1] 
                //     << ",   y = " << y[i-1] << " " << dy[i-1] <<endl;
		if(y[i-1] > maximum) maximum = y[i-1];
	}

	gROOT->LoadMacro("MyGraph.cxx");


	MyGraph* graph = new MyGraph("muonEff");
	graph->setFigureXmin(h_x->GetBinLowEdge(1));
        graph->setFigureXmax(h_x->GetBinLowEdge(1) + N*h_x->GetBinWidth(1));
        graph->setFigureYmin(0);
        graph->setFigureYmax(1.1*maximum);
        graph->setXlabel("Muon eta");
        graph->setYlabel("Efficiency");
//	graph->legend(0.1,0.2,0.5,0.5);

	graph->drawFrame();
	graph->draw(N,x,y,dx,dy,2,20,"test1");
        graph->draw(N,x,y2,dx,dy2,4,20,"test2");
	graph->text(0.1,0.9,"test");
	graph->save();

//	exit(0);
}
