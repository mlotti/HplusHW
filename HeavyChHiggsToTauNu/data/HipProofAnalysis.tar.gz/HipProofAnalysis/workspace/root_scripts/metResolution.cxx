void metResolution(){

	TString dataLabel = "QCD_Pt_120_170";


	TFile file("../histograms.root");

	TH1F* met   = (TH1F*)file.Get("h_met_"+dataLabel+";1");
        TH1F* mcmet = (TH1F*)file.Get("h_mcMET_"+dataLabel+";1");

	cout << "met entries    " << met->GetEntries() << endl;
        cout << "mc met entries " << mcmet->GetEntries() << endl;

	double maximum = -1E10;
	int nbins = met->GetNbinsX();
	const int N = nbins;
	double x[N],y[N],dx[N],dy[N];
	for(int i = 1; i <= nbins; i++){
		//cout << met->GetBinCenter(i) << " " << met->GetBinContent(i) << endl;

		double reso = 0;
////		if(mcmet->GetBinContent(i) > 0) reso = met->GetBinContent(i) / mcmet->GetBinContent(i);
		reso = met->GetBinContent(i) - mcmet->GetBinContent(i);
		y[i-1] = reso;
		x[i-1] = met->GetBinCenter(i); 
		dx[i-1] = 0;
		dy[i-1] = 0;
		//cout << "x = " << x[i-1] << " " << dx[i-1] 
                //     << ",   y = " << y[i-1] << " " << dy[i-1] <<endl;
		if(y[i-1] > maximum) maximum = y[i-1];
	}

	gROOT->LoadMacro("MyGraph.cxx");

	MyGraph* graph = new MyGraph("metResolution");
	graph->setFigureXmin(mcmet->GetBinLowEdge(1));
        graph->setFigureXmax(mcmet->GetBinLowEdge(1) + N*mcmet->GetBinWidth(1));
        graph->setFigureYmin(0);
        graph->setFigureYmax(1.1*maximum);
        graph->setXlabel("MC MET (GeV)");
        graph->setYlabel("MET- MCMET");

        graph->drawFrame();
	graph->draw(N,x,y,dx,dy);
	//graph->text(0.1,0.8,"testi");
	delete graph;

	exit(0);
}
