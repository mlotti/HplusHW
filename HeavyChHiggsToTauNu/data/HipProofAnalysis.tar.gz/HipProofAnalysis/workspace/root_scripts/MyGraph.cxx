#include "TCanvas.h"
#include "TROOT.h"

class MyGraph {
    public:
	MyGraph(TString);
	~MyGraph();

	void setFigureXmin(double);
        void setFigureXmax(double);
        void setFigureYmin(double);
        void setFigureYmax(double);

	void setXlabel(TString);
        void setYlabel(TString);

	void drawFrame();
        void draw(int,double*,double*,double*,double*);
	void draw(int,double*,double*,double*,double*,double color = 1,double marker = 20,TString name = "");

	void text(double,double,TString,double textSize = 0.04);
	void legend(double,double,double,double);
	void drawLegend(double textSize = 0.04);

	void save();
	void save(TString);

    private:
	double xmin,xmax,ymin,ymax;
	TCanvas* canvas;
	TString canvasName,xLabel,yLabel;
	TGraphErrors* legendGraphs[10];
	TLatex* tlatex;
	TLegend* theLegend;
	int nLegends;
	bool firstGraph;
};

MyGraph::MyGraph(TString name){
	canvasName = name;

        theLegend = new TLegend(0.5,0.3,0.9,0.5);
        theLegend->SetBorderSize(2);
        theLegend->SetFillStyle(0);
	nLegends  = 0;
	firstGraph = true;
}

MyGraph::~MyGraph(){
	save();
}

void MyGraph::setFigureXmin(double value){
	xmin = value;
}

void MyGraph::setFigureXmax(double value){
        xmax = value;
}

void MyGraph::setFigureYmin(double value){
        ymin = value;
}

void MyGraph::setFigureYmax(double value){
        ymax = value;
}

void MyGraph::setXlabel(TString name){
	xLabel = name;
}

void MyGraph::setYlabel(TString name){
        yLabel = name;
}

void MyGraph::draw(int N, double* x,double* y,double* dx, double* dy, double color, double marker,TString name){

	const int NN = N;
	double xx[NN];
        double yy[NN];

	for(int i = 0; i < N; i++){
		xx[i] = x[i];
		yy[i] = y[i];
		cout << i << " " << x[i] << " " << y[i] << endl;
	}

	TGraphErrors* graph = new TGraphErrors(N,x,y,dx,dy);
	graph->SetMarkerStyle(marker);
        graph->SetMarkerColor(color);
	if(firstGraph){
		graph->GetXaxis()->SetRangeUser(xmin,xmax);
	        graph->GetXaxis()->SetTitle(xLabel);
	        graph->GetYaxis()->SetRangeUser(ymin,ymax);
		graph->GetYaxis()->SetTitle(yLabel);
		graph->DrawClone("AP");
		firstGraph = false;
	}else{
		graph->DrawClone("P");
	}

	if(name != "") {
		if(nLegends >= 10) cout << "Too many graphs for legend, please increase the maximum (MyGraph.cxx)" << endl;
		legendGraphs[nLegends] = new TGraphErrors(*graph);
		theLegend->AddEntry(legendGraphs[nLegends],name,"p");
		nLegends++;
	}
}

void MyGraph::drawFrame(){

        gROOT->LoadMacro("tdrstyle.cxx");
        setTDRStyle();

        canvas = new TCanvas(canvasName,"",500,500);
        canvas->SetFillColor(0);

        canvas->cd();
/*
        TH2F* frame = new TH2F("frame","",10,xmin,xmax,10,ymin,ymax);
        frame->SetXTitle(xLabel);
        frame->SetYTitle(yLabel);
        frame->SetStats(0);
        frame->Draw();
*/
}

void MyGraph::text(double xPos,double yPos,TString theText,double textSize){

	double x = xmin + (xmax - xmin)*xPos;
        double y = ymin + (ymax - ymin)*yPos;

	tlatex = new TLatex(x,y,theText);
	tlatex->SetTextSize(textSize);
	tlatex->DrawClone();
}

void MyGraph::legend(double xmin,double ymin,double xmax,double ymax){
	theLegend->SetX1(xmin);
        theLegend->SetX2(xmax);
        theLegend->SetY1(ymin);
        theLegend->SetY2(ymax);
}

void MyGraph::drawLegend(double textSize){
	canvas->cd();
	theLegend->SetTextSize(textSize);
        theLegend->DrawClone("same");
}


void MyGraph::save(TString name){
	drawLegend();
////	canvas->Print(name);
}

void MyGraph::save(){
        TString output = canvasName + ".C";
	save(output);
}

