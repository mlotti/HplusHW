#include "MyAnalysis/interface/MyAnalysis.h"
#include "Framework/interface/Counter.h"

#include <TStopwatch.h>

double phifun(double,double);

void MyAnalysis::signalAnalysis(MyEvent* event){
/*
        // event number and run time output
        static TStopwatch myTimer;
        static int myReadEventCount = 0;
        if (myReadEventCount == 0) myTimer.Start();
        ++myReadEventCount;
        
        if (!(myReadEventCount % 1000)) {
          myTimer.Stop();
          cout << "Event: " << myReadEventCount << endl;
          myTimer.Print("-u");
          myTimer.Reset();
          myTimer.Start();
        }
*/
	mcAnalysis->analyse(event);
	
// trigger

//	bool triggerDecision = tauMETtriggerEmulator(event);//triggerTausFound(event);
	//	if(!triggerDecision) return;
	//	eventCounter->addCount("trigger tauMET");

// lepton veto

	double lepton_pt_max = 8;
	if(!electronVeto(event,lepton_pt_max)) return;
	eventCounter->addCount("electron veto");

	lepton_pt_max = 4;
	if(!muonVeto(event,lepton_pt_max)) return;
        eventCounter->addCount("muon veto");


// tau identification

        // All tau selection is done in tauSelection and code is capsulated
        // into the RecoTauJetCandidate class

	// tauType = { CaloTau,CaloTauCorrected,HardTau,HardTauCorrected,PFTau }
	// CaloTauCorrected and HardTauCorrected use TauJet jet energy corrections
	string tauType = "CaloTauCorrected";
	//string tauType = "HardTau";
	vector<const MyJet*> tauCandidates = tauSelection(event,tauType);

        // TEMPORARY CODE
////        return;
        
        vector<const MyJet*> taus;
        for(vector<const MyJet*>::iterator iJet = tauCandidates.begin(); iJet != tauCandidates.end(); ++iJet) {
                //if((*iJet)->E() == 0) continue;
                //if(!rtauCut(**iJet)) continue;
                eventCounter->addSubCount("tau Rtau cut");	
                taus.push_back(*iJet);
        }

	if(taus.size() != 1) return;
	eventCounter->addCount("one tau found");
	MyJet theTau = **taus.begin();

        //if(!rtauCut(theTau)) return;
        //eventCounter->addCount("tau Rtau cut");	

        //if(!tauSecondaryVertexCut(theTau)) return;
        //eventCounter->addCount("secondary vertex");


	vector<MyMCParticle> visible_taus = ::visibleTaus(event,tauOriginFromLabel(eventCounter));
        MyMCParticle visibleTau(0,0,0,0);
	for(vector<MyMCParticle>::const_iterator i = visible_taus.begin();
                                                 i!= visible_taus.end(); i++){
		double DR = deltaR(theTau.eta(),i->Eta(),theTau.phi(),i->Phi());
                if(DR > 0.4) continue;
                visibleTau = *i;
        }
        if(!histograms->booked("h_etMcTau_rtau") ) histograms->book("h_etMcTau_rtau",21,80,500);
        if(!histograms->booked("h_etSelectedRealTau") ) histograms->book("h_etSelectedRealTau",21,80,500);
        if(!histograms->booked("h_etSelectedTau") ) histograms->book("h_etSelectedTau",21,80,500);
        if(visibleTau.Pt() > 0 )  histograms->fill("h_etMcTau_rtau",visibleTau.Pt());
        if(visibleTau.Pt() > 0 )  histograms->fill("h_etSelectedRealTau",theTau.Et());
        histograms->fill("h_etSelectedTau",theTau.Et());
	tauResolutionAnalysis->analyse(theTau,mcAnalysis->visibleTau(theTau));


	//        eventFilter->saveEvent(event);

// tau jet veto

	// tauType = { CaloTau,PFTau,HardTau }
        //tauType = "HardTau";
        //tauType = "PFTau";

        vector<const MyJet*> vetoTaus = tauVeto(event,tauType,theTau);

        vector<MyMCParticle> visible_wtaus = ::visibleTaus(event,24);

        if(!histograms->booked("h_etMcTauVeto_selected") ) histograms->book("h_etMcTauVeto_selected",18,20,200);
        if(!histograms->booked("h_etMcTauVeto_all") ) histograms->book("h_etMcTauVeto_all",18,20,200);
        if(!histograms->booked("h_etSelectedRealVetoTau") ) histograms->book("h_etSelectedRealVetoTau",18,20,200);
        if(!histograms->booked("h_etSelectedVetoTau") ) histograms->book("h_etSelectedVetoTau",18,20,200);

	for(vector<MyMCParticle>::const_iterator i = visible_wtaus.begin();
                                                 i!= visible_wtaus.end(); i++){
                  histograms->fill("h_etMcTauVeto_all",i->Pt());
        }


        for(vector<const MyJet*>::iterator iJet = vetoTaus.begin();
                                           iJet!= vetoTaus.end(); iJet++){
             histograms->fill("h_etSelectedVetoTau",(*iJet)->Et());	     
	     for(vector<MyMCParticle>::const_iterator i = visible_wtaus.begin();
                                                      i!= visible_wtaus.end(); i++){
		  double DR = deltaR((*iJet)->eta(),i->Eta(),(*iJet)->phi(),i->Phi());
                  if(DR < 0.4) histograms->fill("h_etMcTauVeto_selected",i->Pt());
                  if(DR < 0.4 ) histograms->fill("h_etSelectedRealVetoTau",(*iJet)->Et());
	     }
        }


	if(vetoTaus.size() > 0 ) return;
	eventCounter->addCount("tau-jet veto");

// MET

//	MyMET met   = event->MET;
        // metCorrection = "CaloMET_Type1Icone5",
        //                 "CaloMET_Type1Mcone5",
        //                 "CaloMET_NoHF",
	//		   "CaloMET_noHF_Type1Icone5",
        //                 "CaloMET_noHF_Type1Mcone5"
        //string metCorrection = "CaloMET_noHF_Type1Mcone5";
        //met.useCorrection(metCorrection);
	MyMET met   = type1METtau(event,taus,15,"MCJetCorrectorMcone5");

	metResolutionAnalysis(met,event->getMCMET());

        if(!metCut(met)) return;
	eventCounter->addCount("MET cut");
/*
        double dphiTauMet=0;
        if(!metIsolation(event, theTau, met, dphiTauMet)) return;
        eventCounter->addCount("MET not isolated");
*/


// top mass reco
	topMassReco->analyse(&theTau,event, int(cuts->getCutValue("topRecoAlgo")));
        //if(!topFound) return;
        //eventCounter->addCount("top quark found");

	int njets = topMassReco->njets();
	if(njets < 3) return;
	eventCounter->addCount("3 hadronic jets ");

        if(!cuts->applyCut("bTagDiscriminator", topMassReco->bestBJet().tag("discriminator"))) return;
        eventCounter->addCount("b jet discriminator cut");

        if(!cuts->applyCut("bjetEtCut", topMassReco->bestBJet().Et())) return;
	eventCounter->addCount("best b jet, Et cut");

        if(!cuts->applyCut("topFitChi2", topMassReco->fitChi2())) return;
        if(!cuts->applyCut("wMass", topMassReco->WMass())) return;
        eventCounter->addCount("W mass cut");
  
        if(!cuts->applyCut("topMass", topMassReco->topMass())) return;
        eventCounter->addCount("top mass cut");


        eventFilter->saveEvent(event);

// transverseMass reco

        double tmass = transverseMass(theTau,met);
        if ( tmass > 100 )  eventCounter->addCount("mT > 100");

	double dphiTauMet = 180/3.14159*deltaPhi(theTau.phi(),met.phi());
        if ( dphiTauMet  < cuts->getCutValue("deltaPhiCut"))  return;
        histograms->book("h_transverseMassPhicut",100,0,500);
        histograms->fill("h_transverseMassPhicut",tmass);

        eventCounter->addCount("deltaPhi(tau,Met) cut");
}
