#include "MyAnalysis/interface/MyAnalysis.h"
double phifun(double,double);

#include "HiggsAnalysis/HeavyChHiggsToTauNu/interface/MyGlobalPoint.h"


void MyAnalysis::backgroundAnalysisUsingMuonsPrint(MyEvent* event){

  //  	mcAnalysis->analyse(event);

  //    	cout << "begin analysis .,." << endl;
	//  	eventCounter->addCount("all events");

  

	///////////////////////////////////////////////////////////   MC info

        TLorentzVector mcMuonFromW(0,0,0,0);
        TLorentzVector mcNuFromW(0,0,0,0);
        TLorentzVector mcElectronFromW(0,0,0,0);
        TLorentzVector mcTauFromW(0,0,0,0);
        TLorentzVector mcTauNuFromW(0,0,0,0);
        TLorentzVector uQuarkFromW(0,0,0,0);
        TLorentzVector dQuarkFromW(0,0,0,0);
        TLorentzVector sQuarkFromW(0,0,0,0);
        TLorentzVector cQuarkFromW(0,0,0,0);
	TLorentzVector neutrinoMomentum(0,0,0,0);
        TLorentzVector visibleTauPlus(0,0,0,0);
        TLorentzVector visibleTauMinus(0,0,0,0);
        TLorentzVector leadingTauTrack(0,0,0,0);
        vector<TLorentzVector> chargedPionsMCplus;
        vector<TLorentzVector> neutralPionsMCminus;
        vector<TLorentzVector> chargedPionsMCminus;
        vector<TLorentzVector> neutralPionsMCplus;
        vector<TLorentzVector> mcNeutrinos;
        vector<TLorentzVector> chargedPionsFromTau;
        vector<TLorentzVector> neutralPionsFromTau;
        chargedPionsFromTau.clear();
        neutralPionsFromTau.clear();
        mcNeutrinos.clear();        
        chargedPionsMCplus.clear();
        neutralPionsMCminus.clear();
        chargedPionsMCminus.clear();
        neutralPionsMCplus.clear();
        int nChargedPions = 0; 
        int nNeutralPions = 0; 
        vector<MyJet> Bquarks;
        Bquarks.clear();
        vector<MyJet> Cquarks;
        Cquarks.clear();
        vector<MyJet> BquarksFromTop;
        BquarksFromTop.clear();
        vector<MyJet> electronsFromB,eNuFromB;
        electronsFromB.clear();eNuFromB.clear();
        bool taufromW = false;	
        double ptTrack =0;

        if(!histograms->booked("h_ptbQuarkFromTop") ) histograms->book("h_ptbQuarkFromTop",100,0,250);
        if(!histograms->booked("h_etabQuarkFromTop") ) histograms->book("h_etabQuarkFromTop",100,-5,5);  
        if(!histograms->booked("h_electronFromB") ) histograms->book("h_electronFromB",100,0,250);
        if(!histograms->booked("h_eNuFromB") ) histograms->book("h_eNuFromB",100,0,250);

        vector<MyMCParticle>::const_iterator mcParticleEnd =
	  event->mcParticles_end();
	vector<MyMCParticle>::const_iterator imc;
        for(imc = event->mcParticles_begin();
	    imc != mcParticleEnd; ++imc) {

            TLorentzVector mcParticle(0,0,0,0);
            mcParticle.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->E());

            int mother1 = 0;
            vector<int>::const_iterator iMotherEnd = imc->mother_end();
            vector<int>::const_iterator iMotherBegin = imc->mother_begin();

            if(iMotherBegin != iMotherEnd) mother1 = *iMotherBegin;

            if(abs(mother1) == 24) {
	      //	   	      	      cout << " part form W " << imc->pid << endl;
	         if(abs(imc->pid) == 13 ) mcMuonFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());
	         if(abs(imc->pid) == 11 ) mcElectronFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());  
	         if(abs(imc->pid) == 14 ) mcNuFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());
 	         if(abs(imc->pid) == 15 ) {
                     mcTauFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P()); 
                 }
 	         if(abs(imc->pid) == 16 ) mcTauNuFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());   
	         if(abs(imc->pid) == 1 ) uQuarkFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());
	         if(abs(imc->pid) == 2 ) dQuarkFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());
 	         if(abs(imc->pid) == 3 ) sQuarkFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P());
	         if(abs(imc->pid) == 4 ) cQuarkFromW.SetXYZT(imc->Px(),imc->Py(),imc->Pz(),imc->P()); 
            }

            if(abs(imc->pid) == 12 || abs(imc->pid) == 14 || abs(imc->pid) == 16 ) {
                     neutrinoMomentum += mcParticle;              
            }
            if(abs(imc->pid) == 4 ||( abs(imc->pid)> 400 && abs(imc->pid)< 400) ||
	       ( abs(imc->pid)> 4000 && abs(imc->pid)< 4000) ) {
                 MyJet cquark;
                 cquark.SetPx(imc->Px());
                 cquark.SetPy(imc->Py());
                 cquark.SetPz(imc->Pz());
                 Cquarks.push_back(cquark);
            }
            if(abs(imc->pid) == 5 ||( abs(imc->pid)> 500 && abs(imc->pid)< 600) ||
	       ( abs(imc->pid)> 5000 && abs(imc->pid)< 6000) ) {
                 MyJet bquark;
                 bquark.SetPx(imc->Px());
                 bquark.SetPy(imc->Py());
                 bquark.SetPz(imc->Pz());
                 Bquarks.push_back(bquark);
		 //                cout << " mother1 b " << mother1 << endl;

                 for(vector<int>::const_iterator iMother = iMotherBegin;
		     iMother != iMotherEnd; ++iMother) {
		   //         cout << " all mothers " << *iMother << endl;
	             if(abs(*iMother) == 6) {
                       BquarksFromTop.push_back(bquark);
                       histograms->fill("h_ptbQuarkFromTop",imc->Et());                   
                       histograms->fill("h_etabQuarkFromTop",imc->Eta());
                    }
                }

            } 

	    if((abs(imc->pid) == 11  || abs(imc->pid) == 12) && abs(mother1) != 24 && abs(mother1) != 15 ) {
                 MyJet electron;
                 electron.SetPx(imc->Px());
                 electron.SetPy(imc->Py());
                 electron.SetPz(imc->Pz());
                 for(vector<int>::const_iterator iMother = iMotherBegin;
		     iMother != iMotherEnd; ++iMother) {
		   //         cout << " all mothers " << *iMother << endl;
	             if(abs(*iMother) == 5 || abs(*iMother) == 4 ) {

                       if(abs(imc->pid) == 11 ) {                           
                             histograms->fill("h_electronFromB",imc->Et());
                             electronsFromB.push_back(electron);
                       }
                       if(abs(imc->pid) == 12 ) {                           
                             histograms->fill("h_eNuFromB",imc->Et());
                       }

                    }
                 }
            }

            bool fromWplus = false;
            bool fromWminus = false;
            bool fromW = false;
	    
	    for(vector<int>::const_iterator iMother = iMotherBegin;
		iMother != iMotherEnd; ++iMother) {
	     	      if( abs(*iMother) == 24) fromW = true;
	     	      if( *iMother == 24) fromWplus = true;
	     	      if( *iMother == -24) fromWminus = true;
            }

	    // tau jet from W
            if( !fromW ) continue;

	    for(vector<int>::const_iterator iMother = iMotherBegin;
		iMother != iMotherEnd; ++iMother) {
	        if(abs(*iMother) == 15) {
		  //		   cout << " part from tau " << imc->pid << " mother1 " << mother1 << endl;
		   taufromW = true;
	           if(abs(imc->pid) == 211 || abs(imc->pid) == 321) {
                           nChargedPions++;
                           chargedPionsFromTau.push_back(mcParticle);

                           if ( fromWplus ) { 
                               visibleTauPlus += mcParticle;
                               chargedPionsMCplus.push_back(mcParticle);
                           }
                           if ( fromWminus ) { 
                               visibleTauMinus += mcParticle;
                               chargedPionsMCminus.push_back(mcParticle);
                           }
                           if( imc->Et() > ptTrack) {
			       ptTrack = imc->Et();
                               leadingTauTrack = mcParticle;
                           }
                   }

	           if(abs(imc->pid) == 22 ) {
                           nNeutralPions++;
                           neutralPionsFromTau.push_back(mcParticle);
                           if ( fromWplus ) { 
                               visibleTauPlus += mcParticle;
                               neutralPionsMCplus.push_back(mcParticle);
                           }  
                           if ( fromWminus ) { 
                               visibleTauMinus += mcParticle;
                               neutralPionsMCminus.push_back(mcParticle);
                           }                     
                   }
                }
            }

        }

	//    	cout << " nChargedPions " << chargedPionsMC.size() << " bquarksFromTop " << BquarksFromTop.size() << endl;


        if(!histograms->booked("h_ptMCelectronFromW") ) histograms->book("h_ptMCelectronFromW",100,0,500);
        if( mcElectronFromW.Et() > 0 ) histograms->fill("h_ptMCelectronFromW",mcElectronFromW.Et());
        if(!histograms->booked("h_ptudQuarkFromW") ) histograms->book("h_ptudQuarkFromW",100,0,500);
        if( uQuarkFromW.Et() > 0 ) histograms->fill("h_ptudQuarkFromW",uQuarkFromW.Et());
        if( dQuarkFromW.Et() > 0 ) histograms->fill("h_ptudQuarkFromW",dQuarkFromW.Et());
        double pxNu = mcNuFromW.Px();
        double pyNu = mcNuFromW.Py();
        if(!histograms->booked("h_EtNuFromW") ) histograms->book("h_EtNuFromW",100,0,250);
        histograms->fill("h_EtNuFromW",mcNuFromW.Et()); 

       
        double dphiTrue = 999;
        double mtTrue = 999;
        double massTrue  = -999;
        double ptMuonNu = -999;
 	if( mcMuonFromW.Et() > 0 &&   mcNuFromW.Et() > 0 ) { 
	   eventCounter->addCount("W->muon+nu decay "); 

	   massTrue = mass2jets(mcMuonFromW,mcNuFromW);             
           mtTrue = transverseMassRecoAlgo(mcMuonFromW, pxNu, pyNu);
	   dphiTrue = 180/3.14159*deltaPhi(mcNuFromW.Phi(),mcMuonFromW.Phi());
           ptMuonNu = sqrt((mcMuonFromW.Px()+mcNuFromW.Px())*(mcMuonFromW.Px()+mcNuFromW.Px())+
                           (mcMuonFromW.Py()+mcNuFromW.Py())*(mcMuonFromW.Py()+mcNuFromW.Py()));
	     
           if(!histograms->booked("h_massTrue") ) histograms->book("h_massTrue",100,0,500);
           histograms->fill("h_massTrue",massTrue);
           if(!histograms->booked("h_dphiTrueMCcuts") ) histograms->book("h_dphiTrueMCcuts",90,0,90);
           if ( mcNuFromW.Et() > 100 && mcMuonFromW.Et() > 100 ) histograms->fill("h_dphiTrueMCcuts",dphiTrue); 
      
        }

	//	if(mcElectronFromW.Et() > 5 ) return;
	if(mcElectronFromW.Et() > 0 ) eventCounter->addCount("W->enu decay ");


	
	//////////////////////////////////////////////    isolated electron veto

	double lepton_pt_max = 8;
	if(!electronVeto(event,lepton_pt_max)) return;
	eventCounter->addCount("electron veto");


	
	 ///////////////////////////////////////////////////////  tau jet veto
	// MC tau
	if(taufromW ) {
            if(!histograms->booked("h_drTrackMCtau") ) histograms->book("h_drTrackMCtau",100,0,0.3);
            if(!histograms->booked("h_drPi0MCtau") ) histograms->book("h_drPi0MCtau",100,0,0.3);
            if(!histograms->booked("h_leadingTauTrackMC") ) histograms->book("h_leadingTauTrackMC",100,0,100);
            histograms->fill("h_leadingTauTrackMC",leadingTauTrack.Et()); 

            for(vector<TLorentzVector>::iterator imc = chargedPionsFromTau.begin();
	                                         imc!= chargedPionsFromTau.end(); imc++){
                  if( leadingTauTrack.Et() > 10 ) {
                     double DR=deltaR(leadingTauTrack.Eta(),imc->Eta(), leadingTauTrack.Phi(),imc->Phi());
                     histograms->fill("h_drTrackMCtau",DR);
		  }
	    } 
             for(vector<TLorentzVector>::iterator imc = neutralPionsFromTau.begin();
	                                          imc!= neutralPionsFromTau.end(); imc++){
                  if( leadingTauTrack.Et() > 10 ) {
                     double DR=deltaR(leadingTauTrack.Eta(),imc->Eta(), leadingTauTrack.Phi(),imc->Phi());
                     histograms->fill("h_drPi0MCtau",DR);
		  }
	    }       
	}


         double etmax = 0;   
       
   	 if ( visibleTauPlus.Et()> 0)  {
             if(!histograms->booked("h_visibleTauEt") ) histograms->book("h_visibleTauEt",100,0,250);
             histograms->fill("h_visibleTauEt",visibleTauPlus.Et()); 
         } 
   	 if ( visibleTauMinus.Et()> 0)  {
             if(!histograms->booked("h_visibleTauEt") ) histograms->book("h_visibleTauEt",100,0,250);
             histograms->fill("h_visibleTauEt",visibleTauMinus.Et()); 
         }



////    		 vector<MyJet> taus = event->getTaujets();
	 //		 vector<MyJet> taus = event->getPFTaus();
	 //	 vector<MyJet>  taus = recalculatePFlowEnergyUsingPFtracks(event);
	 	vector<MyJet>  taus = recalculateTauEnergyUsingHardTauAlgorithm(event);
	//      vector<MyJet> taus = triggerTaus(event);
	//      if(tauType == "PFTau")   taus = event->getPFTaus();
	//	if(tauType == "HardTau") taus = recalculateTauEnergyUsingHardTauAlgorithm(event);

        // tauType = { CaloTau,PFTau,HardTau }
	//       string tauType = "PFTau";
	//        vector<MyJet> taus = tauSelectionHCh(event,tauType);

        if(!histograms->booked("h_tauCandidateEt") ) histograms->book("h_tauCandidateEt",100,0,200);
        if(!histograms->booked("h_leadingTrackPt") ) histograms->book("h_leadingTrackPt",100,0,200);
        if(!histograms->booked("hEtHcalOverTracks") ) histograms->book("hEtHcalOverTracks",100,-1.5,5.5);
        if(!histograms->booked("hEtHcalOverTracksTrue") ) histograms->book("hEtHcalOverTracksTrue",100,-1.5,5.5);
        if(!histograms->booked("hEtHcalOverTracksWenu") ) histograms->book("hEtHcalOverTracksWenu",100,-1.5,5.5);
        if(!histograms->booked("h_tauJetEt") ) histograms->book("h_tauJetEt",100,0,200);
        if(!histograms->booked("h_matchingtauJetEt") ) histograms->book("h_matchingtauJetEt",100,0,200);
        if(!histograms->booked("h_tauJetEta") ) histograms->book("h_tauJetEta",100,-5,5);
        if(!histograms->booked("h_tauJetDR") ) histograms->book("h_tauJetDR",100,0,5);

        double etHcalOverTracks = 999;
	vector<MyJet> selectedTaus;
        selectedTaus.clear();
        for(vector<MyJet>::iterator iJet = taus.begin();
                                    iJet != taus.end(); iJet++){
		eventCounter->addCount("    all tau cands");
		//                cout << " pftau Et" << iJet->Pt()  << endl;

		histograms->fill("h_tauCandidateEt",iJet->Pt());
                if(!cuts->applyCut("tauEtCut", iJet->Pt())) continue;
		eventCounter->addCount("    tau Et cut");

		bool isolated = isolation(&(*iJet),cuts->getCutValue("isolationCone"),cuts->getCutValue("signalCone"));
		if(!isolated) continue;
		eventCounter->addCount("    tau isolation");


		int nprongs = tauProngCounter(*iJet,cuts->getCutValue("signalCone"),cuts->getCutValue("matchingCone"));
		//                cout << " nprongs  " << nprongs  << endl;
		if(nprongs != 1 && nprongs != 3) continue;
		eventCounter->addCount("    tau 1/3 prong");

                MyTrack leadingTrack = iJet->leadingTrack(cuts->getCutValue("matchingCone"));
		histograms->fill("h_leadingTrackPt",leadingTrack.Pt());

		//		 cout << " leadingTrack.Pt()  "<< leadingTrack.Pt() << endl;
		if(!cuts->applyCut("leadingTrackPtCut", leadingTrack.Pt())) continue;
		eventCounter->addCount("    leading track pt cut");

                vector<MyTrack> tauTracks = iJet->getTracks();
                MyTrack tracksMomentum;
                tracksMomentum.SetPx(0);
                tracksMomentum.SetPy(0); 
                tracksMomentum.SetPz(0);
                for(vector<MyTrack>::const_iterator itrack = tauTracks.begin();
                                                itrack!= tauTracks.end(); itrack++){
                       double DR=deltaR( leadingTrack.Eta(),itrack->eta(),  leadingTrack.Phi(),itrack->phi()); 
	               if( DR < cuts->getCutValue("signalCone")  ) {
                             tracksMomentum += *itrack;
                       }         
                  } 

		if( tracksMomentum.Pt() == 0  ) continue;

		   //  calo deposit
                TVector3 trackEcalHitPoint(0,0,0); 

                trackEcalHitPoint = leadingTrack.trackEcalHitPoint.tvector3();
	         
		//                pair<TVector3,TVector3> caloClusters = getClusterEnergy(towers,trackEcalHitPoint);
		//               TVector3 EcalCluster = caloClusters.first;
		//                TVector3 HcalCluster = caloClusters.second;



		//		MyGlobalPoint HitPoint = leadingTrack.ecalHitPoint();
		//		cout << " track Ecal Hit point, eta " << trackEcalHitPoint.Eta() << " phi  " << trackEcalHitPoint.Phi() << endl; 
		//	        cout << " leadingTrack, eta  "<< leadingTrack.Eta()<< " phi  "<< tracksMomentum.Phi() << endl;
  
		//                double DRleadTkPos=deltaR(trackEcalHitPoint.Eta(),leadingTrack.eta(), trackEcalHitPoint.Phi(),leadingTrack.phi());
		//                double DRleadTkPos=deltaR(leadingTrack.eta(),leadingTrack.eta(), trackEcalHitPoint.Phi(),leadingTrack.phi());
 
                TVector3 HcalCluster(0,0,0); 
   
	        vector<MyCaloTower> towers = iJet->getCaloInfo();
                for(vector<MyCaloTower>::const_iterator i = towers.begin();
                                                i!= towers.end(); i++){
                       vector<TVector3> cells;  
                       cells = i->HCALCells;
		       //		   cout << " hcal cels " << cells.size() << endl;

                       for(vector<TVector3>::const_iterator j = cells.begin();
                                                j!= cells.end(); j++){
                         double eta = j->Eta();
                         double phi = j->Phi();

                         double DR = deltaR(trackEcalHitPoint.Eta(),eta,trackEcalHitPoint.Phi(),phi);
			 //		         cout << " hcal cell e "<< energy << " et  " << et << " DR " << DR << endl; 
                         TVector3 CellMomentum(0,0,0);
                         CellMomentum.SetX(j->Px());
		         CellMomentum.SetY(j->Py());
		         CellMomentum.SetZ(j->Pz()); 
                         if(DR <  0.4 ){
                              HcalCluster += CellMomentum;                
                         }
                      }   
		  }

              
                  double eHcalCluster = sqrt(HcalCluster.X()*HcalCluster.X()+HcalCluster.Y()*HcalCluster.Y()+HcalCluster.Z()*HcalCluster.Z());        
                  if(  tracksMomentum.pt() > 0 ) {  
                     TLorentzVector hcalClusterMomentum(HcalCluster.X(),HcalCluster.Y(),HcalCluster.Z(),eHcalCluster );  
                     etHcalOverTracks = (hcalClusterMomentum.Pt()-tracksMomentum.pt())/tracksMomentum.pt(); 
                  }

                  histograms->fill("hEtHcalOverTracks",etHcalOverTracks); 

	          double DRtauMCtau1 = 999;
	          if ( visibleTauPlus.Et() > 0 ) {
                      DRtauMCtau1  = deltaR( visibleTauPlus.Eta(),iJet->Eta(), visibleTauPlus.Phi(),iJet->Phi()); 
                      if( DRtauMCtau1 < 0.15 )  {
                          histograms->fill("hEtHcalOverTracksTrue",etHcalOverTracks); 
                      }
                  }
	          double DRtauMCtau2 = 999;
	          if ( visibleTauMinus.Et() > 0 ) {
                      DRtauMCtau2  = deltaR( visibleTauMinus.Eta(),iJet->Eta(), visibleTauMinus.Phi(),iJet->Phi()); 
                      if( DRtauMCtau2 < 0.15 )  {
                          histograms->fill("hEtHcalOverTracksTrue",etHcalOverTracks); 
                      }
                  }


	          double DRtauWenu = 999;
                  if( mcElectronFromW.Et() > 0 ) {
                      double DRtauWenu = deltaR(  mcElectronFromW.Eta(),iJet->Eta(),  mcElectronFromW.Phi(),iJet->Phi()); 
                      if( DRtauWenu < 0.415 )  {
                          histograms->fill("hEtHcalOverTracksWenu",etHcalOverTracks);
                      }		 
                   }


                  if( etHcalOverTracks > cuts->getCutValue("etHcalOverTracks") ) continue;
                  eventCounter->addCount(" etHcalOverTracks < 0");

                  histograms->fill("h_tauJetEt",iJet->Et()); 
                  histograms->fill("h_tauJetEta",iJet->Eta()); 	                       
                  if ( visibleTauPlus.Et() > 0) histograms->fill("h_tauJetDR",DRtauMCtau1); 
                  if ( visibleTauMinus.Et() > 0) histograms->fill("h_tauJetDR",DRtauMCtau2); 

                  if( DRtauMCtau1 < 0.4 )  {
                       eventCounter->addCount("matching tau jet ");
                       histograms->fill("h_matchingtauJetEt",iJet->Et()); 
                  }
                  if( DRtauMCtau2 < 0.4 )  {
                       eventCounter->addCount("matching tau jet "); 
                       histograms->fill("h_matchingtauJetEt",iJet->Et()); 
                  }                

                  if( DRtauWenu < 0.4) eventCounter->addCount("matching tau jet W->enu ");
         
		  //		  cout << " et tauJet " << iJet->Et() << " et visibleTau+ " << visibleTauPlus.Et() << " et visibleTau- " << visibleTauMinus.Et()<<  " DR(tau-MC tau) " << DRtauMCtau1 <<  " DR(tau-MC tau) " << DRtauMCtau1 << endl;
		  //   

		selectedTaus.push_back(*iJet);
	     }
 
    
	 if( selectedTaus.size() > 0 ) return;
	 eventCounter->addCount("tau-jet veto");




	////////////////////////////////////////////////////////   muon selection

        if(!histograms->booked("h_etaMuon") ) histograms->book("h_etaMuon",100,-5,5);
        if(!histograms->booked("h_ptMuon") ) histograms->book("h_ptMuon",100,0,250);
        if(!histograms->booked("h_ptIsolatedMuon") ) histograms->book("h_ptIsolatedMuon",100,0,250); 
        if(!histograms->booked("h_etaIsolatedMuon") ) histograms->book("h_etaIsolatedMuon",100,-5,5);   
        if(!histograms->booked("h_ptMatchingIsolatedMuon") ) histograms->book("h_ptMatchingIsolatedMuon",100,0,250);    
        if(!histograms->booked("h_ptMCMuonFromW") ) histograms->book("h_ptMCMuonFromW",100,0,250);
        if( mcMuonFromW.Et() > 0 )  histograms->fill("h_ptMCMuonFromW",mcMuonFromW.Et());

	int allMuons = 0; 
        MyJet selectedMuon;  
        selectedMuon.SetPx(0);
        selectedMuon.SetPy(0); 
        selectedMuon.SetPz(0);
	vector<MyJet> isolatedMuons;
        isolatedMuons.clear();

	for(vector<MyJet>::iterator iMuon = event->muons.begin();
                                    iMuon != event->muons.end(); iMuon++){
                histograms->fill("h_etaMuon",iMuon->eta());
                histograms->fill("h_ptMuon",iMuon->Pt());

                if( iMuon->Pt() > 4 ) allMuons++;
		eventCounter->addCount("    all muons");

	        bool isolated = isolation(&(*iMuon),cuts->getCutValue("leptonIsolCone"),0);
		if(!isolated) continue;
		eventCounter->addCount("    isolated muons");

                isolatedMuons.push_back(*iMuon);		
	}


	if( isolatedMuons.size() != 1 ) return;
        eventCounter->addCount("one isolated muon");

        selectedMuon=*(isolatedMuons.begin());

        histograms->fill("h_ptIsolatedMuon",selectedMuon.Pt());                     
        histograms->fill("h_etaIsolatedMuon",selectedMuon.eta());
        if( mcMuonFromW.Et() > 0) {
            double dr = deltaR(selectedMuon.eta(),mcMuonFromW.Eta(),selectedMuon.phi(),mcMuonFromW.Phi());
            if(dr < 0.4) {                             
                    histograms->fill("h_ptMatchingIsolatedMuon",selectedMuon.Pt()); 
			     
            }
        }


        if ( selectedMuon.Pt() < cuts->getCutValue("muonPtCut")) return;     
        eventCounter->addCount("muon pt cut ");

	if( allMuons != 1 ) return;
        eventCounter->addCount("veto on other muons");

	MyTrack theMuon(0,0,0,0); 
	double DRmin = cuts->getCutValue("leptonIsolCone");
        vector<MyTrack> muTracks = selectedMuon.tracks;
	for(vector<MyTrack>::iterator iTrack = muTracks.begin();
                                      iTrack != muTracks.end(); iTrack++){
                 if(cuts->applyCut("isolationTrackPt", iTrack->Pt())) {
			 double trackEta = iTrack->eta();
			 double trackPhi = iTrack->phi();
            		 double DR = deltaR(selectedMuon.eta(),trackEta,
                                            selectedMuon.phi(),trackPhi);
			 if(DR < DRmin) {
				 theMuon = *iTrack;
				 DRmin = DR;
			 }
		 }
	}

        double muonChi2 = 999;
        double muonHits = 0;
        double muonIpz =  999;
        double muonIp2D = 999;
	double DRmuonRecoMC = -999;
        double resolutionMuon = -5;
        if( theMuon.Pt() > 0 ) {
            muonChi2 =theMuon.normalizedChi2();
            muonHits =theMuon.numberOfValidHits();
            muonIpz = theMuon.impactParameter().impactParameterZ().value();
            muonIp2D = theMuon.impactParameter().impactParameter2D().value();
	//	cout << " muon Chi2  " << theMuon.normalizedChi2() << " Hits  " << muonHits << " muonIpz  " <<muonIpz << " muonIp2D " <<muonIp2D << endl;   

            if(!histograms->booked("h_muonChi2") ) histograms->book("h_muonChi2",100,0,20);
		       histograms->fill("h_muonChi2",muonChi2);
            if(!histograms->booked("h_muonHits") ) histograms->book("h_muonHits",100,0,100);
		       histograms->fill("h_muonHits",muonHits);
            if(!histograms->booked("h_muonIpz") ) histograms->book("h_muonIpz",100,-0.5,0.5);
		       histograms->fill("h_muonIpz",muonIpz);
            if(!histograms->booked("h_muonIp2D") ) histograms->book("h_muonIp2D",100,-0.5,0.5);
                       histograms->fill("h_muonIp2D",muonIp2D);
                       
            if(!cuts->applyCut("muonChi2Cut", muonChi2)) return;
            eventCounter->addCount("muonChi2Cut");

            if(!cuts->applyCut("muonIp2DCut", fabs(muonIp2D))) return;
	    eventCounter->addCount("muonIp2DCut");
 
            if(!cuts->applyCut("muonipzCut", fabs(muonIpz))) return;
	    eventCounter->addCount("muonIpzCut");
   

            if( mcMuonFromW.Et() > 0 ) {
                   DRmuonRecoMC  = deltaR(theMuon.eta(),mcMuonFromW.Eta(),theMuon.phi(),mcMuonFromW.Phi());
                   if( DRmuonRecoMC < 0.2 ) eventCounter->addCount("matching MC muon from W");
                   resolutionMuon = (mcMuonFromW.Et() - theMuon.pt())/ mcMuonFromW.Et();
                   if(!histograms->booked("h_muonResolution") ) histograms->book("h_muonResolution",100,-1,1);
                   histograms->fill("h_muonResolution",resolutionMuon);
                   if(!histograms->booked("h_drMuonRecoMC") ) histograms->book("h_drMuonRecoMC",100,0,1);
                   histograms->fill("h_drMuonRecoMC",DRmuonRecoMC);              
            }
        }


	///////////////////////////////////////////////////    MET 


      	//MyMET Met   = type1MET(event,cut["type1_jetEt"],"MCJetCorrectorMcone5"); 
	//	MyMET Met   = event->MET; 
        MyMET Met   = event->MET;
        // metCorrection = "CaloMET_Type1Icone5",
        //                 "CaloMET_Type1Mcone5",
        //                 "CaloMET_NoHF",
        //                 "CaloMET_noHF_Type1Icone5",
        //                 "CaloMET_noHF_Type1Mcone5"
        string metCorrection = "CaloMET_noHF_Type1Mcone5";
        Met.useCorrection(metCorrection);


        MyMET mcMet   = event->mcMET;   
 
        double met   = Met.value();
	double metX   = Met.getX();
	double metY   = Met.getY();
	double phiMET = phifun(metX,metY);
	double dphiMuMet = 180/3.14159*deltaPhi(theMuon.phi(),phiMET);
        double MCmet   = mcMet.value();
	double mcMetX   = mcMet.getX();
	double mcMetY   = mcMet.getY();	  
	double phimcMET = phifun(mcMetX,mcMetY);
	double dphiMETmcMET = 180/3.14159*deltaPhi(phimcMET,phiMET);

        if(!histograms->booked("h_dphiMuMET") ) histograms->book("h_dphiMuMET",90,0,90);
        histograms->fill("h_dphiMuMET",dphiMuMet);

 
	metResolutionAnalysis(Met,event->getMCMET());

        if(!metCut(Met)) return;
	eventCounter->addCount("MET cut");

 
	////////////////////////////////////////////////////// mT(muon,Met)
	
        if(!histograms->booked("h_transverseMass") ) histograms->book("h_transverseMass",100,0,500);
        if(!histograms->booked("h_ptMuMET") ) histograms->book("h_ptMuMET",100,0,300);
        if(!histograms->booked("h_dphiTrue") ) histograms->book("h_dphiTrue",90,0,90);
        if(!histograms->booked("h_dphiMuonNu") ) histograms->book("h_dphiMuonNu",90,0,90);
        if(!histograms->booked("h_dphiMetNu") ) histograms->book("h_dphiMetNu",90,0,180);
        if(!histograms->booked("h_transversemassTrue") ) histograms->book("h_transversemassTrue",100,0,500);
   
	double mtMuonMet = transverseMass(selectedMuon,Met);
        histograms->fill("h_transverseMass",mtMuonMet);
	histograms->fill("h_transversemassTrue",mtTrue);

        double ptMuonMet = sqrt((selectedMuon.Px()+metX)*(selectedMuon.Px()+metX)+(selectedMuon.Py()+metY)*(selectedMuon.Py()+metY));;
        histograms->fill("h_ptMuMET",ptMuonMet);

        double dphiMuonNu = 999;
        if( mcNuFromW.Et() > 0 ) {
	   dphiMuonNu = 180/3.14159*deltaPhi(mcNuFromW.Phi(),selectedMuon.Phi());
        } 
        histograms->fill("h_dphiTrue",dphiTrue);        
        histograms->fill("h_dphiMuonNu",dphiMuonNu);

        double dphiMETnu =  999;
        if( mcNuFromW.Et() > 0 ) {
           dphiMETnu = 180/3.14159*deltaPhi(mcNuFromW.Phi(),phiMET);
        }
        histograms->fill("h_dphiMetNu",dphiMETnu);



	///////////////////////////////////////////////////////////    Jets

        if(!histograms->booked("h_calibratedJetsEt") ) histograms->book("h_calibratedJetsEt",100,0,250);
        if(!histograms->booked("h_calibratedJetsEta") ) histograms->book("h_calibratedJetsEta",100,-5,5);


	string jetCalibration = "MCJetCorrectorMcone5";
	vector<MyJet> calibatedJets = event->getJets(jetCalibration);
	//	vector<MyJet> calibatedJets = event->getJets();
        int nCalibratedJets= 0;     
        vector<MyJet> bCandidates;
        bCandidates.clear();

        for(vector<MyJet>::iterator iJet = calibatedJets.begin();
                                    iJet != calibatedJets.end(); iJet++){
	  //	  cout << "check jet corrEt " << iJet->Et() << " " 
	  //	  << iJet->getCorrectionFactor(jetCalibration) << endl               
	        histograms->fill("h_calibratedJetsEt",iJet->Et());              
	        histograms->fill("h_calibratedJetsEta",iJet->Eta());
                double DR = deltaR(selectedMuon.eta(),iJet->Eta(),
                                            selectedMuon.phi(),iJet->Phi());
                if ( DR > 0.4 ) {
		     if(iJet->Et() > 20 ) nCalibratedJets++;
                     if( fabs(iJet->Eta()) < 2.5 && iJet->Et() > 20  ) bCandidates.push_back(*iJet);  
                }   
        }


 
        if( bCandidates.size() < 3 ) return;
        eventCounter->addCount("3 hadronic jets ");

	/////////////////////////////////////////////////////////   b tagging

        if(!histograms->booked("h_jetDiscriminator") ) histograms->book("h_jetDiscriminator",100,-50,50);
        if(!histograms->booked("h_realbDiscriminator") ) histograms->book("h_realbDiscriminator",100,-50,50);
        if(!histograms->booked("h_udDiscriminator") ) histograms->book("h_udDiscriminator",100,-50,50);

        etmax = 0;
        MyJet bestBjet;
        MyJet leadingTaggedJet;
        vector<MyJet>::iterator bestbjet;
        bestBjet.SetPx(0); bestBjet.SetPy(0);  bestBjet.SetPz(0);
        leadingTaggedJet.SetPx(0); leadingTaggedJet.SetPy(0); leadingTaggedJet.SetPz(0);  
        double bestDiscriminator = -99999;

        for(vector<MyJet>::iterator iJet = bCandidates.begin();
                                    iJet != bCandidates.end(); iJet++){
                double discriminator = iJet->tag("discriminator");
                double sipCut = 1.5;
                bool tagged = iJet->btag(sipCut);                 
                histograms->fill("h_jetDiscriminator",discriminator);

		//		cout <<  " jet Et " << iJet->Et() << " discrim " << discriminator << " tagged " << tagged <<  endl;	 
                if( tagged ) {
		     if(iJet->Et() > etmax){
			  etmax = iJet->Et();
			  leadingTaggedJet = *iJet;
                     }
		}
     
                if( discriminator > bestDiscriminator ) {
		    bestDiscriminator = discriminator;
                    bestBjet = *iJet;
                    bestbjet = iJet;
		} 

                bool noBjet = false;
	        for(vector<MyJet>::iterator ib = Bquarks.begin();
                                    ib != Bquarks.end(); ib++){
	             double DR = deltaR(iJet->Eta(),ib->Eta(),iJet->Phi(),ib->Phi());
                     if( DR < 0.3 ) {                     
                         histograms->fill("h_realbDiscriminator",discriminator);
                     }
                     if( DR > 0.7 ) {
	                 noBjet = true;
                     }
                } 

                if ( uQuarkFromW.Et() > 0 ) {
                   double DRq = deltaR(iJet->Eta(),uQuarkFromW.Eta(),iJet->Phi(),uQuarkFromW.Phi());                   
                   if( DRq < 0.3 && noBjet )  histograms->fill("h_udDiscriminator",discriminator);
                }
                if ( dQuarkFromW.Et() > 0 ) {
                   double DRq = deltaR(iJet->Eta(),dQuarkFromW.Eta(),iJet->Phi(),dQuarkFromW.Phi());                  
                   if( DRq < 0.3 && noBjet )  histograms->fill("h_udDiscriminator",discriminator);
                }    
        }

        vector<MyJet>::iterator secondbjet;
        MyJet secondBjet;
        secondBjet.SetPx(0); secondBjet.SetPy(0);  secondBjet.SetPz(0);
        double secondDiscriminator = -99999;
        for(vector<MyJet>::iterator iJet = bCandidates.begin();
                                    iJet != bCandidates.end(); iJet++){
                double discriminator = iJet->tag("discriminator");
                if( iJet != bestbjet  && discriminator > secondDiscriminator ) {
		    secondDiscriminator = discriminator;
                    secondBjet = *iJet;
                    secondbjet = iJet;
		} 
	     
        }


        if(!histograms->booked("h_maxBjetEt") ) histograms->book("h_maxBjetEt",100,0,250);
        histograms->fill("h_maxBjetEt",leadingTaggedJet.Et());
        if(!histograms->booked("h_maxBjetEta") ) histograms->book("h_maxBjetEta",100,-5,5);
        if(leadingTaggedJet.Et() > 0) histograms->fill("h_maxBjetEta",leadingTaggedJet.Eta());
        if(!histograms->booked("h_bestBjetEt") ) histograms->book("h_bestBjetEt",100,0,250);
        histograms->fill("h_bestBjetEt",bestBjet.Et());
        if(!histograms->booked("h_bestBjetEta") ) histograms->book("h_bestBjetEta",100,-5,5);
        histograms->fill("h_bestBjetEta",bestBjet.Eta());
        if(!histograms->booked("h_bestDiscriminator") ) histograms->book("h_bestDiscriminator",100,0,50);
        histograms->fill("h_bestDiscriminator",bestDiscriminator);
        if(!histograms->booked("h_secondBjetEt") ) histograms->book("h_secondBjetEt",100,0,250);
        histograms->fill("h_secondBjetEt",secondBjet.Et());
	//        cout <<  " best B jet " << bestBjet.Et() << " best discrim " << bestDiscriminator  << endl;


	//  Origin of b jet: any b quark	 
        bool bestIsBjet = false;
        bool secondBestIsBjet = false;
        MyJet matchingBjet;
        matchingBjet.SetPx(0); matchingBjet.SetPy(0);  matchingBjet.SetPz(0);

        for(vector<MyJet>::iterator iJet = Bquarks.begin();
                                    iJet != Bquarks.end(); iJet++){
	    if( bestBjet.Et() > 0) {
	        double DR1 = deltaR(iJet->Eta(),bestBjet.Eta(),iJet->Phi(),bestBjet.Phi());
                if( DR1 < 0.4 ) {
	             matchingBjet = bestBjet;
		     bestIsBjet = true;
                }
            }
	    if ( secondBjet.Et() > 0 ) {
	        double DR2 = deltaR(iJet->Eta(),secondBjet.Eta(),iJet->Phi(),secondBjet.Phi());
                if( DR2 < 0.4 ) {
	             secondBestIsBjet = true;
                }
            }
        }
          
        if( matchingBjet.Et() > 0  ) {
             double discriminator = matchingBjet.tag("discriminator");
             eventCounter->addCount("matching best b jet ");
	     
             if(!histograms->booked("h_matchingDiscriminator") ) histograms->book("h_matchingDiscriminator",100,0,50);
             histograms->fill("h_matchingDiscriminator",discriminator);
             if(!histograms->booked("h_matchingBjetEt") ) histograms->book("h_matchingBjetEt",100,0,250);
             histograms->fill("h_matchingBjetEt",matchingBjet.Et());
             if(!histograms->booked("h_matchingBjetEta") ) histograms->book("h_matchingBjetEta",100,-5,5);
	     histograms->fill("h_matchingBjetEta",matchingBjet.Eta());
        }

	//  Origin of b jet: top->bW
        bool btopMatching = false;
        MyJet matchingBtopjet;
        matchingBtopjet.SetPx(0); matchingBtopjet.SetPy(0);  matchingBtopjet.SetPz(0);

        for(vector<MyJet>::iterator iJet = BquarksFromTop.begin();
                                    iJet != BquarksFromTop.end(); iJet++){
	  if( bestBjet.Et() > 0) {
	          double DR = deltaR(iJet->Eta(),bestBjet.Eta(),iJet->Phi(),bestBjet.Phi());
                  if( DR < 0.4 ) {
	                 matchingBtopjet = bestBjet;
                  }
            }
        }
          
        if( matchingBtopjet.Et() > 0 && secondBestIsBjet ) {
	     btopMatching = true;
             double discriminator = matchingBtopjet.tag("discriminator");
             eventCounter->addCount("matching top->bW ");
             if(!histograms->booked("h_matchingbtopDiscriminator") ) histograms->book("h_matchingbtopDiscriminator",100,0,50);
             histograms->fill("h_matchingbtopDiscriminator",discriminator);
             if(!histograms->booked("h_matchingBtopjetEt") ) histograms->book("h_matchingBtopjetEt",100,0,250);
             histograms->fill("h_matchingBtopjetEt",matchingBtopjet.Et());
             if(!histograms->booked("h_matchingBtopjetEta") ) histograms->book("h_matchingBtopjetEta",100,-5,5);
	     histograms->fill("h_matchingBtopjetEta",matchingBtopjet.Eta());

        }


	// b tagging cuts
        if(! (cuts->applyCut("bjetEtCut", bestBjet.Et()) || cuts->applyCut("bjetEtCut", secondBjet.Et()))) return;
	eventCounter->addCount("2 b jets, Et cuts");

        if(! (cuts->applyCut("bTagDiscriminator", bestDiscriminator) || cuts->applyCut("bTagDiscriminator", secondDiscriminator))) return;
	eventCounter->addCount("2 b jets,  discriminator cut");

        if (bestIsBjet && secondBestIsBjet )  eventCounter->addCount("2 real bjets, cuts ");

	// b veto cut 
	//        if(leadingTaggedJet.Et() > cut["bjetVetoEtCut"]  ) return;
	//	eventCounter->addCount("b jet  veto  cut");


 
        TLorentzVector neutrinos(0,0,0,0);
        if(  neutrinoMomentum.Et() > 0 &&  mcNuFromW.Et()  > 0 ) {
	     neutrinos =   neutrinoMomentum-mcNuFromW;
        }



        topMassReco->analyse(&selectedMuon,event, int(cuts->getCutValue("topRecoAlgo")));
        //if(!topFound) return;
        //eventCounter->addCount("top quark found");

	int njets = topMassReco->njets();
	if(njets < 3) return;
		eventCounter->addCount("3 hadronic jets ");

	bestDiscriminator = (topMassReco->bestBJet()).tag("discriminator");
        if(!cuts->applyCut("bTagDiscriminator", bestDiscriminator)) return;
	eventCounter->addCount("b jet  discriminator cut");

	double topmass = topMassReco->topMass();
	double Wmass = topMassReco->WMass();

        if(cuts->applyCut("wMass", Wmass)) {
            if(!histograms->booked("h_topmassWmasscut") ) histograms->book("h_topmassWmasscut",100,0,300);
	    histograms->fill("h_topmassWmasscut",topmass);
        }

        if(!cuts->applyCut("topFitChi2", topMassReco->fitChi2())) return;
        if(!cuts->applyCut("topMass", topmass)) return;
        eventCounter->addCount("top mass cut");

        if(!histograms->booked("h_transversemassTop") ) histograms->book("h_transversemassTop",100,0,500);
	histograms->fill("h_transversemassTop",mtMuonMet);

	//       if(!histograms->booked("h_Wmass") ) histograms->book("h_Wmass",100,0,150);
	//	histograms->fill("h_Wmass",Wmass);

	if(!histograms->booked("h_topmassBtopmatch") ) histograms->book("h_topmassBtopmatch",100,0,300);
	if( btopMatching ) histograms->fill("h_topmassBtopmatch",topmass);


        if(!histograms->booked("h_transversemassTrueTop") ) histograms->book("h_transversemassTrueTop",100,0,500);
	histograms->fill("h_transversemassTrueTop",mtTrue);

    
        if(!histograms->booked("h_transversemassTopW") ) histograms->book("h_transversemassTopW",100,0,500);
	histograms->fill("h_transversemassTopW",mtMuonMet);
           


      /////////////////////////////////////////////////////    top mass reconst. Chi2 algorithm
	/*
        double chiMin         = 100000;

        double massW          = -100;
        double massTop        = -100;

        double nominalWmass   = 81;
        double sigmaWmass     = 20;
	double nominalTopmass = 175;
        double sigmaTopmass   = 30;
        double wmassWindow    = 20;



        for(vector<MyJet>::iterator iJet1 = bCandidates.begin();
                                    iJet1 != bCandidates.end(); iJet1++){
               TLorentzVector j1(0,0,0,0);
               j1.SetXYZT(iJet1->Px(),iJet1->Py(),iJet1->Pz(),iJet1->E());
	       //	       cout <<  " et1 " << j1.Et() << endl;
	       if(iJet1 == bestbjet) continue;
               for(vector<MyJet>::iterator iJet2 = bCandidates.begin();
                                    iJet2 != bCandidates.end(); iJet2++){
			if(iJet1 == iJet2 || iJet2 == bestbjet) continue;
                        TLorentzVector j2(0,0,0,0);
                        j2.SetXYZT(iJet2->Px(),iJet2->Py(),iJet2->Pz(),iJet2->E());

			double jjMass = mass2jets(j1,j2);
			//			if( fabs(jjMass-nominalWmass) > wmassWindow ) continue;

                        double jjjMass = mass3jets(j1,j2,bestBjet);
			//			cout <<  " et1 " << j1.Et() << " et2 " << j2.Et() <<  " j3 " << bestBjet.Et() << " mjj "<<jjMass << " mjjj " << jjjMass << endl;
		        double chi2 = ((jjMass-nominalWmass)/sigmaWmass)*
                		      ((jjMass-nominalWmass)/sigmaWmass)+
                		      ((jjjMass-nominalTopmass)/sigmaTopmass)*
                		      ((jjjMass-nominalTopmass)/sigmaTopmass);

			if(chi2 < chiMin){
				chiMin  = chi2;
				massTop = jjjMass;
				massW   = jjMass;
			}
		}
	}

	//        cout << " wmass " << massW << " top mass " << massTop << endl;

	*/

 

	//	if( isolatedTauJets.size() > 0 ) return;
	//	eventCounter->addCount("tau-jet veto");



	if( dphiMuMet > cuts->getCutValue("dphiMetNuCut") ) {
            eventCounter->addCount("dphi(mu,met) cut"); 
            if(!histograms->booked("h_transversemassPhicut") ) histograms->book("h_transversemassPhicut",100,0,500);
	    histograms->fill("h_transversemassPhicut",mtMuonMet);
        }
 
        if(!histograms->booked("h_ptMuonNu") ) histograms->book("h_ptMuonNu",100,0,250);
	histograms->fill("h_ptMuonNu",ptMuonNu);

 
	//    pt cut on muon-Met
	//	if( ptMuonMet < cut["ptMuonMetCut"] ) return;


   
   	eventFilter->saveEvent(event);     
  
	//////////////////////////////////////////////////////   Events in the mT tail


        cout << "    " << endl;

           bool electronFromBottom = true;
	    bool muonOutsideEtaRange = false;
	    bool muonBelow5GeV = false;
	    bool muonFromOtherW = false;
            int nMuonsFromW = 0;
            DRmin = 10000;
            MyMCParticle muParticle;

	    for(imc = event->mcParticles_begin();
		imc != mcParticleEnd; ++imc) {

                int mother1 = 0;
                vector<int> motherList = imc->mother; 
                if(motherList.size() > 0) mother1 = (*motherList.begin());
		//                if ( abs(imc->pid) == 11 || abs(imc->pid) == 13) cout << " mc part " << imc->pid << " part mother " << mother1 << "  pt " << imc->Et()  << "  eta " << imc->Eta() << endl;
		if( imc->Et() > 10 && mtMuonMet > 100 ) {
		  cout << " mc part " << imc->pid << " part mother " << mother1 << "  pt " << imc->Et()  << "  eta " << imc->Eta() << endl;
                } 
         
                if((abs(imc->pid) == 11  || abs(imc->pid) == 12) && abs(mother1) != 24 && abs(mother1) != 15) {
		   electronFromBottom = true;
                }


                if(abs(imc->pid) == 13  && abs(mother1) == 24  ) {          
		    nMuonsFromW++;	   
		    cout << " muon charge  " << theMuon.charge() << " imc->pid  "  << imc->pid << endl;
		    if(  mcMuonFromW.Et() !=  imc->Et() ) { 
		         muonFromOtherW = true;
                         if( fabs(imc->Eta()) > 2.5) muonOutsideEtaRange=true;
                         if( fabs(imc->Eta()) < 2.5 && imc->Et() < 5 ) muonBelow5GeV=true;
                    }
                }

       
	        if( abs(imc->pid) > 6 &&  imc->pid != 22 && imc->pid != 111 ) {
                     double DR  = deltaR(theMuon.eta(),imc->Eta(),theMuon.phi(),imc->Phi());
                     if ( DR < DRmin) {
	                 DRmin = DR;
                         muParticle = *imc;   
                     }
                }
            }


   
        if(!histograms->booked("h_transversemassNoBdec") ) histograms->book("h_transversemassNoBdec",100,0,500);
	if( mcElectronFromW.Et() == 0  &&  eNuFromB.size()==0 ) histograms->fill("h_transversemassNoBdec",mtMuonMet);
        if(!histograms->booked("h_transversemassNoEleNu") ) histograms->book("h_transversemassNoEleNu",100,0,500);
	if( mcElectronFromW.Et() == 0  &&  neutrinos.Et() == 0 ) histograms->fill("h_transversemassNoEleNu",mtMuonMet);

        if(!histograms->booked("h_transversemassNoEleTauMu") ) histograms->book("h_transversemassNoEleTauMu",100,0,500);
	if( mcElectronFromW.Et() == 0  && mcTauFromW.Et() == 0 &&   !muonFromOtherW ) histograms->fill("h_transversemassNoEleTauMu",mtMuonMet);

        if(!histograms->booked("h_transversemassNoTau") ) histograms->book("h_transversemassNoTau",100,0,500);
	if( mcTauFromW.Et() == 0 ) histograms->fill("h_transversemassNoTau",mtMuonMet);

        if(!histograms->booked("h_transversemassNoEle") ) histograms->book("h_transversemassNoEle",100,0,500);
	if( mcElectronFromW.Et() == 0 ) histograms->fill("h_transversemassNoEle",mtMuonMet);
        if(!histograms->booked("h_transversemassBtag") ) histograms->book("h_transversemassBtag",100,0,500);
	histograms->fill("h_transversemassBtag",mtMuonMet);
        if(!histograms->booked("h_transversemassTrueBtag") ) histograms->book("h_transversemassTrueBtag",100,0,500);
	histograms->fill("h_transversemassTrueBtag",mtTrue); 



	if (  mtMuonMet > 100 ) {


            eventCounter->addCount("mT > 100 GeV: ");
            cout << "  " << endl;
            cout << " Large Transverse mass  " << mtMuonMet << " pt(mu,Met)  " << ptMuonMet << " pt(mu,nu)  " << ptMuonNu << " top mass  " << topmass << " W mass  " << Wmass << endl;

	    if( ptMuonMet > cuts->getCutValue("ptMuonMetCut") ) eventCounter->addCount("mT>100: pT(mu,MET) > 100");
	    if( ptMuonMet > 50 ) eventCounter->addCount("mT>100: pT(mu,met) > 50"); 
 
 
		//           cout << " match MC part, id " << muParticle.pid << "  pt " << muParticle.Pt()  << " DR " << DRmin <<  endl;
	    cout << " muon pt " << theMuon.Pt() << " MCmuon " << mcMuonFromW.Et() <<  " MET" << met  << " MCmet " << MCmet << endl;
           cout << " trueWmass " << massTrue << " mtTrue " << mtTrue  << " tmass " << mtMuonMet << "  pt muon " << mcMuonFromW.Et()  << " nu " << mcNuFromW.Et() << "  pt tau " << mcTauFromW.Et() << "  pt electron " << mcElectronFromW.Et() <<  endl;

            if ( mcElectronFromW.Et() > 0 ) eventCounter->addCount(" mT > 100:  W->e+nu"); 
            if ( mcTauFromW.Et() > 0 ) eventCounter->addCount(" mT > 100:  W->tau+nu"); 
            if ( mcTauFromW.Et() > 0  && fabs(mcTauFromW.Eta()) > 2.4) eventCounter->addCount(" mT > 100: eta(W->tau+nu)>2.4 ");
            if ( muonFromOtherW ) eventCounter->addCount(" mT > 100:  muon from other W"); 
            if ( muonOutsideEtaRange ) eventCounter->addCount(" mT > 100:  other muon eta> 2.5");
            if ( muonBelow5GeV ) eventCounter->addCount(" mT > 100:  other muon pt < 5 GeV");
	    if (fabs(resolutionMuon) >  0.1 ) eventCounter->addCount(" mT > 100:  bad muon resolution");
            if ( mcTauFromW.Et() == 0 ) {
               if ( mcElectronFromW.Et() > 0 ) eventCounter->addCount(" No tau: W->e+nu"); 
               if ( muonFromOtherW ) eventCounter->addCount(" No tau:  muon from other W"); 
               if (fabs(resolutionMuon) >  0.1 ) eventCounter->addCount("No tau:  bad muon resolution");
	    }

	    ///////////   reco muons
            cout <<  " Muons " <<event->muons.size() << endl;
             for(vector<MyJet>::iterator iMuon = event->muons.begin();
                                    iMuon != event->muons.end(); iMuon++){
               double DR  = deltaR(iMuon->eta(),mcMuonFromW.Eta(),iMuon->phi(),mcMuonFromW.Phi());
	       cout <<  " reco muon pt " << iMuon->pt() << " eta " << iMuon->eta()  << " DR(Wmu-mu) " << DR << endl;
	     }
	     ////////////all jets and hard tracks
             if(!histograms->booked("h_trackResolution100") ) histograms->book("h_trackResolution100",100,-5,5);
  
	     cout <<  " Jets " <<bCandidates.size() << endl;
            for(vector<MyJet>::iterator iJet = bCandidates.begin();
                                    iJet != bCandidates.end(); iJet++){
	       if ( iJet->Et() > 20 ) cout <<  " Et " << iJet->Et() << " eta " << iJet->Eta() << endl;   
               vector<MyTrack> tracks = iJet->tracks;
	       for(vector<MyTrack>::iterator iTrack = tracks.begin();
                                    iTrack != tracks.end(); iTrack++){
		    if(iTrack->Pt() > 20){
			 double trackEta = iTrack->eta();
			 double trackPhi = iTrack->phi();
            		 double DR = deltaR(iJet->eta(),trackEta,
                                            iJet->phi(),trackPhi);
                         cout << " track in jet " << iTrack->Pt() << " DR " << DR << endl;
                         double drmin = 9999;
			 //                         MyMCParticle matchingParticle(0,0,0,0);
                         vector<MyMCParticle>::iterator matchingParticle;
                         vector<MyMCParticle> mcParticles = event->mcParticles;
                         for(vector<MyMCParticle>::iterator imc = mcParticles.begin();
	                                                    imc!= mcParticles.end(); imc++){
			       if ( imc->pid == 22 ) continue;
			       if ( imc->pid == 12 ) continue;
                               if ( imc->pid == 14 ) continue;
			       if ( imc->pid == 16 ) continue;
            		       double DR = deltaR(imc->eta(),trackEta,imc->phi(),trackPhi);

                               if( abs(imc->pid) != 22 && abs(imc->pid) != 111 && abs(imc->pid) != 12 && abs(imc->pid) != 14  && abs(imc->pid) != 16) {

				 //				 cout << " track,id " << imc->pid << " pt " << imc->Pt() << " DR " << DR <<  endl;  
    
                              if( DR < drmin && abs(imc->pid) != 22 ) {
				        drmin = DR;
                                        matchingParticle = imc;
                                    }
                               }
                         }
                         if ( drmin < 9999 ) { 
                                   int mother1 = 0;
                                   vector<int> motherList = matchingParticle->mother; 
                                   if(motherList.size() > 0) mother1 = (*motherList.begin());
                                   if ( matchingParticle->Pt() > 0) {
				        double trackResolution = (matchingParticle->Pt()-iTrack->Pt()) / matchingParticle->Pt();
	                                histograms->fill("h_trackResolution100",trackResolution);
                                        double DRsquark  = 99;
                                        if ( sQuarkFromW.Et() > 0 ) DRsquark=deltaR(matchingParticle->Eta(),sQuarkFromW.Eta(),matchingParticle->Phi(),sQuarkFromW.Phi());

                                        double DRcquark  = 99;
                                        if ( cQuarkFromW.Et() > 0 ) DRcquark  = deltaR(matchingParticle->Eta(),cQuarkFromW.Eta(),matchingParticle->Phi(),cQuarkFromW.Phi());
				   cout << " matchingParticle, id " << matchingParticle->pid << " pt " << matchingParticle->Pt() << " Min DR " << drmin <<  " mother1  "  << mother1 << " from c " << DRcquark << " from s " << DRsquark << endl;
				   }
		         }
	            }
	        }       
            }

	     //////////// b jets
	     cout <<  " b candidates " <<bCandidates.size() << endl;
            for(vector<MyJet>::iterator iJet = bCandidates.begin();
                                    iJet != bCandidates.end(); iJet++){
                double discriminator = iJet->tag("discriminator");
                double drmin = 99999;
                for(vector<MyJet>::iterator iJet2 = BquarksFromTop.begin();
                                            iJet2 != BquarksFromTop.end(); iJet2++){		      
	              double DR = deltaR(iJet->Eta(),iJet2->Eta(),iJet->Phi(),iJet2->Phi());
                      if( DR < drmin ) {
	                  drmin = DR;
                      }
                }
	        cout <<  " Et " << iJet->Et() << " eta " << iJet->Eta() << " discriminator "<< discriminator << " dr(b-jet) " << drmin << endl;           
            }
            cout << " MC info " << endl;
	    if( mcTauFromW.Et()>0) cout << " MCtau from W et " <<  mcTauFromW.Et() << " eta  " <<  mcTauFromW.Eta() << endl;
	    if(mcTauNuFromW.Et()>0) cout << " MCtauNu from W et " <<  mcTauNuFromW.Et() << " eta  " <<  mcTauNuFromW.Eta() << endl;
            if(visibleTauPlus.Et()>0)  cout << " visibleTauPlus.Et() " << visibleTauPlus.Et()  <<" leadingTauTrack " << leadingTauTrack.Et()  << " nChargedPions " << nChargedPions << " nNeutralPions " << nNeutralPions  << endl;
           if(visibleTauMinus.Et()>0) cout <<  " visibleTauMinus.Et() " << visibleTauMinus.Et() <<" leadingTauTrack " << leadingTauTrack.Et()  << " nChargedPions " << nChargedPions << " nNeutralPions " << nNeutralPions  << endl;
            if(mcElectronFromW.Et()> 0 ) cout << " MC electron from W et " <<  mcElectronFromW.Et() << " eta  " <<  mcElectronFromW.Eta() << endl;

            cout <<  " b quarks from top " << BquarksFromTop.size() << endl;
            for(vector<MyJet>::iterator iJet = BquarksFromTop.begin();
                                    iJet != BquarksFromTop.end(); iJet++){
                cout <<  " Et " << iJet->Et() << " eta " << iJet->Eta() << endl;  
            }


            bool taufound = false;
            bool Wfound = false;
            bool bottomfound = false;
            bool cfound = false;

            if (  muParticle.Pt() > 0 ) {

                int mother1 = 0;
                vector<int> motherList = muParticle.mother; 
		cout << " motherList.size() " <<  motherList.size() << endl;

                for(vector<int>::const_iterator iMother = motherList.begin();
                                            iMother!=motherList.end(); iMother++)  {
		  if( abs( muParticle.pid) == 13 ) cout << " muon mother in tail  " << (*iMother) << endl;
                     if(abs(*iMother) == 15) taufound = true;
                     if(abs(*iMother) == 24) Wfound = true;
  
                     if( abs(*iMother) == 5 ||
                       (abs(*iMother) > 500 && abs(*iMother) < 600) ||
	               (abs(*iMother) > 5000 && abs(*iMother) < 6000) ) {
                              bottomfound = true;
                     } 
                     if( abs(*iMother) == 4 ) cfound = true; 
                }
    

                if (DRmin > 0.1 ) eventCounter->addCount("   DR(muon-MC part ) > 0.1"); 
      
                if (DRmin < 0.1 )  {
                      eventCounter->addCount("   DR(muon-MC part ) < 0.1:"); 
                      if(motherList.size() > 0) mother1 = (*motherList.begin());
                      if( abs( muParticle.pid) == 13 ) {
                            eventCounter->addCount("   matching MC muon ");
                            if ( abs(mother1) == 24) eventCounter->addCount("   matching MC muon from W");
                            if (bottomfound ) eventCounter->addCount("   muon from bottom ");
                      }
	        }
            }


           if(!histograms->booked("h_electronFromB100") ) histograms->book("h_electronFromB100",100,0,500);
           if(!histograms->booked("h_eNuFromB100") ) histograms->book("h_eNuFromB100",100,0,500);
           for(vector<MyJet>::iterator ib = electronsFromB.begin();
                                       ib != electronsFromB.end(); ib++){                 
	         histograms->fill("h_electronFromB100",ib->Et()); 
           }
           for(vector<MyJet>::iterator ib = eNuFromB.begin();
                                       ib != eNuFromB.end(); ib++){
	         histograms->fill("h_eNuFromB100",ib->Et()); 
           }

           if(!histograms->booked("h_leadingTauTrack100") ) histograms->book("h_leadingTauTrack100",100,0,100);
           if(!histograms->booked("hEtHcalOverTracks100") ) histograms->book("hEtHcalOverTracks100",100,-1.5,5.5);


           if( mcTauFromW.Et() > 0 ) {
	     histograms->fill("h_leadingTauTrack100",leadingTauTrack.Pt());
             histograms->fill("hEtHcalOverTracks100",etHcalOverTracks); 


           cout << " match MC part orig, tau " << taufound  << "     W " << Wfound  << "    b " << bottomfound << "    c " << cfound<< " Et other neutrinos " <<  neutrinos.Et() << endl;
           }
      
           if(!histograms->booked("h_ptMuMETcuts") ) histograms->book("h_ptMuMETcuts",100,0,250);
               histograms->fill("h_ptMuMETcuts",ptMuonMet); 
   	   if ( visibleTauPlus.Et()> 0)  {
               if(!histograms->booked("h_visibleTauEt100") ) histograms->book("h_visibleTauEt100",100,0,250);
               histograms->fill("h_visibleTauEt100",visibleTauPlus.Et()); 
           } 
   	   if ( visibleTauMinus.Et()> 0)  {
               if(!histograms->booked("h_visibleTauEt100") ) histograms->book("h_visibleTauEt100",100,0,250);
               histograms->fill("h_visibleTauEt100",visibleTauMinus.Et()); 
           }
           if(!histograms->booked("h_taunuFromW100") ) histograms->book("h_taunuFromW100",100,0,250);
	   histograms->fill("h_taunuFromW100",mcTauNuFromW.Et());
           if(!histograms->booked("h_massTrue100") ) histograms->book("h_massTrue100",100,0,500);
           histograms->fill("h_massTrue100",massTrue);
           if(!histograms->booked("h_topmass100") ) histograms->book("h_topmass100",100,0,500);
           histograms->fill("h_topmass100",topmass);            
           if(!histograms->booked("h_dphiMuMET100") ) histograms->book("h_dphiMuMET100",90,0,180);
           histograms->fill("h_dphiMuMET100",dphiMuMet);                
           if(!histograms->booked("h_dphiMetNu100") ) histograms->book("h_dphiMetNu100",90,0,180);
           histograms->fill("h_dphiMetNu100",dphiMETnu);         
           if(!histograms->booked("h_metMT100") ) histograms->book("h_metMT100",100,0,500);
           histograms->fill("h_metMT100",met);           
           if(!histograms->booked("h_MCmetMT100") ) histograms->book("h_MCmetMT100",100,0,500);
           histograms->fill("h_MCmetMT100",MCmet); 	
           if(!histograms->booked("h_muonMT100") ) histograms->book("h_muonMT100",100,0,250);
           histograms->fill("h_muonMT100",theMuon.pt()); 	 
            if(!histograms->booked("h_dphiMetMT100") ) histograms->book("h_dphiMetMT100",100,0,5);
           histograms->fill("h_dphiMetMT100",dphiMETmcMET);     
           if(!histograms->booked("h_muonResolution100") ) histograms->book("h_muonResolution100",100,-1,1);
           histograms->fill("h_muonResolution100",resolutionMuon);
           if(!histograms->booked("h_ptMuMET100") ) histograms->book("h_ptMuMET100",100,0,300);
           histograms->fill("h_ptMuMET100",ptMuonMet);


	   //           if( neutrinos.Et() == 0 ) {
	   //              if(!histograms->booked("h_metResolution100NoNu") ) histograms->book("h_metResolution100NoNu",100,-5,5);
	   //              histograms->fill("h_metResolution100NoNu",resolutionMet);
	   //           }
	   //           if(!histograms->booked("h_metResolution100") ) histograms->book("h_metResolution100",100,-5,5);
	   //           histograms->fill("h_metResolution100",resolutionMet);

           if(!histograms->booked("h_ptMCMuonFromW100") ) histograms->book("h_ptMCMuonFromW100",100,0,250);
           histograms->fill("h_ptMCMuonFromW100",mcMuonFromW.Et());          
           if(!histograms->booked("h_ptMCnuFromW100") ) histograms->book("h_ptMCnuFromW100",100,0,250);
           histograms->fill("h_ptMCnuFromW100",mcNuFromW.Et());          
           if(!histograms->booked("h_ptMCtauFromW100") ) histograms->book("h_ptMCtauFromW100",100,0,250);
           histograms->fill("h_ptMCtauFromW100",mcTauFromW.Et());        
           if(!histograms->booked("h_ptAllNeutrinos100") ) histograms->book("h_ptAllNeutrinos100",100,0,250);
           histograms->fill("h_ptAllNeutrinos100",neutrinoMomentum.Et());          
           if(!histograms->booked("h_ptNeutrinos100") ) histograms->book("h_ptNeutrinos100",100,0,250);
           histograms->fill("h_ptNeutrinos100",neutrinos.Et());            
     
            if(!histograms->booked("h_ptMCelectronFromW100") ) histograms->book("h_ptMCelectronFromW100",100,0,250);
           histograms->fill("h_ptMCelectronFromW100",mcElectronFromW.Et());   
          	
           if(!histograms->booked("h_muonChi2100") ) histograms->book("h_muonChi2100",100,0,50);
	   histograms->fill("h_muonChi2100",muonChi2);
           if(!histograms->booked("h_muonIpz100") ) histograms->book("h_muonIpz100",100,0,0.1);
	   histograms->fill("h_muonIpz100",muonIpz);       	
           if(!histograms->booked("h_muonHits100") ) histograms->book("h_muonHits100",100,0,50);
	   histograms->fill("h_muonHits100",muonHits); 
           if(!histograms->booked("h_muonIp2D100") ) histograms->book("h_muonIp2D100",100,-5,5);
	   histograms->fill("h_muonIp2D100",muonIp2D);
        } 
	 
	//	eventFilter->saveEvent(event);

}







