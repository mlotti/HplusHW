import sys,shutil,glob,os

# Factory method
def init(name):
    if name == "arc":
        return Arc()
    elif name == "arclib":
        return Arclib()
    elif name == "test":
        return Test()
    else:
        print "Middleware", name, "not recognised!"
        sys.exit(1)


class Middleware:
    # Middleware interface
    def proxyValid(self):
        raise MiddlewareError("Not implemented")

    def create(self, jobNumber, arguments, inputfiles, outputfiles, notify="", email=""):
        raise MiddlewareError("Not implemented")

    def submit(self, descriptionList, whitelist, blacklist):
        raise MiddlewareError("Not implemented")

    def resubmit(self):
        raise MiddlewareError("Not implemented")

    def kill(self, idList):
        raise MiddlewareError("Not implemented")

    def getoutput2(self, idList, numList):
        raise MiddlewareError("Not implemented")

    def getoutput(self, id, num):
        raise MiddlewareError("Not implemented")

    def status(self, idList):
        raise MiddlewareError("Not implemented")



class MiddlewareError(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message

import os,re,time
class Arc(Middleware):
    def proxyValid(self):
        valid = int(os.system("grid-proxy-info -e"))
        return valid == 0

    # inputfiles[0][0] must contain the executable
    def create(self, jobNumber, arguments, inputfiles, outputfiles, notify="", email=""):
        lst = []
        for f in inputfiles:
            lst.append("(\"%s\" \"%s\")" % f)
        lst2 = []
        for f in outputfiles:
            lst2.append("(\"%s\" \"%s\")" % f)
        lst3 = []
        for a in arguments:
            lst3.append("\"%s\"" % str(a))
        
        retstr = "&(executable=\"%s\")" % inputfiles[0][0]
        if len(lst3) > 0:
            retstr += "(arguments=%s)" % " ".join(lst3)
        if len(lst) > 0:
            retstr += "(inputFiles=%s)" % " ".join(lst)
        retstr += "(jobName=\"HipGridAnalysis\")"
        retstr += "(runTimeEnvironment>=\"APPS/HEP/ROOT-5.16.00\")"
        retstr += "(stdout=\"stdout.txt\")"
        retstr += "(join=\"yes\")"
        retstr += "(gmlog=\"grid.log\")"
        retstr += "(architecture=\"x86_64\")"

        if len(notify) > 0:
            if len(email) == 0:
                raise MiddlewareError("notify %s given, email empty" % notify)
            retstr += "(notify=\"%s %s\")" % (notify, email)
        
        if len(lst2) > 0:
            retstr += "(outputfiles=%s)" % " ".join(lst2)
        return retstr

    def submit(self, descriptionList, whitelist, blacklist):
        # if whitelist has items, remove ones which are also in blacklist
        # if whitelist is empty, use blacklist
        ce_lst = []
        if len(whitelist) > 0:
            for ce in whitelist:
                if ce not in blacklist:
                    ce_lst.append("-c %s" %ce)
        else:
            ce_lst = ["-c -%s" % ce for ce in blacklist]
        
        dlst = ["-e '%s'" % desc for desc in descriptionList]
        cmd = "ngsub "+ " ".join(dlst) + " " + " ".join(ce_lst)

        output = self.execute(cmd)
#         output = ["Job submitted with jobid: gsiftp://akaatti.tut.fi:2811/jobs/287381204291882998435441",
#                   "Job submitted with jobid: gsiftp://akaatti.tut.fi:2811/jobs/287841204291882955346303",
#                   "",
#                   "Job submission summary:",
#                   "-----------------------,",
#                   "2 of 2 jobs were submitted."]

        ids = []
        p=re.compile("jobid:\s*(\S+)")
        for line in output:
            match = p.search(line)
            if match:
                ids.append(match.group(1))
        if len(ids) != len(descriptionList):
            outstr = "".join(output)
            print outstr
            raise MiddlewareError("ngsub: "+outstr)
        return ids

    def getoutput2(self, idlist, numlist):
        if len(idlist) != len(numlist):
            raise MiddlewareError("getoutput: len(idlist)=%d != len(numlist)=%d" % (len(idlist),len(numlist)))
        
        cmd = "ngget %s" % " ".join(idlist)
        output = self.execute(cmd)
#        output = ["Results stored at /home/mjkortel/HipProofAnalysis/workspace/287381204291882998435441",
#                  "Results stored at /home/mjkortel/HipProofAnalysis/workspace/287841204291882955346303",
#                  "Jobs processed: 2, successfuly downloaded: 2 "]

        srclist = []
        src_re = re.compile("at (/.*)")
        ext_re = re.compile("(\..*?$)")
        for line in output:
            match = src_re.search(line)
            if match:
                srclist.append(match.group(1))

        if len(srclist) != len(idlist):
            outstr = "".join(output)
            raise MiddlewareError("ngget: "+outstr)

        i=0
        for src in srclist:
            num = numlist[i]
            i+=1
            for file in glob.glob(src+"/*"):
                fname = os.path.basename(file)

                if ext_re.search(fname):
                    fname = ext_re.sub("-%d\g<1>"%num, fname)
                else:
                    fname+= "-%d" % num

                if os.path.isdir(file):
                    shutil.copytree(file, fname)
                else:
                    shutil.copy2(file, fname)

            shutil.rmtree(src)

    def getoutput(self, id, num):
        bn_id = os.path.basename(id)
        if os.path.exists(bn_id):
            new = bn_id+".old-%s" % time.strftime("%Y%m%d-%H%M%S")
            print "Moving existing ngget dir %s to %s" % (bn_id, new)
            shutil.move(bn_id, new)
        
        cmd = "ngget %s" % id
        output = self.execute(cmd)

        srclist = []
        src_re = re.compile("at (/.*)")
        ext_re = re.compile("(\..*?$)")
        for line in output:
            match = src_re.search(line)
            if match:
                srclist.append(match.group(1))

        if len(srclist) != 1:
            outstr = "".join(output)
            raise MiddlewareError("ngget: "+outstr)

        src = srclist[0]
        for file in glob.glob(src+"/*"):
                fname = os.path.basename(file)

                if ext_re.search(fname):
                    fname = ext_re.sub("-%d\g<1>"%num, fname)
                else:
                    fname+= "-%d" % num

                if os.path.isdir(file):
                    shutil.copytree(file, fname)
                else:
                    shutil.copy2(file, fname)

        shutil.rmtree(src)
            


    def status(self, idlist):
        cmd = "ngstat %s" % " ".join(idlist)
#        print cmd
        output = self.execute(cmd)
#         output = ["Job gsiftp://akaatti.tut.fi:2811/jobs/287381204291882998435441",
#                   "Job Name: HipGridAnalysis",
#                   "Status: FINISHED",
#                   "Exit code: 0",
# #                  "Job information not found: gsiftp://akaatti.tut.fi:2811/jobs/287841204291882955346303"]
#                   "Job gsiftp://akaatti.tut.fi:2811/jobs/287841204291882955346303",
#                   "Job Name: HipGridAnalysis",
#                   "Status: INLRMS:R"]

        output.reverse()
        retlist = []
        notfound = re.compile("Job information not found")
        status_re = re.compile("Status:\s*(\S*)")
        code_re = re.compile("Exit Code:\s*(\S*)")
        while len(output) > 0:
            line = output.pop()
            if notfound.search(line):
                retlist.append(("Not found", -1))
                continue

            
            match = status_re.search(line)
            if match:
                status_str = match.group(1)
                exitcode = -1
                if len(output) > 0:
                    next = output.pop()
                    match = code_re.search(next)
                    if match:
                        exitcode = int(match.group(1))
                    else:
                        output.append(next)
                retlist.append((status_str, exitcode))

        if len(retlist) != len(idlist):
            output.reverse()
            raise MiddlewareError("ngstat: %s" % "".join(output))

        return retlist

    def kill(self, idList):
        cmd = "ngkill %s" % " ".join(idList)
        output = self.execute(cmd)
        print "".join(output)

    def execute(self, cmd):
        f = os.popen2(cmd)[1]
        ret=[]
        for line in f:
            ret.append(line)
        f.close()
        return ret

    def extractOutputDir(self, jobid):
        return re.compile("/(\d+)").search(jobid).group(1)

# from arclib import *

# class Arclib(Middleware):
#     def create(self, jobNumber, inputfiles):
#         return """&(executable=/bin/echo)
#         (arguments=\"Hello grid %d\")
#         """ % jobNumber

#     def submit(self, description):
#         SetNotifyLevel(VERBOSE)
#         return "THIS DOES NOT WORK!"
# #        c = Certificate(PROXY)
        
# #        print "ARC: Creating xRSL object"
# #        xrsl = Xrsl(description)
# #        print "ARC: Queruing queues"
# #        qi = GetQueueInfo([], MDS_FILTER_CLUSTERINFO, False, c.GetSN())
# #        print ""
# #        print "ARC: Preparing job"
# #        targets = PrepareJobSubmission(xrsl)
# #        print "ARC: Submitting"
# #        jobid = SubmitJob(xrsl, targets)
# #        print "ARC: Submitted"
# #        return jobid

class Test(Middleware):
    # Middleware interface
    def proxyValid(self):
        print "Checking proxy (true)"
        return True

    def create(self, jobNumber, arguments, inputfiles, outputfiles, notify="", email=""):
        lst = []
        for i in inputfiles:
            lst.append("r: %s, l: %s"% i)

        lst2 = []
        for i in outputfiles:
            lst2.append("r: %s, l: %s"% i)

        print "Creating job with number", jobNumber
        print "Input files: %s" % "\n".join(lst)
        print "Output files: %s" % "\n".join(lst2)
        print "Notify: %s" % notify
        print "Email: %s" % email
        print
        return "Description: %d" % jobNumber

    def submit(self, descriptionList, whitelist, blacklist):
        for desc in descriptionList:
            print "Submitting description", desc
        print "CE whitelist: %s" % ", ".join(whitelist)
        print "CE blacklist: %s" % ", ".join(blacklist)
        return descriptionList

    def kill(self, idList):
        for id in idList:
            print "Killing id", id

    def getoutput2(self, idlist, numlist):
        for i in range(0, len(idlist)):
            print "Fetching output for id %s for job %d"%(idlist[i], numlist[i])

    def getoutput(self, id, num):
        print "Fetching output for id %s for job %d"%(id, num)

    def status(self, idlist):
        ret = []
        for id in idlist:
            print "Querying status for id", id
            ret.append(("Success", 2))
        return ret

