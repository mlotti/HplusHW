from myparser import MyOptions, MyInput
from jobs import Task
import glob,os

class HipGridAnalysis:
    def __init__(self, argv, inputfile):
        self.options = MyOptions(argv)
        self.defaultInput = inputfile

    def run(self):

        # check help
        if self.options.has("help"):
            self.options.printHelp()
            return

        # get options instance
        if self.options.has("create"):
            self.createTask()
        elif self.options.has("continue"):
            self.continueTask(self.options.getContinueDir())
        else:
            list = glob.glob("hipga_*")
            if len(list) > 0:
                list.sort()
                self.continueTask(list.pop())
            else:
                print "No jobs found, you must -create one first!"
                self.options.printHelp()
                return

        if not self.input.verifyInput():
            print "" # extra newline
            self.options.printHelp()
            return

        self.options.checkRange(0, self.input.njobs()-1)

        # check proxy validity
        if not self.task.proxyValid():
            print "No valid proxy certificate found!"
            print "Create new proxy with e.g. grid-proxy-init"
            return

        # check other commands
        range = self.options.getRange()
        if self.options.has("submit"):
            self.task.submit(range)
        elif self.options.has("resubmit"):
            self.task.resubmit(range)
        elif self.options.has("getoutput"):
            self.task.getoutput(range)
        elif self.options.has("status"):
            self.task.status(range)
        elif self.options.has("kill"):
            self.task.kill(range)
        elif self.options.has("clean"):
            self.task.clean()

        # if not clean, dump job to disk
        if not self.options.has("clean"):
            self.task.dump()

            
    def createTask(self):
        self.input = MyInput(self.defaultInput)
        if not self.input.verifyInput():
            return
        
        print "Creating task area for %d job(s)" % self.input.njobs()
        self.task = Task()
        self.task.create(self.input)
        print "Task area created at", self.task.getDirectory()
       
    def continueTask(self, taskdir):
        self.task = Task()
        self.task.load(taskdir)
        self.input = MyInput(self.task.inputFilename())
