import re, os

class MyOptions:
    
    def __init__(self, argv):
        self.kExe = argv[0]
        args = argv[1:]
        args.reverse()

        self.kOpt = {}
        self.kRange = []
        
        # read cmdline options
        while len(args) > 0:
            opt = args.pop()
            if opt == "-help":
                self.kOpt["help"] = True
            elif opt == "-create":
                self.kOpt["create"] = True
            elif opt == "-submit":
                self.kOpt["submit"] = True
            elif opt == "-resubmit":
                self.kOpt["resubmit"] = True
            elif opt == "-getoutput":
                self.kOpt["getoutput"] = True
            elif opt == "-status":
                self.kOpt["status"] = True
            elif opt == "-kill":
                self.kOpt["kill"] = True
            elif opt == "-clean":
                self.kOpt["clean"] = True
            elif opt == "-continue":
                if len(args) == 0:
                    self.kOpt["help"] = True
                    print "-continue requires parameter!"
                else:
                    self.kOpt["continue"] = args.pop()
            else:
                if len(self.kRange) > 0:
                    print "Range already specified!", self.kRange
                    self.kOpt["help"] = True
                elif opt == "all":
                    self.kRange = [-1] # -1 for all
                else:
                    for i in opt.split(","):
                        if i.count("-") == 0 and i.isdigit():
                            self.kRange.append(int(i))
                            continue

                        temp = i.split("-")
                        if len(temp) != 2 or not temp[0].isdigit() or not temp[1].isdigit():
                            print "Malformed range:", opt
                            self.kOpt["help"] = True
                            break

                        self.kRange.extend(range(int(temp[0]), int(temp[1])+1))

        # final checks for options
        if len(self.kOpt) == 0:
            self.kOpt["help"] = True
            return

        if len(self.kOpt) > 1:
            if not (len(self.kOpt) == 2 and ((self.kOpt.has_key("create")
                                              and self.kOpt.has_key("submit"))
                                             or (self.kOpt.has_key("continue")
                                                 and not self.kOpt.has_key("create")))):
                self.kOpt["help"] = True
                print "Invalid options:"
                print "    -create can coexist only with -submit"
                print "    -continue can coexist only with other commands than -create"
                return

        if self.kOpt.has_key("create") and (len(self.kRange) == 0 
                                            or self.kRange[0] != -1):
            self.kOpt["help"] = True
            print "Invalid options:"
            print "    -create requires range 'all'"

        if self.kOpt.has_key("kill") and len(self.kRange) == 0:
            self.kOpt["help"] = True
            print "Invalid options:"
            print "    -kill requires explicit range"


    def has(self, str):
        return self.kOpt.has_key(str)

    def checkRange(self, min, max):
        if len(self.kRange) == 0 or self.kRange[0] == -1:
            self.kRange = range(min, max+1)
        else:
            self.kRange.sort()

            # check for duplicates
            prev = -1
            for i in self.kRange:
                if i == prev:
                    print "Range contains duplicates"
                    self.kOpt["help"] = True
                    return
                prev = i
            if self.kRange[0] < min or self.kRange[-1] > max:
                print "Range contains nonexisting jobs (allowed [%d, %d])" % (min, max)
                self.kOpt["help"] = True
                return

    def getRange(self):
        return self.kRange

    def getContinueDir(self):
        if not self.kOpt.has_key("continue"):
            return ""
        return self.kOpt["continue"]

    def printHelp(self):
        print "Usage: %s [-help]" % self.kExe
        print " -help               Print this help message"
        print " -create    all      Create (all) jobs"
        print " -submit    [range]  Submit jobs"
        print " -resubmit  [range]  Resubmit jobs"
        print " -getoutput [range]  Get job output to task directory"
        print " -status    [range]  Check the status of jobs"
        print " -kill      <range>  Kill jobs"
        print ""
        print "Range is a range of jobs, starting from zero (0)"
        print "Example: 0,3,5-11,5   ; all is expanded to all jobs"
        print ""

class MyInputError(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message



class MyInput:
    def __init__(self, inputfile):
        self.kInputok = True

        print "Using input file", inputfile
        self.kFilename = inputfile
        file=open(inputfile, "r")
        lines = file.readlines()
        file.close()
        lines.reverse()

        # strip comments
        content_lines = []
        comment_line = re.compile("(^|[^:]/*?)//.*$")
        comment_block = re.compile("/\*.*\*/")
        comment_start = re.compile("/\*.*$")
        comment_end = re.compile("^.*\*/")
        while len(lines) > 0:
            line = lines.pop()

            line = comment_line.sub("\g<1>", line) # strip // comments, except :// in URLS
                                                   # (if URL has :/// or more slashes,
                                                   # this considers :/(//) slashes in parenthesis
                                                   # as comments
            line = comment_block.sub("", line) # strip /* ... */ on single lines

            # strip multiline /* */ comments,
            comment = comment_start.search(line)
            if comment:
                line = comment_start.sub("", line)
                content_lines.append(line)
                while len(lines) > 0:
                    line2 = lines.pop()
                    comment2 = comment_end.search(line2)
                    if comment2:
                        line2 = comment_end.sub("", line2)
                        line = line2
                        break
                    content_lines.append("")
            content_lines.append(line)

        # parse input
        self.kCuts = {}
        self.kDatasetNames = []
        self.kDatasets = {}
        self.kDatasetFiles = {}
        self.kScanParameter = ""
        self.kScanValues = []
        self.kGridParam = {}
        scan = self.parse(content_lines)

        # mode
        if not self.kGridParam.has_key("grid_parallel_mode"):
            self.kInputok = False
            print "grid_parallel_mode is missing"
            return
        self.kMode = self.kGridParam["grid_parallel_mode"]
        ok = False
        for x in ["single", "scan", "data", "dataset"]:
            if self.kMode == x:
                ok = True
        if not ok:
            self.kInputok = False
            print "grid_parallel_mode is %s; should be 'single', 'scan' or 'data'" % self.kMode
            return

        # inspect datasets for correct data
        url_re = re.compile("\.URLs$")
        for name in self.kDatasetNames:
            if not self.kDatasets.has_key(name):
                self.kInputok = False
                print "Dataset '%s' not found" % name
                continue
            if not self.kDatasets[name].has_key("directory"):
                self.kInputok = False
                print "Dataset '%s' doesn't have 'directory'" % name
                continue
            dirname = self.kDatasets[name]["directory"]
            if not url_re.search(dirname):
                self.kInputok = False
                print "Dataset '%s' has non-URL directory, which is not supported by grid script" % name

        # if parallel mode is data, url files
        url_re = re.compile("://")
        if self.kMode == "data":
            for name in self.kDatasetNames:
                self.kDatasetFiles[name] = []
                fname = os.path.join("..", "dataURLs", self.kDatasets[name]["directory"])
                f = open(fname)
                for line in f:
                    if url_re.search(line):
                        self.kDatasetFiles[name].append(line.replace("\n", ""));
                f.close()
            #print self.kDatasetFiles

        # check scanning
        if self.kMode == "scan":
            for check in ["Scan parameter", "scanRangeBegin", "scanRangeEnd", "scanNSteps"]:
                if not scan.has_key(check):
                    self.kInputok = False
                    print "%s is missing" % check
            if self.kInputok:
                self.kScanParameter = scan["Scan parameter"]
                begin = scan["scanRangeBegin"]
                end = scan["scanRangeEnd"]
                steps = scan["scanNSteps"]
                for i in range(0, steps):
                    self.kScanValues.append(begin + i*(end-begin)/(steps-1))
        elif len(scan) > 0:
            self.kInputok = False
            print "Scan parameters given, however grid_parallel_mode is %s (should be 'scan')" % self.kMode

        # deduce number of jobs
        self.kNjobs = 0
        if self.kMode == "single":
            self.kNjobs = 1
        elif self.kMode == "scan":
            n = len(self.kScanValues)
            if n > 0:
                self.kNjobs = n
            else:
                self.kNjobs = -1
        elif self.kMode == "data":
            if len(self.kDatasetNames) > 1:
                print "Data parallelization is currently ONLY supported for single datasets"
                self.kInputok = False
            elif self.kGridParam.has_key("grid_njobs"):
                self.kNjobs = int(self.kGridParam["grid_njobs"])

                ds_name = self.kDatasetNames[0]
                nfiles = len(self.kDatasetFiles[ds_name])
                if self.kNjobs > nfiles:
                    print "More jobs (%d) requested than dataset (%s) contains (%d)" % (self.kNjobs, ds_name, nfiles)
                    self.kInputok = False
                elif self.kNjobs < 1:
                    print "grid_jobs should be >= 1"
                    self.kInputok = False
            else:
                self.kNjobs = 1
        elif self.kMode == "dataset":
            self.kNjobs = len(self.kDatasetNames)
      
        # check grid parameter existence
        for check in ["grid_middleware", "grid_storage"]:
            if not self.kGridParam.has_key(check):
                self.kInputok = False
                print "%s is missing" % check
        if self.kInputok:
            se=self.kGridParam["grid_storage"]
            url_re = re.compile("^gsiftp://")
            if se != "output" and not url_re.search(se):
                self.kInputok = False
                print "Invalid storage element: %s" % se
                print "Mode \"output\" and gsiftp:// URLs are supported"

        # check notify
        if self.kGridParam.has_key("grid_notify") and not self.kGridParam.has_key("grid_email"):
            print "grid_notify given, but not grid_email"
            self.kInputok = False
        

    def verifyInput(self):
        return self.kInputok

    def filename(self):
        return self.kFilename

    def contentForJob(self, jobnum, datasets=[]):
        if len(datasets) == 0:
            datasets = self.kDatasetNames

        ret = "datasets = {%s}\n" % ",".join(datasets)
        for key in self.kCuts:
            ret += "%s=%s\n" % (key, self.kCuts[key])

        if self.kMode == "scan":
            ret += "\n// This is the scan parameter and it's value in this job\n"
            ret += "%s=%f\n\n" % (self.kScanParameter, self.kScanValues[jobnum])

        for name in datasets:
            ret += "dataset = {\n"
            dataset = self.kDatasets[name]

            temp = []
            for key in dataset:
                temp.append("    %s=%s" % (key, dataset[key]))
            ret += ",\n".join(temp)
            ret += "\n}\n"

        return ret

    def filesForJob(self, dataset, jobnum):
        ret = []
        files = self.kDatasetFiles[dataset]
        begin = jobnum*len(files) / self.kNjobs
        end = (jobnum+1)*len(files) / self.kNjobs

        return files[begin:end]

    def isScanTask(self):
        return self.kMode == "scan"

    def getMode(self):
        return self.kMode

    def njobs(self):
        return self.kNjobs

    def getDatasetNames(self):
        return self.kDatasetNames

    def getDatasetFiles(self, dataset):
        if self.kDatasetFiles.has_key(dataset):
            return self.kDatasetFiles[dataset]
        else:
            return []

    def getDatasetDirectory(self, dataset):
        if self.kDatasets.has_key(dataset):
            return self.kDatasets[dataset]["directory"]
        else:
            return -1

    def setDatasetDirectory(self, dataset, dir):
        if self.kDatasets.has_key(dataset):
            ds = self.kDatasets[dataset]
            ds["directory"] = dir

    def getScanParameter(self):
        if self.kMode != "scan":
            raise MyInputError("Not a scan task")
        return self.kScanParameter

    def getScanValue(self, jobnum):
        if self.kMode != "scan":
            raise MyInputError("Not a scan task")
        return self.kScanValues[jobnum]

    def middleware(self):
        return self.kGridParam["grid_middleware"]

    def getOptionalValue(self, key, type="string"):
        if self.kGridParam.has_key(key):
            return self.kGridParam[key]
        elif type == "list":
            return []
        else:
            return ""

    def outputfiles(self):
        return self.getOptionalValue("grid_outputfiles", "list")

    def getWhitelist(self):
        return self.getOptionalValue("grid_whitelist", "list")

    def getBlacklist(self):
        return self.getOptionalValue("grid_blacklist", "list")

    def getNotify(self):
        return self.getOptionalValue("grid_notify")

    def getEmail(self):
        return self.getOptionalValue("grid_email")

    def storageElement(self):
        return self.kGridParam["grid_storage"]

    # parsing code, based on compiler technique:
    # first tokenize the input, then parse the lexer tokens
    def parse(self, lines):
        tokens = self.tokenize(lines)
        tokens.reverse()
        scan = {}

        grid_re = re.compile("grid_\S+")
        while len(tokens) > 0:
            token = tokens.pop()

            if token[0] != "id":
                self.kInputok = False
                print "Parse error in %s near '%s' at line %d" % (self.kFilename, token[1], token[2])
                break

            tree = self.parseId(token, tokens)
            if tree[0] == "datasets":
                self.kDatasetNames = tree[1]
            elif tree[0] == "dataset":
                dictio = {}
                for pair in tree[1]:
                    dictio[pair[0]] = pair[1]
                if len(dictio) == 0:
                    continue
                elif not dictio.has_key("name"):
                    self.kInputok = False
                    print "Dataset definition doesn't contain 'name' near line %d" % (self.kFilename, token[2])
                    continue
                else:
                    self.kDatasets[dictio["name"]] = dictio
            else:
                cutPar = tree[0]
                cutVal = tree[1]
                if grid_re.match(cutPar):
                    if self.kGridParam.has_key(cutPar):
                        self.kInputok = False
                        print "%s alread defined (old: %s, new %s)" % (cutPar, self.kGridParam[cutPar], cutVal)
                    else:
                        self.kGridParam[cutPar] = cutVal
                elif cutVal == "scan":
                    scan["Scan parameter"] = cutPar
                elif cutPar == "scanRangeBegin":
                    scan["scanRangeBegin"] = float(cutVal)
                elif cutPar == "scanRangeEnd":
                    scan["scanRangeEnd"] = float(cutVal)
                elif cutPar == "scanNSteps":
                    scan["scanNSteps"] = int(cutVal)
                else:
                    self.kCuts[cutPar] = cutVal
        return scan
            
                
    def parseId(self, id, tokens):
        variable = id[1]
        token = tokens.pop()
        if token[0] == "=":
            value = self.parseAssignment(tokens)
            return [variable, value]
        else:
            tokens.append(token)
            return variable

    def parseAssignment(self, tokens):
        while len(tokens) > 0:
            token = tokens.pop()
            if token[0] == "{":
                return self.parseBlock(tokens)
            elif token[0] == "id":
                return token[1]
            else:
                self.kInputok = False
                print "Parse error in %s near '%s' at line %d: expected '{' or 'id' instead (inside parseAssignment)" % (self.kFilename, token[1], token[2])
        self.kInputok = False
        print "Parse error in %s: premature end of file (inside parseAssignment)" % self.kFilename
        return ""

    def parseBlock(self, tokens):
        block = []
        while len(tokens) > 0:
            token = tokens.pop()

            if token[0] == "{":
                block.append(self.parseBlock(tokens))
            elif token[0] == "id":
                block.append(self.parseId(token, tokens))
                if len(tokens) == 0:
                    print "Parse error in %s: premature end of file (inside parseBlock)" % self.kFilename
                    return []
                token = tokens.pop()
                if token[0] == ",":
                    continue
                elif token[0] == "}":
                    return block
                else:
                    self.kInputok = False
                    print "Parse error in %s near '%s' at line %d: expected ',' or '}' instead (inside parseBlock)" % (self.kFilename, token[1], token[2])
                    tokens.append(token)
            else:
                self.kInputok = False
                print "Parse error in %s near '%s' at line %d: expected '{' or 'id' instead (inside parseBlock)" % (self.kFilename, token[1], token[2])
                return []
        return block
            
        

    def tokenize(self, lines):
        def match(regex, str, index, tokens, lineno):
            m = regex[1].match(str, index)
            if m:
                if regex[0] != "ws":
                    tokens.append((regex[0], m.group(), lineno))
                index = m.end()
            return index

        content = "".join(lines)

        curly_open = ("{", re.compile("{"))
        curly_close = ("}", re.compile("}"))
        equal = ("=", re.compile("="))
        comma = (",", re.compile(","))
        id = ("id", re.compile("[^\s{}=,]+"))
        ws = ("ws", re.compile("\s+"))

        tokens = []
        lineno = 0
        for line in lines:
            lineno += 1
            
            index = 0
            l = len(line)
            while index < l:
                old = index
                index = match(curly_open, line, index, tokens, lineno)
                index = match(curly_close, line, index, tokens, lineno)
                index = match(equal, line, index, tokens, lineno)
                index = match(comma, line, index, tokens, lineno)
                index = match(id, line, index, tokens, lineno)
                index = match(ws, line, index, tokens, lineno)

                if old == index:
                    self.kInputok = False
                    print "Parse error in %s near '%s' at line" % (self.kFilename, line[index:], lineno)
                    break
        return tokens
            
