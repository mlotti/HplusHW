from datetime import datetime
import time
import os,sys,shutil,re,glob
import random,md5
import pickle
import tarfile

import middleware

def buildUniqueString(temp):
    tm = time.time()
    hash= md5.new(temp + str(tm + tm*random.random()))
    return hash.hexdigest()

class Task:
    def __init__(self):
        self.kJobs = []
        self.kData = {"taskfile": "task.data",
                      "jobfile": "jobs.data",
                      "inputfile": "analysis.in",
#                      "packfile": "package.tar"}
                      "packfile": "package.tar.gz"}

    # Helper methods
    def directoryTree(self):
        taskdir = self.kData["taskdir"]
        self.kData["resultdir"] = os.path.join(taskdir, "res")
        self.kData["sharedir"] = os.path.join(taskdir, "share")
        self.kData["sharejobsdir"] = os.path.join(taskdir, "share", "jobs")

    def getDirectory(self):
        return self.kData["taskdir"]

    def getId(self):
        return self.kData["id"]

    def inputFilename(self):
        return os.path.join(self.kData["sharedir"], self.kData["inputfile"])

    def pack(self, dir, file):
        files = glob.glob(os.path.join(dir, "*"))
        
        tar = tarfile.open(file, "w:gz")
#        tar = tarfile.open(file, "w")
#        for name in ["bin", "libs", "dataURLs", "tmva/TMVA/lib", "tmva/data"]:
        for name in ["bin", "libs", "dataURLs"]:
            file = os.path.join("..", name);
            if os.path.exists(file):
                tar.add(file, name)
            else:
                print "Warning: %s doesn't exist (trying to add to %s)"%(file, self.kData["packfile"])

        for file in files:
            tar.add(file, os.path.basename(file))
        tar.close()


    # Creation method
    def create(self, input):
        # generate job directory
        dtstr = datetime.today().strftime("%y%m%d_%H%M%S")
        i=0
        while True:
           dir = "hipga_%d_" %i
           dir += dtstr

           if not os.path.exists(dir):
               os.mkdir(dir)
               self.kData["taskdir"] = dir
               break
           i += 1

        # init middleware
        self.kData["middleware"] = input.middleware();
        self.kMiddleware = middleware.init(self.kData["middleware"])

        # generate (semi-unique) job id string to prevent clashes
        self.kData["id"] = buildUniqueString(self.kData["taskdir"])

        # whitelist and blacklist of computing sites
        self.kData["whitelist"] = input.getWhitelist()
        self.kData["blacklist"] = input.getBlacklist()

        # populate job directory
        self.directoryTree()
        os.mkdir(self.kData["resultdir"])
        os.mkdir(self.kData["sharedir"])
        os.mkdir(self.kData["sharejobsdir"])

        # pack up necessary files for execution
        #self.pack(os.path.join(self.kData["sharedir"], self.kData["packfile"]))

        # copy input file
        shutil.copy(input.filename(), os.path.join(self.kData["sharedir"], self.kData["inputfile"]))

        # create outputfiles
        outputfiles = input.outputfiles()
        outputfiles.append("hipProofAnalysis.txt")
        #outputfiles = [os.path.join("workspace", x) for x in outputfiles]

        # create grid jobs
        se = input.storageElement()
        if se != "output":
            se += "/"+self.kData["id"]
        self.kData["storageElement"] = se
        self.kData["njobs"] = input.njobs()
        mode = input.getMode()
        dataset_names = input.getDatasetNames()

        data_ds_name = ""
        data_dir = ""
        if mode == "data":
            data_ds_name = dataset_names[0]
            ds_dir = input.getDatasetDirectory(data_ds_name)
            dir_re = re.compile("\.URLs")
            data_dir = dir_re.sub("-split.URLs", ds_dir)
            input.setDatasetDirectory(data_ds_name, data_dir)
        
        for i in range(0, self.kData["njobs"]):
            script_argv = []

            #if input.isScanTask():
            if mode == "scan":
                script_argv = [input.getScanParameter(), input.getScanValue(i)]

            #print "Job %d" % i
            #print "\n".join(input.filesForJob(i))

            jobdir = os.path.join(self.kData["sharejobsdir"], str(i))

            # Create per-job subdirectory
            os.mkdir(jobdir)

            # Create per-job dataURLs, if necessary
            # In every iteration this overwrites the directory name
            # thus appending -i every time... Better solution is needed,
            # altough this works. It is just a matter of convenience
            if mode == "data":
                os.mkdir(os.path.join(jobdir, "dataURLs"))
                ifname = os.path.join(jobdir, "dataURLs", data_dir)
                ifile = open(ifname, "w")
                ifile.write("\n".join(input.filesForJob(data_ds_name, i)))
                ifile.close()

            # Create per-job input file
            os.mkdir(os.path.join(jobdir, "workspace"))
            ifname = os.path.join(jobdir, "workspace", "analysis.in")
            ifile = open(ifname, "w")
            if mode == "dataset":
                ifile.write(input.contentForJob(i, [dataset_names[i]]))
            else:
                ifile.write(input.contentForJob(i))
            ifile.close()

            # Pack
            packfile = os.path.join(jobdir, self.kData["packfile"])
            self.pack(jobdir, packfile)
            
            #self.kJobs.append(Job(self.kMiddleware, i, self.kData["sharejobsdir"],
            #                          input.contentForJob(i), script_argv,
            #                          os.path.join(self.kData["sharedir"], self.kData["packfile"]),
            #                          outputfiles, se))
            self.kJobs.append(Job(self.kMiddleware, i, jobdir, script_argv,
                                  packfile, outputfiles, se,
                                  input.getNotify(), input.getEmail()))
            

    # Serialization methods
    def dump(self):
        f = open(os.path.join(self.kData["sharedir"], self.kData["taskfile"]), "w")
        pickle.dump(self.kData, f)
        f.close()

        f = open(os.path.join(self.kData["sharedir"], self.kData["jobfile"]), "w")
        pickle.dump(self.kJobs, f)
        f.close()

    def load(self, taskdir):
        if not os.access(taskdir, os.F_OK | os.R_OK | os.W_OK):
            print "Unable to access task directory", jobdir
            sys.exit(1)

        print "Loading task from", taskdir
        self.kData["taskdir"] = taskdir
        self.directoryTree()
        f = open(os.path.join(self.kData["sharedir"], self.kData["taskfile"]))
        self.kData = pickle.load(f)
        f.close

        # These must be reset after loading serialised objects
        self.kData["taskdir"] = taskdir
        self.directoryTree()
        f = open(os.path.join(self.kData["sharedir"], self.kData["jobfile"]))
        self.kJobs = pickle.load(f)
        f.close

        self.kMiddleware = middleware.init(self.kData["middleware"])

    # Grid functionality methods
    def proxyValid(self):
        return self.kMiddleware.proxyValid()

    def checkStatus(self, jobRange, wanted, action):
        faillist = []
        for i in jobRange:
            status = self.kJobs[i].getStatus()
            failed = True
            for w in wanted:
                if status == w:
                    failed = False
                    break
            
            if failed:
                faillist.append((i, status))

        if len(faillist) > 0:
            print "Following jobs have status other than %s, %s aborted" % (wanted, action)
            for x in faillist:
                print "%3d: %s" % x
            return False
        return True
            
    def submit(self, jobRange):
        if not self.checkStatus(jobRange, ["Created"], "submit"):
            return

        print "Submitting job(s) to grid"
        self.internalSubmit(jobRange)
        print "Submitted"

    def resubmit(self, jobRange):
        if not self.checkStatus(jobRange, ["Cleared", "Killed"], "resubmit"):
            return

        i=0
        backupdir = ""
        while True:
            backupdir = os.path.join(self.kData["resultdir"], "old-%d"%i)
            if not os.path.exists(backupdir):
                os.mkdir(backudir)
                break
            i += 1
        print "Copying output files to %s" % backupdir
        for i in jobRange:
            for file in glob(os.path.join(self.kData["resultdir"], "*-%d*"%i)):
                shutil.move(file, backupdir)

        print "Resubmitting job(s) to grid"
        self.internalSubmit(jobRange)
        print "Submitted"

    def internalSubmit(self, jobRange):
        joblist = [self.kJobs[i] for i in jobRange]
        desclist = [x.getJobDescription() for x in joblist]

        idlist = self.kMiddleware.submit(desclist, self.kData["whitelist"], self.kData["blacklist"])

        for i in range(0, len(joblist)):
            joblist[i].setJobId(idlist[i])
            
        
    def getoutput(self, jobRange):
        if not self.checkStatus(jobRange, ["Submitted"], "getoutput"):
            return
        
#        numlist = []
#        idlist = []
#        for i in jobRange:
#            numlist.append(self.kJobs[i].getJobNumber())
#            idlist.append(self.kJobs[i].getJobId())
        
        pwd = os.getcwd()
        os.chdir(self.kData["resultdir"])
        print "Saving results in directory", self.kData["resultdir"]

#        self.kMiddleware.getoutput2(idlist, numlist)
#        for i in jobRange:
#            self.kJobs[i].setStatus("Cleared")

        try:
            for i in jobRange:
                self.kMiddleware.getoutput(self.kJobs[i].getJobId(),
                                           self.kJobs[i].getJobNumber())
                #            self.kMiddleware.getoutput(idlist[i], numlist[i])
                self.kJobs[i].setStatus("Cleared")
        except middleware.MiddlewareError, e:
            print ""
            print "Error in transferring files (in the middleware layer):"
            print e
            print "It is (or should be) safe to issue -getoutput again"

        os.chdir(pwd)

    def status(self, jobRange):
        se = self.kData["storageElement"]
        if se == "output":
            print "Remember to fetch the output with -getoutput"
        else:
            print "Output is saved to %s" % se
        
        for i in jobRange:
            job = self.kJobs[i]
            stat = job.getStatus()
            stat_tuple = ()
            if stat == "Submitted":
                id = job.getJobId()
                stat_tuple = self.kMiddleware.status([id])[0]
                if stat_tuple[1] >= 0:
                    print "Job %3d, status: %s, exit code: %d (id: %s)" % (i, stat_tuple[0], stat_tuple[1], str(id))
                else:
                    print "Job %3d, status: %s (id: %s)" % (i, stat_tuple[0], id)
            else:
                print "Job %3d, status: %s" % (i, stat)

    def kill(self, jobRange):
        if not self.checkStatus(jobRange, ["Submitted"], "kill"):
            return
        
        idlist = [self.kJobs[i].getJobId() for i in jobRange]
        self.kMiddleware.kill(idlist)
        for i in jobRange:
            self.kJobs[i].setStatus("Killed")

    def clean(self):
        if not self.checkStatus(range(0, self.kData["njobs"]), ["Created", "Cleared", "Killed"], "clean"):
            return

        print "Removing task directory %s" % self.kData["taskdir"]
        shutil.rmtree(self.kData["taskdir"])

class Job:
#    def __init__(self, middleware, jobNumber, jobRootDir, inputcontent,
#                 script_arguments, packagefile, outputfiles, storageElement):
    def __init__(self, middleware, jobNumber, jobDir, script_arguments,
                 packagefile, outputfiles, storageElement, notify="", email=""):
        self.kJobNumber = jobNumber
        self.kJobDir = jobDir
        self.kInputfiles = []
        self.kOutputfiles = []
        self.kJobId = None

        # Create job specific inputfile
        #ifname = os.path.join(self.kJobDir, "analysis.in")
        #ifile = open(ifname, "w")
        #ifile.write(inputcontent)
        #ifile.close()

        # Specify files to be sent to the grid
        self.kInputfiles.append(("hipga.sh", "../grid/hipga.sh"))
#        self.kInputfiles.append(("analysis.in", ifname))
#        self.kInputfiles.append(("package.tar.gz", packagefile))
        self.kInputfiles.append((os.path.basename(packagefile), packagefile))

        if storageElement == "output":
            storageElement = ""
            self.kOutputfiles = [(x, storageElement) for x in outputfiles]
        else:
            ext_re = re.compile("(\..*?$)")
            for file in outputfiles:
                name = ""
                if ext_re.search(file):
                    name = ext_re.sub("-%d\g<1>"%self.kJobNumber, file)
                else:
                    name = file+"-%d" % self.kJobNumber
                    
                self.kOutputfiles.append((file, storageElement+"/%s"%name))
            

        # create (middleware-specific) job description
        self.kJobDescription = middleware.create(jobNumber, script_arguments,
                                                 self.kInputfiles, self.kOutputfiles,
                                                 notify, email)

        self.kStatus = "Created"
        
    def __str__(self):
        return "Number: %d\nDirectory: %s\nDescription: %s\n" % (self.kJobNumber, self.kJobDir, self.kJobDescription)

    def getJobDescription(self):
        return self.kJobDescription

    def setJobId(self, jobId):
        if self.kStatus != "Submitted":
            self.kJobId = jobId
            self.kStatus = "Submitted"
        else:
            raise Exception("Job is already submitted with ID: %s !" % str(self.kJobId))

    def getJobId(self):
        return self.kJobId

    def getJobNumber(self):
        return self.kJobNumber

    def getStatus(self):
        return self.kStatus

    def setStatus(self, status):
        self.kStatus = status
