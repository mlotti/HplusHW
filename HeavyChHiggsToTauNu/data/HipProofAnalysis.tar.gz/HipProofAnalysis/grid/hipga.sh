#!/bin/bash

#set -e
ulimit -s 10240 # limit to stack to 10M

echo "Untar package"
tar zxvf package.tar.gz
#tar xvf package.tar
#mkdir workspace
#cp analysis.in workspace 
echo "Set environment"
cd workspace

# This is only related to the scan task
if [ "x$#" == "x2" ]; then
    export HIPGRIDANALYSIS=1
fi

export INPUTFILE=analysis.in
export LS_SUBCWD=$PWD # this is necessary step!
export LD_LIBRARY_PATH=$LS_SUBCWD/../libs:$LS_SUBCWD/../tmva/TMVA/lib:$LD_LIBRARY_PATH

echo "Environment"
env
echo ""


echo ""
echo "Configuration"
echo ""

cat $INPUTFILE

echo ""
echo "Execute"
echo ""

../bin/analysis.exe

FILE=hipProofAnalysis.txt
if [ "x$#" == "x2" ]; then
    echo "Appending scan parameters to $FILE"
    echo "scanParameter = $1" >> $FILE
    echo "scanValue     = $2" >> $FILE
fi

# copy everything to parent for output retrieval/saving
cp * ..

echo ""
echo "Done"
echo ""

